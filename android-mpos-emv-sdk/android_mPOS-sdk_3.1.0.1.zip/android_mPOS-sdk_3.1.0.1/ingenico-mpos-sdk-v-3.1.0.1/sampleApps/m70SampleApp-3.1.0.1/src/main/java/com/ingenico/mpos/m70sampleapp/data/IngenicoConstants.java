package com.ingenico.mpos.m70sampleapp.data;

import com.roam.roamreaderunifiedapi.constants.DeviceType;

public class IngenicoConstants {
    public final static String URL = "https://uatmcm.roamdata.com";
    public final static DeviceType DEVICETYPE_RP45USB = DeviceType.RP45USB;

}
