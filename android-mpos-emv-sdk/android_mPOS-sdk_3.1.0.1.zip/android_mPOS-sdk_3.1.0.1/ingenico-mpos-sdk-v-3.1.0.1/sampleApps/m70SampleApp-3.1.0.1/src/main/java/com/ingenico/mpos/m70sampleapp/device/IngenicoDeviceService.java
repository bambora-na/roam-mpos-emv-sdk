package com.ingenico.mpos.m70sampleapp.device;

import android.app.Service;
import android.content.Intent;
import android.hardware.usb.UsbDevice;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

import com.ingenico.mpos.sdk.Ingenico;
import com.ingenico.mpos.sdk.callbacks.CheckDeviceSetupCallback;
import com.ingenico.mpos.sdk.callbacks.CheckFirmwareUpdateCallback;
import com.ingenico.mpos.sdk.callbacks.DeviceSetupWithProgressCallback;
import com.ingenico.mpos.sdk.callbacks.UpdateFirmwareCallback;
import com.ingenico.mpos.sdk.constants.FirmwareUpdateAction;
import com.ingenico.mpos.sdk.data.FirmwareInfo;
import com.roam.roamreaderunifiedapi.callback.DeviceStatusHandler;
import com.roam.roamreaderunifiedapi.callback.ReleaseHandler;
import com.roam.roamreaderunifiedapi.data.Device;
import com.ingenico.mpos.m70sampleapp.data.IngenicoConstants;
import com.ingenico.mpos.m70sampleapp.util.IngenicoDeviceHelper;

public class IngenicoDeviceService extends Service {
    private static final String TAG = IngenicoDeviceService.class.getSimpleName();
    private final IBinder mIBinder = new ServiceBinder();
    private boolean mAutoDiscoveryIsInProgress;
    private boolean mConnectingToDevice;

    private SetupCallbackState mState = new SetupCallbackState();
    private IngenicoSetupCallback mRegisteredSetupCallback;

    private final IngenicoUsbDeviceAttachmentMonitor.Listener mUsbDeviceAttachmentListener =
            new IngenicoUsbDeviceAttachmentMonitor.Listener() {
                @Override
                public void attached(UsbDevice usbDevice, boolean sticky) {
                    if (!Ingenico.getInstance().device().connected()) {
                        stopAutoDiscovery();
                        connect(usbDevice);
                    }
                }

                @Override
                public void detached(UsbDevice usbDevice) {

                }
            };

    private final DeviceStatusHandler mInternalDeviceStatusHandler =
            new DeviceStatusHandler() {
                @Override
                public void onConnected() {
                    Log.i(TAG, "onConnected");
                    mConnectingToDevice = false;
                }

                @Override
                public void onDisconnected() {
                    Log.i(TAG, "onDisconnected");
                    mConnectingToDevice = false;
                    startAutoDiscovery();
                }

                @Override
                public void onError(String s) {
                    Log.i(TAG, "onError");
                    mConnectingToDevice = false;
                    startAutoDiscovery();
                }
            };

    public IngenicoDeviceService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mIBinder;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i(TAG, "*** Starting IngenicoDeviceService Service ***");
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Ingenico.getInstance().device().unregisterConnectionStatusUpdates(
                mInternalDeviceStatusHandler);
        Ingenico.getInstance().release();
        Log.i(TAG, "*** Stopping IngenicoDeviceService Service ***");
    }

    // Actions

    /**
     * Returns if the device is connected or not
     * @return
     */
    public boolean isConnected() {
        return Ingenico.getInstance().device().connected();
    }

    /**
     * Detects attached USB device and attempts to connect to it, if the attached device is an Ingenico device
     */
    public void detectAndConnect() {
        Ingenico.getInstance().device().registerConnectionStatusUpdates(
                mInternalDeviceStatusHandler
        );
        mConnectingToDevice = false;
        startAutoDiscovery();
    }

    /**
     * Register device status handler to receive device status updates. Can register any number of handlers.
     * @param handler
     */
    public void registerStatusHandler(DeviceStatusHandler handler) {
        if (handler == null) {
            throw new IllegalArgumentException("invalid handler");
        }
        Log.i(TAG, "Registering DeviceStatusHandler");
        Ingenico.getInstance().device().registerConnectionStatusUpdates(handler);
    }

    /**
     * Register device status handler to stop receiving device status updates
     * @param handler
     */
    public void unregisterStatusHandler(DeviceStatusHandler handler) {
        Log.i(TAG, "Unregistering DeviceStatusHandler");
        Ingenico.getInstance().device().unregisterConnectionStatusUpdates(handler);
    }

    /**
     * Register to receive firmware update and device setup callbacks
     * @param setupCallback
     */
    synchronized public void registerSetupCallback(IngenicoSetupCallback setupCallback) {
        mRegisteredSetupCallback = setupCallback;
        postPendingData();
    }

    /**
     * Unregister from firmware update and device setup callbacks
     */
    synchronized public void unregisterSetupCallback() {
        mRegisteredSetupCallback = null;
    }

    public void isFirmwareUpdateRequired(IngenicoSetupCallback setupCallback) {
        if (!hasRegisteredSetupCallback()) {
            mRegisteredSetupCallback = setupCallback;
        }
        mState.setCommand(Command.CheckFirmwareUpdate);
        Ingenico.getInstance().device().checkFirmwareUpdate(new CheckFirmwareUpdateCallback() {
            @Override
            public void done(Integer responseCode, final FirmwareUpdateAction action, FirmwareInfo firmwareInfo) {
                if (hasRegisteredSetupCallback()) {
                    mRegisteredSetupCallback.checkFirmwareUpdateDone(responseCode, action, firmwareInfo);
                    mState.clearCheckFwUpdateResponse();
                } else {
                    mState.setCheckFwUpdateResponse(responseCode, action, firmwareInfo);
                }
            }
        });
    }

    public void updateFirmware() {
        mState.setCommand(Command.UpdateFirmware);
        Ingenico.getInstance().device().updateFirmware(new UpdateFirmwareCallback() {
            @Override
            public void downloadProgress(Long downloadedSize, Long totalFileSize) {
                if (hasRegisteredSetupCallback()) {
                    mRegisteredSetupCallback.downloadProgress(downloadedSize, totalFileSize);
                }
            }

            @Override
            public void updateProgress(Integer current, Integer total) {
                if (hasRegisteredSetupCallback()) {
                    mRegisteredSetupCallback.firmwareUpdateProgress(current, total);
                }
            }

            @Override
            public void done(Integer responseCode) {
                if (hasRegisteredSetupCallback()) {
                    mRegisteredSetupCallback.updateFirmwareDone(responseCode);
                    mState.clearUpdatFwResponse();
                } else {
                    mState.setUpdateFwResponse(responseCode);
                }
            }
        });
    }

    public void isSetupRequired() {
        mState.setCommand(Command.CheckDeviceSetup);
        Ingenico.getInstance().device().checkDeviceSetup(new CheckDeviceSetupCallback() {
            @Override
            public void done(Integer responseCode, Boolean isSetupRequired) {
                if (hasRegisteredSetupCallback()) {
                    mRegisteredSetupCallback.checkDeviceSetupDone(responseCode, isSetupRequired);
                    mState.clearCheckSetupResponse();
                } else {
                    mState.setCheckSetupResponse(responseCode, isSetupRequired);
                }
            }
        });
    }

    public void setupDevice() {
        mState.setCommand(Command.SetupDevice);
        Ingenico.getInstance().device().setup(
            new DeviceSetupWithProgressCallback() {
                @Override
                public void done(Integer responseCode) {
                   if (hasRegisteredSetupCallback()) {
                       mRegisteredSetupCallback.setupDone(responseCode);
                       mState.clearSetupResponse();
                       mRegisteredSetupCallback = null;
                   } else {
                       mState.setSetupResponse(responseCode);
                   }
                }

                @Override
                public void setupProgress(int cur, int total) {
                    if (hasRegisteredSetupCallback()) {
                        mRegisteredSetupCallback.setupProgress(cur, total);
                    }
                }
            }
        );
    }

    // Helper methods

    private void connect(UsbDevice usbDevice) {
        final Device device = IngenicoDeviceHelper.createIngenicoUsbDevice(
                        IngenicoConstants.DEVICETYPE_RP45USB,
                        usbDevice);
        Log.i(TAG, "Connecting to::" + device.toString());
        if (Ingenico.getInstance().device().initialized()) {
            Ingenico.getInstance().device().release(
                    new ReleaseHandler() {
                        @Override
                        public void done() {
                            initializeDevice(device);
                        }
                    }
            );
        } else {
            initializeDevice(device);
        }
    }

    private void initializeDevice(Device device) {
        Ingenico.getInstance().device().setDeviceType(IngenicoConstants.DEVICETYPE_RP45USB);
        Ingenico.getInstance().device().select(device);
        Ingenico.getInstance().device().initialize(getApplicationContext());
        mConnectingToDevice = true;
    }

    private void startAutoDiscovery() {
        if (!mAutoDiscoveryIsInProgress && !mConnectingToDevice) {
            Log.i(TAG, "startAutoDiscovery");
            mAutoDiscoveryIsInProgress = true;
            IngenicoUsbDeviceAttachmentMonitor.getInstance().register(mUsbDeviceAttachmentListener);
            IngenicoUsbDeviceAttachmentMonitor.getInstance().start(getApplicationContext());
        }
    }

    private void stopAutoDiscovery() {
        Log.i(TAG, "stopAutoDiscovery");
        mAutoDiscoveryIsInProgress = false;
        IngenicoUsbDeviceAttachmentMonitor.getInstance().unregister(mUsbDeviceAttachmentListener);
        IngenicoUsbDeviceAttachmentMonitor.getInstance().stop();
    }

    synchronized private boolean hasRegisteredSetupCallback() {
        return mRegisteredSetupCallback != null;
    }

    public class ServiceBinder extends Binder {
        public IngenicoDeviceService getService() {
            return IngenicoDeviceService.this;
        }
    }

    private void postPendingData() {
        switch (mState.getCommand()) {
            case CheckFirmwareUpdate:
                if (mState.hasCheckFwUpdateResponse()) {
                    mRegisteredSetupCallback.checkFirmwareUpdateDone(mState.responseCode,
                            mState.action,
                            mState.firmwareInfo);
                    mState.clearCheckFwUpdateResponse();
                }
                break;
            case UpdateFirmware:
                if (mState.hasUpdateFwResponse()) {
                    mRegisteredSetupCallback.updateFirmwareDone(mState.responseCode);
                    mState.clearUpdatFwResponse();
                }
                break;
            case CheckDeviceSetup:
                if (mState.hasCheckSetupResponse()) {
                    mRegisteredSetupCallback.checkDeviceSetupDone(mState.responseCode, mState.isSetupRequired);
                    mState.clearCheckSetupResponse();
                }
                break;
            case SetupDevice:
                if (mState.hasSetupResponse()) {
                    mRegisteredSetupCallback.setupDone(mState.responseCode);
                    mState.clearSetupResponse();
                    mRegisteredSetupCallback = null;
                }
                break;
        }
    }

    private class SetupCallbackState {
        private int responseCode = -1;
        private FirmwareUpdateAction action;
        private FirmwareInfo firmwareInfo;
        private boolean isSetupRequired;
        private Command command = Command.None;
        private boolean hasCheckFwUpdateResponse;
        private boolean hasUpdateFwResponse;
        private boolean hasCheckSetupResponse;
        private boolean hasSetupResponse;

        synchronized void setCheckFwUpdateResponse(Integer responseCode, final FirmwareUpdateAction action, FirmwareInfo firmwareInfo) {
            this.responseCode = responseCode;
            this.action = action;
            this.firmwareInfo = firmwareInfo;
            hasCheckFwUpdateResponse = true;
        }

        synchronized boolean hasCheckFwUpdateResponse() {
            return hasCheckFwUpdateResponse;
        }

        synchronized void clearCheckFwUpdateResponse() {
            responseCode = -1;
            hasCheckFwUpdateResponse = false;
        }

        synchronized void setUpdateFwResponse(Integer responseCode) {
            this.responseCode = responseCode;
            hasUpdateFwResponse = true;
        }

        synchronized boolean hasUpdateFwResponse() {
            return hasUpdateFwResponse;
        }

        synchronized void clearUpdatFwResponse() {
            responseCode = -1;
            hasUpdateFwResponse = false;
        }

        synchronized void setCheckSetupResponse(Integer responseCode, Boolean isSetupRequired) {
            this.responseCode = responseCode;
            this.isSetupRequired = isSetupRequired;
            hasCheckSetupResponse = true;
        }

        synchronized boolean hasCheckSetupResponse() {
            return hasCheckSetupResponse;
        }

        synchronized void clearCheckSetupResponse() {
            responseCode = -1;
            hasCheckSetupResponse = false;
        }

        synchronized void setSetupResponse(Integer responseCode) {
            this.responseCode = responseCode;
            hasSetupResponse = true;
        }

        synchronized boolean hasSetupResponse() {
            return hasSetupResponse;
        }

        synchronized void clearSetupResponse() {
            responseCode = -1;
            hasSetupResponse = false;
        }

        public Command getCommand() {
            return command;
        }

        public void setCommand(Command command) {
            this.command = command;
        }
    }

    public interface IngenicoSetupCallback {
        public void checkFirmwareUpdateDone(Integer responseCode, final FirmwareUpdateAction action, FirmwareInfo firmwareInfo);
        public void downloadProgress(Long downloadedSize, Long totalFileSize);
        public void firmwareUpdateProgress(Integer current, Integer total);
        public void updateFirmwareDone(Integer responseCode);
        public void checkDeviceSetupDone(Integer responseCode, Boolean isSetupRequired);
        public void setupProgress(int cur, int total);
        public void setupDone(Integer responseCode);
    }

    private enum Command {
        CheckFirmwareUpdate,
        UpdateFirmware,
        CheckDeviceSetup,
        SetupDevice,
        None
    }
}
