package com.ingenico.mpos.m70sampleapp.device;

import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Binder;
import android.os.IBinder;
import android.util.Base64;
import android.util.Log;

import com.ingenico.mpos.m70sampleapp.R;
import com.ingenico.mpos.m70sampleapp.util.IngenicoMessageHelper;
import com.ingenico.mpos.sdk.Ingenico;
import com.ingenico.mpos.sdk.callbacks.ApplicationSelectionCallback;
import com.ingenico.mpos.sdk.callbacks.EmailReceiptCallback;
import com.ingenico.mpos.sdk.callbacks.TransactionCallback;
import com.ingenico.mpos.sdk.callbacks.UpdateTransactionCallback;
import com.ingenico.mpos.sdk.callbacks.UploadSignatureCallback;
import com.ingenico.mpos.sdk.data.CardholderInfo;
import com.ingenico.mpos.sdk.request.CreditSaleTransactionRequest;
import com.ingenico.mpos.sdk.response.TransactionResponse;
import com.roam.roamreaderunifiedapi.data.ApplicationIdentifier;

import java.io.ByteArrayOutputStream;
import java.util.List;

public class IngenicoPaymentService extends Service {
    public static final String TAG = IngenicoPaymentService.class.getSimpleName();

    private final IBinder mIBinder = new ServiceBinder();
    private PaymentCallbackState mState = new PaymentCallbackState();

    private IngenicoPaymentCallback mRegisteredPaymentCallback;

    private String mSignatureImage;

    public IngenicoPaymentService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mIBinder;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i(TAG, "*** Starting IngenicoPaymentService Service ***");
        mSignatureImage = getBase64EncodedString(
                BitmapFactory.decodeResource(
                        getResources(),
                        R.drawable.signature
                )
        );
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "*** Stopping IngenicoPaymentService Service ***");
    }

    // Actions
    synchronized public void registerPaymentCallback(IngenicoPaymentCallback paymentCallback) {
        mRegisteredPaymentCallback = paymentCallback;
        postPendingData();
    }

    synchronized public void unregisterPaymentCallback() {
        mRegisteredPaymentCallback = null;
    }

    public void processCreditSaleTransactionWithCardReader(CreditSaleTransactionRequest request, IngenicoPaymentCallback paymentCallback) {
        if (!hasRegisteredCallback()) {
            registerPaymentCallback(paymentCallback);
        }
        mState.setCommand(Command.ProcessTransaction);
        Ingenico.getInstance().payment().processCreditSaleTransactionWithCardReader(request, new TransactionCallback() {
            @Override
            public void updateProgress(Integer progressCode, String extraMessage) {
                if (hasRegisteredCallback()) {
                    Log.d(TAG, "update progress::" + IngenicoMessageHelper.getProgressMessage(progressCode));
                    mRegisteredPaymentCallback.transactionProgress(progressCode, extraMessage);
                }
            }

            @Override
            public void applicationSelection(List<ApplicationIdentifier> appList, ApplicationSelectionCallback applicationcallback) {
                if (hasRegisteredCallback()) {
                    mRegisteredPaymentCallback.applicationSelection(appList, applicationcallback);
                    mState.clearApplicationSelectionData();
                } else {
                    mState.setApplicationSelectionData(appList, applicationcallback);
                }
            }

            @Override
            public void done(Integer responseCode, TransactionResponse response) {
                if (hasRegisteredCallback()) {
                    mRegisteredPaymentCallback.transactionDone(responseCode, response);
                    mState.clearTxnResponseData();
                } else {
                    mState.seTxntResponseData(responseCode, response);
                }
            }
        });
    }

    public void uploadSignature(String transactionId) {
        mState.setCommand(Command.UploadSignature);
        Ingenico.getInstance().user().uploadSignature(transactionId, mSignatureImage,
                new UploadSignatureCallback() {
                    @Override
                    public void done(Integer responseCode) {
                        if (hasRegisteredCallback()) {
                            mRegisteredPaymentCallback.uploadSignatureDone(responseCode);
                            mState.clearUploadSignatureResponse();
                        } else {
                            mState.setUploadSignatureResponse(responseCode);
                        }
                    }
                });
    }

    public void updateTransaction(final String transactionId) {
        mState.setCommand(Command.UpdateTransaction);
        Ingenico.getInstance().user().updateTransaction(
                transactionId,
                new CardholderInfo(
                        "Ingenico",
                        "Droid",
                        "X",
                        "imsdummyemail@gmail.com",
                        "1234567890",
                        "280 Summer St",
                        "Lobby Level",
                        "Boston",
                        "MA",
                        "12345"),
                null,
                true,
                true,
                new UpdateTransactionCallback() {
                    @Override
                    public void done(Integer responseCode) {
                        if (hasRegisteredCallback()) {
                            mRegisteredPaymentCallback.updateTransactionDone(responseCode);
                            mState.clearUpdateTxnResponse();
                            mRegisteredPaymentCallback = null;
                        } else {
                            mState.setUpdateTxnResponse(responseCode);
                        }
                        Ingenico.getInstance().user().sendEmailReceipt(
                                null,
                                transactionId,
                                new EmailReceiptCallback() {
                                    @Override
                                    public void done(Integer responseCode) {

                                    }
                                }
                        );
                    }
                }
        );
    }

    synchronized private boolean hasRegisteredCallback() {
        return mRegisteredPaymentCallback != null;
    }

    private void postPendingData() {
        switch (mState.getCommand()) {
            case ProcessTransaction:
                if (mState.hasApplicationSelectionData()) {
                    mRegisteredPaymentCallback.applicationSelection(mState.mAppList, mState.mApplicationcallback);
                    mState.clearApplicationSelectionData();
                } else if (mState.hasTxnResponseData()) {
                    mRegisteredPaymentCallback.transactionDone(mState.mResponseCode, mState.mResponse);
                    mState.clearTxnResponseData();
                    mRegisteredPaymentCallback = null;
                }
                break;
            case UploadSignature:
                if (mState.hasUploadSignatureResponse()) {
                    mRegisteredPaymentCallback.uploadSignatureDone(mState.mResponseCode);
                    mState.clearUploadSignatureResponse();
                }
                break;
            case UpdateTransaction:
                if (mState.hasUpdateTxnResponse()) {
                    mRegisteredPaymentCallback.updateTransactionDone(mState.mResponseCode);
                    mState.clearUpdateTxnResponse();
                    mRegisteredPaymentCallback = null;
                }
                break;
            case None:
                break;
        }
    }

    private static String getBase64EncodedString(Bitmap image) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        image.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] b = baos.toByteArray();
        return Base64.encodeToString(b, Base64.NO_WRAP);
    }

    private class PaymentCallbackState {
        private Command mCommand = Command.None;
        private List<ApplicationIdentifier> mAppList;
        private ApplicationSelectionCallback mApplicationcallback;
        private int mResponseCode = -1;
        private TransactionResponse mResponse;
        private boolean hasApplicationSelectionData;
        private boolean hasTxnResponseData;
        private boolean hasUploadSignatureResponse;
        private boolean hasUpdateTxnResponse;

        synchronized void setApplicationSelectionData(List<ApplicationIdentifier> appList, ApplicationSelectionCallback applicationcallback) {
            mAppList = appList;
            mApplicationcallback = applicationcallback;
            hasApplicationSelectionData = true;
        }

        synchronized void clearApplicationSelectionData() {
            mResponseCode = -1;
            hasApplicationSelectionData = false;
        }

        synchronized public boolean hasApplicationSelectionData() {
            return hasApplicationSelectionData;
        }

        synchronized void seTxntResponseData(Integer responseCode, TransactionResponse response) {
            mResponseCode = responseCode;
            mResponse = response;
            hasTxnResponseData = true;
            // response data takes precedence over other flags so setting them to false
            hasApplicationSelectionData = false;
        }

        synchronized void clearTxnResponseData() {
            mResponseCode = -1;
            hasTxnResponseData = false;
        }

        synchronized public boolean hasTxnResponseData() {
            return hasTxnResponseData;
        }

        synchronized void setUploadSignatureResponse(Integer responseCode) {
            mResponseCode = responseCode;
            hasUploadSignatureResponse = true;
        }

        synchronized void clearUploadSignatureResponse() {
            mResponseCode = -1;
            hasUploadSignatureResponse = false;
        }

        synchronized boolean hasUploadSignatureResponse() {
            return hasUploadSignatureResponse;
        }

        synchronized void setUpdateTxnResponse(Integer responseCode) {
            mResponseCode = responseCode;
            hasUpdateTxnResponse = true;
        }

        synchronized void clearUpdateTxnResponse() {
            mResponseCode = -1;
            hasUpdateTxnResponse = false;
        }

        synchronized boolean hasUpdateTxnResponse() {
            return hasUpdateTxnResponse;
        }

        public Command getCommand() {
            return mCommand;
        }

        public void setCommand(Command mCommand) {
            this.mCommand = mCommand;
        }
    }

    public class ServiceBinder extends Binder {
        public IngenicoPaymentService getService() {
            return IngenicoPaymentService.this;
        }
    }

    public interface IngenicoPaymentCallback {
        public void transactionProgress(Integer progressCode, String extraMessage);
        public void applicationSelection(List<ApplicationIdentifier> appList, ApplicationSelectionCallback applicationcallback);
        public void transactionDone(Integer responseCode, TransactionResponse response);
        public void uploadSignatureDone(Integer responseCode);
        public void updateTransactionDone(Integer responseCode);
    }

    private enum Command {
        ProcessTransaction,
        UploadSignature,
        UpdateTransaction,
        None
    }
}
