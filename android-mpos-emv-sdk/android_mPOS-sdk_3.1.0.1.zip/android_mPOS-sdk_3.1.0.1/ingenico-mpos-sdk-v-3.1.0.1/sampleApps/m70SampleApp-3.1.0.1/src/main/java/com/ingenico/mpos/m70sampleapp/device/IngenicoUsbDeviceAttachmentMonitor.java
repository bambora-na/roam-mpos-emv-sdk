package com.ingenico.mpos.m70sampleapp.device;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.os.Handler;
import android.os.Looper;

import com.ingenico.mpos.sdk.utils.Runner;
import com.ingenico.mpos.m70sampleapp.util.IngenicoDeviceHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class IngenicoUsbDeviceAttachmentMonitor {
    private static final IngenicoUsbDeviceAttachmentMonitor
            sInstance = new IngenicoUsbDeviceAttachmentMonitor();
    private final List<Listener> mListenerList = new ArrayList<>();
    private UsbManager mUsbManager;
    private Context applicationContext;
    private UsbDevice lastAttachedUsbDevice;
    private boolean postCallbacksOnUiThread;
    private boolean isReceiverRegistered;

    private final BroadcastReceiver mUsbDetachReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(action)) {
                UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                if (IngenicoDeviceHelper.isIngenicoDevice(device)) {
                    postDetachedEvent(device);
                    lastAttachedUsbDevice = null;
                }
            }
        }
    };

    private final BroadcastReceiver mUsbAttachReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(action)) {
                UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                if (IngenicoDeviceHelper.isIngenicoDevice(device)) {
                    lastAttachedUsbDevice = device;
                    postAttachedEvent(device, false);
                }
            }
        }
    };

    private IngenicoUsbDeviceAttachmentMonitor() {
    }

    public static IngenicoUsbDeviceAttachmentMonitor getInstance() {
        return sInstance;
    }

    public void setPostCallbacksOnUiThread(boolean onUiThread) {
        this.postCallbacksOnUiThread = onUiThread;
    }

    public void start(Context context) {
        applicationContext = context.getApplicationContext();
        mUsbManager = (UsbManager) applicationContext.getSystemService(Context.USB_SERVICE);
        IntentFilter filter = new IntentFilter(UsbManager.ACTION_USB_DEVICE_ATTACHED);
        applicationContext.registerReceiver(mUsbAttachReceiver, filter);
        filter = new IntentFilter(UsbManager.ACTION_USB_DEVICE_DETACHED);
        applicationContext.registerReceiver(mUsbDetachReceiver, filter);
        isReceiverRegistered = true;
        Runner.getInstance().run(
                new Runnable() {
                    @Override
                    public void run() {
                        getAttachedUsbDevices();
                    }
                }
        );
    }

    public void stop() {
        if (null != applicationContext && isReceiverRegistered) {
            applicationContext.unregisterReceiver(mUsbDetachReceiver);
            applicationContext.unregisterReceiver(mUsbAttachReceiver);
            isReceiverRegistered = false;
        }
        applicationContext = null;
        lastAttachedUsbDevice = null;
    }


    public void register(Listener listener) {
        if (null != listener) {
            if (!mListenerList.contains(listener)) {
                mListenerList.add(listener);
            }
            if (null != lastAttachedUsbDevice) {
                listener.attached(lastAttachedUsbDevice, true);
            }
        }
    }

    public void unregister(Listener listener) {
        if (mListenerList.contains(listener)) {
            mListenerList.remove(listener);
        }
    }

    private void getAttachedUsbDevices() {
        HashMap<String, UsbDevice> deviceList = mUsbManager.getDeviceList();
        for (UsbDevice device : deviceList.values()) {
            if (IngenicoDeviceHelper.isIngenicoDevice(device)) {
                lastAttachedUsbDevice = device;
                postAttachedEvent(device, true);
            }
        }
    }

    private void postDetachedEvent(final UsbDevice device) {
        for (final Listener listener : mListenerList) {
            if (!postCallbacksOnUiThread) {
                listener.detached(device);
            } else {
                final Handler handler = new Handler(Looper.getMainLooper());
                final Runnable work = new Runnable() {
                    @Override
                    public void run() {
                        listener.detached(device);
                    }
                };
                handler.post(work);
            }
        }
    }

    private void postAttachedEvent(final UsbDevice device, final boolean sticky) {
        for (final Listener listener : mListenerList) {
            if (!postCallbacksOnUiThread) {
                listener.attached(device, sticky);
            } else {
                final Handler handler = new Handler(Looper.getMainLooper());
                final Runnable work = new Runnable() {
                    @Override
                    public void run() {
                        listener.attached(device, sticky);
                    }
                };
                handler.post(work);
            }
        }
    }

    public interface Listener {
        void attached(UsbDevice usbDevice, boolean sticky);

        void detached(UsbDevice usbDevice);
    }
}
