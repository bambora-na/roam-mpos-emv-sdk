package com.ingenico.mpos.m70sampleapp.ui;

import android.app.ProgressDialog;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.text.TextUtils;

public class BaseActivity extends AppCompatActivity {
    private static final String SAVEKEY_PROGRESS_MESSAGE = "SAVEKEY_PROGRESS_MESSAGE";

    private ProgressDialog mProgressDialog;
    private String mCurrentProgressMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mProgressDialog = new ProgressDialog(this);
        if (savedInstanceState != null) {
            String progressMessage = savedInstanceState.getString(SAVEKEY_PROGRESS_MESSAGE, null);
            if (null != progressMessage) {
                onLoadingStart(progressMessage);
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        onLoadingFinish();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (null != mProgressDialog && mProgressDialog.isShowing()) {
            outState.putString(SAVEKEY_PROGRESS_MESSAGE, mCurrentProgressMessage);
        }
    }

    public void onLoadingStart(String msg) {
        mCurrentProgressMessage = TextUtils.isEmpty(msg) ? "Processing.." : msg;
        if (mProgressDialog != null && mProgressDialog.isShowing()) {
            mProgressDialog.setMessage(mCurrentProgressMessage);
        } else {
            mProgressDialog = ProgressDialog.show(this, null, mCurrentProgressMessage, true, false);
        }
    }

    public void onLoadingFinish() {
        if (mProgressDialog != null && mProgressDialog.isShowing()) {
            mProgressDialog.dismiss();
        }
    }

}
