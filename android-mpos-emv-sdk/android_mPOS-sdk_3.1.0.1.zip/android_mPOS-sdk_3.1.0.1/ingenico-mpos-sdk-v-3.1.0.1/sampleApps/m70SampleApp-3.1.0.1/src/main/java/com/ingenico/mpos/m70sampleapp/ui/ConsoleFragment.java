package com.ingenico.mpos.m70sampleapp.ui;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ScrollView;

import com.ingenico.mpos.m70sampleapp.R;
import com.ingenico.mpos.m70sampleapp.logger.LogView;
import com.ingenico.mpos.m70sampleapp.util.UiHelper;

import java.io.File;
import java.util.ArrayList;

public class ConsoleFragment extends Fragment {
    private static final String SAVEKEY_LOG_TEXT = "SAVEKEY_LOG_TEXT";
    private static final String SEPARATOR = "\n\t*--*--*\t";

    private ScrollView mConsoleScrollView;
    private LogView mConsoleView;

    public ConsoleFragment() {
        // Required empty public constructor
    }

    public static ConsoleFragment newInstance() {
        return new ConsoleFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_console, container, false);
        mConsoleScrollView = (ScrollView) v.findViewById(R.id.sv_console);

        mConsoleView = (LogView) v.findViewById(R.id.tv_console);
        Button clearBtn = (Button) v.findViewById(R.id.btn_clear);
        Button emailBtn = (Button) v.findViewById(R.id.btn_email);

        mConsoleScrollView.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    mConsoleScrollView.fullScroll(View.FOCUS_DOWN);
                }
            }
        });
        clearBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearConsole();
            }
        });
        emailBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendEmail();
            }
        });
        if (savedInstanceState != null) {
             mConsoleView.appendToLog(savedInstanceState.getString(SAVEKEY_LOG_TEXT));
        }
        return v;
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(SAVEKEY_LOG_TEXT, mConsoleView.getText().toString());
    }

    public LogView getLogView() {
        return mConsoleView;
    }

    private void clearConsole() {
        mConsoleView.setText("");
        mConsoleScrollView.fullScroll(View.FOCUS_DOWN);
        UiHelper.clearLogcat(getActivity());
    }

    private void sendEmail() {
        new SendEmailTask(getContext()).executeTask();
    }

    public class SendEmailTask extends AsyncTask<Void, Void, Intent> {
        final Context context;
        final String log = mConsoleView.getText().toString();

        public SendEmailTask(Context context) {
            this.context = context;
        }

        @Override
        protected Intent doInBackground(Void... params) {
            Intent emailIntent = new Intent(Intent.ACTION_SEND_MULTIPLE);
            emailIntent.setType("text/plain");
            emailIntent.putExtra(Intent.EXTRA_SUBJECT,
                    getContext().getString(R.string.app_name) + " Log " + UiHelper.getTimeStamp());
            emailIntent.putExtra(Intent.EXTRA_TEXT, UiHelper.getAboutInfo(context) + SEPARATOR + log);
            String logFilePath = UiHelper.captureLogcat(context);
            ArrayList<Uri> uris = new ArrayList<>();
            if (logFilePath != null) {
                File file = new File(logFilePath);
                if (file.exists() || file.canRead()) {
                    uris.add(Uri.parse("file://" + file));
                }
            }
            emailIntent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
            return uris.isEmpty() ? null : emailIntent;
        }

        @Override
        protected void onPostExecute(Intent result) {
            context.startActivity(Intent.createChooser(result, "Email Log"));
        }

        @TargetApi(Build.VERSION_CODES.HONEYCOMB)
        public void executeTask() {
            if (Build.VERSION_CODES.HONEYCOMB <= Build.VERSION.SDK_INT) {
                executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
            } else {
                execute();
            }
        }
    }
}
