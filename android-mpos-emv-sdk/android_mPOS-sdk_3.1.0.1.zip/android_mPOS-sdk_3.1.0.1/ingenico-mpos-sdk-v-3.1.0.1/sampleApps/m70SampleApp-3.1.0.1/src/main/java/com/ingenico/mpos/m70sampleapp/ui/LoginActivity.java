/*
 * //////////////////////////////////////////////////////////////////////////////
 * //
 * // Copyright (c) 2015 - 2018. All Rights Reserved, Ingenico Inc.
 * //
 * //////////////////////////////////////////////////////////////////////////////
 */

package com.ingenico.mpos.m70sampleapp.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.ingenico.mpos.m70sampleapp.BuildConfig;
import com.ingenico.mpos.m70sampleapp.R;
import com.ingenico.mpos.m70sampleapp.data.IngenicoConstants;
import com.ingenico.mpos.m70sampleapp.util.PrefHelper;
import com.ingenico.mpos.m70sampleapp.util.UiHelper;
import com.ingenico.mpos.sdk.Ingenico;
import com.ingenico.mpos.sdk.callbacks.LoginCallback;
import com.ingenico.mpos.sdk.constants.ResponseCode;
import com.ingenico.mpos.sdk.data.UserProfile;

public class LoginActivity extends BaseActivity {
    private static final String CLIENT_VERSION = "1.0";
    private final Ingenico mIngenicoInstance = Ingenico.getInstance();

    // UI references.
    private EditText mHostnameView;
    private EditText mUsernameView;
    private EditText mPasswordView;

    private String mHostname;
    private String mUsername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        mUsername = PrefHelper.get(getApplicationContext(), PrefHelper.USER_NAME, "");
        mHostname = PrefHelper.get(getApplicationContext(), PrefHelper.HOST_NAME,
                IngenicoConstants.URL);

        mHostnameView = (EditText) findViewById(R.id.et_hostname);
        mHostnameView.setText(mHostname);

        mUsernameView = (EditText) findViewById(R.id.et_username);
        mUsernameView.setText(mUsername);

        mPasswordView = (EditText) findViewById(R.id.et_password);
        mPasswordView.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int id, KeyEvent keyEvent) {
                if (id == EditorInfo.IME_ACTION_DONE || id == EditorInfo.IME_NULL) {
                    attemptLogin();
                    return true;
                }
                return false;
            }
        });

        if (mUsername.isEmpty()) {
            mUsernameView.requestFocus();
        } else {
            mPasswordView.requestFocus();
        }

        Button loginBtn = (Button) findViewById(R.id.email_sign_in_button);
        loginBtn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                attemptLogin();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);
        menu.findItem(R.id.menu_logoff).setVisible(false);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_about:
                UiHelper.showAbout(this);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void initializeIngenicoSdk() {
        mHostname = mHostnameView.getText().toString();
        mUsername = mUsernameView.getText().toString();
        PrefHelper.set(this, PrefHelper.HOST_NAME, mHostname);
        PrefHelper.set(this, PrefHelper.USER_NAME, mUsername);
        if (UiHelper.isValidAPIKey(this, BuildConfig.API_KEY)) {
            mIngenicoInstance.initialize(this,
                    mHostname,
                    BuildConfig.API_KEY,
                    CLIENT_VERSION);
            mIngenicoInstance.setLogging(true);
        }
    }

    private void attemptLogin() {
        initializeIngenicoSdk();

        mUsernameView.setError(null);
        mPasswordView.setError(null);

        String password = mPasswordView.getText().toString();
        boolean cancel = false;
        View focusView = null;

        if (TextUtils.isEmpty(mUsername)) {
            mUsernameView.setError(getString(R.string.error_field_required));
            focusView = mUsernameView;
            cancel = true;
        }

        if (cancel) {
            focusView.requestFocus();
        } else {
            onLoadingStart("Logging in...");
            mIngenicoInstance.user().login(mUsername,
                    password,
                    new LoginCallback() {
                        @Override
                        public void done(Integer responseCode, UserProfile user) {
                            onLoadingFinish();
                            if (responseCode == ResponseCode.Success) {
                                Intent intent = new Intent();
                                intent.setClass(LoginActivity.this, PaymentActivity.class);
                                startActivity(intent);
                            } else {
                                Toast.makeText(LoginActivity.this, "Failed : " + responseCode, Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        }
    }
}

