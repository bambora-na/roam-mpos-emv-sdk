package com.ingenico.mpos.m70sampleapp.ui;

import android.Manifest;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.IBinder;
import androidx.fragment.app.DialogFragment;
import androidx.appcompat.app.AlertDialog;
import android.text.InputType;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.ingenico.mpos.m70sampleapp.R;
import com.ingenico.mpos.m70sampleapp.device.IngenicoDeviceService;
import com.ingenico.mpos.m70sampleapp.device.IngenicoPaymentService;
import com.ingenico.mpos.m70sampleapp.logger.Log;
import com.ingenico.mpos.m70sampleapp.logger.LogWrapper;
import com.ingenico.mpos.m70sampleapp.logger.MessageOnlyLogFilter;
import com.ingenico.mpos.m70sampleapp.util.IngenicoMessageHelper;
import com.ingenico.mpos.m70sampleapp.util.UiHelper;
import com.ingenico.mpos.sdk.Ingenico;
import com.ingenico.mpos.sdk.callbacks.ApplicationSelectionCallback;
import com.ingenico.mpos.sdk.callbacks.LogoffCallback;
import com.ingenico.mpos.sdk.constants.FirmwareUpdateAction;
import com.ingenico.mpos.sdk.constants.ResponseCode;
import com.ingenico.mpos.sdk.data.Amount;
import com.ingenico.mpos.sdk.data.FirmwareInfo;
import com.ingenico.mpos.sdk.data.Product;
import com.ingenico.mpos.sdk.request.CreditSaleTransactionRequest;
import com.ingenico.mpos.sdk.response.TransactionResponse;
import com.roam.roamreaderunifiedapi.callback.DeviceStatusHandler;
import com.roam.roamreaderunifiedapi.callback.ReleaseHandler;
import com.roam.roamreaderunifiedapi.data.ApplicationIdentifier;
import com.tbruyelle.rxpermissions2.RxPermissions;

import java.util.ArrayList;
import java.util.List;

public class PaymentActivity extends BaseActivity implements ApplicationSelectionDialog.Listener{
    private static final String SAVEKEY_RECREATED_ON_ORIENTATION_CHANGE = "SAVEKEY_RECREATED_ON_ORIENTATION_CHANGE";
    private static final String SAVEKEY_TRANSACTION_RESPONSE = "SAVEKEY_TRANSACTION_RESPONSE";
    public static final String DEVICE_SERVICE_BOUND = "com.ingenico.mpos.m70sampleapp.DEVICE_SERVICE_BOUND";
    public static final String PAYMENT_SERVICE_BOUND = "com.ingenico.mpos.m70sampleapp.PAYMENT_SERVICE_BOUND";
    private static final String TAG = PaymentActivity.class.getSimpleName();

    // UI References
    private TextView mStatusView;
    private Button mCreditSaleBtn;

    private boolean mDeviceServiceBound;
    private boolean mPaymentServiceBound;
    protected boolean mRecreatedOnOrientationChange;

    private ApplicationSelectionCallback applicationSelectionCallback;
    private DeviceStatusHandler mDeviceStatusHandler = new DeviceStatusHandlerImpl();
    private IngenicoPaymentCallbackImpl mPaymentCallback = new IngenicoPaymentCallbackImpl();
    private IngenicoSetupCallbackImpl mSetupCallback = new IngenicoSetupCallbackImpl();

    private IngenicoDeviceService mIngenicoDeviceService;
    private IngenicoPaymentService mIngenicoPaymentService;
    private final ServiceConnection mDeviceServiceConnection = new DeviceServiceConnection();
    private final ServiceConnection mPaymentServiceConnection = new PaymentServiceConnection();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        mStatusView = (TextView) findViewById(R.id.tv_status);
        mCreditSaleBtn = (Button) findViewById(R.id.btn_credit_sale);
        mCreditSaleBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAmountDialog();
            }
        });
        if (savedInstanceState != null) {
            mRecreatedOnOrientationChange = savedInstanceState.getBoolean(
                    SAVEKEY_RECREATED_ON_ORIENTATION_CHANGE);
            mPaymentCallback.transactionResponse = savedInstanceState.getParcelable(SAVEKEY_TRANSACTION_RESPONSE);
        }
        initConsoleView();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean(SAVEKEY_RECREATED_ON_ORIENTATION_CHANGE,
                ActivityInfo.CONFIG_ORIENTATION ==
                        (this.getChangingConfigurations()
                                & ActivityInfo.CONFIG_ORIENTATION));
        outState.putParcelable(SAVEKEY_TRANSACTION_RESPONSE, mPaymentCallback.transactionResponse);
    }

    @Override
    protected void onStart() {
        super.onStart();
        bindServices();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (null != mIngenicoDeviceService) {
            mIngenicoDeviceService.unregisterStatusHandler(mDeviceStatusHandler);
            mIngenicoDeviceService.unregisterSetupCallback();
        }
        if (null != mIngenicoPaymentService) {
            mIngenicoPaymentService.unregisterPaymentCallback();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mDeviceServiceBound) {
            unbindService(mDeviceServiceConnection);
            mDeviceServiceBound = false;
        }
        if (mPaymentServiceBound) {
            unbindService(mPaymentServiceConnection);
            mPaymentServiceBound = false;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_about:
                UiHelper.showAbout(this);
                return true;
            case R.id.menu_logoff:
                logoff();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void isSetupRequired() {
        if (mIngenicoDeviceService.isConnected()) {
            onLoadingStart("Checking if device setup is required");
            mIngenicoDeviceService.isSetupRequired();
        } else {
            UiHelper.showToast(PaymentActivity.this,"Device is not connected");
        }
    }

    private void processCreditSale(int total) {
        Amount saleAmount = new Amount(
                "USD",
                total,
                total,
                0,
                0,
                "ROAM Discount",
                0
        );

        CreditSaleTransactionRequest request = new CreditSaleTransactionRequest(saleAmount,
                getProductList(saleAmount), "1234",
                "42.355241", "-71.056863",
                null, "Note",
                "Mer01", Boolean.TRUE, null,
                "asdf-1234", false);

        mIngenicoPaymentService.processCreditSaleTransactionWithCardReader(request, mPaymentCallback);
    }

    public void logoff() {
        onLoadingStart("Logging off...");
        Ingenico.getInstance().user().logOff(new LogoffCallback() {
            @Override
            public void done(Integer responseCode) {
                onLoadingStart("Releasing resources...");
                Ingenico.getInstance().release(new ReleaseHandler() {
                    @Override
                    public void done() {
                        onLoadingFinish();
                        Intent intent = new Intent();
                        intent.setClass(PaymentActivity.this, LoginActivity.class);
                        startActivity(intent);
                    }
                });
            }
        });
    }

    private class IngenicoPaymentCallbackImpl implements IngenicoPaymentService.IngenicoPaymentCallback {
        TransactionResponse transactionResponse;

        @Override
        public void transactionProgress(Integer progressCode, String extraMessage) {
            String progressMsg = IngenicoMessageHelper.getProgressMessage(progressCode);
            onLoadingStart(progressMsg);
            Log.i(TAG, "updateProgress::" + progressMsg + "::" + extraMessage);
        }

        @Override
        public void applicationSelection(List<ApplicationIdentifier> list,
                ApplicationSelectionCallback applicationSelectionCallback) {
            showApplicationSelectionDialog(
                    list,
                    applicationSelectionCallback
            );
        }

        @Override
        public void transactionDone(Integer responseCode, TransactionResponse transactionResponse) {
            Log.i(TAG, "transactionDone::" + responseCode);
            if (responseCode == ResponseCode.Success) {
                UiHelper.showToast(PaymentActivity.this, "Success");
                this.transactionResponse = transactionResponse;

                onLoadingStart("Uploading Signature");
                mIngenicoPaymentService.uploadSignature(
                        transactionResponse.getTransactionId());
            } else {
                onLoadingFinish();
                UiHelper.showToast(PaymentActivity.this, "Failed : " + responseCode);
            }
            Log.i(TAG, transactionResponse != null ? transactionResponse.toString() : "");
        }

        @Override
        public void uploadSignatureDone(Integer responseCode) {
            Log.i(TAG, "uploadSignatureDone::" + responseCode);
            onLoadingStart("Updating Transaction");
            mIngenicoPaymentService.updateTransaction(transactionResponse.getTransactionId());
        }

        @Override
        public void updateTransactionDone(Integer responseCode) {
            Log.i(TAG, "updateTransactionDone::" + responseCode);
            onLoadingFinish();
        }
    }

    private class DeviceStatusHandlerImpl implements DeviceStatusHandler {
        @Override
        public void onConnected() {
            updateDeviceStatus("Connected");
            if (!mRecreatedOnOrientationChange) {
                onLoadingStart("Checking if firmware update is required");
                mIngenicoDeviceService.isFirmwareUpdateRequired(mSetupCallback);
            }
        }

        @Override
        public void onDisconnected() {
            updateDeviceStatus("Disconnected");
        }

        @Override
        public void onError(String s) {
            updateDeviceStatus("Error : " + s);
        }
    }

    private class IngenicoSetupCallbackImpl implements IngenicoDeviceService.IngenicoSetupCallback {
        @Override
        public void checkFirmwareUpdateDone(Integer responseCode,
                                            FirmwareUpdateAction action,
                                            FirmwareInfo firmwareInfo) {
            onLoadingFinish();
            if (responseCode == ResponseCode.Success) {
                Log.i(TAG, "Firmware update required::" + action.toString() + '\n' + firmwareInfo.toString());
                if (action == FirmwareUpdateAction.Required || action == FirmwareUpdateAction.Optional){
                    showFirmwareUpdateDialog(action);
                } else {
                    isSetupRequired();
                }
            } else {
                UiHelper.newDialog(PaymentActivity.this,
                        "Error",
                        "Check Firmware Update Complete failed with error " + responseCode).show();
            }
        }

        @Override
        public void downloadProgress(Long downloadedSize, Long totalFileSize) {
            onLoadingStart(String.format("Downloading firmware %d/%d bytes", downloadedSize, totalFileSize));
        }

        @Override
        public void firmwareUpdateProgress(Integer current, Integer total) {
            onLoadingStart(String.format("Updating firmware %d/%d", current, total));
        }

        @Override
        public void updateFirmwareDone(Integer responseCode) {
            onLoadingFinish();
            String title = "Firmware Update Complete";
            String msg;
            AlertDialog dialog;
            if (responseCode == ResponseCode.Success) {
                msg = "Firmware update successful";
                dialog = UiHelper.newDialog(PaymentActivity.this, title, msg);
                // No need to check for device setup because device will be rebooted when firmware update succeeds
                // and reconnection will trigger check for device setup
            } else {
                msg = "Firmware update failed with error " + responseCode;
                dialog = UiHelper.newDialog(PaymentActivity.this,
                        title,
                        msg,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                isSetupRequired();
                            }
                        });
            }
            Log.v(TAG, msg);
            dialog.show();
        }

        @Override
        public void checkDeviceSetupDone(Integer responseCode, Boolean isSetupRequired) {
            onLoadingFinish();
            if (responseCode == ResponseCode.Success) {
                if (isSetupRequired) {
                    Log.i(TAG, "Setup required");
                    AlertDialog.Builder builder = new AlertDialog.Builder(PaymentActivity.this)
                            .setTitle("Setup")
                            .setMessage("Setup Required")
                            .setPositiveButton("Setup", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    onLoadingStart("Setting up your card reader...");
                                    mIngenicoDeviceService.setupDevice();
                                }
                            })
                            .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.dismiss();
                                }
                            });
                    builder.create().show();
                } else {
                    Log.i(TAG, "Setup not required");
                    UiHelper.showToast(PaymentActivity.this, "Setup not required");
                }
            } else {
                UiHelper.newDialog(PaymentActivity.this,
                        "Error",
                        "Check device setup failed with " + responseCode).show();
            }
        }

        @Override
        public void setupProgress(int cur, int total) {
            onLoadingStart(String.format("Setting up your card reader %d/%d", cur, total));
        }

        @Override
        public void setupDone(Integer responseCode) {
            onLoadingFinish();
            Log.d(TAG, "DeviceSetupWithProgressCallback::done::" + responseCode);
            UiHelper.newDialog(
                    PaymentActivity.this,
                    "Setup Complete",
                    (responseCode == ResponseCode.Success) ? "Setup Success" : "Setup Failed with error " + responseCode
            ).show();
        }
    }

    @Override
    public void onApplicationSelected(ApplicationIdentifier applicationIdentifier) {
        this.applicationSelectionCallback.done(applicationIdentifier);
    }

    private void showFirmwareUpdateDialog(FirmwareUpdateAction action) {
        AlertDialog.Builder builder = new AlertDialog.Builder(PaymentActivity.this)
                .setTitle("Update Firmware")
                .setMessage("Update Firmware " + action.toString())
                .setPositiveButton("Update", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        onLoadingStart("Starting firmware update");
                        mIngenicoDeviceService.updateFirmware();
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if(action != FirmwareUpdateAction.Required) {
                            isSetupRequired();
                        }
                    }
                });
        builder.create().show();
    }

    private void showAmountDialog() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
        alertDialog.setTitle("Sale Amount");

        final EditText amount = new EditText(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        amount.setLayoutParams(lp);
        amount.setInputType(InputType.TYPE_CLASS_NUMBER);
        amount.setHint("Enter amount in cents");
        alertDialog.setView(amount);

        alertDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                try {
                    processCreditSale(Integer.parseInt(amount.getText().toString()));
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }
        });
        alertDialog.create().show();
    }

    private void showApplicationSelectionDialog(
            List<ApplicationIdentifier> applicationIdentifiers,
            ApplicationSelectionCallback applicationSelectionCallback) {
        this.applicationSelectionCallback = applicationSelectionCallback;
        DialogFragment dialogFragment = ApplicationSelectionDialog.newInstance(
                applicationIdentifiers);
        dialogFragment.show(getSupportFragmentManager(),
                ApplicationSelectionDialog.class.getSimpleName());
    }

    private List<Product> getProductList(Amount saleAmount) {
        List<Product> products = new ArrayList<>();
        products.add(
                new Product(
                        "Coffee Beans",
                        saleAmount.getSubtotal(),
                        "Ethiopian Coffee Whole Beans",
                        null,
                        1
                )
        );
        return products;
    }

    public void initConsoleView() {
        // Wraps Android's native log framework.
        LogWrapper logWrapper = new LogWrapper();
        // Using Log, front-end to the logging chain, emulates android.util.log method signatures.
        Log.setLogNode(logWrapper);

        // Filter strips out everything except the message text.
        MessageOnlyLogFilter msgFilter = new MessageOnlyLogFilter();
        logWrapper.setNext(msgFilter);

        // On screen logging via a fragment with a TextView.
        ConsoleFragment logFragment = (ConsoleFragment) getSupportFragmentManager()
                .findFragmentById(R.id.activity_main_log_fragment);
        msgFilter.setNext(logFragment.getLogView());
    }

    private class PaymentServiceConnection implements ServiceConnection {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            IngenicoPaymentService.ServiceBinder binder =
                    (IngenicoPaymentService.ServiceBinder) service;
            mIngenicoPaymentService = binder.getService();
            mIngenicoPaymentService.registerPaymentCallback(mPaymentCallback);
            mPaymentServiceBound = true;
            Intent broadcastIntent = new Intent(PAYMENT_SERVICE_BOUND);
            sendBroadcast(broadcastIntent);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.i(TAG, "Payment service disconnected");
            mPaymentServiceBound = false;
        }
    }

    private class DeviceServiceConnection implements ServiceConnection {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            IngenicoDeviceService.ServiceBinder binder =
                    (IngenicoDeviceService.ServiceBinder) iBinder;
            mIngenicoDeviceService = binder.getService();
            mIngenicoDeviceService.registerStatusHandler(mDeviceStatusHandler);
            mIngenicoDeviceService.registerSetupCallback(mSetupCallback);
            mDeviceServiceBound = true;
            Intent broadcastIntent = new Intent(DEVICE_SERVICE_BOUND);
            sendBroadcast(broadcastIntent);
            new RxPermissions(PaymentActivity.this)
                    .request(
                            Manifest.permission.RECORD_AUDIO,
                            Manifest.permission.MODIFY_AUDIO_SETTINGS,
                            Manifest.permission.BLUETOOTH,
                            Manifest.permission.BLUETOOTH_ADMIN,
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                    )
                    .subscribe(
                            granted -> {
                                if (granted) {
                                    mIngenicoDeviceService.detectAndConnect();
                                }
                            }
                    );
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            Log.i(TAG, "Device service disconnected");
            mDeviceServiceBound = false;
        }
    }

    private void bindServices() {
        if (!mDeviceServiceBound) {
            Intent intent = new Intent(this, IngenicoDeviceService.class);
            startService(intent);
            bindService(intent, mDeviceServiceConnection, BIND_AUTO_CREATE);
        } else {
            Log.i(TAG, "Already bound to device service, registering handler");
            mIngenicoDeviceService.registerStatusHandler(mDeviceStatusHandler);
        }
        if (!mPaymentServiceBound) {
            Intent intent = new Intent(this, IngenicoPaymentService.class);
            startService(intent);
            bindService(intent, mPaymentServiceConnection, BIND_AUTO_CREATE);
        }else {
            Log.i(TAG, "Already bound to payment service, registering handler");
            mIngenicoPaymentService.registerPaymentCallback(mPaymentCallback);
        }
    }

    private void updateDeviceStatus(String status) {
        UiHelper.showToast(PaymentActivity.this, status);
        mStatusView.setText(status);
    }
}
