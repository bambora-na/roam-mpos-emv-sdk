package com.ingenico.mpos.m70sampleapp.util;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.usb.UsbDevice;

import com.roam.roamreaderunifiedapi.constants.CommunicationType;
import com.roam.roamreaderunifiedapi.constants.DeviceType;
import com.roam.roamreaderunifiedapi.data.Device;

public class IngenicoDeviceHelper {

    /**
     * Create Ingenico Device using the attributes in provided UsbDevice and DeviceType
     */
    public static Device createIngenicoUsbDevice(DeviceType deviceType, UsbDevice usbDevice) {
        return new Device(
                deviceType,
                CommunicationType.Usb,
                usbDevice.getDeviceName(),
                usbDevice.getDeviceName()
        );
    }

    /**
     * Checks if the UsbDevice is a Ingenico Mobile card reader based on the vendorId
     *
     * @param usbDevice UsbDevice
     * @return true if the UsbDevice is a Ingenico Mobile card reader, false otherwise
     */
    public static boolean isIngenicoDevice(UsbDevice usbDevice) {
        return null != usbDevice && 9969 == usbDevice.getVendorId();
    }
    
    public static boolean hasRequiredPermissions(Context context) {
        return context.checkSelfPermission(Manifest.permission.BLUETOOTH) == PackageManager.PERMISSION_GRANTED &&
                context.checkSelfPermission(Manifest.permission.BLUETOOTH_ADMIN) == PackageManager.PERMISSION_GRANTED &&
                context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                context.checkSelfPermission(Manifest.permission.MODIFY_AUDIO_SETTINGS) == PackageManager.PERMISSION_GRANTED &&
                context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

}