package com.ingenico.mpos.m70sampleapp.util;

import com.ingenico.mpos.sdk.Ingenico;
import com.ingenico.mpos.sdk.constants.POSEntryMode;
import com.ingenico.mpos.sdk.constants.ProgressMessage;

import java.util.List;

public class IngenicoMessageHelper {
    public static String getProgressMessage(int progressMessage) {
        switch (progressMessage) {
            case ProgressMessage.ApplicationSelectionCompleted:
                return "Application Selection Completed";
            case ProgressMessage.ApplicationSelectionStarted:
                return "Application Selection Started";
            case ProgressMessage.CardInserted:
                return "Card Inserted";
            case ProgressMessage.CardHolderPressedCancelKey:
                return "Card Holder Pressed Cancel Key";
            case ProgressMessage.DeviceBusy:
                return "Device Busy";
            case ProgressMessage.ErrorReadingContactlessCard:
                return "Error Reading Contactless Card";
            case ProgressMessage.FirstPinEntryPrompt:
                return "First Pin Entry Prompt";
            case ProgressMessage.ICCErrorSwipeCard:
                return "ICC Error Swipe Card";
            case ProgressMessage.LastPinEntryPrompt:
                return "Last Pin Entry Prompt";
            case ProgressMessage.PinEntryFailed:
                return "Pin Entry Failed";
            case ProgressMessage.PinEntryInProgress:
                return "Pin Entry In Progress";
            case ProgressMessage.PinEntrySuccessful:
                return "Pin Entry Successful";
            case ProgressMessage.PleaseInsertCard: {
                List<POSEntryMode> posList = Ingenico.getInstance().device().allowedPOSEntryModes();
                if (posList.contains(POSEntryMode.ContactlessEMV) ||
                        posList.contains(POSEntryMode.ContactlessMSR)) {
                    if (posList.contains(POSEntryMode.ContactEMV)) {
                        return "Please insert/tap/swipe card";
                    } else {
                        return "Please tap or swipe card";
                    }
                } else {
                    return "Please insert or swipe card";
                }
            }
            case ProgressMessage.RetryPinEntryPrompt:
                return "Retry Pin Entry";
            case ProgressMessage.SwipeDetected:
                return "Swipe Detected";
            case ProgressMessage.SwipeErrorReswipeMagStripe:
                return "Swipe Error Re-swipe MagStripe";
            case ProgressMessage.TapDetected:
                return "Tap Detected";
            case ProgressMessage.UseContactInterfaceInsteadOfContactless:
                return "Use Contact Interface Instead Of Contactless";
            case ProgressMessage.WaitingforCardSwipe:
                return "Waiting for Card Swipe";
            case ProgressMessage.RecordingTransaction:
                return "Recording Transaction";
            case ProgressMessage.GettingOnlineAuthorization:
                return "Getting Payment Authorization";
            case ProgressMessage.GettingCardVerification:
                return "Getting Card Verification";
            case ProgressMessage.SendingReversal:
                return "Sending Reversal";
            case ProgressMessage.UpdatingTransaction:
                return "Updating Transaction";
            case ProgressMessage.RestartingContactlessInterface:
                return "Restarting Contactless Interface";
            case ProgressMessage.TryContactInterface:
                return "Try Contact Interface";
            case ProgressMessage.PleaseRemoveCard:
                return "Please Remove Card";
            case ProgressMessage.PleaseSeePhone:
                return "Please See Phone";
            case ProgressMessage.MultipleContactlessCardsDetected:
                return "Please Present One Card Only";
            case ProgressMessage.PresentCardAgain:
                return "Please Present Card Again";
            case ProgressMessage.CardRemoved:
                return "Card Removed";
            case ProgressMessage.ReinsertCard:
                return "Reinsert card properly";
            case ProgressMessage.RestartingTransactionDueToIncorrectPin:
                return "Restarting Transaction Due To Incorrect Pin";
        }
        return "Progress Message:" + progressMessage;
    }
}
