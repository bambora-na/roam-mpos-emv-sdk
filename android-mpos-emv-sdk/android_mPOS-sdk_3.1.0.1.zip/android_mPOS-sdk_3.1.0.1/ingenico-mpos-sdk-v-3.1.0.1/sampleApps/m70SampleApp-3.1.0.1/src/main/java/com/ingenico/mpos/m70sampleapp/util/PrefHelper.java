package com.ingenico.mpos.m70sampleapp.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.text.TextUtils;

import java.util.HashSet;
import java.util.Set;

public final class PrefHelper {

    public final static String USER_NAME = "USER_NAME";
    public final static String HOST_NAME = "HOST_NAME";
    public final static String API_KEY = "API_KEY";
    private final static String PREF_KEY_CONFIGURED_DEVICE_SIZE = "PREF_KEY_CONFIGURED_DEVICE_SIZE";
    private final static String PREF_KEY_SERIAL_NUMBER = "PREF_KEY_SERIAL_NUMBER_";

    public static Set<String> getConfiguredDevices(Context context) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        Set<String> configuredDevicesSerialNumbers = new HashSet<>();
        int size = sp.getInt(PREF_KEY_CONFIGURED_DEVICE_SIZE, 0);
        String serialNumber;
        for (int i = 0; i < size; i++) {
            serialNumber = sp.getString(PREF_KEY_SERIAL_NUMBER + i, null);
            if (!TextUtils.isEmpty(serialNumber)) {
                configuredDevicesSerialNumbers.add(serialNumber);
            }
        }
        return configuredDevicesSerialNumbers;
    }

    public static boolean setConfiguredDevices(
            Context context,
            Set<String> configuredDevicesSerialNumbers) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(PREF_KEY_CONFIGURED_DEVICE_SIZE, configuredDevicesSerialNumbers.size());
        int i = 0;
        for (String str : configuredDevicesSerialNumbers) {
            editor.remove(PREF_KEY_SERIAL_NUMBER + i);
            editor.putString(PREF_KEY_SERIAL_NUMBER + i, str);
            i++;
        }
        return editor.commit();
    }

    public static boolean clear(Context context) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = sp.edit();
        editor.clear();
        return editor.commit();
    }

    public static boolean contains(Context ctx, String preferenceName) {
        return PreferenceManager.getDefaultSharedPreferences(ctx).contains(preferenceName);
    }

    // setters
    public static void set(Context ctx, String preferenceName, boolean value) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(ctx);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(preferenceName, value);
        editor.commit();
    }

    public static void set(Context ctx, String preferenceName, String value) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(ctx);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(preferenceName, value);
        editor.commit();
    }

    public static void set(Context ctx, String preferenceName, long value) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(ctx);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putLong(preferenceName, value);
        editor.commit();
    }

    public static void remove(Context ctx, String preferenceName) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(ctx);
        SharedPreferences.Editor editor = prefs.edit();
        editor.remove(preferenceName);
        editor.commit();
    }

    public static void clearAllPrefs(Context ctx) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(ctx);
        SharedPreferences.Editor editor = prefs.edit();
        editor.clear();
        editor.commit();
    }

    // getters
    public static Boolean get(Context ctx, String preferenceName, boolean fallback) {
        return PreferenceManager.getDefaultSharedPreferences(ctx).getBoolean(
                preferenceName,
                fallback
        );
    }

    public static String get(Context ctx, String preferenceName, String fallback) {
        return PreferenceManager.getDefaultSharedPreferences(ctx).getString(
                preferenceName,
                fallback
        );
    }

    public static Long get(Context ctx, String preferenceName, long fallback) {
        return PreferenceManager.getDefaultSharedPreferences(ctx).getLong(
                preferenceName,
                fallback
        );
    }
}
