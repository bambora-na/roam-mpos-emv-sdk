package com.ingenico.mpos.m70sampleapp.util;


import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.appcompat.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.ingenico.mpos.m70sampleapp.R;
import com.ingenico.mpos.sdk.Ingenico;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class UiHelper {
    public static boolean isValidAPIKey(Context context, String apiKey) {
        if (apiKey == null ||
                apiKey.equals("Set your API key here")) {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("API Key Missing")
                    .setMessage("If you have an API Key, please set the API_KEY build config field in the build.gradle file."
                            + " If not, please contact apisupport.us@mIngenicoInstance.com to obtain a key.")
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                        }
                    }).show();
            return false;
        }
        return true;
    }

    public static void showToast(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }

    public static AlertDialog newDialog(Context context, String title, String msg) {
        return newDialog(context,
                title,
                msg,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
    }

    public static AlertDialog newDialog(Context context, String title, String msg, DialogInterface.OnClickListener positiveListener) {
        AlertDialog dialog;
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(title)
                .setMessage(msg)
                .setPositiveButton("OK", positiveListener);
        dialog = builder.create();
        return dialog;
    }

    public static String getTimeStamp() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        return "[" + format.format(new Date()) + "]";
    }

    public static void showAbout(Context context) {
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View messageView = layoutInflater.inflate(R.layout.dialog_about, null, false);


        TextView textView = messageView.findViewById(R.id.dialog_about_device_info);
        int defaultColor = textView.getTextColors().getDefaultColor();
        textView.setTextColor(defaultColor);
        textView.setText(getAboutInfo(context));

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setTitle(R.string.app_name);
        builder.setView(messageView);
        builder.create();
        builder.show();
    }

    public static String getAboutInfo(Context context) {
        StringBuilder buf = new StringBuilder();
        String appVersion = getAppVersion(context);
        if (appVersion != null) {
            buf.append("SAMPLE.APP.VERSION: ").append(appVersion);
        }
        buf.append("\nMPOS.SDK.VERSION: ").append(Ingenico.getInstance().getVersion());
        buf.append("\nVERSION.RELEASE :").append(Build.VERSION.RELEASE);
        buf.append("\nVERSION.SDK_INT :").append(Build.VERSION.SDK_INT);
        buf.append("\nVERSION.INCREMENTAL :").append(Build.VERSION.INCREMENTAL);
        buf.append("\nMANUFACTURER :").append(Build.MANUFACTURER);
        buf.append("\nMODEL :").append(Build.MODEL);
        buf.append("\nBRAND :").append(Build.BRAND);
        buf.append("\nCPU ARCH :").append(System.getProperty("os.arch"));

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            buf.append("\nCPU_ABI :").append(Build.CPU_ABI);
            buf.append("\nCPU_ABI2 :").append(Build.CPU_ABI2);
        } else {
            buf.append("\nSUPPORTED_ABIS:");
            for (String abi : Build.SUPPORTED_ABIS) {
                buf.append(abi).append(",");
            }
        }
        return buf.toString();
    }

    public static void clearLogcat(Context ctx) {
        try {
            Runtime.getRuntime().exec("logcat -c");
        } catch (IOException e) {
        }
    }

    public static String captureLogcat(Context ctx) {
        String fileName = ctx.getString(R.string.app_name);
        SimpleDateFormat s = new SimpleDateFormat("MMddyyyyhhmmss", Locale.getDefault());
        String currentDateandTime = s.format(new Date());
        String fname = "logcat_" + fileName + "_" + currentDateandTime + ".txt";
        File file = new File(ctx.getExternalFilesDir(null), fname);
        PrintWriter pw = null;
        FileOutputStream f = null;
        try {
            f = new FileOutputStream(file);
            pw = new PrintWriter(f);
            pw.append(readLogcat());
            pw.flush();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            if (null != pw) {
                pw.close();
            }
            if (null != f) {
                try {
                    f.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return file.getAbsolutePath();
    }

    private static StringBuilder readLogcat() {
        StringBuilder log = new StringBuilder();
        BufferedReader bufferedReader = null;
        try {
            Process process = Runtime.getRuntime().exec("logcat -v time -d");
            bufferedReader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                log.append(line);
                log.append("\r\n");
            }
        } catch (IOException e) {
        } finally {
            if (null != bufferedReader) {
                try {
                    bufferedReader.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
        }
        return (log);
    }

    private static String getAppVersion(Context context) {
        String appVersion = null;
        try {
            appVersion = context.getPackageManager().getPackageInfo(context.getPackageName(),
                    0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return appVersion;
    }
}
