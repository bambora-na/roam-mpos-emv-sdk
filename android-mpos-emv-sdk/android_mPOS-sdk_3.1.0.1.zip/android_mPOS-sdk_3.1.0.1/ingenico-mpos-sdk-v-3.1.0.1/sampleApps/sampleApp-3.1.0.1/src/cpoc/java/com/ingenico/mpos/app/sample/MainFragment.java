/*
 * //////////////////////////////////////////////////////////////////////////////
 * //
 * // Copyright (c) 2017 ROAM, Inc. All rights reserved.
 * //
 * //////////////////////////////////////////////////////////////////////////////
 */

package com.ingenico.mpos.app.sample;

import android.app.Activity;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class MainFragment extends FragmentBase implements View.OnClickListener {

    private OnFragmentInteractionListener mListener;

    public MainFragment() {
        // Required empty public constructor
    }

    public static MainFragment newInstance() {
        return new MainFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_main, container, false);
        view.findViewById(R.id.fragment_main_btn_payment_api).setOnClickListener(this);
        view.findViewById(R.id.fragment_main_btn_merchant_api).setOnClickListener(this);
        view.findViewById(R.id.fragment_main_btn_payment_device_api).setOnClickListener(this);
        view.findViewById(R.id.fragment_main_btn_store_and_forward).setOnClickListener(this);

        return view;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mListener = (OnFragmentInteractionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onStart() {
        super.onStart();
        mListener.onMainFragmentStarted();
    }

    @Override
    public void onStop() {
        super.onStop();
        mListener.onMainFragmentStopped();
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.fragment_main_btn_payment_api:
                mListener.onPaymentApiSelected();
                break;
            case R.id.fragment_main_btn_merchant_api:
                mListener.onMerchantApiSelected();
                break;
            case R.id.fragment_main_btn_payment_device_api:
                mListener.onPaymentDeviceApiSelected();
                break;
            case R.id.fragment_main_btn_store_and_forward:
                mListener.onStoreAndForwardApiSelected();
                break;
        }
    }

    public interface OnFragmentInteractionListener {
        void onPaymentApiSelected();

        void onMerchantApiSelected();

        void onMainFragmentStarted();

        void onMainFragmentStopped();

        void onPaymentDeviceApiSelected();

        void onStoreAndForwardApiSelected();
    }

    private void replaceContentFragment(Fragment fragment, boolean addToBackStack) {
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(
                R.id.activity_main_content,
                fragment
        );
        if (addToBackStack) {
            fragmentTransaction.addToBackStack(fragment.getClass().getSimpleName());
        }
        fragmentTransaction.commit();
    }

}
