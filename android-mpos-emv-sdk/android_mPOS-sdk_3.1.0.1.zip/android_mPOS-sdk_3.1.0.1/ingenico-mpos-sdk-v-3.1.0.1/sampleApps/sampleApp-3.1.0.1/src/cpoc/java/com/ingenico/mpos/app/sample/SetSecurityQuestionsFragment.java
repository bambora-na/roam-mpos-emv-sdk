package com.ingenico.mpos.app.sample;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import androidx.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.ingenico.mpos.app.sample.common.logger.Log;
import com.ingenico.mpos.sdk.Ingenico;
import com.ingenico.mpos.sdk.callbacks.GetSecurityQuestionsCallback;
import com.ingenico.mpos.sdk.callbacks.SetSecurityQuestionsCallback;
import com.ingenico.mpos.sdk.constants.ResponseCode;
import com.ingenico.mpos.sdk.data.SecurityQuestion;

import java.util.ArrayList;
import java.util.List;

public class SetSecurityQuestionsFragment extends FragmentBase {
    private static final String TAG = SetSecurityQuestionsFragment.class.getSimpleName();

    private OnFragmentInteractionListener mListener = new OnFragmentInteractionListener() {
        @Override
        public void onSecurityQuestionsAnswered() {

        }
    };
    private List<SecurityQuestion> mQuestions = new ArrayList<>();

    private Spinner spOne;
    private Spinner spTwo;
    private EditText etOne;
    private EditText etTwo;
    private Button btnSubmit;

    public SetSecurityQuestionsFragment() {
        // Required empty public constructor
    }

    public static SetSecurityQuestionsFragment newInstance() {
        SetSecurityQuestionsFragment fragment = new SetSecurityQuestionsFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
            ViewGroup container,
            Bundle savedInstanceState) {
        View view = getActivity().getLayoutInflater().inflate(
                R.layout.fragment_set_security_questions,
                null);
        spOne = (Spinner) view.findViewById(R.id.dialog_set_security_questions_sp_one);
        spTwo = (Spinner) view.findViewById(R.id.dialog_set_security_questions_sp_two);
        etOne = (EditText) view.findViewById(R.id.dialog_set_security_questions_et_one);
        etTwo = (EditText) view.findViewById(R.id.dialog_set_security_questions_et_two);
        btnSubmit = (Button) view.findViewById(
                R.id.dialog_set_security_questions_btn_submit);
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!etOne.getText().toString().isEmpty() &&
                        !etTwo.getText().toString().isEmpty()) {
                    List<SecurityQuestion> answers = new ArrayList<>();
                    answers.add(new SecurityQuestion(
                            mQuestions.get(spOne.getSelectedItemPosition()).getQuestionId(),
                            etOne.getText().toString()));
                    answers.add(new SecurityQuestion(
                            mQuestions.get(spTwo.getSelectedItemPosition()).getQuestionId(),
                            etTwo.getText().toString()));
                    Ingenico.getInstance().user().setSecurityQuestions(answers,
                            new SetSecurityQuestionsCallbackImpl());
                }
            }
        });

        mProgressDialogListener.showProgressMessage("Please wait");
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        Ingenico.getInstance().user().getSecurityQuestions(new GetSecurityQuestionsCallbackImpl());
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mListener = (OnFragmentInteractionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException("Calling fragment must implement ChangePasswordListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    private void populateSpinners() {
        if (!mQuestions.isEmpty()) {
            ArrayList<String> questions = new ArrayList();
            for (SecurityQuestion s : mQuestions) {
                questions.add(s.getQuestion());
            }

            ArrayAdapter<String> adapterOne = new CustomArrayAdapter(getActivity(),
                    android.R.layout.simple_spinner_item, questions);
            adapterOne.setDropDownViewResource(R.layout.list_item_security_question);
            spOne.setAdapter(adapterOne);
            spOne.setSelection(0);

            ArrayAdapter<String> adapterTwo = new CustomArrayAdapter(getActivity(),
                    android.R.layout.simple_spinner_item, questions);
            adapterTwo.setDropDownViewResource(R.layout.list_item_security_question);
            spTwo.setAdapter(adapterTwo);
            spTwo.setSelection(1);
        } else {
            Utils.newDialog(getActivity(), "Failed", "Unable to retrieve security questions");
        }
    }

    public interface OnFragmentInteractionListener {
        void onSecurityQuestionsAnswered();
    }

    private class GetSecurityQuestionsCallbackImpl implements GetSecurityQuestionsCallback {
        @Override
        public void done(Integer responseCode, List<SecurityQuestion> questions) {
            Log.v(TAG, "GetSecurityQuestionsCallback::done::" + responseCode);
            if (responseCode == ResponseCode.Success) {
                mQuestions = questions;
                populateSpinners();
                btnSubmit.setEnabled(true);
            } else {
                Utils.newDialog(getActivity(), "Failed", "Response code " + responseCode).show();
            }
            mProgressDialogListener.hideProgress();
        }
    }

    private class SetSecurityQuestionsCallbackImpl implements SetSecurityQuestionsCallback {
        @Override
        public void done(Integer responseCode) {
            Log.v(TAG, "SetSecurityQuestionsCallback::done::" + responseCode);
            mProgressDialogListener.hideProgress();
            if (ResponseCode.Success == responseCode) {
                showToast("Success");
            } else {
                showToast("Failed");
            }
            mListener.onSecurityQuestionsAnswered();
        }
    }

    class CustomArrayAdapter extends ArrayAdapter<String> {
        public CustomArrayAdapter(Context context,
                int resource,
                List<String> objects) {
            super(context, resource, objects);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View v = super.getView(position, convertView, parent);

            if (getCount() == position && null != v) {
                TextView tv = (TextView) v;
                tv.setText(null);
                tv.setHint(getItem(position));
            }

            return v;
        }
    }
}
