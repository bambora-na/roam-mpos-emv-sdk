package com.ingenico.mpos.app.sample;

import android.os.Bundle;

import com.ingenico.mpos.sdk.Ingenico;
import com.ingenico.mpos.sdk.data.Preference;
import com.ingenico.mpos.sdk.jni.NativeHelper;
import com.orhanobut.logger.AndroidLogAdapter;
import com.orhanobut.logger.FormatStrategy;
import com.orhanobut.logger.Logger;
import com.orhanobut.logger.PrettyFormatStrategy;
import com.roam.roamreaderunifiedapi.LoggerInterface;
import com.roam.roamreaderunifiedapi.constants.CommunicationType;

public class SetupFragment extends BaseSetupFragment {

    public SetupFragment() {
        // Required empty public constructor
    }

    public static SetupFragment newInstance(CommunicationType type, String apiKey,
            String hostname, int localeIndex) {
        SetupFragment fragment = new SetupFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_COMMUNICATION_TYPE_ORDINAL, type.ordinal());
        args.putString(ARG_HOST_NAME, hostname);
        args.putString(ARG_API_KEY, apiKey);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    void initializeSDK() {
        final Ingenico ingenico = Ingenico.getInstance();
        final String HTTPS = "https://";
        String hostname = mHostname != null && mHostname.contains(HTTPS) ? mHostname : HTTPS + mHostname;
        Preference.Builder prefBuilder = new Preference.Builder();
        prefBuilder.setMerchantLocale(IngenicoConstants.SUPPORTED_LOCALES.get(mLocaleIndex));
        if(mConfigMode != null){
            prefBuilder.setConfigMode(mConfigMode)
                    .setRetryCount(mRetryCount);
        }
        ingenico.setLogging(true);
        ingenico.sendDiagnostics(mSendDiagnostics);
        FormatStrategy formatStrategy = PrettyFormatStrategy.newBuilder()
                .showThreadInfo(false)
                .methodCount(0)
                .build();
        Logger.clearLogAdapters();
        Logger.addLogAdapter(new AndroidLogAdapter(formatStrategy));
        Ingenico.getInstance().setCustomLogger(new LoggerHelper());
        setupIngenicoSDK();
    }

    private class LoggerHelper implements LoggerInterface {

        @Override
        public void d(String tag, String message) {
            Logger.log(Logger.DEBUG, tag, message, null);
        }

        @Override
        public void e(String tag, String message) {
            Logger.log(Logger.ERROR, tag, message, null);
        }

        @Override
        public void i(String tag, String message) {
            Logger.log(Logger.INFO, tag, message, null);
        }
    }
}
