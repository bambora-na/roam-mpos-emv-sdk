/*
 * Copyright (c) 2015 - 2021. All Rights Reserved, Worldline SMB US Inc.
 */
package com.ingenico.mpos.app.sample.common;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.util.Base64;
import android.widget.Toast;

import com.ingenico.mobytap.reader.MobyTapReader;
import com.ingenico.mpos.app.sample.common.logger.Log;
import com.ingenico.mpos.sdk.Ingenico;
import com.ingenico.mpos.sdk.callbacks.ApplicationSelectionCallback;
import com.ingenico.mpos.sdk.callbacks.TransactionCallback;
import com.ingenico.mpos.sdk.data.Amount;
import com.ingenico.mpos.sdk.data.TokenRequestParameters;
import com.ingenico.mpos.sdk.request.CreditSaleTransactionRequest;
import com.ingenico.mpos.sdk.response.TransactionResponse;
import com.roam.roamreaderunifiedapi.data.ApplicationIdentifier;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Protocol;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.internal.Util;


public class CpocHelper {
    static final String TAG = "STICKSHIFT";

    public static void initCpoc(Activity activity) {
        MobyTapReader mobyTapReader = new MobyTapReader(activity);
        Ingenico.getInstance().device().initialize(activity.getApplicationContext(), mobyTapReader.getCommunicationAdapterInterface());
    }


    public static void doStickShiftTransaction(Intent intent, String sessionToken,
            String hostUrl, Context context) {
        try {
            JSONObject transaction =  new JSONObject(new String(
                    Base64.decode(intent.getStringExtra("transaction"), Base64.DEFAULT)));
            String responseUrl = intent.getStringExtra("responseUrl");
            doTransaction(transaction, sessionToken, hostUrl, responseUrl, context);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private static void doTransaction(JSONObject transaction, String sessionToken,
            String hostUrl, String responseUrl, Context context) throws JSONException {
        JSONObject jsonAmount = transaction.getJSONObject("amount");
        Amount amount = new Amount(
                jsonAmount.getString("currency"),
                jsonAmount.getInt("total"),
                jsonAmount.getInt("subtotal"),
                jsonAmount.getInt("tax"),
                jsonAmount.getInt("discount"),
                jsonAmount.getString("discount_description"),
                jsonAmount.getInt("tip"),
                jsonAmount.getInt("surcharge")
        );
        JSONObject jsonTokenRequest = transaction.getJSONObject("token_request");

        TokenRequestParameters.Builder builder = new TokenRequestParameters.Builder()
                .setTokenFeeInCents(jsonTokenRequest.getInt("tokenFee"))
                .setTokenReferenceNumber(jsonTokenRequest.getString("tokenReferenceNumber"))
                .setCardholderFirstName(jsonTokenRequest.getString("cardholderFirstName"))
                .setCardholderLastName(jsonTokenRequest.getString("cardholderLastName"))
                .setBillToEmail(jsonTokenRequest.getString("billToEmail"))
                .setBillToAddress1(jsonTokenRequest.getString("billToAddress"))
                .setBillToAddress2(jsonTokenRequest.getString("billToAddress2"))
                .setBillToCity(jsonTokenRequest.getString("billToCity"))
                .setBillToState(jsonTokenRequest.getString("billToState"))
                .setBillToCountry(jsonTokenRequest.getString("billToCountry"))
                .setBillToZip(jsonTokenRequest.getString("billToZip"))
                .setIgnoreAVSResut(true)
                .setTokenIdentifier(jsonTokenRequest.getString("tokenIdentifier"));
        TokenRequestParameters parameters = null;
        switch (jsonTokenRequest.getInt("tokenRequestType")) {
            case 0:
                parameters = builder.createTokenEnrollmentRequestParameters();
                break;
            case 1:
                parameters = builder.createTokenUpdateRequestParameters();
                break;
            default:
                break;
        }
        Ingenico.getInstance().payment().processCreditSaleTransactionWithCardReader(
                new CreditSaleTransactionRequest(
                        amount, false
                ),
                new TransactionCallback() {
                    @Override
                    public void updateProgress(Integer progressCode, String extraMessage) {
                        Log.d(TAG, String.format(Locale.ENGLISH, "%d: %s", progressCode, extraMessage));
                    }

                    @Override
                    public void applicationSelection(List<ApplicationIdentifier> appList,
                            ApplicationSelectionCallback applicationcallback) {

                    }

                    @Override
                    public void done(Integer responseCode, TransactionResponse response) {
                        if (response == null) {
                            Toast.makeText(context, "Transaction response was null", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        Toast.makeText(context, "Transaction response received", Toast.LENGTH_SHORT).show();
                        Log.d(TAG, response.toJSON().toString());
                        JSONObject responseJson = new JSONObject();
                        Handler handler = new Handler();
                        //run with delay to give cpoc activity time to close
                        handler.postDelayed(() -> {
                            try {
                                responseJson.put("transactionResponse", response.toJSON());
                                responseJson.put("receiptData", getReceiptData(
                                        response.getClientTransactionId(), hostUrl, sessionToken, context));
                                postDataToStickshift(responseJson, responseUrl, context);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }, 1000);
                    }
                }
        );
    }

    private static void postDataToStickshift(JSONObject responseJson, String responseUrl,
            Context context) {
        OkHttpClient client = new OkHttpClient();
        RequestBody body = RequestBody.create(
                MediaType.parse("application/json"), responseJson.toString());
        Log.d(TAG, responseJson.toString());
        Request request = new Request.Builder()
                .url(responseUrl)
                .post(body)
                .build();
        try {
            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                Toast.makeText(context, "Successfully posted to responseUrl", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, "Failed to post to responseUrl", Toast.LENGTH_SHORT).show();
            }
            Log.d(TAG, response.body().string());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String getReceiptData(String transactionId, String hostUrl,
            String sessionToken, Context context) {
        OkHttpClient client = new OkHttpClient.Builder().protocols(Util.immutableListOf(
                Protocol.HTTP_1_1))
                .connectTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .build();
        String endpoint = String.format("%s/wsapi/Transactions/%s/Receipt", hostUrl, transactionId);
        Log.d(TAG, endpoint);
        Request request = new Request.Builder()
                .addHeader("X-Roam-Token", sessionToken)
                .addHeader("X-Roam-ApiVersion", "6.0.0")
                .addHeader("X-Roam-ClientVersion", "1.0.0")
                .url(endpoint)
                .get()
                .build();
        try {
            Response receiptResponse = client.newCall(request).execute();
            if (receiptResponse.isSuccessful()) {
                Toast.makeText(context, "GET transaction receipt success", Toast.LENGTH_SHORT).show();
                return receiptResponse.body().string();
            } else {
                Log.e(TAG, "failed to get receipt data");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }
}