/*
 * //////////////////////////////////////////////////////////////////////////////
 * //
 * // Copyright (c) 2017 ROAM, Inc. All rights reserved.
 * //
 * //////////////////////////////////////////////////////////////////////////////
 */

package com.ingenico.mpos.app.sample.common.logger;

import android.app.Activity;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ScrollView;

import com.ingenico.mpos.app.sample.R;
import com.ingenico.mpos.app.sample.Utils;

/**
 * Simple fraggment which contains a LogView and uses is to output log data it receives
 * through the LogNode interface.
 */
public class LogFragment extends Fragment implements View.OnClickListener {
    private final static String TAG = LogFragment.class.getSimpleName();

    private OnFragmentInteractionListener mListener;

    private LogView mLogView;
    private ScrollView mScrollView;


    public LogFragment() {
    }


    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mListener = (OnFragmentInteractionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_log, container, false);

        mScrollView = (ScrollView) view.findViewById(R.id.fragment_log_sv);
        mLogView = (LogView) view.findViewById(R.id.fragment_log_lv);

        Button btnClear = (Button) view.findViewById(R.id.fragment_log_btn_clear);
        Button btnEmail = (Button) view.findViewById(R.id.fragment_log_email);

        btnClear.setOnClickListener(this);
        btnEmail.setOnClickListener(this);

        mLogView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                mScrollView.fullScroll(ScrollView.FOCUS_DOWN);
            }
        });
        return view;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.fragment_log_btn_clear:
                mLogView.setText("");
                Utils.clearLogcat(getActivity());
                break;
            case R.id.fragment_log_email:
                mListener.sendEmail(mLogView.getText().toString());
                break;
            default:
                break;
        }
    }

    public LogView getLogView() {
        return mLogView;
    }

    public interface OnFragmentInteractionListener {
        void sendEmail(String log);
    }
}