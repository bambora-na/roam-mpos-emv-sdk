package com.ingenico.mpos.app.sample;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import androidx.annotation.NonNull;
import com.google.android.material.textfield.TextInputLayout;
import androidx.fragment.app.DialogFragment;
import android.text.InputFilter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.ingenico.mpos.app.sample.common.InputFilterMinMax;
import com.ingenico.mpos.sdk.Ingenico;

import java.util.Locale;

public class AmountDialogFragment extends DialogFragment implements CompoundButton.OnCheckedChangeListener {
    private static final String ARG_DIALOG_MSG = "ARG_DIALOG_MSG";
    private static final String ARG_TRANSACTION_TYPE = "ARG_TRANSACTION_TYPE";
    private static final String ARG_REFUND_TYPE = "ARG_REFUND_TYPE";
    private static final String ARG_IS_CREDIT_FORCE = "ARG_IS_CREDIT_FORCE";
    private static final String ARG_IS_AUTH_COMPLETE = "ARG_IS_AUTH_COMPLETE";
    private static final String ARG_CAN_ENROLL_TOKEN = "ARG_CAN_ENROLL_TOKEN";
    private static final String ARG_CAN_SET_CUSTOM_REF = "ARG_CAN_SET_CUSTOM_REF";
    private static final String ARG_IS_PARTIAL_AUTH = "ARG_IS_PARTIAL_AUTH";
    private static final String ARG_IS_KEYED_WITH_DEVICE = "ARG_IS_KEYED_WITH_DEVICE";
    private static final String ARG_IS_KEYED = "ARG_IS_KEYED";
    private static final String ARG_AMOUNT_MIN_VALUE = "ARG_AMOUNT_MIN_VALUE";
    private static final String ARG_AMOUNT_MAX_VALUE = "ARG_AMOUNT_MAX_VALUE";
    private static final String ARG_CACHED_TOKEN_ID = "ARG_CACHED_TOKEN_ID";
    private static final String ARG_SHOW_NOTE_AND_INVOICE_ON_RECEIPT = "ARG_SHOW_NOTE_AND_INVOICE_ON_RECEIPT";
    private static final String ARG_SHOW_ONLY_AMOUNT = "ARG_SHOW_ONLY_AMOUNT";
    private static final String ARG_IS_PARTIAL_VOID = "ARG_IS_PARTIAL_VOID";
    private static final String ARG_CAN_SET_ORDER_NUMBER = "ARG_CAN_SET_ORDER_NUMBER";
    private static final String ARG_IS_TOKEN_SALE = "ARG_IS_TOKEN_SALE";
    private static final String ARG_CAN_VALIDATE_EXPIRY_DATE = "ARG_CAN_VALIDATE_EXPIRY_DATE";
    private AmountDialogListener mListener;

    private EditText etTotal;
    private EditText etSubtotal;
    private EditText etTip;
    private EditText etTax;
    private EditText etDiscount;
    private EditText etSurcharge;
    private EditText etCurrencyCode;
    private EditText etClerkId;
    private EditText etAuthCode;
    private EditText etSystemTrackAuditNumber;
    private EditText etMerchantInvoiceID;
    private EditText etTransactionNote;
    private EditText etTokenFee;
    private EditText etCustomRef;
    private EditText etTokenId;
    private EditText etOrderNumber;
    private CheckBox cbEnrollToken;
    private CheckBox cbUpdateToken;
    private CheckBox cbRequestCvv;
    private CheckBox cbRequestAvs;
    private CheckBox cbCardPresent;
    private CheckBox cbShowNoteAndInvoiceOnReceipt;
    private CheckBox cbValidateExpiryDate;

    private View view;

    private String mMessage;
    private boolean mIsRefund;
    private boolean mIsOpenRefund;
    private boolean mIsCreditForce;
    private boolean mIsAuthComplete;
    private boolean mCanEnrollToken;
    private boolean mEnrollToken;
    private boolean mUpdateToken;
    private boolean mCanSetCustomRef;
    private boolean mIsPartialAuth;
    private boolean mIsKeyedWithDevice;
    private boolean mIsKeyed;
    private boolean mRequestCvv;
    private boolean mRequestAvs;
    private boolean mShowNoteAndInvoiceOnReceipt;
    private boolean mShowOnlyAmount;
    private boolean mIsPartialVoid;
    private boolean mCanSetOrderNumber;
    private boolean mIsTokenSale;
    private boolean mCanValidateExpiryDate;
    private int mMinValueForAmount;
    private int mMaxValueForAmount;
    private String mCachedTokenId;

    public AmountDialogFragment() {
        // Required empty public constructor
    }

    private static AmountDialogFragment newInstance(
            String message,
            boolean isRefund,
            boolean isOpenRefund,
            boolean isCreditForce,
            boolean isAuthComplete,
            boolean canEnrollToken,
            boolean canSetCustomRef,
            boolean isPartialAuth,
            boolean isKeyedWithDevice,
            int minForAmount,
            int maxForAmount,
            String cachedTokenId,
            boolean isKeyed,
            boolean showNoteAndInvoiceOnReceipt,
            boolean showOnlyAmount,
            boolean isPartialVoid,
            boolean canSetOrderNumber,
            boolean isTokenSale,
            boolean canValidateExpiryDate
    ) {
        AmountDialogFragment fragment = new AmountDialogFragment();
        Bundle args = new Bundle();
        args.putString(ARG_DIALOG_MSG, message);
        args.putBoolean(ARG_TRANSACTION_TYPE, isRefund);
        args.putBoolean(ARG_REFUND_TYPE, isOpenRefund);
        args.putBoolean(ARG_IS_CREDIT_FORCE, isCreditForce);
        args.putBoolean(ARG_IS_AUTH_COMPLETE, isAuthComplete);
        args.putBoolean(ARG_CAN_ENROLL_TOKEN, canEnrollToken);
        args.putBoolean(ARG_CAN_SET_CUSTOM_REF, canSetCustomRef);
        args.putBoolean(ARG_IS_PARTIAL_AUTH, isPartialAuth);
        args.putBoolean(ARG_IS_KEYED_WITH_DEVICE, isKeyedWithDevice);
        args.putInt(ARG_AMOUNT_MIN_VALUE, minForAmount);
        args.putInt(ARG_AMOUNT_MAX_VALUE, maxForAmount);
        args.putString(ARG_CACHED_TOKEN_ID, cachedTokenId);
        args.putBoolean(ARG_IS_KEYED, isKeyed);
        args.putBoolean(ARG_SHOW_NOTE_AND_INVOICE_ON_RECEIPT, showNoteAndInvoiceOnReceipt);
        args.putBoolean(ARG_SHOW_ONLY_AMOUNT, showOnlyAmount);
        args.putBoolean(ARG_IS_PARTIAL_VOID, isPartialVoid);
        args.putBoolean(ARG_CAN_SET_ORDER_NUMBER, canSetOrderNumber);
        args.putBoolean(ARG_IS_TOKEN_SALE, isTokenSale);
        args.putBoolean(ARG_CAN_VALIDATE_EXPIRY_DATE, canValidateExpiryDate);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mMessage = getArguments().getString(ARG_DIALOG_MSG);
            mIsRefund = getArguments().getBoolean(ARG_TRANSACTION_TYPE);
            mIsOpenRefund = getArguments().getBoolean(ARG_REFUND_TYPE);
            mIsCreditForce = getArguments().getBoolean(ARG_IS_CREDIT_FORCE);
            mIsAuthComplete = getArguments().getBoolean(ARG_IS_AUTH_COMPLETE);
            mCanEnrollToken = getArguments().getBoolean(ARG_CAN_ENROLL_TOKEN);
            mCanSetCustomRef = getArguments().getBoolean(ARG_CAN_SET_CUSTOM_REF);
            mIsPartialAuth = getArguments().getBoolean(ARG_IS_PARTIAL_AUTH);
            mIsKeyedWithDevice = getArguments().getBoolean(ARG_IS_KEYED_WITH_DEVICE);
            mMinValueForAmount = getArguments().getInt(ARG_AMOUNT_MIN_VALUE);
            mMaxValueForAmount = getArguments().getInt(ARG_AMOUNT_MAX_VALUE);
            mCachedTokenId = getArguments().getString(ARG_CACHED_TOKEN_ID);
            mIsKeyed = getArguments().getBoolean(ARG_IS_KEYED);
            mShowNoteAndInvoiceOnReceipt = getArguments().getBoolean(ARG_SHOW_NOTE_AND_INVOICE_ON_RECEIPT);
            mShowOnlyAmount = getArguments().getBoolean(ARG_SHOW_ONLY_AMOUNT);
            mIsPartialVoid = getArguments().getBoolean(ARG_IS_PARTIAL_VOID);
            mCanSetOrderNumber = getArguments().getBoolean(ARG_CAN_SET_ORDER_NUMBER);
            mIsTokenSale = getArguments().getBoolean(ARG_IS_TOKEN_SALE);
            mCanValidateExpiryDate = getArguments().getBoolean(ARG_CAN_VALIDATE_EXPIRY_DATE);
        }
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        LayoutInflater inflater = getActivity().getLayoutInflater();
        view = inflater.inflate(R.layout.dialog_amount, null);
        TextView tvMsg = (TextView) view.findViewById(R.id.dialog_amount_tv_message);
        etTotal = (EditText) view.findViewById(R.id.dialog_amount_et_total);
        etSubtotal = (EditText) view.findViewById(R.id.dialog_amount_et_subtotal);
        etTip = (EditText) view.findViewById(R.id.dialog_amount_et_tip);
        etTax = (EditText) view.findViewById(R.id.dialog_amount_et_tax);
        etDiscount = (EditText) view.findViewById(R.id.dialog_amount_et_discount);
        etSurcharge = (EditText) view.findViewById(R.id.dialog_amount_et_surcharge);
        etCurrencyCode = (EditText) view.findViewById(R.id.dialog_amount_et_currency_code);
        etCurrencyCode.setText(PrefHelper.get(getActivity(), PrefHelper.PREF_KEY_CURRENCY, "USD"));
        etClerkId = (EditText) view.findViewById(R.id.dialog_clerk_et_id);
        etAuthCode = (EditText) view.findViewById(R.id.dialog_auth_code);
        etSystemTrackAuditNumber = (EditText) view.findViewById(R.id.dialog_stan);
        etMerchantInvoiceID = (EditText) view.findViewById(R.id.dialog_merchant_invoice_id);
        etTransactionNote = (EditText) view.findViewById(R.id.dialog_transaction_note);
        etTokenFee = (EditText) view.findViewById(R.id.dialog_token_fee);
        etCustomRef = (EditText) view.findViewById(R.id.dialog_clerk_et_custom_ref);
        etTokenId = (EditText) view.findViewById(R.id.dialog_token_id);
        etOrderNumber = (EditText) view.findViewById(R.id.dialog_et_order_number);
        tvMsg.setText(mMessage);
        TextInputLayout etAmountWrapper = (TextInputLayout) view.findViewById(
                R.id.dialog_amount_et_total_wrapper);
        cbEnrollToken = (CheckBox) view.findViewById(R.id.dialog_enroll_token);
        cbUpdateToken = (CheckBox) view.findViewById(R.id.dialog_update_token);
        cbRequestCvv = (CheckBox) view.findViewById(R.id.dialog_request_cvv);
        cbRequestAvs = (CheckBox) view.findViewById(R.id.dialog_request_avs);
        cbCardPresent = (CheckBox) view.findViewById(R.id.dialog_card_present);
        cbShowNoteAndInvoiceOnReceipt = (CheckBox) view.findViewById(R.id.dialog_clerk_show_note_and_invoice_on_receipt);
        cbValidateExpiryDate = (CheckBox) view.findViewById(R.id.dialog_clerk_validate_expiry_date);
        cbEnrollToken.setOnCheckedChangeListener(this);
        cbUpdateToken.setOnCheckedChangeListener(this);
        cbRequestCvv.setOnCheckedChangeListener(this);
        cbRequestAvs.setOnCheckedChangeListener(this);
        view.findViewById(R.id.dialog_clerk_request_avs).setVisibility(View.GONE);
        view.findViewById(R.id.dialog_clerk_request_CVV).setVisibility(View.GONE);
        view.findViewById(R.id.dialog_clerk_card_present).setVisibility(View.GONE);
        Spinner localeSpinner = view.findViewById(R.id.dialog_clerk_locale);
        localeSpinner.setAdapter(new Utils.CustomArrayAdapter(getActivity(), IngenicoConstants.SUPPORTED_LOCALES));
        localeSpinner.setSelection(IngenicoConstants.SUPPORTED_LOCALES.indexOf(Ingenico.getInstance().getPreference().getMerchantLocale()));
        cbRequestCvv.setChecked(true); // default for firmware versions < 8.60
        if (mMaxValueForAmount > -1 && mMinValueForAmount > -1) {
            etTotal.setFilters(new InputFilter[]{ new InputFilterMinMax(mMinValueForAmount, mMaxValueForAmount)});
            if (mIsPartialAuth) {
                etTotal.setText(String.valueOf(mMaxValueForAmount));
            } else {
                etTotal.setText(String.valueOf(mMinValueForAmount));
            }
        }
        if (mMaxValueForAmount > -1 && mMinValueForAmount > -1) {
            etSubtotal.setFilters(new InputFilter[]{ new InputFilterMinMax(mMinValueForAmount, mMaxValueForAmount)});
            if (!mIsPartialAuth) {
                etSubtotal.setText(String.valueOf(mMinValueForAmount));
            } 
        }
        if(mShowOnlyAmount) {
            etClerkId.setVisibility(View.GONE);
            etAuthCode.setVisibility(View.GONE);
            etSystemTrackAuditNumber.setVisibility(View.GONE);
            etMerchantInvoiceID.setVisibility(View.GONE);
            etTransactionNote.setVisibility(View.GONE);
            etTokenFee.setVisibility(View.GONE);
            etCustomRef.setVisibility(View.GONE);
            etTokenId.setVisibility(View.GONE);
            cbEnrollToken.setVisibility(View.GONE);
            cbUpdateToken.setVisibility(View.GONE);
            cbRequestCvv.setVisibility(View.GONE);
            cbRequestAvs.setVisibility(View.GONE);
            cbCardPresent.setVisibility(View.GONE);
            cbShowNoteAndInvoiceOnReceipt.setVisibility(View.GONE);
        } else {
            if (mIsRefund) {
                etAmountWrapper.setHint(getString(R.string.str_dialog_amount_label));
            }
            if (!mIsCreditForce) {
                etAuthCode.setVisibility(View.GONE);
                etSystemTrackAuditNumber.setVisibility(View.GONE);
            }
            if (mIsAuthComplete || (mIsRefund && !mIsOpenRefund)) {
                etMerchantInvoiceID.setVisibility(View.GONE);
            }
            if (!mCanEnrollToken) {
                cbEnrollToken.setVisibility(View.GONE);
                cbUpdateToken.setVisibility(View.GONE);
            }
            if (!mCanSetCustomRef) {
                etCustomRef.setVisibility(View.GONE);
            }
            if (!mShowNoteAndInvoiceOnReceipt) {
                cbShowNoteAndInvoiceOnReceipt.setVisibility(View.GONE);
            }
            if (mIsKeyedWithDevice && !mIsRefund) {
                cbRequestAvs.setVisibility(View.VISIBLE);
                cbRequestCvv.setVisibility(View.VISIBLE);
            }
            if ((mIsKeyed || mIsKeyedWithDevice) && !mIsCreditForce) {
                cbCardPresent.setVisibility(View.VISIBLE);
            }
            if (mIsPartialVoid) {
                cbShowNoteAndInvoiceOnReceipt.setVisibility(View.GONE);
            }
            if (!mCanSetOrderNumber) {
                etOrderNumber.setVisibility(View.GONE);
            }
            if (mIsTokenSale) {
                etTokenId.setVisibility(View.VISIBLE);
                if (mCachedTokenId != null)
                    etTokenId.setText(mCachedTokenId);
            }
        }
        if (!mCanValidateExpiryDate) {
            cbValidateExpiryDate.setVisibility(View.GONE);
        }
        else {
            cbValidateExpiryDate.setChecked(true);
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(getString(R.string.str_dialog_common_title))
                .setView(view)
                .setPositiveButton(
                        R.string.str_common_btn_ok,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                InputMethodManager
                                        inputManager =
                                        (InputMethodManager) getActivity().getSystemService(
                                                Context.INPUT_METHOD_SERVICE
                                        );
                                inputManager.hideSoftInputFromWindow(
                                        view.getWindowToken(),
                                        InputMethodManager.HIDE_NOT_ALWAYS
                                );
                                PrefHelper.set(getActivity(), PrefHelper.PREF_KEY_CURRENCY, etCurrencyCode.getText().toString());
                                if (mIsRefund) {
                                    if (mIsOpenRefund) {
                                        mListener.onOpenRefundAmountCaptured(
                                                etTotal.getText().toString(),
                                                etTax.getText().toString(),
                                                etDiscount.getText().toString(),
                                                etSurcharge.getText().toString(),
                                                etCurrencyCode.getText().toString(),
                                                etTransactionNote.getText().toString(),
                                                etMerchantInvoiceID.getText().toString(),
                                                etCustomRef.getText().toString(),
                                                mEnrollToken,
                                                mUpdateToken,
                                                etTokenFee.getText().toString(),
                                                cbCardPresent.isChecked(),
                                                etClerkId.getText().toString(),
                                                cbShowNoteAndInvoiceOnReceipt.isChecked(),
                                                etOrderNumber.getText().toString(),
                                                (Locale)localeSpinner.getSelectedItem());
                                    } else {
                                        mListener.onRefundAmountCaptured(
                                                etTotal.getText().toString(),
                                                etSubtotal.getText().toString(),
                                                etTip.getText().toString(),
                                                etTax.getText().toString(),
                                                etDiscount.getText().toString(),
                                                etSurcharge.getText().toString(),
                                                etCurrencyCode.getText().toString(),
                                                etCustomRef.getText().toString(),
                                                etClerkId.getText().toString(),
                                                etTransactionNote.getText().toString(),
                                                etOrderNumber.getText().toString(),
                                                cbShowNoteAndInvoiceOnReceipt.isChecked(),
                                                (Locale)localeSpinner.getSelectedItem());
                                    }
                                } else {
                                    mListener.onSaleAmountCaptured(
                                            etTotal.getText().toString(),
                                            etSubtotal.getText().toString(),
                                            etTip.getText().toString(),
                                            etTax.getText().toString(),
                                            etDiscount.getText().toString(),
                                            etSurcharge.getText().toString(),
                                            etCurrencyCode.getText().toString(),
                                            etClerkId.getText().toString(),
                                            etAuthCode.getText().toString(),
                                            etSystemTrackAuditNumber.getText().toString(),
                                            etTransactionNote.getText().toString(),
                                            etMerchantInvoiceID.getText().toString(),
                                            mEnrollToken,
                                            mUpdateToken,
                                            mRequestCvv,
                                            mRequestAvs,
                                            etTokenFee.getText().toString(),
                                            etCustomRef.getText().toString(),
                                            etTokenId.getText().toString(),
                                            cbCardPresent.isChecked(),
                                            cbShowNoteAndInvoiceOnReceipt.isChecked(),
                                            etOrderNumber.getText().toString(),
                                            cbValidateExpiryDate.isChecked(),
                                            (Locale)localeSpinner.getSelectedItem()
                                    );
                                }
                            }
                        })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        mListener.onTransactionCancelled();
                        dialogInterface.dismiss();
                    }
                });
        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        return dialog;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mListener = (AmountDialogListener) getTargetFragment();
        } catch (ClassCastException e) {
            throw new ClassCastException("Calling fragment must implement AmountDialogListener");
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        switch (buttonView.getId()) {
            case R.id.dialog_enroll_token:
                mEnrollToken = isChecked;
                if (mEnrollToken) {
                    cbUpdateToken.setChecked(false);
                    etTokenFee.setVisibility(View.VISIBLE);
                } else {
                    etTokenFee.setVisibility(View.GONE);
                }
                break;
            case R.id.dialog_update_token:
                mUpdateToken = isChecked;
                if (mUpdateToken) {
                    cbEnrollToken.setChecked(false);
                    etTokenFee.setVisibility(View.VISIBLE);
                    etTokenId.setVisibility(View.VISIBLE);
                    if (mCachedTokenId != null)
                        etTokenId.setText(mCachedTokenId);

                } else {
                    etTokenFee.setVisibility(View.GONE);
                    etTokenId.setText("");
                    etTokenId.setVisibility(View.GONE);
                }
                break;
            case R.id.dialog_request_cvv:
                mRequestCvv = isChecked;
                break;
            case R.id.dialog_request_avs:
                mRequestAvs = isChecked;
                break;
        }
    }

    public interface AmountDialogListener {
        void onSaleAmountCaptured(String total,
                                  String subtotal,
                                  String tipAmount, String taxAmount,
                                  String discountAmount, String surchargeAmount,
                                  String currencyCode,
                                  String clerkId, String authCode,
                                  String systemTrackAuditNumber,
                                  String transactionNote,
                                  String merchantInvoiceID,
                                  boolean shouldEnrollForToken,
                                  boolean shouldUpdateForToken,
                                  boolean shouldRequestCvv,
                                  boolean shouldRequestAvs,
                                  String tokenFee,
                                  String customReference,
                                  String tokenId,
                                  boolean isCardPresent,
                                  boolean showNoteAndInvoiceOnReceipt,
                                  String orderNumber,
                                  boolean validateExpiryDate,
                                  Locale cardholderLocale);

        void onRefundAmountCaptured(String refundAmount,
                String subtotalAmount,
                String tipAmount,
                String taxAmount,
                String discountAmount,
                String surchargeAmount,
                String currencyCode,
                String customReference,
                String clerkID,
                String transactionNote,
                String orderNumber,
                boolean showNotesAndInvoiceOnReceipt,
                Locale cardholderLocale);

        void onOpenRefundAmountCaptured(String refundAmount,
                String taxAmount, String discountAmount,
                String surchargeAmount,
                String currencyCode,
                String transactionNote,
                String merchantInvoiceID,
                String customReference,
                boolean shouldEnrollForToken,
                boolean shouldUpdateForToken,
                String tokenFee,
                boolean isCardPresent,
                String clerkID,
                boolean showNoteAndInvoiceOnReceipt,
                String orderNumber,
                Locale cardholderLocale);

        void onTransactionCancelled();
    }

    static class Builder {
        private String mMessage;
        private boolean mIsRefund;
        private boolean mIsOpenRefund;
        private boolean mIsCreditForce;
        private boolean mIsAuthComplete;
        private boolean mCanEnrollToken;
        private boolean mCanSetCustomRef;
        private boolean mIsPartialAuth;
        private boolean mIsKeyedWithDevice;
        private boolean mIsKeyed;
        private boolean mShowNoteAndInvoiceOnReceipt;
        private boolean mShowOnlyAmount;
        private boolean mIsPartialVoid;
        private boolean mCanSetOrderNumber;
        private boolean mIsTokenSale;
        private boolean mCanValidateExpiryDate;
        private int mMinValueForAmount = -1;
        private int mMaxValueForAmount = -1;
        private String mCachedTokenId;

        public Builder setIsRefund(boolean refund) {
            mIsRefund = refund;
            return this;
        }

        public Builder setIsOpenRefund(boolean openRefund) {
            mIsOpenRefund = openRefund;
            return this;
        }

        public Builder setIsCreditForce(boolean creditForce) {
            mIsCreditForce = creditForce;
            return this;
        }

        public Builder setIsAuthComplete(boolean authComplete) {
            mIsAuthComplete = authComplete;
            return this;
        }

        public Builder setCanEnrollToken(boolean canEnrollToken) {
            mCanEnrollToken = canEnrollToken;
            return this;
        }

        public Builder setCanSetCustomRef(boolean canSetCustomRef) {
            mCanSetCustomRef = canSetCustomRef;
            return this;
        }

        public Builder setIsPartialAuth(boolean partialAuth) {
            mIsPartialAuth = partialAuth;
            return this;
        }

        public Builder setIsKeyedWithDevice(boolean isKeyedWithDevice) {
            mIsKeyedWithDevice = isKeyedWithDevice;
            return this;
        }

        public Builder setMinValueForAmount(int minValueForAmount) {
            mMinValueForAmount = minValueForAmount;
            return this;
        }

        public Builder setMaxValueForAmount(int maxValueForAmount) {
            mMaxValueForAmount = maxValueForAmount;
            return this;
        }

        public Builder setCachedTokenId(String cachedTokenId) {
            mCachedTokenId = cachedTokenId;
            return this;
        }

        public Builder setMessage(String message) {
            mMessage = message;
            return this;
        }

        public Builder setIsKeyed(boolean isKeyed) {
            mIsKeyed = isKeyed;
            return this;
        }

        public Builder setShowNoteAndInvoiceOnReceipt(boolean ShowNoteAndInvoiceOnReceipt) {
            mShowNoteAndInvoiceOnReceipt = ShowNoteAndInvoiceOnReceipt;
            return this;
        }

        public Builder setShowOnlyAmount(boolean showOnlyAmount) {
            mShowOnlyAmount = showOnlyAmount;
            return this;
        }

        public Builder setIsPartialVoid(boolean isPartialVoid) {
            mIsPartialVoid = isPartialVoid;
            return this;
        }

        public Builder setCanSetOrderNumber(boolean canSetOrderNumber) {
            mCanSetOrderNumber = canSetOrderNumber;
            return this;
        }

        public Builder setIsTokenSale(boolean mIsTokenSale) {
            this.mIsTokenSale = mIsTokenSale;
            return this;
        }

        public Builder setCanValidateExpiryDate(boolean canValidateExpiryDate) {
            this.mCanValidateExpiryDate = canValidateExpiryDate;
            return this;
        }

        public AmountDialogFragment build() {
            return AmountDialogFragment.newInstance(mMessage,
                    mIsRefund,
                    mIsOpenRefund,
                    mIsCreditForce,
                    mIsAuthComplete,
                    mCanEnrollToken,
                    mCanSetCustomRef,
                    mIsPartialAuth,
                    mIsKeyedWithDevice,
                    mMinValueForAmount,
                    mMaxValueForAmount,
                    mCachedTokenId,
                    mIsKeyed,
                    mShowNoteAndInvoiceOnReceipt,
                    mShowOnlyAmount,
                    mIsPartialVoid,
                    mCanSetOrderNumber,
                    mIsTokenSale,
                    mCanValidateExpiryDate);
        }
    }
}
