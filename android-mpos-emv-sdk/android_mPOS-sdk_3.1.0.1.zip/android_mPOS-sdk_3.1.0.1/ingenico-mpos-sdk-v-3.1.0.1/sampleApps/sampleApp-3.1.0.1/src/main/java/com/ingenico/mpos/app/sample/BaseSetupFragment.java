package com.ingenico.mpos.app.sample;

import android.app.Activity;
import android.app.AlertDialog;

import androidx.fragment.app.DialogFragment;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;

import com.ingenico.mpos.app.sample.common.logger.Log;
import com.ingenico.mpos.app.sample.dialogs.FilterOptionsDialogFragment;
import com.ingenico.mpos.sdk.constants.ConfigMode;
import com.roam.roamreaderunifiedapi.constants.CommunicationType;
import com.roam.roamreaderunifiedapi.constants.DeviceType;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public abstract class BaseSetupFragment extends FragmentBase
        implements View.OnClickListener,
        RadioButton.OnCheckedChangeListener,
        FilterOptionsDialogFragment.OnFilterOptionsSelectedListener{

    protected static final String ARG_COMMUNICATION_TYPE_ORDINAL = "ARG_COMMUNICATION_TYPE_ORDINAL";
    protected static final String ARG_HOST_NAME = "ARG_HOST_NAME";
    protected static final String ARG_API_KEY = "ARG_API_KEY";
    protected static final String ARG_LOCALE_INDEX = "ARG_LOCALE";
    protected final static String LAST_SELECTED_DEVICE_TYPE = "LAST_SELECTED_DEVICE_TYPE";
    private final static String TAG = BaseSetupFragment.class.getSimpleName();
    private final List<DeviceType> usbSupportedDevices = Arrays.asList(
            DeviceType.RP450c,
            DeviceType.RP45BT,
            DeviceType.RP45USB,
            DeviceType.RP750x,
            DeviceType.MOBY3000,
            DeviceType.MOBY8500,
            DeviceType.MOBY5500
    );
    private List<DeviceType> selectedUsbPreferredDevices = new ArrayList<>();
    private LinkedHashMap<String, Boolean> usbPreferredDevicesMap = new LinkedHashMap<>();

    protected CommunicationType mAutoDetectCommType;
    protected String mHostname;
    protected String mAPIKey;
    protected int mLocaleIndex = 0;
    protected DeviceType mDeviceType;
    protected ConfigMode mConfigMode;
    protected int mRetryCount;
    protected ArrayList<CommunicationType> mManualSearchCommTypes = new ArrayList<>();
    protected boolean mSendDiagnostics;
    protected OnFragmentInteractionListener mListener;
    private AutoCompleteTextView etHostname;
    private EditText etAPIKey;
    private RadioGroup rgDeviceManagerType;
    private RadioButton rbAudioJack;
    private RadioButton rbUsb;
    private Button btnChangeDeviceType;
    private CheckBox cbAudiojack;
    private CheckBox cbBluetooth;
    private CheckBox cbUsb;
    private Spinner localeSpinner;

    public BaseSetupFragment() {
        // Required empty public constructor
    }

    abstract void initializeSDK();

    void setupIngenicoSDK() {
        mListener.setupIngenicoSDK(
                etAPIKey.getText().toString(),
                etHostname.getText().toString(),
                mDeviceType,
                mAutoDetectCommType,
                mManualSearchCommTypes
        );
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mAPIKey = getArguments().getString(ARG_API_KEY);
            mHostname = getArguments().getString(ARG_HOST_NAME);
            mLocaleIndex = getArguments().getInt(ARG_LOCALE_INDEX);
            int ordinal = getArguments().getInt(ARG_COMMUNICATION_TYPE_ORDINAL);
            mAutoDetectCommType = CommunicationType.values()[ordinal];
        }
        selectedUsbPreferredDevices = PrefHelper.getUsbPreferredDevices(getActivity()) != null ?
                PrefHelper.getUsbPreferredDevices(getActivity()) :
                usbSupportedDevices;
        for (DeviceType type : DeviceType.values()) {
            if (type != DeviceType.UNKNOWN && type != DeviceType.MOBY6500) {
                usbPreferredDevicesMap.put(type.name(), selectedUsbPreferredDevices.contains(type));
            }
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_setup, container, false);
        Log.v(TAG, "onCreateView");

        etHostname = view.findViewById(R.id.fragment_setup_et_hostname);
        etAPIKey = view.findViewById(R.id.fragment_setup_et_api_key);
        rgDeviceManagerType = view.findViewById(R.id.rg_dm_type);
        Button btnSetup =  view.findViewById(R.id.fragment_setup_btn_setup);
        btnChangeDeviceType = view.findViewById(R.id.btn_change_device_types);
        rbUsb = view.findViewById(R.id.fragment_setup_rb_usb);
        rbAudioJack = view.findViewById(R.id.fragment_setup_rb_audiojack);
        RadioButton rb750 = view.findViewById(R.id.fragment_setup_rb_750);
        RadioButton rb450 = view.findViewById(R.id.fragment_setup_rb_450);
        RadioButton mb3000 = view.findViewById(R.id.fragment_setup_rb_moby_3000);
        RadioButton rp450bt = view.findViewById(R.id.fragment_setup_rb_45bt);
        RadioButton mb8500 = view.findViewById(R.id.fragment_setup_rb_moby_8500);
        RadioButton rb45usb = view.findViewById(R.id.fragment_setup_rb_45usb);
        RadioButton rb5500 = view.findViewById(R.id.fragment_setup_rb_moby_5500);
        RadioButton rbMobyTap = view.findViewById(R.id.fragment_setup_rb_moby_tap);
        if (!BuildConfig.FLAVOR.toLowerCase().contains("cpoc")) {
            rbMobyTap.setVisibility(View.GONE);
        }
        updateLabelWithSelectedDeviceTypes(usbPreferredDevicesMap);
        cbAudiojack = view.findViewById(R.id.cb_comm_type_audiojack);
        cbBluetooth = view.findViewById(R.id.cb_comm_type_bluetooth);
        cbUsb = view.findViewById(R.id.cb_comm_type_usb);
        Switch swDiagnostics = view.findViewById(R.id.sw_send_diagnostics);

        RadioButton notSet = view.findViewById(R.id.fragment_setup_rb_notset);
        notSet.setChecked(true);
        RadioButton manual = view.findViewById(R.id.fragment_setup_rb_manual);
        RadioButton optimal = view.findViewById(R.id.fragment_setup_rb_optimal);
        RadioButton auto = view.findViewById(R.id.fragment_setup_rb_auto);

        RadioButton retryCountZero = view.findViewById(R.id.fragment_setup_rb_retry_count_zero);
        retryCountZero.setChecked(true);
        RadioButton retryCountOne = view.findViewById(R.id.fragment_setup_rb_retry_count_one);
        RadioButton retryCountTwo = view.findViewById(R.id.fragment_setup_rb_retry_count_two);
        RadioButton retryCountThree = view.findViewById(R.id.fragment_setup_rb_retry_count_three);

        localeSpinner = view.findViewById(R.id.fragment_setup_spinner_locale);
        Utils.CustomArrayAdapter localeArrayAdapter = new Utils.CustomArrayAdapter(
                getActivity(),
                IngenicoConstants.SUPPORTED_LOCALES
        );
        localeSpinner.setAdapter(localeArrayAdapter);
        localeSpinner.setSelection(mLocaleIndex);

        btnSetup.setOnClickListener(this);
        btnChangeDeviceType.setOnClickListener(this);
        rbUsb.setOnCheckedChangeListener(this);
        rbAudioJack.setOnCheckedChangeListener(this);
        rb750.setOnCheckedChangeListener(this);
        rb450.setOnCheckedChangeListener(this);
        mb3000.setOnCheckedChangeListener(this);
        rp450bt.setOnCheckedChangeListener(this);
        mb8500.setOnCheckedChangeListener(this);
        rb45usb.setOnCheckedChangeListener(this);
        rb5500.setOnCheckedChangeListener(this);
        rbMobyTap.setOnCheckedChangeListener(this);
        notSet.setOnCheckedChangeListener(this);
        manual.setOnCheckedChangeListener(this);
        optimal.setOnCheckedChangeListener(this);
        auto.setOnCheckedChangeListener(this);
        retryCountZero.setOnCheckedChangeListener(this);
        retryCountOne.setOnCheckedChangeListener(this);
        retryCountTwo.setOnCheckedChangeListener(this);
        retryCountThree.setOnCheckedChangeListener(this);

        ArrayList<String> recentHostNames = new ArrayList<>();
        recentHostNames.addAll(PrefHelper.getRecentHostNames(getActivity()));
        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (getActivity(), android.R.layout.select_dialog_item, recentHostNames);
        etHostname.setText(mHostname);
        etHostname.setThreshold(1);
        etHostname.setAdapter(adapter);

        etAPIKey.setText(mAPIKey);
        swDiagnostics.setOnCheckedChangeListener(this);
        swDiagnostics.setChecked(true);

        mManualSearchCommTypes = PrefHelper.getManualSearchCommTypes(getActivity());
        if (mManualSearchCommTypes.size() > 0) {
            cbAudiojack.setChecked(mManualSearchCommTypes.contains(CommunicationType.AudioJack));
            cbBluetooth.setChecked(mManualSearchCommTypes.contains(CommunicationType.Bluetooth));
            cbUsb.setChecked(mManualSearchCommTypes.contains(CommunicationType.Usb));
        }

        mDeviceType = DeviceType.getEnum(
                PrefHelper.get(
                        getActivity(),
                        LAST_SELECTED_DEVICE_TYPE,
                        DeviceType.UNKNOWN.toString()
                )
        );
        switch (mDeviceType) {
            case RP750x:
                rb750.setChecked(true);
                break;
            case RP450c:
                rb450.setChecked(true);
                break;
            case MOBY3000:
                mb3000.setChecked(true);
                break;
            case RP45BT:
                rp450bt.setChecked(true);
                break;
            case MOBY8500:
                mb8500.setChecked(true);
                break;
            case RP45USB:
                rb45usb.setChecked(true);
                break;
            case MOBY5500:
                rb5500.setChecked(true);
                break;
            case MOBYTAP:
                rbMobyTap.setChecked(true);
                break;
            default:
                break;
        }
        switch (mAutoDetectCommType) {
            case Usb:
                rbUsb.setChecked(true);
                break;
            case AudioJack:
                rbAudioJack.setChecked(true);
                break;
            default:
                break;
        }
        if(BuildConfig.disableAutoComplete) {
            etHostname.setThreshold(1000);
        }
        return view;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mListener = (OnFragmentInteractionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (R.id.fragment_setup_btn_setup == id) {
            if (!Utils.isBluetoothEnabled()
                    && !rbAudioJack.isChecked()
                    && !rbUsb.isChecked()
                    && cbBluetooth.isChecked()) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setTitle("Bluetooth is disabled")
                        .setMessage(
                                "Please enable bluetooth from system settings and retry.")
                        .setPositiveButton(R.string.str_common_btn_ok,
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                })
                        .show();
                return;
            }
            if (!TextUtils.isEmpty(etHostname.getText())) {
                PrefHelper.set(
                        getActivity(),
                        LAST_SELECTED_DEVICE_TYPE,
                        mDeviceType.toString()
                );
                PrefHelper.set(
                        getActivity(),
                        PrefHelper.COMM_TYPE,
                        mAutoDetectCommType.toString()
                );

                mManualSearchCommTypes.clear();
                if (cbAudiojack.isChecked())
                    mManualSearchCommTypes.add(CommunicationType.AudioJack);
                if (cbBluetooth.isChecked())
                    mManualSearchCommTypes.add(CommunicationType.Bluetooth);
                if (cbUsb.isChecked())
                    mManualSearchCommTypes.add(CommunicationType.Usb);
                PrefHelper.setManualSearchCommTypes(getActivity(),
                        mManualSearchCommTypes);

                mHostname = etHostname.getText().toString();
                mAPIKey = etAPIKey.getText().toString();
                mLocaleIndex = localeSpinner.getSelectedItemPosition();
                PrefHelper.set(getActivity().getApplicationContext(), PrefHelper.HOST_NAME, mHostname);
                PrefHelper.set(getActivity().getApplicationContext(), PrefHelper.API_KEY, mAPIKey);
                PrefHelper.set(getActivity().getApplicationContext(), PrefHelper.LOCALE_INDEX, mLocaleIndex);
                if (BuildConfig.API_KEY == null ||
                        BuildConfig.API_KEY.equals("Set your API key here")) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setTitle("API Key Missing")
                            .setMessage(
                                    "If you have an API Key, please set the API_KEY build config "
                                            + "field in the build.gradle file."
                                            + " If not, please contact apisupport.us@ingenico.com"
                                            + " to obtain a key.")
                            .setPositiveButton(R.string.str_common_btn_ok,
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface,
                                                int i) {
                                            initializeSDK();
                                        }
                                    }).show();
                } else {
                    initializeSDK();
                }
            } else {
                Utils.newDialog(getActivity(), "Error", "Hostname cannot be empty").show();
            }
        } else if (R.id.btn_change_device_types == id) {
            DialogFragment dialogFragment = FilterOptionsDialogFragment.getInstance(DEVICE_TYPE, usbPreferredDevicesMap);
            dialogFragment.setTargetFragment(BaseSetupFragment.this, 0);
            dialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        int id = buttonView.getId();
        if (R.id.sw_send_diagnostics == id) {
            mSendDiagnostics = isChecked;
        }
        if (R.id.fragment_setup_rb_usb == id) {
            if (isChecked) {
                btnChangeDeviceType.setVisibility(View.VISIBLE);
            } else {
                btnChangeDeviceType.setVisibility(View.GONE);
            }
        }
        if (isChecked) {
            if (R.id.fragment_setup_rb_audiojack == id) {
                mAutoDetectCommType = CommunicationType.AudioJack;
                mDeviceType = DeviceType.UNKNOWN;
            } else if (R.id.fragment_setup_rb_usb == id) {
                mAutoDetectCommType = CommunicationType.Usb;
                mDeviceType = DeviceType.UNKNOWN;
                mListener.setUsbPrefDevices(selectedUsbPreferredDevices);
            } else if (R.id.fragment_setup_rb_750 == id) {
                mAutoDetectCommType = CommunicationType.UNKNOWN;
                mDeviceType = DeviceType.RP750x;
            } else if (R.id.fragment_setup_rb_450 == id) {
                mAutoDetectCommType = CommunicationType.UNKNOWN;
                mDeviceType = DeviceType.RP450c;
            } else if (R.id.fragment_setup_rb_moby_3000 == id) {
                mAutoDetectCommType = CommunicationType.UNKNOWN;
                mDeviceType = DeviceType.MOBY3000;
            } else if (R.id.fragment_setup_rb_45bt == id) {
                mAutoDetectCommType = CommunicationType.UNKNOWN;
                mDeviceType = DeviceType.RP45BT;
            } else if (R.id.fragment_setup_rb_moby_8500 == id) {
                mAutoDetectCommType = CommunicationType.UNKNOWN;
                mDeviceType = DeviceType.MOBY8500;
            } else if (R.id.fragment_setup_rb_45usb == id) {
                mAutoDetectCommType = CommunicationType.UNKNOWN;
                mDeviceType = DeviceType.RP45USB;
            } else if (R.id.fragment_setup_rb_moby_5500 == id) {
                mAutoDetectCommType = CommunicationType.UNKNOWN;
                mDeviceType = DeviceType.MOBY5500;
            } else if (R.id.fragment_setup_rb_moby_tap == id) {
                mAutoDetectCommType = CommunicationType.UNKNOWN;
                mDeviceType = DeviceType.MOBYTAP;
            } else if (R.id.fragment_setup_rb_notset == id) {
                mConfigMode = null;
            } else if (R.id.fragment_setup_rb_manual == id) {
                mConfigMode = ConfigMode.Manual;
            } else if (R.id.fragment_setup_rb_optimal == id) {
                mConfigMode = ConfigMode.Optimal;
            } else if (R.id.fragment_setup_rb_auto == id) {
                mConfigMode = ConfigMode.Auto;
            } else if (R.id.fragment_setup_rb_retry_count_zero == id) {
                mRetryCount = 0;
            } else if (R.id.fragment_setup_rb_retry_count_one == id) {
                mRetryCount = 1;
            } else if (R.id.fragment_setup_rb_retry_count_two == id) {
                mRetryCount = 2;
            } else if (R.id.fragment_setup_rb_retry_count_three == id) {
                mRetryCount = 3;
            }
        }
    }

    @Override
    public void onFilterOptionsSelected(String filterType,
                                        LinkedHashMap<String, Boolean> optionSelectionMap) {
        if (DEVICE_TYPE.equals(filterType)) {
            usbPreferredDevicesMap = optionSelectionMap;
            PrefHelper.setUsbPreferredDevices(getActivity(), getSelectedOptionStrings(usbPreferredDevicesMap));
            selectedUsbPreferredDevices = getSelectedUsbPreferredDevices(usbPreferredDevicesMap);
            updateLabelWithSelectedDeviceTypes(usbPreferredDevicesMap);
            mListener.setUsbPrefDevices(selectedUsbPreferredDevices);
        }
    }

    private void updateLabelWithSelectedDeviceTypes(Map<String, Boolean> usbPreferredDevicesMap) {
        String selectedDevicesStr;
        List<String> selectedOptions = getSelectedOptionStrings(usbPreferredDevicesMap);
        if (selectedOptions.isEmpty()) {
            selectedDevicesStr = "None";
        } else if (selectedOptions.size() == usbPreferredDevicesMap.size()) {
            selectedDevicesStr = "All";
        } else {
            selectedDevicesStr = TextUtils.join(" ,", selectedOptions);
        }
        rbUsb.setText(String.format(getString(R.string.usb_autodetect_pref_types), selectedDevicesStr));
    }

    private List<DeviceType> getSelectedUsbPreferredDevices(Map<String, Boolean> usbPreferredDevicesMap) {
        List<DeviceType> selectedDeviceTypes = new ArrayList<>();
        for (String type : getSelectedOptionStrings(usbPreferredDevicesMap)) {
            selectedDeviceTypes.add(DeviceType.getEnum(type));
        }
        return selectedDeviceTypes;
    }

    public interface OnFragmentInteractionListener {
        void setupIngenicoSDK(String apiKey, String baseURL, DeviceType deviceType,
                              CommunicationType autoDetectCommtype, ArrayList<CommunicationType> manualSearchCommTypes);
        void setUsbPrefDevices(List<DeviceType> usbDeviceTypes);
    }
}
