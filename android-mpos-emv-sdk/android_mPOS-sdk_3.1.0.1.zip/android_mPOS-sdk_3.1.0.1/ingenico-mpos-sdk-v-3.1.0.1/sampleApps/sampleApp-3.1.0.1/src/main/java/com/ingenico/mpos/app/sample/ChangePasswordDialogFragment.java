package com.ingenico.mpos.app.sample;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

public class ChangePasswordDialogFragment extends DialogFragment {

    private ChangePasswordListener mListener;

    private View mView;
    private EditText etOldPassword;
    private EditText etNewPassword;

    @Nullable
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        mView = getActivity().getLayoutInflater().inflate(R.layout.dialog_change_password, null);
        etOldPassword = (EditText) mView.findViewById(R.id.dialog_change_password_et_old);
        etNewPassword = (EditText) mView.findViewById(R.id.dialog_change_password_et_new);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(getString(R.string.str_dialog_common_title))
                .setView(mView)
                .setPositiveButton(
                        R.string.str_common_btn_ok,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                InputMethodManager
                                        inputManager =
                                        (InputMethodManager) getActivity().getSystemService(
                                                Context.INPUT_METHOD_SERVICE
                                        );
                                inputManager.hideSoftInputFromWindow(
                                        mView.getWindowToken(),
                                        InputMethodManager.HIDE_NOT_ALWAYS
                                );
                                mListener.onPasswordsCaptured(etOldPassword.getText().toString(),
                                        etNewPassword.getText().toString());
                            }
                        }
                ).setNegativeButton(
                R.string.str_common_btn_cancel,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dismiss();
                    }
                }
        );
        return builder.create();
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mListener = (ChangePasswordListener) getTargetFragment();
        } catch (ClassCastException e) {
            throw new ClassCastException("Calling fragment must implement ChangePasswordListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface ChangePasswordListener {
        void onPasswordsCaptured(String oldPassword, String newPassword);
    }

}
