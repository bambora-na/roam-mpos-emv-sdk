/*
 * //////////////////////////////////////////////////////////////////////////////
 * //
 * // Copyright (c) 2016 ROAM, Inc. All rights reserved.
 * //
 * //////////////////////////////////////////////////////////////////////////////
 */

package com.ingenico.mpos.app.sample;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.Locale;

/**
 * Created by nkonda on 6/16/16.
 */
public class ClerkIdDialogFragment extends DialogFragment {
    private static final String ARG_DIALOG_MSG = "ARG_DIALOG_MSG";
    private static final String ARG_CAPTURE_TOKEN_FEE = "ARG_CAPTURE_TOKEN_FEE";
    private static final String ARG_CAN_UPDATE_TOKEN = "ARG_CAN_UPDATE_TOKEN";
    private static final String ARG_CAN_SET_CUSTOM_REF = "ARG_CAN_SET_CUSTOM_REF";
    private static final String ARG_CACHED_TOKEN_ID = "ARG_CACHED_TOKEN_ID";
    private static final String ARG_AVS_ONLY = "ARG_AVS_ONLY";
    private static final String ARG_CAN_SET_TRANSACTION_NOTE = "ARG_CAN_SET_TRANSACTION_NOTE";
    private static final String ARG_CAN_SET_ORDER_NUMBER = "ARG_CAN_SET_ORDER_NUMBER";
    private static final String ARG_CAN_VALIDATE_EXPIRY_DATE = "ARG_CAN_VALIDATE_EXPIRY_DATE";
    private static final String ARG_IS_CARD_READER_KEYED= "ARG_IS_CARD_READER_KEYED";
    private static final String ARG_SHOW_NOTE_AND_INVOICE_ON_RECEIPT = "ARG_SHOW_NOTE_AND_INVOICE_ON_RECEIPT";
    private static final String ARG_ORIG_TXN_ID = "ARG_ORIG_TXN_ID";

    private ClerkIdDialogListener mListener;
    private EditText etClerkId;
    private EditText etTokenFee;
    private EditText etTokenId;
    private EditText etCustomRef;
    private EditText etAvsZipCode;
    private EditText etAvsAddress;
    private EditText etTransactionNote;
    private EditText etOrderNumber;
    private EditText etOrigTxnId;
    private CheckBox cbValidateExpiryDate;
    private CheckBox cbRequestAVS;
    private CheckBox cbRequestCVV;
    private CheckBox cbCardPresent;
    private CheckBox cbShowNoteAndInvoiceOnReceipt;


    private View view;
    private String mMessage;
    private boolean mCaptureTokenFee;
    private boolean mCanSetCustomRef;
    private boolean mCanUpdateToken;
    private boolean mAvsOnly;
    private boolean mCanSetTransactionNote;
    private boolean mCanSetOrderNumber;
    private boolean mCanValidateExpiryDate;
    private String mCachedTokenId;
    private boolean mIsCardReaderKeyed;
    private boolean mShowNoteAndInvoiceOnReceipt;
    private String mOrigTxnId;

    public ClerkIdDialogFragment() {
        // Required empty public constructor
    }

    private static ClerkIdDialogFragment newInstance(
            String message,
            boolean captureTokenFee,
            boolean canUpdateToken,
            boolean canSetCustomRef,
            boolean avsOnly,
            boolean canSetTransactionNote,
            boolean canSetOrderNumber,
            String cachedTokenId,
            boolean canValidateExpiryDate,
            boolean isCardReaderKeyed,
            boolean showNoteAndInvoiceOnReceipt,
            String origTxnId
    ) {
        ClerkIdDialogFragment fragment = new ClerkIdDialogFragment();
        Bundle args = new Bundle();
        args.putString(ARG_DIALOG_MSG, message);
        args.putBoolean(ARG_CAPTURE_TOKEN_FEE, captureTokenFee);
        args.putBoolean(ARG_CAN_SET_CUSTOM_REF, canSetCustomRef);
        args.putString(ARG_CACHED_TOKEN_ID, cachedTokenId);
        args.putBoolean(ARG_CAN_UPDATE_TOKEN, canUpdateToken);
        args.putBoolean(ARG_AVS_ONLY, avsOnly);
        args.putBoolean(ARG_CAN_SET_TRANSACTION_NOTE, canSetTransactionNote);
        args.putBoolean(ARG_CAN_SET_ORDER_NUMBER, canSetOrderNumber);
        args.putBoolean(ARG_CAN_VALIDATE_EXPIRY_DATE, canValidateExpiryDate);
        args.putBoolean(ARG_IS_CARD_READER_KEYED, isCardReaderKeyed);
        args.putBoolean(ARG_SHOW_NOTE_AND_INVOICE_ON_RECEIPT, showNoteAndInvoiceOnReceipt);
        args.putString(ARG_ORIG_TXN_ID, origTxnId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mMessage = getArguments().getString(ARG_DIALOG_MSG);
            mCaptureTokenFee = getArguments().getBoolean(ARG_CAPTURE_TOKEN_FEE);
            mCanSetCustomRef = getArguments().getBoolean(ARG_CAN_SET_CUSTOM_REF);
            mCachedTokenId = getArguments().getString(ARG_CACHED_TOKEN_ID);
            mCanUpdateToken = getArguments().getBoolean(ARG_CAN_UPDATE_TOKEN);
            mAvsOnly = getArguments().getBoolean(ARG_AVS_ONLY);
            mCanSetTransactionNote = getArguments().getBoolean(ARG_CAN_SET_TRANSACTION_NOTE);
            mCanSetOrderNumber = getArguments().getBoolean(ARG_CAN_SET_ORDER_NUMBER);
            mCanValidateExpiryDate = getArguments().getBoolean(ARG_CAN_VALIDATE_EXPIRY_DATE);
            mIsCardReaderKeyed = getArguments().getBoolean(ARG_IS_CARD_READER_KEYED);
            mShowNoteAndInvoiceOnReceipt = getArguments().getBoolean(ARG_SHOW_NOTE_AND_INVOICE_ON_RECEIPT);
            mOrigTxnId = getArguments().getString(ARG_ORIG_TXN_ID);
        }
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        LayoutInflater inflater = getActivity().getLayoutInflater();
        view = inflater.inflate(R.layout.dialog_clerk_id, null);
        etClerkId = (EditText) view.findViewById(R.id.dialog_clerk_et_id);
        etTokenFee = (EditText) view.findViewById(R.id.dialog_clerk_token_fee);
        etTokenId = (EditText) view.findViewById(R.id.dialog_clerk_token_id);
        etCustomRef = (EditText) view.findViewById(R.id.dialog_clerk_et_custom_ref);
        etAvsZipCode = (EditText) view.findViewById(R.id.dialog_clerk_et_avs_zip_code);
        etAvsAddress = (EditText) view.findViewById(R.id.dialog_clerk_et_avs_address);
        etTransactionNote = (EditText) view.findViewById(R.id.dialog_transaction_note);
        etOrderNumber = (EditText) view.findViewById(R.id.dialog_et_order_number);
        cbValidateExpiryDate = (CheckBox) view.findViewById(R.id.dialog_clerk_validate_expiry_date);
        cbRequestAVS = (CheckBox) view.findViewById(R.id.dialog_clerk_request_avs);
        cbRequestCVV = (CheckBox) view.findViewById(R.id.dialog_clerk_request_CVV);
        cbCardPresent = (CheckBox) view.findViewById(R.id.dialog_clerk_card_present);
        cbShowNoteAndInvoiceOnReceipt = (CheckBox) view.findViewById(R.id.dialog_clerk_show_note_and_invoice_on_receipt);
        etOrigTxnId = view.findViewById(R.id.dialog_clerk_et_original_txn_id);
        Spinner localeSpinner = view.findViewById(R.id.dialog_clerk_locale);
        localeSpinner.setAdapter(new Utils.CustomArrayAdapter(getActivity(), IngenicoConstants.SUPPORTED_LOCALES));

        if (mCaptureTokenFee) {
            etTokenFee.setVisibility(View.VISIBLE);
        }
        if (!mCanSetCustomRef) {
            etCustomRef.setVisibility(View.GONE);
        }
        if (mCanUpdateToken) {
            etTokenId.setVisibility(View.VISIBLE);
            if (mCachedTokenId != null) {
                etTokenId.setText(mCachedTokenId);
            }
        }
        if (mAvsOnly) {
            etAvsZipCode.setVisibility(View.VISIBLE);
            etAvsAddress.setVisibility(View.VISIBLE);
        }
        if (mCanSetTransactionNote) {
            etTransactionNote.setVisibility(View.VISIBLE);
        }
        if (!mCanSetOrderNumber) {
            etOrderNumber.setVisibility(View.GONE);
        }
        if (!mCanValidateExpiryDate) {
            cbValidateExpiryDate.setVisibility(View.GONE);
        }
        else {
            cbValidateExpiryDate.setChecked(true);
        }
        if (mIsCardReaderKeyed) {
            cbRequestCVV.setVisibility(View.VISIBLE);
            cbRequestAVS.setVisibility(View.VISIBLE);
            cbCardPresent.setVisibility(View.VISIBLE);
        }
        else {
            cbRequestCVV.setVisibility(View.GONE);
            cbRequestAVS.setVisibility(View.GONE);
            cbCardPresent.setVisibility(View.GONE);
        }
        if (!mShowNoteAndInvoiceOnReceipt) {
            cbShowNoteAndInvoiceOnReceipt.setVisibility(View.GONE);
        }
        if(!TextUtils.isEmpty(mOrigTxnId)) {
            etOrigTxnId.setVisibility(View.VISIBLE);
            etOrigTxnId.setText(mOrigTxnId);
            etOrigTxnId.setSelection(mOrigTxnId.length());
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(getString(R.string.str_dialog_common_title))
                .setMessage(mMessage)
                .setView(view)
                .setPositiveButton(
                        R.string.str_common_btn_ok,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                InputMethodManager
                                        inputManager =
                                        (InputMethodManager) getActivity().getSystemService(
                                                Context.INPUT_METHOD_SERVICE
                                        );
                                inputManager.hideSoftInputFromWindow(
                                        view.getWindowToken(),
                                        InputMethodManager.HIDE_NOT_ALWAYS
                                );
                                mListener.onClerkIdCaptured(etOrigTxnId.getText().toString(),
                                        etClerkId.getText().toString(),
                                        etTokenFee.getText().toString(),
                                        etTokenId.getText().toString(),
                                        etCustomRef.getText().toString(),
                                        etAvsZipCode.getText().toString(),
                                        etAvsAddress.getText().toString(),
                                        etTransactionNote.getText().toString(),
                                        etOrderNumber.getText().toString(),
                                        cbValidateExpiryDate.isChecked(),
                                        cbRequestAVS.isChecked(),
                                        cbRequestCVV.isChecked(),
                                        cbCardPresent.isChecked(),
                                        cbShowNoteAndInvoiceOnReceipt.isChecked(),
                                        (Locale)localeSpinner.getSelectedItem()
                                );
                            }
                        });
        return builder.create();
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mListener = (ClerkIdDialogListener) getTargetFragment();
        } catch (ClassCastException e) {
            throw new ClassCastException("Calling fragment must implement ClerkIdDialogListener");
        }
    }

    public interface ClerkIdDialogListener {
        void onClerkIdCaptured(String originalTxnId, String clerkId, String tokenFee, String tokenId,
                String customReference, String avsZipCode, String avsAddress,
                String transactionNote, String orderNumber, boolean validateExpiryDate,
                boolean requestAVS, boolean requestCVV, boolean cardPresent,
                boolean showNoteAndInvoiceOnReceipt, Locale locale);
    }

    public static class Builder {
        private String mMessage;
        private boolean mCaptureTokenFee;
        private boolean mCanUpdateToken;
        private boolean mCanSetCustomRef;
        private boolean mAvsOnly;
        private boolean mCanSetTransactionNote;
        private boolean mCanSetOrderNumber;
        private boolean mCanValidateExpiryDate;
        private String mCachedTokenId;
        private boolean mIsCardReaderKeyed;
        private boolean mShowNoteAndInvoiceOnReceipt;
        private String mOrigTxnId;

        public Builder setMessage(String message) {
            mMessage = message;
            return this;
        }

        public Builder setCanCaptureTokenFee(boolean captureTokenFee) {
            mCaptureTokenFee = captureTokenFee;
            return this;
        }

        public Builder setCanUpdateToken(boolean canUpdateToken) {
            mCanUpdateToken = canUpdateToken;
            return this;
        }

        public Builder setCanSetCustomRef(boolean canSetCustomRef) {
            mCanSetCustomRef = canSetCustomRef;
            return this;
        }

        public Builder setCachedTokenId(String cachedTokenId) {
            mCachedTokenId = cachedTokenId;
            return this;
        }

        public Builder setAvsOnly(boolean avsOnly) {
            mAvsOnly = avsOnly;
            return this;
        }

        public Builder setCanSetTransactionNote(boolean canSetTransactionNote) {
            mCanSetTransactionNote = canSetTransactionNote;
            return this;
        }

        public Builder setOrderNumber(boolean canSetOrderNumber) {
            mCanSetOrderNumber = canSetOrderNumber;
            return this;
        }

        public Builder setCanValidateExpiryDate(boolean canValidateExpiryDate) {
            this.mCanValidateExpiryDate = canValidateExpiryDate;
            return this;
        }

        public Builder setIsCardReaderKeyed(boolean isCardReaderKeyed) {
            this.mIsCardReaderKeyed = isCardReaderKeyed;
            return this;
        }

        public Builder setShowNoteAndInvoiceOnReceipt(boolean showNoteAndInvoiceOnReceipt) {
            mShowNoteAndInvoiceOnReceipt = showNoteAndInvoiceOnReceipt;
            return this;
        }

        public Builder setOrigTxnId(String origTxnId) {
            this.mOrigTxnId = origTxnId;
            return this;
        }

        public ClerkIdDialogFragment build() {
            return ClerkIdDialogFragment.newInstance(
                    mMessage,
                    mCaptureTokenFee,
                    mCanUpdateToken,
                    mCanSetCustomRef,
                    mAvsOnly,
                    mCanSetTransactionNote,
                    mCanSetOrderNumber,
                    mCachedTokenId,
                    mCanValidateExpiryDate,
                    mIsCardReaderKeyed,
                    mShowNoteAndInvoiceOnReceipt,
                    mOrigTxnId);
        }
    }
}
