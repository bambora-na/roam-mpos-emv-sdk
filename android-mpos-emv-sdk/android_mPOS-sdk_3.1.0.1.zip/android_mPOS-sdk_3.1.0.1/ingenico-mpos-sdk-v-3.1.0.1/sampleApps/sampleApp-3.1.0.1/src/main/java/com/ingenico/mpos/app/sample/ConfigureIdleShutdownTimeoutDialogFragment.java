/*
 * //////////////////////////////////////////////////////////////////////////////
 * //
 * // Copyright (c) 2017 ROAM, Inc. All rights reserved.
 * //
 * //////////////////////////////////////////////////////////////////////////////
 */

package com.ingenico.mpos.app.sample;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

public class ConfigureIdleShutdownTimeoutDialogFragment extends DialogFragment{

    private View mView;
    private ConfigureIdleShutdownTimeoutDialogListener mListener;

    public ConfigureIdleShutdownTimeoutDialogFragment() {
        // Required empty public constructor
    }

    public static ConfigureIdleShutdownTimeoutDialogFragment newInstance() {
        ConfigureIdleShutdownTimeoutDialogFragment fragment = new ConfigureIdleShutdownTimeoutDialogFragment();
        return fragment;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        LayoutInflater inflater = getActivity().getLayoutInflater();
        mView = inflater.inflate(R.layout.dialog_configure_idle_timeout_dialog, null);
        final EditText etTimeout = (EditText) mView.findViewById(R.id.dialog_configure_idle_shutdown_et_timeout);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Enter Idle Shutdown Timeout")
                .setView(mView)
                .setPositiveButton(
                        R.string.str_common_btn_ok,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                InputMethodManager
                                        inputManager =
                                        (InputMethodManager) getActivity().getSystemService(
                                                Context.INPUT_METHOD_SERVICE
                                        );
                                inputManager.hideSoftInputFromWindow(
                                        mView.getWindowToken(),
                                        InputMethodManager.HIDE_NOT_ALWAYS
                                );
                                int timeout = 0;
                                try {
                                    timeout = Integer.parseInt(etTimeout.getText().toString());
                                } catch (NumberFormatException e) {};
                                mListener.onTimeoutCaptured(timeout);
                            }
                        });
        return builder.create();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            mListener = (ConfigureIdleShutdownTimeoutDialogListener) getTargetFragment();
        } catch (ClassCastException e) {
            throw new ClassCastException("Calling fragment must implement ConfigureBeepDialogListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface ConfigureIdleShutdownTimeoutDialogListener {
        void onTimeoutCaptured(int timeout);
    }
}
