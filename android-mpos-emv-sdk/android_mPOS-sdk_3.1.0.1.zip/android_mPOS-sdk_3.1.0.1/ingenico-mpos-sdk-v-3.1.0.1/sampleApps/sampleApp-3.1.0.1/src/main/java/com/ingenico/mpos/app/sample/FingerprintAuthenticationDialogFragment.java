/*
 * Copyright (c) 2018. All Rights Reserved, ROAM Data, Inc.
 */

package com.ingenico.mpos.app.sample;

import android.app.AlertDialog;
import android.app.Dialog;
import androidx.fragment.app.DialogFragment;
import android.content.Context;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * A dialog which uses fingerprint APIs to authenticate the user
 */
public class FingerprintAuthenticationDialogFragment extends DialogFragment
        implements FingerprintHelper.FingerprintHelperListener {

    private Button mCancelButton;
    private View mView;
    private TextView mAuthDescriptionTextView;
    private String title;

    private Stage mStage = Stage.FINGERPRINT;

    private FingerprintManager.CryptoObject mCryptoObject;
    private FingerprintHelper mFingerprintHelper;
    private LoginFragment mFragment;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Do not create a new Fragment when the Activity is re-created such as orientation changes.
        setRetainInstance(true);
        setStyle(DialogFragment.STYLE_NORMAL, android.R.style.Theme_Material_Light_Dialog);
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        LayoutInflater inflater = getActivity().getLayoutInflater();
        mView = inflater.inflate(R.layout.dialog_fingerprint_auth, null);
        mCancelButton = mView.findViewById(R.id.cancel_button);
        mAuthDescriptionTextView = mView.findViewById(R.id.auth_description);
        mFingerprintHelper = new FingerprintHelper(
                getActivity().getSystemService(FingerprintManager.class),
                mView.findViewById(R.id.fingerprint_icon),
                mView.findViewById(R.id.fingerprint_status), this);
        mCancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mStage == Stage.NEW_USER_AUTH) {
                    mFragment.newUserFingerprintLogin(mCryptoObject, false);
                }
                dismiss();
            }
        });
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        updateStage();
        builder.setTitle(title).setView(mView);
        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        return dialog;
    }

    @Override
    public void onResume() {
        super.onResume();
        mFingerprintHelper.startListening(mCryptoObject);
    }

    public void setStage(Stage stage) {
        mStage = stage;
    }

    @Override
    public void onPause() {
        super.onPause();
        mFingerprintHelper.stopListening();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        Fragment f = getFragmentManager().findFragmentById(R.id.activity_main_content);
        if (f instanceof LoginFragment) {
            mFragment = (LoginFragment) f;
        }
    }

    /**
     * Sets the crypto object to be passed in when authenticating with fingerprint.
     */
    public void setCryptoObject(FingerprintManager.CryptoObject cryptoObject) {
        mCryptoObject = cryptoObject;
    }

    private void updateStage() {
        switch (mStage) {
            case FINGERPRINT:
                title = getString(R.string.sign_in);
                mCancelButton.setText(R.string.use_password);
                mAuthDescriptionTextView.setVisibility(View.GONE);
                break;
            case NEW_USER_AUTH:
                title = getString(R.string.enable_fingerprint);
                mCancelButton.setText(R.string.cancel);
                break;
        }
    }

    @Override
    public void authenticationFailed() {
        dismiss();
    }

    @Override
    public void authenticationSucceeded() {
        if (mStage == Stage.NEW_USER_AUTH) {
            mFragment.newUserFingerprintLogin(mCryptoObject, true);
        }
        else {
            mFragment.decryptFromFingerprint(mCryptoObject);
        }
        dismiss();

    }

    /**
     * Enumeration to indicate which authentication method the user is trying to authenticate with.
     */
    public enum Stage {
        FINGERPRINT,
        NEW_USER_AUTH
    }
}