package com.ingenico.mpos.app.sample;

import android.app.Activity;
import android.os.Bundle;
import android.os.Looper;
import android.text.TextUtils;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.StringDef;
import androidx.fragment.app.Fragment;

import com.ingenico.mpos.app.sample.common.logger.Log;
import com.ingenico.mpos.sdk.Ingenico;
import com.ingenico.mpos.sdk.constants.POSEntryMode;
import com.ingenico.mpos.sdk.constants.ProgressMessage;
import com.ingenico.mpos.sdk.constants.ResponseCode;
import com.ingenico.mpos.sdk.data.TokenResponseParameters;
import com.ingenico.mpos.sdk.response.TransactionResponse;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public abstract class FragmentBase extends Fragment {
    @Retention(RetentionPolicy.SOURCE)
    @StringDef({DEVICE_TYPE,
            TRANSACTION_TYPE,
            CARD_TYPE,
            TRANSACTION_STATUS,
            PAYMENT_SOURCE,
            OPTIONAL_FIELDS})
    public @interface FilterType {}
    public static final String DEVICE_TYPE = "Device Type";
    public static final String TRANSACTION_TYPE = "Transaction Type";
    public static final String CARD_TYPE = "Card Type";
    public static final String TRANSACTION_STATUS = "Transaction Status";
    public static final String PAYMENT_SOURCE = "Payment Source";
    public static final String OPTIONAL_FIELDS = "Optional Fields";

    protected ProgressDialogListener mProgressDialogListener;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                getActivity().onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

        if (activity instanceof ProgressDialogListener) {
            mProgressDialogListener = (ProgressDialogListener) activity;
        } else {
            throw new IllegalArgumentException(
                    "Activity must implemement ParseOnLoadingListener");
        }
    }

    public void onBackPressed() {

    }

    protected List<String> getSelectedOptionStrings(Map<String, Boolean> optionSelectionMap) {
        List<String> selectedOptions = new ArrayList<>();
        for (Object option : optionSelectionMap.keySet()) {
            if (optionSelectionMap.get(option)) {
                selectedOptions.add(option.toString());
            }
        }
        return selectedOptions;
    }

    void showToast(String message) {
        showToast(message, Toast.LENGTH_SHORT);
    }

    void showToast(String message, int duration) {
        if (isAdded()) {
            ((MainActivity)getActivity()).showToast(message, duration);
        }
    }

    protected void loadingStart(String message) {
        if (mProgressDialogListener != null) {
            mProgressDialogListener.showProgressMessage(message);
        }
    }

    protected void loadingFinish() {
        if (mProgressDialogListener != null) {
            mProgressDialogListener.hideProgress();
        }
    }

    protected boolean isMainThread() {
        return (Looper.myLooper() == Looper.getMainLooper());
    }

    protected void logTransactionResponse(String tag, TransactionResponse response) {
        Log.v(tag, "Response : " + (BuildConfig.showResultDialogs ? response.toString() : response.toString().replaceAll(
                "\\*", "X")));
    }
}
