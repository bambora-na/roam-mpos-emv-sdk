package com.ingenico.mpos.app.sample;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

public class GetUsernameDialogFragment extends DialogFragment {

    private GetUsernameDialogListener mListener;

    private View mView;
    private EditText etUsername;

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        mView = getActivity().getLayoutInflater().inflate(R.layout.dialog_get_username, null);
        etUsername = (EditText) mView.findViewById(R.id.dialog_get_username_et_username);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(getString(R.string.str_dialog_common_title))
                .setView(mView)
                .setPositiveButton(
                        R.string.str_common_btn_ok,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                InputMethodManager
                                        inputManager =
                                        (InputMethodManager) getActivity().getSystemService(
                                                Context.INPUT_METHOD_SERVICE
                                        );
                                inputManager.hideSoftInputFromWindow(
                                        mView.getWindowToken(),
                                        InputMethodManager.HIDE_NOT_ALWAYS
                                );
                                mListener.onUsernameCaptured(etUsername.getText().toString());
                            }
                        }
                ).setNegativeButton(
                R.string.str_common_btn_cancel,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dismiss();
                    }
                }
        );
        return builder.create();
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mListener = (GetUsernameDialogListener) getTargetFragment();
        } catch (ClassCastException e) {
            throw new ClassCastException("Calling fragment must implement GetEmailDialogListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface GetUsernameDialogListener {
        void onUsernameCaptured(String username);
    }
}
