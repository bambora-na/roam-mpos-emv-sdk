package com.ingenico.mpos.app.sample;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class IngenicoConstants {
    public final static String URL = "https://uatmcm.roamdata.com";
    public final static List<Locale> SUPPORTED_LOCALES = Arrays.asList(Locale.US, Locale.CANADA, Locale.CANADA_FRENCH);
}
