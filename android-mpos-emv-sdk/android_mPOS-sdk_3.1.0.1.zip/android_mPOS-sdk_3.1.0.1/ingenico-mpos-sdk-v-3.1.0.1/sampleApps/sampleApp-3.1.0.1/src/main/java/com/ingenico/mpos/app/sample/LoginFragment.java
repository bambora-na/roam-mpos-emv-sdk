package com.ingenico.mpos.app.sample;

import android.app.Activity;
import android.app.KeyguardManager;
import android.content.Context;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;
import android.os.Bundle;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyPermanentlyInvalidatedException;
import android.security.keystore.KeyProperties;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentActivity;
import android.util.Base64;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.ingenico.mpos.app.sample.common.logger.Log;
import com.ingenico.mpos.sdk.Ingenico;
import com.ingenico.mpos.sdk.callbacks.ForgotPasswordCallback;
import com.ingenico.mpos.sdk.constants.ResponseCode;

import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;

public class LoginFragment extends FragmentBase implements View.OnClickListener,
        GetUsernameDialogFragment.GetUsernameDialogListener {
    private final static String TAG = LoginFragment.class.getSimpleName();
    private static final String ARG_USER_NAME = "ARG_USER_NAME";

    private static final String KEY_ALIAS = "ingenico";
    private static final String KEYSTORE = "AndroidKeyStore";
    public static final String PREFERENCES_KEY_FINGERPRINTUSER = "fingerprintUser";
    public static final String PREFERENCES_KEY_FINGERPRINTPASS = "fingerprintPass";
    public static final String PREFERENCES_KEY_FINGERPRINTIV = "fingerprintIV";

    private String mUsername;
    private String mPassword;
    private OnFragmentInteractionListener mListener;

    private EditText etUsername;
    private EditText etPassword;
    private CheckBox cbOfflineMode;

    private KeyStore mKeyStore;
    private Cipher mCipher;
    public LoginFragment() {
        // Required empty public constructor
    }

    public static LoginFragment newInstance(String username) {
        LoginFragment fragment = new LoginFragment();
        Bundle args = new Bundle();
        args.putString(ARG_USER_NAME, username);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mUsername = getArguments().getString(ARG_USER_NAME);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login, container, false);
        TextView tvForgotPwd = (TextView) view.findViewById(R.id.fragment_login_tv_forgot_password);
        etUsername = (EditText) view.findViewById(R.id.fragment_login_et_username);
        etPassword = (EditText) view.findViewById(R.id.fragment_login_et_password);
        cbOfflineMode = (CheckBox) view.findViewById(R.id.fragment_login_cb_offline_mode);
        Button btnLogin = (Button) view.findViewById(R.id.fragment_login_btn_login);
        Button btnLoginFingerprint = (Button) view.findViewById(R.id.fragment_login_btn_login_fingerprint);
        btnLogin.setOnClickListener(this);
        tvForgotPwd.setOnClickListener(this);
        Log.d(TAG, "mUsername::" + mUsername);
        etUsername.setText(mUsername);
        etPassword.setOnEditorActionListener(
                new TextView.OnEditorActionListener() {
                    @Override
                    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                        if (actionId == EditorInfo.IME_ACTION_DONE) {
                            doLogin();
                            return true;
                        }
                        return false;
                    }
                }
        );
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            btnLoginFingerprint.setOnClickListener(this);
            FingerprintManager fingerprintManager = getActivity().getSystemService(
                    FingerprintManager.class);
            if (fingerprintManager != null && fingerprintManager.isHardwareDetected()) {
                btnLoginFingerprint.setVisibility(View.VISIBLE);
            }
        }
        return view;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mListener = (OnFragmentInteractionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onBackPressed() {
        Activity activity = this.getActivity();
        if (activity != null && activity.getCurrentFocus() != null) {
            InputMethodManager imm = (InputMethodManager)activity.getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (R.id.fragment_login_btn_login == id) {
            doLogin();
        } else if (R.id.fragment_login_tv_forgot_password == id) {
            showEmailDialog();
        } else if (R.id.fragment_login_btn_login_fingerprint == id && hasFingerprintEnabled(true)) {
            doFingerprintLogin();
        }
    }

    @Override
    public void onUsernameCaptured(String username) {
        mProgressDialogListener.showProgressMessage("Requesting password reset...");
        Ingenico.getInstance().user().forgotPassword(username, new ForgotPasswordCallbackImpl());
    }

    private void generateKeyStoreKey(boolean forceNewKey) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return;
        }
        try {
            mKeyStore = KeyStore.getInstance(KEYSTORE);
            mCipher = Cipher.getInstance(KeyProperties.KEY_ALGORITHM_AES + "/"
                    + KeyProperties.BLOCK_MODE_CBC + "/"
                    + KeyProperties.ENCRYPTION_PADDING_PKCS7);

            mKeyStore.load(null);
            if (mKeyStore.containsAlias(KEY_ALIAS)) {
                if (forceNewKey) {
                    mKeyStore.deleteEntry(KEY_ALIAS);

                }
                else {
                    return;
                }
            }
            KeyGenerator keyGenerator = KeyGenerator
                    .getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE);

            // Set the alias of the entry in Android KeyStore where the key will appear
            // and the constrains (purposes) in the constructor of the Builder

            KeyGenParameterSpec.Builder builder = new KeyGenParameterSpec.Builder(KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT |
                            KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_CBC)
                    // Require the user to authenticate with a fingerprint to authorize every use
                    // of the key
                    .setUserAuthenticationRequired(true)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_PKCS7);
            keyGenerator.init(builder.build());
            keyGenerator.generateKey();
        } catch (IOException | CertificateException | NoSuchAlgorithmException |
                InvalidAlgorithmParameterException | NoSuchPaddingException | NoSuchProviderException
                | KeyStoreException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to initialize key", e);
        }
    }

    private boolean initCipher(int CipherMode) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return false;
        }
        try {
            SecretKey key = (SecretKey) mKeyStore.getKey(KEY_ALIAS, null);
            if (CipherMode == Cipher.ENCRYPT_MODE) {
                mCipher.init(CipherMode, key);
                PrefHelper.set(
                        getActivity().getApplicationContext(), PREFERENCES_KEY_FINGERPRINTIV,
                        android.util.Base64.encodeToString(mCipher.getIV(), Base64.URL_SAFE)
                );
            }
            else {
                byte[] iv = android.util.Base64.decode(PrefHelper.get(getActivity().getApplicationContext(),
                        PREFERENCES_KEY_FINGERPRINTIV, null), Base64.URL_SAFE);
                if (iv != null) {
                    IvParameterSpec ivspec = new IvParameterSpec(iv);
                    mCipher.init(CipherMode, key, ivspec);
                }
            }
            return true;
        } catch (KeyPermanentlyInvalidatedException | KeyStoreException |
                UnrecoverableKeyException e) {
            deviceSecurityChanged();
            return false;
        } catch (InvalidKeyException | InvalidAlgorithmParameterException |
                NoSuchAlgorithmException e) {
            throw new RuntimeException("Failed to init Cipher", e);
        }
    }

    private void deviceSecurityChanged() {
        if (userRegistered()) {
            PrefHelper.remove(getActivity().getApplicationContext(), PREFERENCES_KEY_FINGERPRINTUSER);
            PrefHelper.remove(getActivity().getApplicationContext(), PREFERENCES_KEY_FINGERPRINTPASS);
            PrefHelper.remove(getActivity().getApplicationContext(), PREFERENCES_KEY_FINGERPRINTIV);
            // lock screen was reset or new fingerprint was enrolled
            showToast(
                    "Device security changed. Fingerprint has been added or lock screen has been "
                            + "disabled. Please enter your password again");
        }
        if (hasFingerprintEnabled(false)) {
            generateKeyStoreKey(true);
        }
    }

    private void doFingerprintLogin() {
        View view = getActivity().getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(
                    FragmentActivity.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
        mUsername = etUsername.getText().toString();
        mPassword = etPassword.getText().toString();
        generateKeyStoreKey(false);
        if (!userRegistered()) {
            if (mPassword.isEmpty()) {
                showToast("This user is not fingerprint enabled\n\nPlease enable fingerprint authentication by "
                        + "entering the password and clicking 'Fingerprint Login'");
                return;
            }
            mListener.login(
                    mUsername,
                    mPassword,
                    cbOfflineMode.isChecked(),
                    true
            );
        }
        else {
            if (initCipher(Cipher.DECRYPT_MODE)) {
                showFingerprintAuthDialog(FingerprintAuthenticationDialogFragment.Stage.FINGERPRINT);
            }
        }
    }

    void decryptFromFingerprint(FingerprintManager.CryptoObject cryptoObject) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return;
        }
        mPassword = PrefHelper.get(getActivity().getApplicationContext(), PREFERENCES_KEY_FINGERPRINTPASS,
                null);
        byte[] bytes = android.util.Base64.decode(mPassword, Base64.NO_WRAP);
        try {
            mPassword = new String(cryptoObject.getCipher().doFinal(bytes));
        } catch (BadPaddingException e) {
            throw new RuntimeException("Failed to decrypt password", e);
        } catch (IllegalBlockSizeException e) {
            deviceSecurityChanged();
            return;
        }
        mListener.login(mUsername, mPassword, cbOfflineMode.isChecked(), true);
    }

    private boolean userRegistered() {
        String username = PrefHelper.get(getActivity().getApplicationContext(),
                PREFERENCES_KEY_FINGERPRINTUSER, null);
        if ( username == null || !username.equals(mUsername)) {
            return false;
        }
        return true;
    }

    private void doLogin() {
        mProgressDialogListener.showProgressMessage("Logging in...");
        mUsername = etUsername.getText().toString();
        mPassword = etPassword.getText().toString();
        View view = getActivity().getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(
                    FragmentActivity.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
        mListener.login(
                mUsername,
                mPassword,
                cbOfflineMode.isChecked(),
                false
        );
    }

    private boolean hasFingerprintEnabled(boolean showToast) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return false;
        }
        KeyguardManager keyguardManager = getActivity().getSystemService(KeyguardManager.class);
        if (!keyguardManager.isKeyguardSecure()) {
            // Show a message that the user hasn't set up a fingerprint or lock screen.
            if (showToast) {
                showToast("User has not enabled Lock Screen\n" +
                                "Go to 'Settings -> Security -> Fingerprint' to set up lock screen",
                        Toast.LENGTH_LONG);
            }
            return false;
        }
        if (!getActivity().getSystemService(FingerprintManager.class).hasEnrolledFingerprints()) {
            // This happens when no fingerprints are registered.
            if (showToast) {
                showToast("Go to 'Settings -> Security -> Fingerprint' and register at least one" +
                                " fingerprint",
                        Toast.LENGTH_LONG);
            }
            return false;
        }
        return true;
    }

    private void showFingerprintAuthDialog(FingerprintAuthenticationDialogFragment.Stage stage) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return;
        }
        FingerprintAuthenticationDialogFragment fragment = new FingerprintAuthenticationDialogFragment();
        fragment.setCryptoObject(new FingerprintManager.CryptoObject(mCipher));
        fragment.setStage(stage);
        fragment.show(getFragmentManager(),
                FingerprintAuthenticationDialogFragment.class.getSimpleName());
    }

    public void newUserFingerprintLogin(FingerprintManager.CryptoObject cryptoObject, boolean
            saveNewUser) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return;
        }
        if (saveNewUser) {
            PrefHelper.set(
                    getActivity().getApplicationContext(),
                    PREFERENCES_KEY_FINGERPRINTUSER,
                    mUsername
            );
            try {
                byte[] encrypted = cryptoObject.getCipher().doFinal(mPassword.getBytes());
                PrefHelper.set(
                        getActivity().getApplicationContext(),
                        PREFERENCES_KEY_FINGERPRINTPASS,
                        android.util.Base64.encodeToString(encrypted, Base64.NO_WRAP)
                );
            } catch (BadPaddingException e) {
                throw new RuntimeException("Failed to encrypt password", e);
            } catch (IllegalBlockSizeException e) {
                deviceSecurityChanged();
                return;
            }
        }
        mListener.newFingerprintUserLoggedIn();
    }

    private void showEmailDialog() {
        DialogFragment dialogFragment = new GetUsernameDialogFragment();
        dialogFragment.setTargetFragment(this, 0);
        dialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
    }

    void loginSuccess() {
        if (initCipher(Cipher.ENCRYPT_MODE)) {
            showFingerprintAuthDialog(
                    FingerprintAuthenticationDialogFragment.Stage.NEW_USER_AUTH);
            return;
        }
        // try this twice in case device security has changed so that the user doesn't have to
        // hit the login button again
        if (initCipher(Cipher.ENCRYPT_MODE)) {
            showFingerprintAuthDialog(
                    FingerprintAuthenticationDialogFragment.Stage.NEW_USER_AUTH);
        }
    }

    public interface OnFragmentInteractionListener {
        void login(String username, String password, boolean offline, boolean fingerprintLogin);
        void newFingerprintUserLoggedIn();
    }

    private class ForgotPasswordCallbackImpl implements ForgotPasswordCallback {
        @Override
        public void done(Integer responseCode) {
            Log.v(TAG, "ForgotPasswordCallback::done::" + responseCode);
            mProgressDialogListener.hideProgress();
            if (ResponseCode.Success == responseCode) {
                showToast("Success");
            } else {
                showToast("Failed");
            }
        }
    }
}
