package com.ingenico.mpos.app.sample;

import android.Manifest;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewAnimator;

import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.snackbar.Snackbar;
import com.ingenico.mpos.app.sample.common.ConnectivityChangeReceiver;
import com.ingenico.mpos.app.sample.common.CpocHelper;
import com.ingenico.mpos.app.sample.common.activities.SampleActivityBase;
import com.ingenico.mpos.app.sample.common.logger.Log;
import com.ingenico.mpos.app.sample.common.logger.LogFragment;
import com.ingenico.mpos.app.sample.common.logger.LogWrapper;
import com.ingenico.mpos.app.sample.common.logger.MessageOnlyLogFilter;
import com.ingenico.mpos.app.sample.helpers.Moby5500PairingHelper;
import com.ingenico.mpos.sdk.Ingenico;
import com.ingenico.mpos.sdk.callbacks.CheckDeviceSetupCallback;
import com.ingenico.mpos.sdk.callbacks.CheckFirmwareUpdateCallback;
import com.ingenico.mpos.sdk.callbacks.DeviceSetupWithProgressCallback;
import com.ingenico.mpos.sdk.callbacks.DeviceStatusAndEMVConfigurationHandler;
import com.ingenico.mpos.sdk.callbacks.LoginCallback;
import com.ingenico.mpos.sdk.callbacks.LoginOfflineCallback;
import com.ingenico.mpos.sdk.callbacks.LogoffCallback;
import com.ingenico.mpos.sdk.callbacks.PingCallback;
import com.ingenico.mpos.sdk.callbacks.UpdateFirmwareCallback;
import com.ingenico.mpos.sdk.callbacks.UserActionResponseCallback;
import com.ingenico.mpos.sdk.constants.FirmwareUpdateAction;
import com.ingenico.mpos.sdk.constants.ResponseCode;
import com.ingenico.mpos.sdk.constants.TransactionType;
import com.ingenico.mpos.sdk.data.Capabilities;
import com.ingenico.mpos.sdk.data.FirmwareInfo;
import com.ingenico.mpos.sdk.data.TransactionQuery;
import com.ingenico.mpos.sdk.data.UserProfile;
import com.ingenico.mpos.sdk.response.TransactionResponse;
import com.roam.roamreaderunifiedapi.callback.AudioJackPairingListenerWithDevice;
import com.roam.roamreaderunifiedapi.callback.DeviceStatusHandler;
import com.roam.roamreaderunifiedapi.callback.ReleaseHandler;
import com.roam.roamreaderunifiedapi.callback.TurnOnDeviceCallback;
import com.roam.roamreaderunifiedapi.constants.CommunicationType;
import com.roam.roamreaderunifiedapi.constants.DeviceType;
import com.roam.roamreaderunifiedapi.data.Device;
import com.tbruyelle.rxpermissions2.RxPermissions;

import java.util.ArrayList;
import java.util.List;

public final class MainActivity extends SampleActivityBase
        implements ActivityCompat.OnRequestPermissionsResultCallback,
        DeviceStatusAndEMVConfigurationHandler,
        ReleaseHandler,
        AudioJackPairingListenerWithDevice,
        ProgressDialogListener,
        LogFragment.OnFragmentInteractionListener,
        PaymentApiFragment.OnFragmentInteractionListener,
        FragmentManager.OnBackStackChangedListener,
        BaseSetupFragment.OnFragmentInteractionListener,
        MainFragment.OnFragmentInteractionListener,
        LoginFragment.OnFragmentInteractionListener,
        MerchantFragment.OnFragmentInteractionListener,
        PaymentDeviceFragment.OnFragmentInteractionListener,
        SelectDeviceFragment.OnFragmentInteractionListener,
        SetSecurityQuestionsFragment.OnFragmentInteractionListener,
        TransactionHistoryFilterFragment.OnFragmentInteractionListener,
        ConnectivityChangeReceiver.Listener,
        StoreAndForwardFragment.OnFragmentInteractionListener,
        TransactionHistoryFragment.OnFragmentInteractionListener {

    private final static String TAG = MainActivity.class.getSimpleName();

    private final List<DeviceType> audioJackDeviceTypes = new ArrayList<>();
    private List<DeviceType> usbDeviceTypes = new ArrayList<>();
    private View mLayout;
    private String mAPIKey;
    private String mHostname;
    private int mLocaleIndex;
    private CommunicationType mCommType;
    private String mUsername;
    private String mPassword;
    private boolean mOffline;
    private String mLog;
    private TransactionResponse mCachedTransactionResponse;
    private TransactionType mCachedTransactionType;
    private int mCachedTransactionResponseCode;
    private String mCachedRefundableCreditTransactionId;
    private String mCachedTokenId;
    // Whether the Log Fragment is currently shown
    private boolean mLogShown;
    private boolean mIsMainFragmentVisible = false;
    private boolean mIsConnected = false;
    private boolean mUserLoggedIn = false;
    private boolean mIsUsbFwUpdate;
    private boolean mIsCancelledByUser;
    private ProgressDialog progressDialog;
    private ProgressDialog transactionProgressDialog;
    private AlertDialog pairConfirmationDialog;
    private TextView tvDeviceConnectionStatus;
    private ProgressBar pbAutoConnectionProgress;
    private TextView tvSessionToken;
    private FragmentBase fragmentBase;
    private Device mSelectedDevice;
    private UserProfile mCurrentUserProfile;
    private boolean mUseFingerprintLogin;
    private DeviceStatusHandler mAudiojackPairingDeviceStatusHandler = null;
    private boolean mIsPaused;
    private boolean rp450cPaired;
    private String mCachedTransactionId;

    private final BroadcastReceiver autoConnectionDiscoveryReceiver = new BroadcastReceiver() {

        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (BluetoothAdapter.ACTION_DISCOVERY_STARTED.equals(action)) {
                Log.d("AUTOCONNECT", "Bluetooth discovery started");
            }
            if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                // restart discovery
                Log.d("AUTOCONNECT", "No device found, restarting");
                stopDiscoveryForAutoConnection();
                startDiscoveryForAutoConnection();
            } else if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                pbAutoConnectionProgress.setVisibility(View.VISIBLE);
                if (mSelectedDevice != null &&
                        mSelectedDevice.getIdentifier().equals(device.getAddress())) {
                    Log.d("AUTOCONNECT", "Auto Connecting to discoveredDevice::" + mSelectedDevice);
                    pbAutoConnectionProgress.setVisibility(View.INVISIBLE);
                    stopDiscoveryForAutoConnection();
                    tvDeviceConnectionStatus.setText("Device Status : Reconnecting..");
                    connectToReader(mSelectedDevice);
                }
            }
            else if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(action)) {
                Log.d(TAG, "Usb device attached");
                UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                if (mSelectedDevice != null &&
                        mSelectedDevice.getName().equals(device.getDeviceName())) {
                    Log.d("AUTOCONNECT", "Auto Connecting to discoveredDevice::" + mSelectedDevice);
                    stopDiscoveryForAutoConnection();
                    connectToReader(mSelectedDevice);
                }
            }
        }
    };

    {
        audioJackDeviceTypes.add(DeviceType.RP450c);
    }

    public static IntentFilter getBluetoothAndUsbDiscoveryIntent() {
        IntentFilter bluetoothAndUsbDiscoveryIntentFilter = new IntentFilter();
        bluetoothAndUsbDiscoveryIntentFilter.addAction(BluetoothDevice.ACTION_FOUND);
        bluetoothAndUsbDiscoveryIntentFilter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        bluetoothAndUsbDiscoveryIntentFilter.addAction("android.hardware.usb.action.USB_DEVICE_ATTACHED");
        bluetoothAndUsbDiscoveryIntentFilter.addAction("android.hardware.usb.action.USB_DEVICE_DETACHED");
        return bluetoothAndUsbDiscoveryIntentFilter;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mLayout = findViewById(R.id.activity_main_root_layout);
        tvDeviceConnectionStatus = (TextView) findViewById(R.id.activity_main_tv_device_status);
        pbAutoConnectionProgress = (ProgressBar) findViewById(R.id.activity_main_pb_auto_conn);
        tvSessionToken = (TextView) findViewById(R.id.activity_main_tv_session_token);
        mUsername = PrefHelper.get(getApplicationContext(), PrefHelper.USER_NAME, "");
        mHostname = PrefHelper.get(getApplicationContext(), PrefHelper.HOST_NAME,
                IngenicoConstants.URL);
        mAPIKey = PrefHelper.get(getApplicationContext(), PrefHelper.API_KEY,
                BuildConfig.API_KEY);
        mCommType = CommunicationType.getEnum(PrefHelper.get(getApplicationContext(), PrefHelper.COMM_TYPE,
                CommunicationType.AudioJack.toString()));
        mLocaleIndex = PrefHelper.get(getApplicationContext(), PrefHelper.LOCALE_INDEX, 0).intValue();
        if (null == savedInstanceState || !mUserLoggedIn) {
            replaceContentFragment(
                    SetupFragment.newInstance(
                            mCommType, mAPIKey, mHostname,
                            mLocaleIndex),
                    false
            );
        }

        ConnectivityChangeReceiver.getInstance().startup(this);

        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportFragmentManager().addOnBackStackChangedListener(this);
    }



    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if ("com.ingenico.STICKSHIFT".equals(intent.getAction())) {
            CpocHelper.doStickShiftTransaction(intent, mCurrentUserProfile.getSession().getSessionToken(),
                    PrefHelper.get(getApplicationContext(), PrefHelper.HOST_NAME,
                    IngenicoConstants.URL), getApplicationContext());
        } else {
            Uri intentData = intent.getData();
            replaceContentFragment(MainFragment.newInstance(), true);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public void onAttachFragment(Fragment fragment) {
        super.onAttachFragment(fragment);
        if (fragment instanceof FragmentBase) {
            fragmentBase = (FragmentBase) fragment;
        }
    }

    @Override
    public void onBackPressed() {
        fragmentBase.onBackPressed();
        super.onBackPressed();
    }

    @Override
    public void onResume() {
        super.onResume();
        ConnectivityChangeReceiver.getInstance().register(this);
        if (0 < getSupportFragmentManager().getBackStackEntryCount()) {
            showUpNavigationIndicator();
        }
        mIsPaused = false;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem logToggle = menu.findItem(R.id.menu_toggle_log);
        logToggle.setVisible(
                findViewById(R.id.activity_main_sample_output) instanceof ViewAnimator);
        logToggle.setTitle(mLogShown ? R.string.sample_hide_log : R.string.sample_show_log);
        MenuItem offlineIndicator = menu.findItem(R.id.menu_offline);
        offlineIndicator.setVisible(!ConnectivityChangeReceiver.getInstance().hasConnectivity());
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_toggle_log:
                mLogShown = !mLogShown;
                if (mLogShown) {
                    hideUpNavigationIndicator();
                } else if (!mIsMainFragmentVisible) {
                    showUpNavigationIndicator();
                }
                ViewAnimator output = (ViewAnimator) findViewById(R.id.activity_main_sample_output);
                if (mLogShown) {
                    output.setDisplayedChild(1);
                } else {
                    output.setDisplayedChild(0);
                }
                supportInvalidateOptionsMenu();
                return true;
            case R.id.menu_logoff:
                showProgressMessage("Logging off...");
                mSelectedDevice = null;
                View view = this.getCurrentFocus();
                if (view != null) {
                    InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                }
                Ingenico.getInstance().user().logOff(
                        new LogoffCallbackImpl()
                );
                return true;
            case R.id.menu_ping:
                Ingenico.getInstance().ping(new PingCallback() {
                    @Override
                    public void done(Integer responseCode) {
                        if (responseCode == ResponseCode.Success) {
                            Log.v(TAG, "ping " + responseCode);
                            Utils.newDialog(MainActivity.this,
                                    "Success",
                                    "Ping succeeded").show();
                        } else {
                            Utils.newDialog(MainActivity.this,
                                    "Error",
                                    "Ping failed with error " + responseCode).show();
                        }
                    }
                });
                break;
            case R.id.menu_about:
                showAbout();
                return true;
            case R.id.menu_clear:
                PrefHelper.clear(getApplicationContext());
                return true;
            case R.id.test_crash:
                throw new RuntimeException("Test Crash");
            case android.R.id.home:
                final Fragment f = getSupportFragmentManager().findFragmentById(R.id.activity_main_content);
                if (f instanceof LoginFragment) {
                    clearBackStack();
                    replaceContentFragment(SetupFragment.newInstance(
                            mCommType,
                            mAPIKey,
                            mHostname, mLocaleIndex),
                            false);
                    if (isDeviceConnected()) {
                        showProgressMessage("Disconnecting...");
                    }
                    Ingenico.getInstance().device().release(this::hideProgress);
                    return true;
                }
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * Create a chain of targets that will receive log data
     */
    @Override
    public void initializeLogging() {
        // Wraps Android's native log framework.
        LogWrapper logWrapper = new LogWrapper();
        // Using Log, front-end to the logging chain, emulates android.util.log method signatures.
        Log.setLogNode(logWrapper);

        // Filter strips out everything except the message text.
        MessageOnlyLogFilter msgFilter = new MessageOnlyLogFilter();
        logWrapper.setNext(msgFilter);

        // On screen logging via a fragment with a TextView.
        LogFragment logFragment = (LogFragment) getSupportFragmentManager()
                .findFragmentById(R.id.activity_main_log_fragment);
        msgFilter.setNext(logFragment.getLogView());
    }

    @Override
    public void onStart() {
        super.onStart();
        Ingenico.getInstance().device().registerConnectionStatusUpdates(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        Ingenico.getInstance().device().unregisterConnectionStatusUpdates(this);
        ConnectivityChangeReceiver.getInstance().cleanup();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Ingenico.getInstance().release();
        if (progressDialog != null) {
            progressDialog.dismiss();
        }
        if (transactionProgressDialog != null){
            transactionProgressDialog.dismiss();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        ConnectivityChangeReceiver.getInstance().unregister(this);
        mIsPaused = true;
    }

    @Override
    public void onBackStackChanged() {
        FragmentManager fragmentManager = getSupportFragmentManager();
        if (null != fragmentManager) {
            int backStackEntries = fragmentManager.getBackStackEntryCount();
            if (backStackEntries == 0 || mIsMainFragmentVisible) {
                hideUpNavigationIndicator();
            } else {
                showUpNavigationIndicator();
            }
        }
    }

    private void checkFirmwareUpdate(final boolean continueWithSetup) {
        if (mUserLoggedIn
                && Ingenico.getInstance().device().connected()) {
            showProgressMessage("Checking if firmware update is required");
            Ingenico.getInstance().device().checkFirmwareUpdate(new CheckFirmwareUpdateCallback() {
                @Override
                public void done(Integer responseCode, final FirmwareUpdateAction action, FirmwareInfo firmwareInfo) {
                    hideProgress();
                    if (responseCode == ResponseCode.Success) {
                        Log.v(TAG, "Firmware update " + action.toString() + '\n' + String.valueOf(firmwareInfo));
                        if (action == FirmwareUpdateAction.Required || action == FirmwareUpdateAction.Optional){
                            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this)
                                    .setTitle("Update Firmware")
                                    .setMessage("Update Firmware " + action.toString());
                            if (continueWithSetup) {
                                builder.setPositiveButton("Update", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {
                                            try {
                                                if (Ingenico.getInstance().device().getActiveCommunicationType() == CommunicationType.AudioJack &&
                                                        action != FirmwareUpdateAction.Required) {
                                                    showToast("Firmware update is not supported via Audiojack. Please connect via Bluetooth or USB and try again.");
                                                    Log.v(TAG, "Firmware update is not supported via Audiojack. Please connect via Bluetooth or USB and try again. Continuing with setup");
                                                    checkDeviceSetup();
                                                } else {
                                                    doFirmwareUpdate();
                                                }
                                            } catch (IllegalStateException e) {
                                                showToast("Device is not connected");
                                            }
                                        }
                                    })
                                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {
                                            if(action != FirmwareUpdateAction.Required) {
                                                checkDeviceSetup();
                                            }
                                        }
                                    });
                            } else {
                                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        dialogInterface.dismiss();
                                    }
                                });
                            }
                            builder.create().show();
                        } else {
                            if (continueWithSetup) {
                                checkDeviceSetup();
                            } else {
                                showToast("Firmware update not required");
                            }
                        }
                    } else {
                        hideProgress();
                        Utils.newDialog(MainActivity.this,
                                "Error",
                                "Check Firmware Update Complete failed with error " + responseCode).show();
                    }
                }
            });
        } else {
            showToast("User not logged in or Device is not connected");
        }
    }

    private void doFirmwareUpdate() {
        if (!mUserLoggedIn) {
            showToast("User not logged in");
        } else if (!Ingenico.getInstance().device().connected()) {
            showToast("Device is not connected.");
        } else if (Ingenico.getInstance().device().getActiveCommunicationType() != CommunicationType.AudioJack) {
            showProgressMessage("Starting firmware update");
            if (Ingenico.getInstance().device().getActiveCommunicationType() == CommunicationType.Usb) {
                mIsUsbFwUpdate = true;
            }
            Ingenico.getInstance().device().updateFirmware(new UpdateFirmwareCallback() {
                @Override
                public void downloadProgress(Long downloadedSize, Long totalFileSize) {
                    Log.v(TAG, String.format("File download %d/%d", downloadedSize, totalFileSize));
                    showProgressMessage(String.format("Downloading firmware %d/%d bytes", downloadedSize, totalFileSize));
                }

                @Override
                public void updateProgress(Integer current, Integer total) {
                    Log.v(TAG, String.format("Firmware update %d/%d", current, total));
                    showFirmwareUpdateProgressMessageWithCancelButton(
                            String.format("Updating firmware %d/%d", current, total)
                    );
                }

                @Override
                public void done(Integer responseCode) {
                    hideProgress();
                    String title = "Firmware Update Complete";
                    String msg;
                    AlertDialog dialog;
                    if (responseCode == ResponseCode.Success) {
                        msg = "Firmware update successful";
                        dialog = Utils.newDialog(MainActivity.this, title, msg);
                        // No need to check for device setup because device will be rebooted when firmware update succeeds
                        // and reconnection will trigger check for device setup
                    } else {
                        msg = "Firmware update failed with error " + responseCode;
                        dialog = Utils.newDialog(MainActivity.this,
                                title,
                                msg,
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        checkDeviceSetup();
                                    }
                                });
                    }
                    Log.v(TAG, msg);
                    dialog.show();
                }
            });
        } else {
            showToast("Firmware update is not supported via Audiojack. Please connect via Bluetooth or USB and try again.");
            Log.v(TAG, "Firmware update is not supported via Audiojack. Please connect via Bluetooth or USB and try again.");
        }
    }

    private void promptForDeviceSetup(boolean isDeviceSetupRequired) {
        Log.i(TAG, isDeviceSetupRequired ? "Setup required" : "Setup recommended");
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this)
                .setTitle(isDeviceSetupRequired ? "Setup" : "Setup recommended")
                .setMessage(isDeviceSetupRequired ? "Setup Required" : "Setup recommended")
                .setPositiveButton("Setup", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        doDeviceSetup();
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });
        builder.create().show();
    }

    private void checkDeviceSetup() {
        if (mUserLoggedIn
                && Ingenico.getInstance().device().connected()) {
            showProgressMessage("Checking if device setup is required");
            Ingenico.getInstance().device().checkDeviceSetup(new CheckDeviceSetupCallback() {
                @Override
                public void done(Integer responseCode, Boolean isSetupRequired) {
                    hideProgress();
                    if (responseCode == ResponseCode.Success) {
                        if (isSetupRequired) {
                            promptForDeviceSetup(true);//device set up is requird or device will be capable of MSR only
                        } else if (!Ingenico.getInstance().getCurrentCapabilities().isEMVConfigUptoDate()){
                            promptForDeviceSetup(false);//device set up is recommended but device will still be capable of EMV
                        } else {
                            Log.i(TAG, "Setup not required");
                            showToast("Setup not required");
                        }
                    } else {
                        Utils.newDialog(MainActivity.this,
                                "Error",
                                "Check device setup failed with " + responseCode).show();
                    }
                }
            });
        } else {
            showToast("User not logged in or Device is not connected");
        }
    }

    private void doDeviceSetup() {
        if (mUserLoggedIn
                && Ingenico.getInstance().device().connected()) {
            showProgressMessage("Setting up your card reader...");
            Ingenico.getInstance().device().setup(
                    new DeviceSetupWithProgressCallback() {
                        @Override
                        public void done(Integer responseCode) {
                            Log.d(TAG, "DeviceSetupWithProgressCallback::done::" + responseCode);
                            hideProgress();
                            showSetupCompleteDialog(responseCode);
                        }

                        @Override
                        public void setupProgress(int cur, int total) {
                            Log.v(TAG, String.format("Device setup %d/%d", cur, total));
                            showProgressMessage(String.format("Setting up your card reader %d/%d", cur, total));
                        }
                    }
            );
        } else {
            showToast("User not logged in or Device is not connected");
        }
    }

    private void pairWithRP450c() {
        if (rp450cPaired) {
            return;
        }
        showProgressMessage("Requesting to pair with your card reader...");
        Ingenico.getInstance().device().requestPairing(this);
    }

    /**
     * AudioJackPairingListener Implementation
     */
    @Override
    public void onPairConfirmation(String readerPasskey, String mobilePasskey, Device device) {
        hideProgress();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.str_dialog_pair_confirm_title);
        builder.setMessage(
                String.format(getString(R.string.str_dialog_pair_confirm_message),
                        mobilePasskey,
                        readerPasskey));
        builder.setPositiveButton(getString(R.string.str_dialog_pair_confirm_positive),
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Ingenico.getInstance().device().confirmPairing(true);
                        dialog.dismiss();
                        showProgressMessage("Finishing pairing...");
                    }
                });
        builder.setNegativeButton(getString(R.string.str_dialog_pair_confirm_negative),
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Ingenico.getInstance().device().confirmPairing(false);
                        dialog.dismiss();
                        showProgressMessage("Cancelling pairing...");
                    }
                });
        AlertDialog dialog = builder.create();
        pairConfirmationDialog = dialog;
        dialog.show();
    }

    @Override
    public void onPairSucceeded(Device device) {
        hideProgress();
        tvDeviceConnectionStatus.setText("Device Status : RP450c paired");
        connectToReader(device);
        showToast(
                "Pairing Successful",
                Toast.LENGTH_SHORT
        );
        rp450cPaired = true;
        replaceContentFragment(LoginFragment.newInstance(mUsername), true);
        mSelectedDevice = device;
        if(mIsConnected){
            mIsConnected = false;
        }
    }

    @Override
    public void onPairNotSupported() {
        hideProgress();
        showToast(
                "Pairing not supported by this device manager.",
                Toast.LENGTH_SHORT
        );
    }

    @Override
    public void onPairFailed() {
        hideProgress();
        if (pairConfirmationDialog != null && pairConfirmationDialog.isShowing()) {
            pairConfirmationDialog.dismiss();
        }
        showToast(
                "Pairing failed.",
                Toast.LENGTH_SHORT
        );
    }

    /**
     * DeviceStatusHandler Implementation
     */
    @Override
    public void onConnected() {
        hideProgress();
        if(mIsConnected){
            return;
        }
        Log.v(TAG, Utils.SEPARATOR);
        Log.i(TAG, "Card Reader Connected");
        if (null != mSelectedDevice) {
            stopDiscoveryForAutoConnection();
        }
        final Fragment f = getSupportFragmentManager().findFragmentById(R.id.activity_main_content);
        if (f instanceof SetupFragment) {
            showProgressMessage("Disconnecting...");
            Ingenico.getInstance().device().release(this::hideProgress);
            stopDiscoveryForAutoConnection();
            mSelectedDevice = null;     //prevent auto-connection when on initial URL screen
        }
        mIsConnected = true;
        tvDeviceConnectionStatus.setText("Device Status : Connected to " + Ingenico.getInstance().device().getType()
            + " via " + Ingenico.getInstance().device().getActiveCommunicationType());
        showToast("Connected", Toast.LENGTH_SHORT);
        if(Ingenico.getInstance().getPreference() == null || Ingenico.getInstance().getPreference().getConfigMode() == null){
            checkFirmwareUpdate(true);
        }
    }

    @Override
    public void onDisconnected() {
        hideProgress();
        Log.v(TAG, Utils.SEPARATOR);
        Log.w(TAG, "Card Reader Disconnected");
        Log.d("AUTOCONNECT", "ondisconnected mSelectedDevice is " + mSelectedDevice);
        if (null != mSelectedDevice) {
            if (mIsUsbFwUpdate) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Log.d(TAG, "connectToReader after firmware update via USB");
                        if (mCommType == CommunicationType.Usb) {
                            Ingenico.getInstance().device().initialize(getApplicationContext());
                        }
                        else {
                            connectToReader(mSelectedDevice);
                        }
                    }
                }, 10000);
                mIsUsbFwUpdate = false;
            } else  {
                startAutoConnection();
            }
        }
        mIsConnected = false;
        tvDeviceConnectionStatus.setText("Device Status : Disconnected");
        showToast("Disconnected", Toast.LENGTH_SHORT);
    }

    @Override
    public void onError(String s) {
        hideProgress();
        Log.v(TAG, Utils.SEPARATOR);
        Log.e(TAG, "Card Reader Connection Error");
        startAutoConnection();
        mIsConnected = false;
        tvDeviceConnectionStatus.setText("Device Status : Connection Error");
        showToast("Error", Toast.LENGTH_SHORT);
    }

    @Override
    public void onDetectionStarted() {
        Log.v(TAG, Utils.SEPARATOR);
        Log.w(TAG, "Card Reader DetectionStarted");
        tvDeviceConnectionStatus.setText("Device Status : Detection Started");
        showToast("Detection Started", Toast.LENGTH_SHORT);
    }

    @Override
    public void onDetectionStopped() {
        Log.v(TAG, Utils.SEPARATOR);
        Log.w(TAG, "Card Reader DetectionStopped");
        tvDeviceConnectionStatus.setText("Device Status : Detection Stopped");
        showToast("Detection Stopped", Toast.LENGTH_SHORT);
    }

    @Override
    public void performSetup(UserActionResponseCallback userActionResponseCallback) {
        showProgressMessage("Perform set up?");
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this)
                .setTitle("Setup")
                .setMessage("Setup Required")
                .setPositiveButton("Setup", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        userActionResponseCallback.canContinue(true);
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        userActionResponseCallback.canContinue(false);
                    }
                });
        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    @Override
    public void performFirmwareUpdate(FirmwareUpdateAction firmwareUpdateAction, UserActionResponseCallback userActionResponseCallback) {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this)
                .setTitle("Update Firmware")
                .setMessage("Update Firmware " + firmwareUpdateAction.toString())
                .setPositiveButton("Update", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        userActionResponseCallback.canContinue(true);
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        userActionResponseCallback.canContinue(false);
                    }
                });
        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    @Override
    public void onConfigured(Integer responseCode, Capabilities capabilities) {
        boolean EMVCapable = capabilities.isEMVCapable();
        Log.d(TAG, "on Configured, response code:" + responseCode + " EMV capable: " + capabilities.isEMVCapable());
        if (EMVCapable && !Ingenico.getInstance().getCurrentCapabilities().isEMVConfigUptoDate()){
            promptForDeviceSetup(false);//device set up is recommended but device will still be capable of EMV
        }else {
            showToast("Configured\nEMV Capable: " + EMVCapable + "\nResponse code: " + responseCode + "\nFW update action: " + Utils.getFirmwareUpdateActionString(capabilities.getFirmwareUpdateAction()), Toast.LENGTH_LONG);
        }
        hideProgress();
    }

    @Override
    public void onProgress(Integer progressCode, String additionalMessage) {
        if(progressCode == 1500) {
            showFirmwareUpdateProgressMessageWithCancelButton(
                    String.format(Utils.getProgressMessage(progressCode) + ", progress:" + additionalMessage)
            );
        }else{
            showProgressMessage(Utils.getProgressMessage(progressCode) + " " + additionalMessage);
        }
    }

    @Override
    public boolean isDeviceConnected() {
        return mIsConnected;
    }

    @Override
    public void cacheTransactionResponse(TransactionResponse transactionResponse,
            int responseCode) {
        // if transactionResponse is null, use the previous successful transaction
        if (transactionResponse != null) {
            mCachedTransactionResponse = transactionResponse;
            mCachedTransactionResponseCode = responseCode;
            if (transactionResponse.getTokenResponseParameters() != null
                    && transactionResponse.getTokenResponseParameters().getTokenIdentifier() != null
                    && !transactionResponse.getTokenResponseParameters().getTokenIdentifier().isEmpty()) {
                mCachedTokenId =
                        transactionResponse.getTokenResponseParameters().getTokenIdentifier();
            }
            mCachedTransactionId = transactionResponse.getTransactionId();
        }
    }

    @Override
    public TransactionResponse getCachedTransactionResponse() {
        return mCachedTransactionResponse;
    }

    @Override
    public int getCachedTransactionResponseCode() {
        return mCachedTransactionResponseCode;
    }

    @Override
    public void cacheTransactionType(TransactionType transactionType) {
        mCachedTransactionType = transactionType;
    }

    @Override
    public TransactionType getCachedTransactionType() {
        return mCachedTransactionType;
    }

    @Override
    public void cacheCreditRefundableTransactionId(String transactionId) {
        mCachedRefundableCreditTransactionId = transactionId;
    }

    @Override
    public String getCachedCreditRefundableTransactionId() {
        return mCachedRefundableCreditTransactionId;
    }

    @Override
    public String getCachedTokenId() {
        return mCachedTokenId;
    }

    @Override
    public boolean isCancelledByUser() {
        return mIsCancelledByUser;
    }

    @Override
    public void setUsbPrefDevices(List<DeviceType> usbDeviceTypes) {
        this.usbDeviceTypes = usbDeviceTypes;
    }

    /**
     * BaseSetupFragment OnFragmentInteractionListener Implementation
     */

    @Override
    public void setupIngenicoSDK(
            String apiKey,
            String baseURL,
            DeviceType deviceType,
            CommunicationType autoDetectCommtype,
            ArrayList<CommunicationType> manualSearchCommTypes
    ) {
        // Setup the SDK
        mHostname = baseURL;
        mAPIKey = apiKey;
        final Ingenico ingenico = Ingenico.getInstance();
        try {
            if (CommunicationType.AudioJack == autoDetectCommtype) {
                mCommType = CommunicationType.AudioJack;
                new RxPermissions(this)
                        .request(
                                Manifest.permission.RECORD_AUDIO,
                                Manifest.permission.MODIFY_AUDIO_SETTINGS
                        ).subscribe(
                                granted -> {
                                    if (granted) {
                                        Snackbar.make(mLayout,
                                                "Audio permission is available.",
                                                Snackbar.LENGTH_SHORT).show();
                                        ingenico.device().setAudioJackDeviceTypes(audioJackDeviceTypes);
                                        ingenico.device().initialize(getApplicationContext());
                                        showUpNavigationIndicator();
                                        replaceContentFragment(
                                                LoginFragment.newInstance(mUsername),
                                                true
                                        );
                                    }
                                },
                        error -> { releasingDeviceToast(); }
                );
            } else if (CommunicationType.Usb == autoDetectCommtype) {
                mCommType = CommunicationType.Usb;
                ingenico.device().setUSBDeviceTypes(usbDeviceTypes);
                ingenico.device().initialize(getApplicationContext());
                showUpNavigationIndicator();
                replaceContentFragment(
                        LoginFragment.newInstance(mUsername),
                        true
                );
            } else {
                mCommType = CommunicationType.Bluetooth;
                new RxPermissions(this)
                        .request(
                                Manifest.permission.RECORD_AUDIO,
                                Manifest.permission.MODIFY_AUDIO_SETTINGS,
                                Manifest.permission.BLUETOOTH,
                                Manifest.permission.BLUETOOTH_ADMIN,
                                Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION,
                                Manifest.permission.NFC
                        )
                        .subscribe(
                                granted -> {
                                    if (granted) {
                                        switch (deviceType) {
                                            case RP450c:
                                                Snackbar.make(mLayout,
                                                        "Bluetooth and Audio permissions are available.",
                                                        Snackbar.LENGTH_SHORT).show();
                                                ingenico.device().setDeviceType(DeviceType.RP450c);
                                                break;
                                            case RP45BT:
                                                Snackbar.make(mLayout,
                                                        "Bluetooth and Audio permissions are available.",
                                                        Snackbar.LENGTH_SHORT).show();
                                                ingenico.device().setDeviceType(DeviceType.RP45BT);
                                                break;
                                            case RP750x:
                                                Snackbar.make(mLayout,
                                                        "Bluetooth permission is available.",
                                                        Snackbar.LENGTH_SHORT).show();
                                                ingenico.device().setDeviceType(DeviceType.RP750x);
                                                break;
                                            case MOBY3000:
                                                Snackbar.make(mLayout,
                                                        "Bluetooth permission is available.",
                                                        Snackbar.LENGTH_SHORT).show();
                                                ingenico.device().setDeviceType(DeviceType.MOBY3000);
                                                break;
                                            case MOBY8500:
                                                Snackbar.make(mLayout,
                                                        "Bluetooth permission is available.",
                                                        Snackbar.LENGTH_SHORT).show();
                                                ingenico.device().setDeviceType(DeviceType.MOBY8500);
                                                break;
                                            case RP45USB:
                                                Snackbar.make(mLayout,
                                                        "Bluetooth permission is available.",
                                                        Snackbar.LENGTH_SHORT).show();
                                                ingenico.device().setDeviceType(DeviceType.RP45USB);
                                                break;
                                            case MOBY5500:
                                                Snackbar.make(mLayout,
                                                        "Bluetooth permission is available.",
                                                        Snackbar.LENGTH_SHORT).show();
                                                ingenico.device().setDeviceType(DeviceType.MOBY5500);
                                                break;
                                            case MOBYTAP:
                                                mCommType = CommunicationType.Local;
                                                Snackbar.make(mLayout,
                                                        "Bluetooth & NFC permission is available.",
                                                        Snackbar.LENGTH_SHORT).show();
                                                ingenico.device().setDeviceType(DeviceType.MOBYTAP);
                                            default:
                                                break;
                                        }
                                        showUpNavigationIndicator();
                                        if (manualSearchCommTypes != null && manualSearchCommTypes.size() > 0) {
                                            replaceContentFragment(
                                                    SelectDeviceFragment.newInstance(deviceType, manualSearchCommTypes),
                                                    true
                                            );
                                        } else {
                                            showToast("Please select atleast one communication type", Toast.LENGTH_LONG);
                                        }
                                    }
                                },
                                error -> { releasingDeviceToast(); }
                        );
            }
        } catch (IllegalStateException e) {
            releasingDeviceToast();
        } catch (IllegalArgumentException e) {
            showToast(
                    e.getMessage(),
                    Toast.LENGTH_LONG
            );
        }
    }

    @Override
    public void login(String username, String password, boolean offline, boolean fingerprint) {
        RxPermissions rxPermissions = new RxPermissions(this);
        rxPermissions
                .request(Manifest.permission.INTERNET)
                .subscribe(granted -> {
                    if (granted) {
                        mUsername = username;
                        mPassword = password;
                        mOffline = offline;
                        mUseFingerprintLogin = fingerprint;
                        doLogin();
                    } else {
                        // Oups permission denied
                    }
                });
    }

    @Override
    public void newFingerprintUserLoggedIn() {
        showUpNavigationIndicator();
        replaceContentFragment(MainFragment.newInstance(), true);
        if(Ingenico.getInstance().getPreference() == null || Ingenico.getInstance().getPreference().getConfigMode() == null){
            checkFirmwareUpdate(true);
        }
    }

    private void startAutoConnection() {
        Fragment currFragment = getSupportFragmentManager().findFragmentById(R.id.activity_main_content);
        if (null != mSelectedDevice &&
                !((currFragment instanceof SetupFragment)
                        || (currFragment instanceof LoginFragment))) {
            startDiscoveryForAutoConnection();
        }
    }

    private void releasingDeviceToast() {
        showToast(
                "Please Wait. Device resources are being released.",
                Toast.LENGTH_SHORT
        );
    }

    private void doLogin() {
        showProgressMessage("Logging in...");
        if (mOffline) {
            Ingenico.getInstance().storeAndForward().loginOffline(
                    mUsername,
                    mPassword,
                    new LoginOfflineCallbackImpl()
            );
        } else {
            Ingenico.getInstance().user().login(
                    mUsername,
                    mPassword,
                    new LoginCallbackImpl()
            );
        }
    }

    private void loginSuccess(String username) {
        mUsername = username;
        mUserLoggedIn = true;
        PrefHelper.set(
                getApplicationContext(),
                PrefHelper.USER_NAME,
                mUsername
        );
        if (mUseFingerprintLogin && !mUsername.equalsIgnoreCase(
                PrefHelper.get(getApplicationContext(), LoginFragment.PREFERENCES_KEY_FINGERPRINTUSER,
                        null))) {
            Fragment f = getSupportFragmentManager().findFragmentById(R.id.activity_main_content);
            if (f instanceof LoginFragment) {
                LoginFragment loginFragment = (LoginFragment) f;
                loginFragment.loginSuccess();
            }
        }
        else {
            showUpNavigationIndicator();
            replaceContentFragment(MainFragment.newInstance(), true);
            if(Ingenico.getInstance().getPreference() == null || Ingenico.getInstance().getPreference().getConfigMode() == null){
                checkFirmwareUpdate(true);
            }
        }
    }

    private void clearBackStack() {
        if (!mIsPaused) {
            FragmentManager manager = getSupportFragmentManager();
            if (manager.getBackStackEntryCount() > 0) {
                FragmentManager.BackStackEntry first = manager.getBackStackEntryAt(0);
                manager.popBackStack(first.getId(), FragmentManager.POP_BACK_STACK_INCLUSIVE);
            }
        }
    }

    private void showUpNavigationIndicator() {
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private void hideUpNavigationIndicator() {
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
    }

    private void replaceContentFragment(Fragment fragment, boolean addToBackStack) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(
                R.id.activity_main_content,
                fragment
        );
        if (addToBackStack) {
            fragmentTransaction.addToBackStack(fragment.getClass().getSimpleName());
        }
        fragmentTransaction.commitAllowingStateLoss();
    }

    @Override
    public void showProgressMessage(String msg) {
        String txt = TextUtils.isEmpty(msg) ? getString(R.string.progress_dialog_text) : msg;
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.setMessage(msg);
        } else {
            progressDialog = ProgressDialog.show(this, null, txt, true, false);
        }
    }

    @Override
    public void hideProgress() {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
        if (transactionProgressDialog != null && transactionProgressDialog.isShowing()) {
            transactionProgressDialog.dismiss();
        }
        mIsCancelledByUser = false;
    }

    @Override
    public void showFirmwareUpdateProgressMessageWithCancelButton(String message){
        transactionProgressDialog = showProgressMessageWithOnClickListener(transactionProgressDialog, message, new FirmwareUpdateOnClickListener());
    }

    @Override
    public void showTransactionProgressMessageWithCancelButton(String message){
        transactionProgressDialog = showProgressMessageWithOnClickListener(transactionProgressDialog, message, new AbortTransactionOnClickListener());
    }

    @Override
    public void showProgressMessageWithCancelButton(String message,
                                                    DialogInterface.OnClickListener listener) {
        progressDialog = showProgressMessageWithOnClickListener(progressDialog, message, listener);
    }

    @Override
    public void showImplicitDeviceSetupProgressMessage(String message, String extraMessage) {
        String txt = TextUtils.isEmpty(message) ? getString(R.string.progress_dialog_text) : message + " " + extraMessage;
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.setMessage(txt);
            String spl[]= extraMessage.split("/");
            int progress =Integer.parseInt(spl[0]);
            int total =Integer.parseInt(spl[1]);
            if(progress == total){
                progressDialog.hide();
            }
        } else {
            progressDialog = ProgressDialog.show(this, null, txt, true, false);
        }
    }

    public ProgressDialog showProgressMessageWithOnClickListener(ProgressDialog dialog,
                                                       String message,
                                                       DialogInterface.OnClickListener listener){
        String txt = TextUtils.isEmpty(message) ? getString(R.string.progress_dialog_text) : message;
        if (dialog != null && dialog.isShowing()) {
            dialog.setMessage(message);
        } else {
            dialog = new ProgressDialog(this);
            dialog.setMessage(txt);
            dialog.setCancelable(false);
            dialog.setIndeterminate(true);
            dialog.setTitle(null);
            dialog.setButton(DialogInterface.BUTTON_NEGATIVE, "Cancel", listener);
            dialog.show();
        }
        return dialog;
    }

    @Override
    public void onPaymentApiSelected() {
        replaceContentFragment(PaymentApiFragment.newInstance(), true);
    }

    @Override
    public void onPaymentDeviceApiSelected() {
        replaceContentFragment(PaymentDeviceFragment.newInstance(), true);
    }

    @Override
    public void onStoreAndForwardApiSelected() {
        replaceContentFragment(StoreAndForwardFragment.newInstance(), true);
    }

    @Override
    public void onMerchantApiSelected() {
        replaceContentFragment(MerchantFragment.newInstance(), true);
    }

    @Override
    public void onMainFragmentStarted() {
        mIsMainFragmentVisible = true;
    }

    @Override
    public void onMainFragmentStopped() {
        mIsMainFragmentVisible = false;
    }

    @Override
    public void onCheckDeviceSetup() {
        checkDeviceSetup();
    }

    @Override
    public void onSetupDevice() {
        doDeviceSetup();
    }

    @Override
    public void onCheckFirmwareUpdate() {
        checkFirmwareUpdate(false);
    }

    @Override
    public void onDoFirmwareUpdate() {
        doFirmwareUpdate();
    }

    private void connectToReader(final Device device) {
        Log.d(TAG, "connectToReader::" + device);
        if (null != device) {
            Ingenico.getInstance().device().select(device);
            if (device.getDeviceType() == DeviceType.MOBY5500) {
                Moby5500PairingHelper.connect(this, new Moby5500PairingHelper.UiCallback() {
                    @Override
                    public void onProgresssUpdate(String message) {
                        Log.v(TAG, message);
                        showProgressMessage(message);
                    }

                    @Override
                    public void onStatusUpdate(boolean pairingSuccess, String message) {
                        hideProgress();
                        if (pairingSuccess) {
                            tvDeviceConnectionStatus.setText("Device Status : MOBY5500 paired");
                        }
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                showToast(
                                        message,
                                        Toast.LENGTH_SHORT
                                );
                            }
                        });
                    }
                });
            } else if (device.getDeviceType() == DeviceType.MOBYTAP) {
                CpocHelper.initCpoc(this);
            } else {
                Ingenico.getInstance().device().initialize(getApplicationContext());
            }
        }
    }

    @Override
    public void onDeviceSelected(Device device) {
        mSelectedDevice = device;
        connectToReader(mSelectedDevice);
        replaceContentFragment(
                LoginFragment.newInstance(mUsername),
                true
        );
    }

    @Override
    public void onTurnOnDeviceButtonClicked() {
        if (isWiredHeadsetOn(getApplicationContext())) {
            Ingenico.getInstance().device().turnOnDeviceViaAudioJack(
                    getApplicationContext(),
                    new TurnOnDeviceCallback() {
                        @Override
                        public void success() {
                            showToast("Turn on Device Success");
                            Log.d(TAG, "Turn on Device Success");

                        }

                        @Override
                        public void failed(String s) {
                            showToast("Turn on Device Failed::" + s);
                            Log.d(TAG, "Turn on Device Failed::" + s);

                        }

                        @Override
                        public void notSupported() {
                            showToast("Turn on Device Not supported");
                            Log.d(TAG, "Turn on Device Not supported");
                        }
                    }
            );
        } else {
            showToast("Please plug in an RP450 into the audio jack");
        }
    }

    @Override
    public void onPairButtonClicked() {
        if (isWiredHeadsetOn(getApplicationContext())) {
            mAudiojackPairingDeviceStatusHandler = new AudioJackPairingConnectionStatusHandlerImpl();
            Ingenico.getInstance().device().registerConnectionStatusUpdates(mAudiojackPairingDeviceStatusHandler);
            Ingenico.getInstance().device().initialize(getApplicationContext());
            showProgressMessage("Connecting to RP450 via audiojack");
        } else {
            showToast(
                    "Cannot pair with card reader if it is not connected",
                    Toast.LENGTH_SHORT
            );
        }
    }

    @Override
    public void onSetSecurityQuestionsApiSelected() {
        replaceContentFragment(SetSecurityQuestionsFragment.newInstance(), true);
    }

    @Override
    public void onGetTransactionHistoryApiSelected() {
        replaceContentFragment(TransactionHistoryFilterFragment.newInstance(false), true);
    }

    @Override
    public void onGetTransactionInvoicesApiSelected() {
        replaceContentFragment(TransactionHistoryFilterFragment.newInstance(true), true);
    }

    @Override
    public void onTransactionFilterCriteriaCreated(TransactionQuery query) {
        replaceContentFragment(TransactionHistoryFragment.newInstance(query, false), true);
    }

    @Override
    public void onInvoiceFilterCriteriaCreated(TransactionQuery query) {
        replaceContentFragment(TransactionHistoryFragment.newInstance(query, true), true);
    }

    @Override
    public void onSecurityQuestionsAnswered() {
        replaceContentFragment(MerchantFragment.newInstance(), true);
    }

    @Override
    public void sendEmail(String log) {
        mLog = log;
        new RxPermissions(this)
                .request(
                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.READ_EXTERNAL_STORAGE
                )
                .subscribe(
                        granted -> {
                            if (granted) {
                                Snackbar.make(mLayout,
                                        "Storage permission is available.",
                                        Snackbar.LENGTH_SHORT).show();
                                new SendEmailTask(
                                        this,
                                        mLog
                                ).executeTask();
                            }
                        }
                );
    }

    @Override
    public void done() {
        Log.d(TAG, "ReleaseHandler::done");
        onDisconnected();
    }

    private void releaseSDK() {
        Ingenico.getInstance().release(this);
    }

    private void showSetupCompleteDialog(Integer responseCode) {
        Utils.newDialog(
                this,
                "Setup Complete",
                (responseCode == ResponseCode.Success) ? "Setup Success" : "Setup Failed with error " + responseCode
        ).show();
    }

    private void showAbout() {
        View messageView = getLayoutInflater().inflate(R.layout.dialog_about, null, false);


        TextView textView = messageView.findViewById(R.id.dialog_about_device_info);
        int defaultColor = textView.getTextColors().getDefaultColor();
        textView.setTextColor(defaultColor);
        textView.setText(Utils.getAboutInfo(this));

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setTitle(R.string.app_name);
        builder.setView(messageView);
        builder.create();
        builder.show();
    }

    private boolean isDiscoveryInProgress() {
        return null != BluetoothAdapter.getDefaultAdapter()
                && BluetoothAdapter.getDefaultAdapter().isDiscovering();
    }

    private void startDiscoveryForAutoConnection() {
        if (Utils.isBluetoothEnabled()) {
            Log.d("AUTOCONNECT", "registering discovery receiver");
            registerReceiver(autoConnectionDiscoveryReceiver, getBluetoothAndUsbDiscoveryIntent());
            if (isDiscoveryInProgress()) {
                Log.d("AUTOCONNECT", "discovery in progress, stopping");
                BluetoothAdapter.getDefaultAdapter().cancelDiscovery();
            }
            Log.d("AUTOCONNECT", "starting discovery");
            BluetoothAdapter.getDefaultAdapter().startDiscovery();
        } else {
            Log.d("AUTOCONNECT", "Bluetooth disabled,unregistering discovery receiver & stopping discovery");
            stopDiscoveryForAutoConnection();
        }
    }

    private void stopDiscoveryForAutoConnection() {
        Log.d("AUTOCONNECT", "stopDiscoveryForAutoConnection");
        try {
            unregisterReceiver(autoConnectionDiscoveryReceiver);
        } catch (Exception e) {
            // ok to ignore
        }
        BluetoothAdapter.getDefaultAdapter().cancelDiscovery();
    }

    private void updateOfflineIndicator() {
        invalidateOptionsMenu();
    }

    @Override
    public void hasConnectivity() {
        updateOfflineIndicator();
    }

    @Override
    public void noConnectivity() {
        updateOfflineIndicator();
    }

    @Override
    public void setCachedTransactionId(String transactionId) {
        mCachedTransactionId = transactionId;
    }

    @Override
    public String getCachedTransactionId() {
        return mCachedTransactionId;
    }

    private class FirmwareUpdateOnClickListener implements DialogInterface.OnClickListener {
        @Override
        public void onClick(DialogInterface var1, int var2){
            Log.d(TAG, "Firmware update cancelled by user");
            Ingenico.getInstance().device().cancelFirmwareUpdate();
            transactionProgressDialog.dismiss();
        }
    }

    private class AbortTransactionOnClickListener implements DialogInterface.OnClickListener {
        @Override
        public void onClick(DialogInterface var1, int var2){
            Log.d(TAG, "Transaction cancelled by user");
            mIsCancelledByUser = true;
            Ingenico.getInstance().payment().abortTransaction();
            transactionProgressDialog.dismiss();
            showProgressMessage("Cancelling...");
        }
    }

    private class LogoffCallbackImpl implements LogoffCallback {
        @Override
        public void done(Integer responseCode) {
            Log.v(TAG, "LogoffCallback::done::" + responseCode);
            mUserLoggedIn = false;
            clearBackStack();
            hideProgress();
            replaceContentFragment(SetupFragment.newInstance(
                    mCommType, mAPIKey, mHostname, mLocaleIndex),
                    false
            );
            releaseSDK();
            if (ResponseCode.Success == responseCode) {
                showToast(
                        "Logged off successfully.",
                        Toast.LENGTH_SHORT
                );
            } else {
                showToast(
                        "Logged off failed.",
                        Toast.LENGTH_SHORT
                );
            }
            tvSessionToken.setText("");
        }
    }

    private class LoginCallbackImpl implements LoginCallback {
        @Override
        public void done(Integer responseCode, UserProfile user) {
            Log.v(TAG, "LoginCallback::done::" + responseCode);
            String msg;
            hideProgress();
            if (ResponseCode.Success == responseCode) {
                mCurrentUserProfile = user;
                tvSessionToken.setText(user.getSession().getSessionToken());
                loginSuccess(mUsername);
                msg = "Logged in as " + mUsername;
                Log.v(TAG, user.toString());
            } else if (ResponseCode.InvalidCredentials == responseCode) {
                msg = "Invalid credentials";
                // User has changed password on backend, remove stored fingerprint-encrypted password
                if (mUseFingerprintLogin) {
                    PrefHelper.remove(getApplicationContext(), LoginFragment.PREFERENCES_KEY_FINGERPRINTUSER);
                    PrefHelper.remove(getApplicationContext(), LoginFragment.PREFERENCES_KEY_FINGERPRINTPASS);
                    PrefHelper.remove(getApplicationContext(), LoginFragment.PREFERENCES_KEY_FINGERPRINTIV);
                }
            } else if (ResponseCode.AccountLocked == responseCode) {
                msg = "Account Locked - please try again later or reset password";
            } else {
                msg = "Login failed";
            }
            Log.v(TAG, msg);
            Log.v(TAG, Utils.SEPARATOR);
            showToast(msg);
        }
    }

    private class LoginOfflineCallbackImpl implements LoginOfflineCallback {
        @Override
        public void done(Integer responseCode) {
            Log.v(TAG, "LoginOfflineCallback::done::" + responseCode);
            String msg;
            hideProgress();
            if (ResponseCode.Success == responseCode) {
                tvSessionToken.setText(R.string.offline_authenticated);
                loginSuccess(mUsername);
                msg = "Logged in as " + mUsername;
            } else if (ResponseCode.InvalidCredentials == responseCode) {
                msg = "Invalid credentials";
            } else if (ResponseCode.StoreAndForwardNotEnabled == responseCode) {
                msg = "User has not completed online login or user profile not enabled for offline "
                        + "transactions";
            } else {
                msg = "Login Offline failed";
            }
            Log.v(TAG, msg);
            Log.v(TAG, Utils.SEPARATOR);
            showToast(msg);
        }
    }

    private class AudioJackPairingConnectionStatusHandlerImpl implements DeviceStatusHandler {

        @Override
        public void onConnected() {
            Log.v(TAG, "AudioJackPairingConnectionStatusHandlerImpl::onConnected");
            pairWithRP450c();
        }

        @Override
        public void onDisconnected() {
            Log.v(TAG, "AudioJackPairingConnectionStatusHandlerImpl::onDisconnected");
            hideProgress();
            showToast("Cannot detect RP450 via Audiojack. Try again.");
        }

        @Override
        public void onError(String s) {
            Log.v(TAG, "AudioJackPairingConnectionStatusHandlerImpl::onError");
            hideProgress();
            showToast("Cannot detect RP450 via Audiojack. Try again.");
        }
    }
}
