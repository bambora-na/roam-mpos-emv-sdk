package com.ingenico.mpos.app.sample;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import androidx.fragment.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;

import com.ingenico.mpos.app.sample.common.logger.Log;
import com.ingenico.mpos.app.sample.dialogs.UpdateTransactionDialogFragment;
import com.ingenico.mpos.sdk.Ingenico;
import com.ingenico.mpos.sdk.User;
import com.ingenico.mpos.sdk.callbacks.AcceptTermsAndConditionsCallback;
import com.ingenico.mpos.sdk.callbacks.ChangePasswordCallback;
import com.ingenico.mpos.sdk.callbacks.EmailReceiptCallback;
import com.ingenico.mpos.sdk.callbacks.GetEmailReceiptInfoCallback;
import com.ingenico.mpos.sdk.callbacks.GetInvoiceHistoryCallback;
import com.ingenico.mpos.sdk.callbacks.GetProcessorInfoCallback;
import com.ingenico.mpos.sdk.callbacks.GetSecurityQuestionsCallback;
import com.ingenico.mpos.sdk.callbacks.GetTransactionDetailsCallback;
import com.ingenico.mpos.sdk.callbacks.GetTransactionsSummaryCallback;
import com.ingenico.mpos.sdk.callbacks.RefreshUserSessionCallback;
import com.ingenico.mpos.sdk.callbacks.SetEmailReceiptInfoCallback;
import com.ingenico.mpos.sdk.callbacks.SetUserEmailCallback;
import com.ingenico.mpos.sdk.callbacks.UpdateTransactionCallback;
import com.ingenico.mpos.sdk.constants.ResponseCode;
import com.ingenico.mpos.sdk.data.CardholderInfo;
import com.ingenico.mpos.sdk.data.EmailReceiptInfo;
import com.ingenico.mpos.sdk.data.InvoiceHistorySummary;
import com.ingenico.mpos.sdk.data.ProcessorInfo;
import com.ingenico.mpos.sdk.data.SecurityQuestion;
import com.ingenico.mpos.sdk.data.TransactionHistoryDetail;
import com.ingenico.mpos.sdk.data.TransactionQuery;
import com.ingenico.mpos.sdk.data.TransactionQueryBuilder;
import com.ingenico.mpos.sdk.data.TransactionsSummary;
import com.ingenico.mpos.sdk.data.UserProfile;
import com.ingenico.mpos.sdk.response.TransactionResponse;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MerchantFragment extends FragmentBase implements View.OnClickListener,
        GetEmailDialogFragment.GetEmailDialogListener,
        ChangePasswordDialogFragment.ChangePasswordListener,
        TransactionsSummaryDialogFragment.TransactionsSummaryListener,
        UpdateTransactionDialogFragment.UpdateTransactionDialogFragmentListener {
    private final static String TAG = MerchantFragment.class.getSimpleName();
    private final User user = Ingenico.getInstance().user();
    private OnFragmentInteractionListener mListener;

    private String cachedTransactionId;
    private String logoImageStr;
    private int currentActionId;

    public MerchantFragment() {
        // Required empty public constructor
    }

    public static MerchantFragment newInstance() {
        return new MerchantFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_merchant, container, false);

        Button btnSetEmail = (Button) view.findViewById(R.id.fragment_merchant_btn_set_email);
        Button btnChangePwd = (Button) view.findViewById(R.id.fragment_merchant_btn_change_pwd);
        Button btnGetSecurityQuestions = (Button) view.findViewById(
                R.id.fragment_merchant_btn_get_security_questions);
        Button btnSetSecurityQuestions = (Button) view.findViewById(
                R.id.fragment_merchant_btn_set_security_questions);
        Button btnSetEmailReceiptInfo = (Button) view.findViewById(
                R.id.fragment_merchant_btn_set_email_receipt_info);
        Button btnGetEmailReceiptInfo = (Button) view.findViewById(
                R.id.fragment_merchant_btn_get_email_receipt_info);
        Button btnSendEmailReceipt = (Button) view.findViewById(
                R.id.fragment_merchant_btn_send_email_receipt);
        Button btnGetTransactionDetails = (Button) view.findViewById(
                R.id.fragment_merchant_btn_get_transaction_details);
        Button btnGetTransactions = (Button) view.findViewById(
                R.id.fragment_merchant_btn_get_transactions);
        Button btnGetInvoices = (Button) view.findViewById(
                R.id.fragment_merchant_btn_get_invoices);
        Button btnRefreshUserSession = (Button) view.findViewById(
                R.id.fragment_merchant_btn_refresh_user_session);
        Button btnAcceptTnC = (Button) view.findViewById(
                R.id.fragment_merchant_btn_accept_tandc);

        btnSetEmail.setOnClickListener(this);
        btnChangePwd.setOnClickListener(this);
        btnGetSecurityQuestions.setOnClickListener(this);
        btnSetSecurityQuestions.setOnClickListener(this);
        btnSetEmailReceiptInfo.setOnClickListener(this);
        btnGetEmailReceiptInfo.setOnClickListener(this);
        btnSendEmailReceipt.setOnClickListener(this);
        btnGetTransactionDetails.setOnClickListener(this);
        btnGetTransactions.setOnClickListener(this);
        btnGetInvoices.setOnClickListener(this);
        btnRefreshUserSession.setOnClickListener(this);
        btnAcceptTnC.setOnClickListener(this);
        view.findViewById(R.id.fragment_merchant_btn_get_processor_info).setOnClickListener(this);
        view.findViewById(R.id.fragment_merchant_btn_get_transactions_summary).setOnClickListener(this);
        view.findViewById(R.id.fragment_merchant_btn_update_transaction).setOnClickListener(this);

        logoImageStr = Utils.getBase64EncodedString(BitmapFactory.decodeResource(
                getResources(),
                R.drawable.merchant_receipt_info
                )
        );
        return view;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mListener = (OnFragmentInteractionListener) activity;
            if (mListener.getCachedTransactionResponse() != null) {
                String cachedTransactionId =
                        mListener.getCachedTransactionResponse().getTransactionId();
                if (cachedTransactionId != null) {
                    this.cachedTransactionId = cachedTransactionId;
                }
            }
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onClick(View v) {
        Log.v(TAG, Utils.SEPARATOR);
        Utils.logTimeStamp(TAG);
        currentActionId = v.getId();
        switch (currentActionId) {
            case R.id.fragment_merchant_btn_set_email:
                showEmailDialog();
                break;
            case R.id.fragment_merchant_btn_change_pwd:
                showChangePasswordDialog();
                break;
            case R.id.fragment_merchant_btn_get_security_questions:
                mProgressDialogListener.showProgressMessage("Getting Security Questions...");
                Ingenico.getInstance().user().getSecurityQuestions(
                        new GetSecurityQuestionsCallbackImpl());
                break;
            case R.id.fragment_merchant_btn_set_security_questions:
                mListener.onSetSecurityQuestionsApiSelected();
                break;
            case R.id.fragment_merchant_btn_set_email_receipt_info:
                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getActivity());
                final EditText etPhoneNumber = new EditText(getActivity());
                etPhoneNumber.setInputType(EditorInfo.TYPE_CLASS_TEXT);
                etPhoneNumber.setId(R.id.dialog_set_email_receipt_phone);
                dialogBuilder.setTitle("Enter phone number");
                dialogBuilder.setView(etPhoneNumber);
                dialogBuilder.setPositiveButton("Ok",
                        new DialogInterface.OnClickListener() {
                            public void onClick(
                                    DialogInterface dialog,
                                    int val) {
                                mProgressDialogListener.showProgressMessage("Setting Email Receipt Info...");
                                Ingenico.getInstance().user().setEmailReceiptInfo(
                                        new EmailReceiptInfo("imsdummyemail@gmail.com",
                                                "lol",
                                                etPhoneNumber.getText().toString(),
                                                "twitterURLTEST",
                                                "facebookURLTEST",
                                                "instragramURLTEST",
                                                logoImageStr,
                                                "websiteURLTEST",
                                                "The Bakery",
                                                "123 Boston Ave",
                                                "Suite 007",
                                                "Boston",
                                                "MA",
                                                "US",
                                                "01234"),
                                        new SetEmailReceiptInfoCallbackImpl());
                            }
                        });
                dialogBuilder.setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(
                                    DialogInterface dialog,
                                    int val) {
                                dialog.dismiss();
                            }
                        });
                dialogBuilder.show();
                break;
            case R.id.fragment_merchant_btn_get_email_receipt_info:
                mProgressDialogListener.showProgressMessage("Getting Email Receipt Info...");
                Ingenico.getInstance().user().getEmailReceiptInfo(
                        new GetEmailReceiptInfoCallbackImpl());
                break;
            case R.id.fragment_merchant_btn_send_email_receipt:
                showEmailDialog();
                break;
            case R.id.fragment_merchant_btn_get_transaction_details:
                if (cachedTransactionId != null) {
                    mProgressDialogListener.showProgressMessage("Getting Transaction Details...");
                    Ingenico.getInstance().user().getTransactionDetails(
                            cachedTransactionId,
                            new GetTransactionDetailsCallbackImpl()
                    );
                } else {
                    Utils.newDialog(getActivity(), "Error",
                            "Run a transaction before trying to get its details").show();
                }
                break;
            case R.id.fragment_merchant_btn_get_transactions:
                mListener.onGetTransactionHistoryApiSelected();
                break;
            case R.id.fragment_merchant_btn_get_invoices:
                mListener.onGetTransactionInvoicesApiSelected();
                break;
            case R.id.fragment_merchant_btn_refresh_user_session:
                mProgressDialogListener.showProgressMessage("Refreshing User Session...");
                Ingenico.getInstance().user().refreshUserSession(
                        new RefreshUserSessionCallbackImpl());
                break;
            case R.id.fragment_merchant_btn_accept_tandc:
                mProgressDialogListener.showProgressMessage("Accepting Terms And Conditions...");
                Ingenico.getInstance().user().acceptTermsAndConditions(
                        new AcceptTermsAndConditionsCallbackImpl()
                );
                break;
            case R.id.fragment_merchant_btn_get_processor_info:
                mProgressDialogListener.showProgressMessage("Getting Processor Information...");
                Ingenico.getInstance().user().getProcessorInfo(new ProcessorInfoCallbackImpl());
                break;
            case R.id.fragment_merchant_btn_get_transactions_summary:
                DialogFragment transactionsSummaryFragment = new TransactionsSummaryDialogFragment();
                transactionsSummaryFragment.setTargetFragment(this, 0);
                transactionsSummaryFragment.show(getActivity().getSupportFragmentManager(), TAG);
                break;
            case R.id.fragment_merchant_btn_update_transaction:
                if (cachedTransactionId != null) {
                    UpdateTransactionDialogFragment dialogFragment =
                            UpdateTransactionDialogFragment.newInstance(false, mListener.getCachedTransactionId());
                    dialogFragment.setTargetFragment(this, 0);
                    dialogFragment.show(getActivity().getSupportFragmentManager(),
                            UpdateTransactionDialogFragment.class.getSimpleName());
                } else {
                    Utils.newDialog(getActivity(), "Error",
                            "Run a transaction before trying to update").show();
                }
                break;
        }
    }

    @Override
    public void updateTransaction(String txnId,
            CardholderInfo cardholderInfo,
            String transactionNote,
            Boolean displayNotesAndInvoice,
            Boolean isCompleted,
            String signatureImage) {
        mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Updating Transaction ...");
        Ingenico.getInstance().user().updateTransaction(txnId,
                cardholderInfo,
                transactionNote,
                displayNotesAndInvoice,
                isCompleted,
                new UpdateTransactionCallback() {
                    @Override
                    public void done(Integer responseCode) {
                        mProgressDialogListener.hideProgress();
                        user.sendEmailReceipt(null, cachedTransactionId,
                                new SendEmailReceiptCallbackImpl());
                    }
                });
    }

    @Override
    public void onEmailCaptured(String email) {
        switch (currentActionId) {
            case R.id.fragment_merchant_btn_set_email:
                mProgressDialogListener.showProgressMessage("Setting Email...");
                user.setUserEmail(
                        email,
                        new SetUserEmailCallbackImpl()
                );
                break;
            case R.id.fragment_merchant_btn_send_email_receipt:
                if (cachedTransactionId != null) {
                    mProgressDialogListener.showProgressMessage("Sending Email Receipt...");
                    user.sendEmailReceipt(email, cachedTransactionId,
                            new SendEmailReceiptCallbackImpl());
                } else {
                    Utils.newDialog(getActivity(), "Error",
                            "Run a transaction before trying to send email receipt").show();
                }
                break;
        }
    }

    @Override
    public void onPasswordsCaptured(String oldPassword, String newPassword) {
        mProgressDialogListener.showProgressMessage("Changing Password...");
        user.changePassword(
                oldPassword,
                newPassword,
                new ChangePasswordCallbackImpl()
        );
    }

    @Override
    public void onTransactionsSummaryCaptured(String startDate, String endDate) {
        mProgressDialogListener.showProgressMessage("Getting Transactions Summary...");
        Ingenico.getInstance().user().getTransactionsSummary(startDate, endDate,
                        new GetTransactionsSummaryCallback() {
                            @Override
                            public void done(Integer responseCode,
                                    TransactionsSummary transactionsSummary) {
                                mProgressDialogListener.hideProgress();
                                String msg = String.format(
                                        "\nResponse Code : %s \n" +
                                                "Total transactions : %s \n" +
                                                "Net amount : %s \n",
                                        responseCode == ResponseCode.Success ? "Success" : responseCode,
                                        transactionsSummary.getTotalNumberOfTransactions(),
                                        transactionsSummary.getNetTransactionAmount());
                                Utils.newDialog(getActivity(), "Transactions Summary", msg).show();
                            }
                        });
    }

    private void showEmailDialog() {
        DialogFragment dialogFragment = new GetEmailDialogFragment();
        dialogFragment.setTargetFragment(this, 0);
        dialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
    }

    private void showChangePasswordDialog() {
        DialogFragment dialogFragment = new ChangePasswordDialogFragment();
        dialogFragment.setTargetFragment(this, 0);
        dialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
    }

    public interface OnFragmentInteractionListener {
        void onSetSecurityQuestionsApiSelected();

        void onGetTransactionHistoryApiSelected();

        TransactionResponse getCachedTransactionResponse();

        String getCachedTransactionId();

        void onGetTransactionInvoicesApiSelected();
    }

    private class SetUserEmailCallbackImpl implements SetUserEmailCallback {
        @Override
        public void done(Integer responseCode) {
            Log.v(TAG, "SetUserEmailCallback::done::" + responseCode);
            mProgressDialogListener.hideProgress();
            if (ResponseCode.Success == responseCode) {
                showToast("Success");
            } else {
                showToast("Failed");
            }
        }
    }

    private class ChangePasswordCallbackImpl implements ChangePasswordCallback {
        @Override
        public void done(Integer responseCode) {
            Log.v(TAG, "ChangePasswordCallback::done::" + responseCode);
            mProgressDialogListener.hideProgress();
            if (ResponseCode.Success == responseCode) {
                showToast("Success");
            } else {
                showToast("Failed");
            }
        }
    }

    private class SetEmailReceiptInfoCallbackImpl implements SetEmailReceiptInfoCallback {
        @Override
        public void done(Integer responseCode) {
            Log.v(TAG, "SetEmailReceiptInfoCallback::done::" + responseCode);
            mProgressDialogListener.hideProgress();
            if (ResponseCode.Success == responseCode) {
                showToast("Success");
            } else {
                showToast("Failed");
            }
        }
    }

    private class GetEmailReceiptInfoCallbackImpl implements GetEmailReceiptInfoCallback {
        @Override
        public void done(Integer responseCode, EmailReceiptInfo receiptInfo) {
            Log.v(TAG, "GetEmailReceiptInfoCallback::done::" + responseCode);
            mProgressDialogListener.hideProgress();
            if (ResponseCode.Success == responseCode) {
                Log.v(TAG, receiptInfo.toString());
                showToast("Success");
            } else {
                showToast("Failed");
            }
        }
    }

    private class SendEmailReceiptCallbackImpl implements EmailReceiptCallback {
        @Override
        public void done(Integer responseCode) {
            Log.v(TAG, "SendEmailReceipt::done::" + responseCode);
            mProgressDialogListener.hideProgress();
            if (ResponseCode.Success == responseCode) {
                showToast("Success");
            } else {
                showToast("Failed");
            }
        }
    }

    private class UpdateTransactionCallbackImpl implements UpdateTransactionCallback {
        @Override
        public void done(Integer responseCode) {
            Log.v(TAG, "UpdateTransaction::done::" + responseCode);
            mProgressDialogListener.hideProgress();
            if (ResponseCode.Success == responseCode) {
                showToast("Success");
            } else {
                showToast("Failed");
            }
        }
    }

    private class GetTransactionDetailsCallbackImpl implements GetTransactionDetailsCallback {
        @Override
        public void done(Integer responseCode, TransactionHistoryDetail transaction) {
            Log.v(TAG, "GetTransactionDetails::done::" + responseCode);
            mProgressDialogListener.hideProgress();
            if (ResponseCode.Success == responseCode) {
                showToast("Success");
                Log.v(TAG, transaction.toString());
            } else {
                showToast("Failed");
            }
        }
    }

    private class GetSecurityQuestionsCallbackImpl implements GetSecurityQuestionsCallback {
        @Override
        public void done(Integer responseCode, List<SecurityQuestion> questions) {
            Log.v(TAG, "GetSecurityQuestionsCallback::done::" + responseCode);
            Log.v(TAG, "GetSecurityQuestionsCallback::questions::" + questions);
            mProgressDialogListener.hideProgress();
            if (ResponseCode.Success == responseCode) {
                showToast("Success");
            } else {
                showToast("Failed");
            }
        }
    }

    private class GetInvoiceHistoryCallbackImpl implements GetInvoiceHistoryCallback {
        @Override
        public void done(Integer responseCode,
                Integer totalMatches,
                List<InvoiceHistorySummary> transactions) {
            Log.v(TAG, "GetInvoices::done::" + responseCode);
            Log.v(TAG, "GetInvoices total matches::" + totalMatches);
            mProgressDialogListener.hideProgress();
            if (ResponseCode.Success == responseCode) {
                showToast("Success");
                for (InvoiceHistorySummary historySummary : transactions) {
                    Log.v(TAG, historySummary.toString());
                }
            } else {
                showToast("Failed");
            }
        }
    }

    private class RefreshUserSessionCallbackImpl implements RefreshUserSessionCallback {
        @Override
        public void done(Integer responseCode,
                UserProfile userProfile) {
            mProgressDialogListener.hideProgress();
            Log.v(TAG, "RefreshUserSession::done::" + responseCode);
            if (ResponseCode.Success == responseCode) {
                showToast("Success");
                Log.v(TAG, "RefreshUserSession succeeded with new expire time "
                        + userProfile.getSession().getExpiresTime());
            } else {
                showToast("Failed");
            }
        }
    }

    private class AcceptTermsAndConditionsCallbackImpl implements AcceptTermsAndConditionsCallback {
        @Override
        public void done(Integer responseCode) {
            mProgressDialogListener.hideProgress();
            Log.v(TAG, "AcceptTermsAndConditions::done::" + responseCode);
            if (ResponseCode.Success == responseCode) {
                showToast("Success");
            } else {
                showToast("Failed");
            }
        }
    }

    private class ProcessorInfoCallbackImpl implements GetProcessorInfoCallback {
        @Override
        public void done(Integer responseCode, ProcessorInfo processorInfo) {
            Log.v(TAG, "GetProcessorInfoCallback::done::" + responseCode);
            mProgressDialogListener.hideProgress();
            if (ResponseCode.Success == responseCode) {
                Log.v(TAG, processorInfo.toString());
                showToast("Success");
            } else {
                showToast("Failed");
            }
        }
    }

}
