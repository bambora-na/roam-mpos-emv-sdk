package com.ingenico.mpos.app.sample;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentTransaction;

import com.ingenico.mpos.app.sample.common.StopWatch;
import com.ingenico.mpos.app.sample.common.logger.Log;
import com.ingenico.mpos.sdk.Ingenico;
import com.ingenico.mpos.sdk.SCEActivity;
import com.ingenico.mpos.sdk.callbacks.ApplicationSelectionCallback;
import com.ingenico.mpos.sdk.callbacks.EmailReceiptCallback;
import com.ingenico.mpos.sdk.callbacks.GetPendingTransactionsCallback;
import com.ingenico.mpos.sdk.callbacks.GetTransactionDetailsCallback;
import com.ingenico.mpos.sdk.callbacks.ReversePendingTransactionCallback;
import com.ingenico.mpos.sdk.callbacks.TransactionCallback;
import com.ingenico.mpos.sdk.callbacks.TransactionTypeSelectionCallback;
import com.ingenico.mpos.sdk.callbacks.TransactionTypeSelectionResponseCallback;
import com.ingenico.mpos.sdk.callbacks.UpdateTransactionCallback;
import com.ingenico.mpos.sdk.callbacks.UploadSignatureCallback;
import com.ingenico.mpos.sdk.callbacks.WaitForCardRemovalCallback;
import com.ingenico.mpos.sdk.constants.ApplicationType;
import com.ingenico.mpos.sdk.constants.CardVerificationMethod;
import com.ingenico.mpos.sdk.constants.ConfigMode;
import com.ingenico.mpos.sdk.constants.POSEntryMode;
import com.ingenico.mpos.sdk.constants.ProgressMessage;
import com.ingenico.mpos.sdk.constants.ResponseCode;
import com.ingenico.mpos.sdk.constants.TransactionResponseCode;
import com.ingenico.mpos.sdk.constants.TransactionType;
import com.ingenico.mpos.sdk.constants.UCIFormat;
import com.ingenico.mpos.sdk.data.Amount;
import com.ingenico.mpos.sdk.data.Card;
import com.ingenico.mpos.sdk.data.CardholderInfo;
import com.ingenico.mpos.sdk.data.PendingTransaction;
import com.ingenico.mpos.sdk.data.Preference;
import com.ingenico.mpos.sdk.data.Product;
import com.ingenico.mpos.sdk.data.TokenRequestParameters;
import com.ingenico.mpos.sdk.data.TransactionHistoryDetail;
import com.ingenico.mpos.sdk.request.AVSOnlyTransactionRequest;
import com.ingenico.mpos.sdk.request.BalanceInquiryTransactionRequest;
import com.ingenico.mpos.sdk.request.CashRefundTransactionRequest;
import com.ingenico.mpos.sdk.request.CashSaleTransactionRequest;
import com.ingenico.mpos.sdk.request.CreditAuthAdjustTransactionRequest;
import com.ingenico.mpos.sdk.request.CreditAuthCompleteTransactionRequest;
import com.ingenico.mpos.sdk.request.CreditAuthTransactionRequest;
import com.ingenico.mpos.sdk.request.CreditBalanceInquiryTransactionRequest;
import com.ingenico.mpos.sdk.request.CreditCardRefundTransactionRequest;
import com.ingenico.mpos.sdk.request.CreditForceSaleTransactionRequest;
import com.ingenico.mpos.sdk.request.CreditReauthTransactionRequest;
import com.ingenico.mpos.sdk.request.CreditRefundTransactionRequest;
import com.ingenico.mpos.sdk.request.CreditResaleTransactionRequest;
import com.ingenico.mpos.sdk.request.CreditSaleAdjustTransactionRequest;
import com.ingenico.mpos.sdk.request.CreditSaleTransactionRequest;
import com.ingenico.mpos.sdk.request.DebitBalanceInquiryTransactionRequest;
import com.ingenico.mpos.sdk.request.DebitCardRefundTransactionRequest;
import com.ingenico.mpos.sdk.request.DebitSaleTransactionRequest;
import com.ingenico.mpos.sdk.request.KeyedCardSaleTransactionRequest;
import com.ingenico.mpos.sdk.request.KeyedCardSaleTransactionWithCardReaderRequest;
import com.ingenico.mpos.sdk.request.KeyedCreditAuthTransactionRequest;
import com.ingenico.mpos.sdk.request.KeyedCreditAuthTransactionWithCardReaderRequest;
import com.ingenico.mpos.sdk.request.KeyedCreditForceSaleTransactionRequest;
import com.ingenico.mpos.sdk.request.KeyedCreditRefundTransactionWithCardReaderRequest;
import com.ingenico.mpos.sdk.request.KeyedTokenEnrollmentTransactionRequest;
import com.ingenico.mpos.sdk.request.KeyedTokenEnrollmentWithCardReaderTransactionRequest;
import com.ingenico.mpos.sdk.request.PartialVoidTransactionRequest;
import com.ingenico.mpos.sdk.request.RefundTransactionRequest;
import com.ingenico.mpos.sdk.request.SCECreditAuthTransactionRequest;
import com.ingenico.mpos.sdk.request.SCECreditRefundTransactionRequest;
import com.ingenico.mpos.sdk.request.SCECreditSaleTransactionRequest;
import com.ingenico.mpos.sdk.request.SaleTransactionRequest;
import com.ingenico.mpos.sdk.request.TokenAuthTransactionRequest;
import com.ingenico.mpos.sdk.request.TokenEnrollmentTransactionRequest;
import com.ingenico.mpos.sdk.request.TokenSaleTransactionRequest;
import com.ingenico.mpos.sdk.request.VoidTransactionRequest;
import com.ingenico.mpos.sdk.response.TransactionResponse;
import com.roam.roamreaderunifiedapi.data.ApplicationIdentifier;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class PaymentApiFragment extends FragmentBase
        implements View.OnClickListener,
        AmountDialogFragment.AmountDialogListener,
        ClerkIdDialogFragment.ClerkIdDialogListener,
        ApplicationSelectionDialog.Listener,
        PendingSignatureDialog.PendingSignatureDialogListener,
        LocationListener{
    private final static String TAG = PaymentApiFragment.class.getSimpleName();

    private final static String SAVEKEY_IGNORE_REVERSAL_BEFORE_TXN = "SAVEKEY_IGNORE_REVERSAL_BEFORE_TXN";

    private final static String TOKEN_REFERENCE_NO = "Test-123";

    private final Card card;
    private LocationManager locationManager;
    private String longitude = "-71.056711";    // set default lat and long in case fragment detaches
    private String latitude = "42.354929";      // before getting real location
    private String clerkId;
    private String authCode;
    private String transactionNote;
    private String merchantInvocieID;
    private OnFragmentInteractionListener mListener;
    private int buttonClickedId;
    private String mSignatureImage;
    private String mProductImage;
    private String mTransactionType;
    private boolean showDialog;
    private Amount saleAmount;
    private Amount refundAmount;
    private Integer systemTraceAuditNumber;
    private ApplicationSelectionCallback applicationSelectionCallback = null;
    private String customReference;
    private boolean showNoteAndInvoiceOnReceipt;
    private String orderNumber;
    private Locale cardholderLocale;

    private List<PendingTransaction> pendingTransactions = new ArrayList<>();
    private TokenRequestParameters tokenRequest;
    private boolean canEnrollToken;
    private boolean canUpdateToken;
    private boolean canSetCustomRef;
    private boolean canDisplayShowNoteAndInvoiceOnReceiptCheckbox;
    private boolean isKeyedWithDevice;
    private boolean isKeyed;
    private boolean ignoreReversalBeforeTxn;
    private boolean isPerformingPartialAuth;
    private boolean isCardPresent;
    private boolean avsOnly;
    private boolean canSetTransactionNote;
    private boolean canSetOrderNumber;
    private int initialSubmittedAmount = 0;
    private int partialAuthAmount = 0;
    private List<String> partialTransactionIds = new ArrayList<>();
    private String transactionGroupId;

    {
        card = new Card(
                "4111111111111111",
                "0127",
                "82560",
                "123",
                POSEntryMode.Keyed
        );
    }

    public PaymentApiFragment() {
        // Required empty public constructor
    }

    public static PaymentApiFragment newInstance() {
        PaymentApiFragment fragment = new PaymentApiFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        locationManager = (LocationManager) getActivity().getSystemService(
                Context.LOCATION_SERVICE);
        Criteria criteria = new Criteria();
        String provider = locationManager.getBestProvider(criteria, true);
        if (locationManager != null) {
            if (ActivityCompat.checkSelfPermission(getActivity(),
                    Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                    || ActivityCompat.checkSelfPermission(getActivity(),
                    Manifest.permission.ACCESS_COARSE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {
                Location location = locationManager.getLastKnownLocation(provider);
                if (location != null) {
                    onLocationChanged(location);
                } else {
                    locationManager.requestLocationUpdates(provider, 1000, 0, this);
                }
            }
        }
    }

    @Override
    public View onCreateView(
            LayoutInflater inflater,
            ViewGroup container,
            Bundle savedInstanceState) {
        if (savedInstanceState != null) {
            ignoreReversalBeforeTxn = savedInstanceState.getBoolean(SAVEKEY_IGNORE_REVERSAL_BEFORE_TXN);
        }

        View view = inflater.inflate(R.layout.fragment_payment_api, container, false);

        Button btnCashTransaction = (Button) view.findViewById(
                R.id.fragment_payment_btn_cash_transaction);
        Button btnKeyedTransaction = (Button) view.findViewById(
                R.id.fragment_payment_btn_keyed_transaction);
        Button btnCardSaleTransaction = (Button) view.findViewById(
                R.id.fragment_payment_btn_credit_sale_transaction);
        Button btnCardAuthTransaction = (Button) view.findViewById(
                R.id.fragment_payment_btn_credit_auth_transaction);
        Button btnAuthComplete = (Button) view.findViewById(
                R.id.fragment_payment_btn_credit_auth_complete);
        Button btnKeyedCreditAuth = (Button) view.findViewById(
                R.id.fragment_payment_btn_keyed_credit_auth_transaction);
        Button btnCashRefund = (Button) view.findViewById(R.id.fragment_payment_btn_cash_refund);
        Button btnCreditRefund = (Button) view.findViewById(
                R.id.fragment_payment_btn_credit_refund);
        Button btnCardRefund = (Button) view.findViewById(R.id.fragment_payment_btn_card_refund);
        Button btnDebitSale = (Button) view.findViewById(
                R.id.fragment_payment_btn_debit_sale_transaction);
        Button btnVoid = (Button) view.findViewById(R.id.fragment_payment_btn_void_transaction);
        Button btnVoidWithCardReader = (Button) view.findViewById(R.id.fragment_payment_btn_void_transaction_with_reader);
        Button btnDebitCardRefund = (Button) view.findViewById(
                R.id.fragment_payment_btn_debit_card_refund);
        Button btnManualKeyed = (Button) view.findViewById(
                R.id.fragment_payment_btn_manual_keyed_transaction);
        Button btnCreditForce = (Button) view.findViewById(
                R.id.fragment_payment_btn_credit_force_transaction);
        Button btnKeyedCreditForce = (Button) view.findViewById(
                R.id.fragment_payment_btn_keyed_credit_force_transaction);
        Button btnCreditBalanceInquiry = (Button) view.findViewById(
                R.id.fragment_payment_btn_credit_balance_inquiry);
        Button btnReverseTxn = (Button) view.findViewById(
                R.id.fragment_payment_btn_reverse_all_transactions);
        Button btnGetPendingTransactions = (Button) view.findViewById(
                R.id.fragment_payment_btn_get_pending_transactions);
        Button btnIgnorePendingTransaction = (Button) view.findViewById(
                R.id.fragment_payment_btn_ignore_pending_transaction);
        Button btnTokenEnrollment = (Button) view.findViewById(
                R.id.fragment_payment_btn_token_enrollment);
        Button btnKeyedTokenEnrollment = (Button) view.findViewById(
                R.id.fragment_payment_btn_keyed_token_enrollment);
        Button btnTokenUpdate = (Button) view.findViewById(
                R.id.fragment_payment_btn_token_update);
        Button btnKeyedTokenUpdate = (Button) view.findViewById(
                R.id.fragment_payment_btn_keyed_token_update);
        Button btnSecureCardEntryCreditSale = (Button) view.findViewById(
                R.id.fragment_payment_btn_secure_card_entry_credit_sale);
        Button btnSecureCardEntryCreditAuth = (Button) view.findViewById(
                R.id.fragment_payment_btn_secure_card_entry_credit_auth);
        Button btnSecureCardEntryCreditRefund = (Button) view.findViewById(
                R.id.fragment_payment_btn_secure_card_entry_credit_refund);
        Button btnIgnorePendingReversals = (Button) view.findViewById(
                R.id.fragment_payment_btn_ignore_reversal_before_txn);
        Button btnTokenSale = (Button) view.findViewById(
                R.id.fragment_payment_btn_keyed_token_sale);
        Button btnTokenAuth = (Button) view.findViewById(
                R.id.fragment_payment_btn_keyed_token_auth);
        Button btnCreditSaleAdjust = (Button) view.findViewById(
                R.id.fragment_payment_btn_credit_sale_adjust);
        Button btnPartialAuth = (Button) view.findViewById(
                R.id.fragment_payment_btn_partial_auth);
        Button btnCreditResale = (Button) view.findViewById(
                R.id.fragment_payment_btn_credit_resale);
        Button btnCreditReauth = (Button) view.findViewById(
                R.id.fragment_payment_btn_credit_reauth);
        Button btnCreditAuthAdjust = (Button) view.findViewById(
                R.id.fragment_payment_btn_credit_auth_adjust);
        Button btnDebitBalanceInquiry = (Button) view.findViewById(
                R.id.fragment_payment_btn_debit_balance_inquiry);
        Button btnAvsOnly = (Button) view.findViewById(
                R.id.fragment_payment_btn_avs_only);
        Button btnSale = (Button) view.findViewById(
                R.id.fragment_payment_btn_sale);
        Button btnRefund = (Button) view.findViewById(
                R.id.fragment_payment_btn_refund);
        Button btnBalanceInquiryTransaction = (Button) view.findViewById(
                R.id.fragment_payment_btn_balance_inquiry);
        Button btnAbortTransaction = (Button) view.findViewById(
                R.id.fragment_payment_btn_abort_transaction);
        Button btnManualKeyedCreditAuth = (Button) view.findViewById(
                R.id.fragment_payment_btn_manual_keyed_credit_auth);
        Button btnManualKeyedCreditRefund = (Button) view.findViewById(
                R.id.fragment_payment_btn_manual_keyed_credit_refund);
        Button btnManualKeyedTokenEnroll = (Button) view.findViewById(
                R.id.fragment_payment_btn_manual_keyed_token_enroll);
        Button btnManualKeyedTokenUpdate = (Button) view.findViewById(
                R.id.fragment_payment_btn_manual_keyed_token_update);
        Button btnGetCurrentCapabilities = (Button) view.findViewById(
                R.id.fragment_payment_btn_get_current_capabilities);
        Button btnUpdatePreference = (Button) view.findViewById(
                R.id.fragment_payment_btn_update_preference);
        Button btnVasOnlyTxn = (Button) view.findViewById(
                R.id.fragment_payment_btn_vas_only);

        btnCashTransaction.setOnClickListener(this);
        btnKeyedTransaction.setOnClickListener(this);
        btnCardSaleTransaction.setOnClickListener(this);
        btnCardAuthTransaction.setOnClickListener(this);
        btnCashRefund.setOnClickListener(this);
        btnCreditRefund.setOnClickListener(this);
        btnCardRefund.setOnClickListener(this);
        btnDebitSale.setOnClickListener(this);
        btnVoid.setOnClickListener(this);
        btnAuthComplete.setOnClickListener(this);
        btnKeyedCreditAuth.setOnClickListener(this);
        btnDebitCardRefund.setOnClickListener(this);
        btnManualKeyed.setOnClickListener(this);
        btnCreditForce.setOnClickListener(this);
        btnKeyedCreditForce.setOnClickListener(this);
        btnCreditBalanceInquiry.setOnClickListener(this);
        btnReverseTxn.setOnClickListener(this);
        btnGetPendingTransactions.setOnClickListener(this);
        btnIgnorePendingTransaction.setOnClickListener(this);
        btnTokenEnrollment.setOnClickListener(this);
        btnKeyedTokenEnrollment.setOnClickListener(this);
        btnTokenUpdate.setOnClickListener(this);
        btnKeyedTokenUpdate.setOnClickListener(this);
        btnSecureCardEntryCreditSale.setOnClickListener(this);
        btnSecureCardEntryCreditAuth.setOnClickListener(this);
        btnSecureCardEntryCreditRefund.setOnClickListener(this);
        btnIgnorePendingReversals.setOnClickListener(this);
        btnTokenSale.setOnClickListener(this);
        btnTokenAuth.setOnClickListener(this);
        btnCreditSaleAdjust.setOnClickListener(this);
        btnPartialAuth.setOnClickListener(this);
        btnCreditResale.setOnClickListener(this);
        btnCreditReauth.setOnClickListener(this);
        btnCreditAuthAdjust.setOnClickListener(this);
        btnDebitBalanceInquiry.setOnClickListener(this);
        btnAvsOnly.setOnClickListener(this);
        btnAbortTransaction.setOnClickListener(this);
        btnGetCurrentCapabilities.setOnClickListener(this);
        btnUpdatePreference.setOnClickListener(this);
        btnSale.setOnClickListener(this);
        btnRefund.setOnClickListener(this);
        btnBalanceInquiryTransaction.setOnClickListener(this);
        btnManualKeyedCreditAuth.setOnClickListener(this);
        btnManualKeyedCreditRefund.setOnClickListener(this);
        btnManualKeyedTokenEnroll.setOnClickListener(this);
        btnManualKeyedTokenUpdate.setOnClickListener(this);
        btnVasOnlyTxn.setOnClickListener(this);
        btnVoidWithCardReader.setOnClickListener(this);

        view.findViewById(R.id.fragment_payment_btn_partial_void_transaction)
                .setOnClickListener(this);
        view.findViewById(R.id.fragment_payment_btn_reverse_single_transaction)
                .setOnClickListener(this);

        mProductImage = Utils.getBase64EncodedString(
                BitmapFactory.decodeResource(
                        getResources(),
                        R.drawable.coffee_beans
                )
        );
        mSignatureImage = Utils.getBase64EncodedString(
                BitmapFactory.decodeResource(
                        getResources(),
                        R.drawable.signature
                )
        );

        return view;
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean(SAVEKEY_IGNORE_REVERSAL_BEFORE_TXN, ignoreReversalBeforeTxn);
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mListener = (OnFragmentInteractionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
        if (locationManager != null) {
            locationManager.removeUpdates(this);
        }
    }

    @Override
    public void onClick(View v) {
        Log.v(TAG, Utils.SEPARATOR);
        Utils.logTimeStamp(TAG);
        buttonClickedId = v.getId();
        setTransactionProps();
        TransactionResponse cachedTransactionResponse = mListener.getCachedTransactionResponse();
        int cachedTransactionResponseCode = mListener.getCachedTransactionResponseCode();
        if (buttonClickedId == R.id.fragment_payment_btn_void_transaction
                || buttonClickedId == R.id.fragment_payment_btn_keyed_token_enrollment
                || buttonClickedId == R.id.fragment_payment_btn_keyed_token_update) {
            if (!shouldReversePendingTransactions()) {
                showClerkIdDialog();
            }
        } else if (buttonClickedId == R.id.fragment_payment_btn_partial_void_transaction) {
            if (mListener.getCachedTransactionResponse() == null) {
                Utils.newDialog(getActivity(), "Error",
                        "Please first run a credit auth or auth adjust transaction").show();
                return;
            }
            if (!shouldReversePendingTransactions()) {
                showPartialVoidAmountDialog();
            }
        } else if(buttonClickedId == R.id.fragment_payment_btn_credit_refund ) {
            if (!shouldReversePendingTransactions()) {
                final String transactionId = mListener.getCachedCreditRefundableTransactionId();
                if (transactionId == null) {
                    Utils.newDialog(getActivity(), "Error",
                            "Please first run a credit sale or credit force sale transaction").show();
                } else {
                    showRefundAmountDialogIfTransactionNotFullyRefunded(transactionId);
                }
            }
        } else if (buttonClickedId == R.id.fragment_payment_btn_credit_sale_transaction
                || buttonClickedId == R.id.fragment_payment_btn_credit_auth_transaction
                || buttonClickedId == R.id.fragment_payment_btn_debit_sale_transaction
                || buttonClickedId == R.id.fragment_payment_btn_card_refund
                || buttonClickedId == R.id.fragment_payment_btn_debit_card_refund
                || buttonClickedId == R.id.fragment_payment_btn_manual_keyed_transaction
                || buttonClickedId == R.id.fragment_payment_btn_credit_force_transaction
                || buttonClickedId == R.id.fragment_payment_btn_credit_balance_inquiry
                || buttonClickedId == R.id.fragment_payment_btn_debit_balance_inquiry
                || buttonClickedId == R.id.fragment_payment_btn_balance_inquiry
                || buttonClickedId == R.id.fragment_payment_btn_token_enrollment
                || buttonClickedId == R.id.fragment_payment_btn_token_update
                || buttonClickedId == R.id.fragment_payment_btn_avs_only
                || buttonClickedId == R.id.fragment_payment_btn_sale
                || buttonClickedId == R.id.fragment_payment_btn_refund
                || buttonClickedId == R.id.fragment_payment_btn_manual_keyed_credit_auth
                || buttonClickedId == R.id.fragment_payment_btn_manual_keyed_credit_refund
                || buttonClickedId == R.id.fragment_payment_btn_manual_keyed_token_enroll
                || buttonClickedId == R.id.fragment_payment_btn_manual_keyed_token_update
                || buttonClickedId == R.id.fragment_payment_btn_void_transaction_with_reader) {
            if (!shouldReversePendingTransactions()) {
                if (!mListener.isDeviceConnected()) {
                    Utils.newDialog(getActivity(), "Warning", "Please connect the device!").show();
                } else {
                    if (buttonClickedId == R.id.fragment_payment_btn_credit_balance_inquiry
                            || buttonClickedId == R.id.fragment_payment_btn_debit_balance_inquiry
                            || buttonClickedId == R.id.fragment_payment_btn_balance_inquiry
                            || buttonClickedId == R.id.fragment_payment_btn_token_enrollment
                            || buttonClickedId == R.id.fragment_payment_btn_avs_only
                            || buttonClickedId == R.id.fragment_payment_btn_manual_keyed_token_enroll
                            || buttonClickedId == R.id.fragment_payment_btn_manual_keyed_token_update
                            || buttonClickedId == R.id.fragment_payment_btn_void_transaction_with_reader) {
                        showClerkIdDialog();
                    } else if (buttonClickedId == R.id.fragment_payment_btn_card_refund
                            || buttonClickedId == R.id.fragment_payment_btn_debit_card_refund
                            || buttonClickedId == R.id.fragment_payment_btn_refund
                            || buttonClickedId == R.id.fragment_payment_btn_manual_keyed_credit_refund) {
                        showOpenRefundDialog();
                    } else if (buttonClickedId == R.id.fragment_payment_btn_token_update) {
                        showClerkIdDialog();
                    } else {
                        showSaleAmountDialog();
                    }
                }
            }
        } else if (buttonClickedId == R.id.fragment_payment_btn_credit_auth_complete) {
            if (!shouldReversePendingTransactions()) {
                Log.v(TAG, "Auth Complete");
                showDialog = true;
                showSaleAmountDialog();
            }
        } else if (buttonClickedId == R.id.fragment_payment_btn_reverse_all_transactions) {
            Log.v(TAG, "Reverse all pending Transactions");
            mTransactionType = "Reversal";
            mProgressDialogListener.showProgressMessage("Reversing all pending transaction..");
            Ingenico.getInstance().payment().reverseAllPendingTransactions(10, new ReversePendingTransactionCallback() {
                            @Override
                            public void done(Integer responseCode) {
                                mProgressDialogListener.hideProgress();
                                if (ResponseCode.Success == responseCode) {
                                    showToast("Reversal Success");
                                } else {
                                    Log.v(TAG, "Reversal failed with error code::" + responseCode);
                                    showToast("Reversal Failed");
                                    logResult(responseCode, null, true);
                                }
                            }
                        });
        } else if (buttonClickedId == R.id.fragment_payment_btn_reverse_single_transaction) {
            mProgressDialogListener.showProgressMessage("Getting pending transactions..");
            Ingenico.getInstance().payment().getPendingTransactions(new GetPendingTransactionsCallback() {
                @Override
                public void done(List<PendingTransaction> transactions, Integer responseCode) {
                    mProgressDialogListener.hideProgress();
                    if (ResponseCode.Success == responseCode) {
                        ArrayList<String> pendingClientTxnIds = new ArrayList<>();
                        for (PendingTransaction txn : transactions) {
                            pendingClientTxnIds.add(txn.getClientTransactionId());
                        }
                        Utils.CustomArrayAdapter pendingTxnArrayAdapter = new Utils.CustomArrayAdapter(
                                getActivity(),
                                pendingClientTxnIds
                        );

                        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getActivity())
                                .setTitle("Select Pending Transaction")
                                .setAdapter(pendingTxnArrayAdapter, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        Log.v(TAG, "Reverse signle pending Transaction");
                                        mTransactionType = "Reversal";
                                        mProgressDialogListener.showProgressMessage("Reversing transaction..");
                                        Ingenico.getInstance().payment().reversePendingTransaction(pendingClientTxnIds.get(which), new ReversePendingTransactionCallback() {
                                            @Override
                                            public void done(Integer responseCode) {
                                                mProgressDialogListener.hideProgress();
                                                showToast(Utils.getResponseCodeString(responseCode));
                                                Log.v(TAG, "Reversal completed with response code::" + responseCode);
                                            }
                                        });
                                    }
                                })
                                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                });
                        dialogBuilder.create().show();
                    } else {
                        Log.v(TAG, "Get pending transactions failed with error code::" + responseCode);
                        if (BuildConfig.showResultDialogs) {
                            Utils.newDialog(getActivity(), "Failed fetching pending transactions", "Response code " + responseCode).show();
                        }
                    }
                }
            });



        } else if (buttonClickedId == R.id.fragment_payment_btn_get_pending_transactions) {
            Log.v(TAG, "Get pending transactions");
            mProgressDialogListener.showProgressMessage("Getting pending transactions..");
            Ingenico.getInstance().payment().getPendingTransactions(new GetPendingTransactionsCallback() {
                @Override
                public void done(List<PendingTransaction> transactions, Integer responseCode) {
                    mProgressDialogListener.hideProgress();
                    if (ResponseCode.Success == responseCode) {
                        pendingTransactions = transactions;
                        for (PendingTransaction txn : transactions) {
                            Log.v(TAG, txn.toString());
                        }
                        showToast("Success");
                    } else {
                        Log.v(TAG, "Get pending transactions failed with error code::" + responseCode);
                        if (BuildConfig.showResultDialogs) {
                            Utils.newDialog(getActivity(), "Failed", "Response code " + responseCode).show();
                        }
                    }
                }
            });
        } else if (buttonClickedId == R.id.fragment_payment_btn_ignore_pending_transaction) {
          if (pendingTransactions.isEmpty()) {
              Utils.newDialog(getActivity(), "Error", "Get pending transactions first").show();
          } else {
              for (PendingTransaction txn : pendingTransactions) {
                  Ingenico.getInstance().payment().ignorePendingTransaction(txn.getClientTransactionId());
              }
              pendingTransactions.clear();
              showToast("Success");
          }
        } else if (buttonClickedId == R.id.fragment_payment_btn_ignore_reversal_before_txn) {
            ignoreReversalBeforeTxn = true;
            Ingenico.getInstance().payment().ignorePendingReversalsBeforeNextTransaction();
            showToast("Success");
        } else if (buttonClickedId == R.id.fragment_payment_btn_keyed_token_sale) {
            if (!shouldReversePendingTransactions()) {
                Log.v(TAG, "Token Sale");
                showDialog = true;
                if (mListener.getCachedTokenId() != null) {
                    showSaleAmountDialog();
                } else {
                    Utils.newDialog(
                            getActivity(),
                            "Error",
                            "Enroll a token before trying to do a token sale"
                    ).show();
                }
            }
        } else if (buttonClickedId == R.id.fragment_payment_btn_keyed_token_auth) {
            if (!shouldReversePendingTransactions()) {
                Log.v(TAG, "Token Auth");
                showDialog = true;
                if (mListener.getCachedTokenId() != null) {
                    showSaleAmountDialog();
                } else {
                    Utils.newDialog(
                            getActivity(),
                            "Error",
                            "Enroll a token before trying to do a token auth"
                    ).show();
                }
            }
        } else if (buttonClickedId == R.id.fragment_payment_btn_credit_sale_adjust) {
            if (!shouldReversePendingTransactions()) {
                Log.v(TAG, "Credit Sale Adjust");
                showDialog = true;
                TransactionType cachedTransactionType = mListener.getCachedTransactionType();
                if (cachedTransactionResponse != null) {
                    if (cachedTransactionResponseCode == ResponseCode.Success) {
                        showSaleAmountDialog();
                    } else {
                        Utils.newDialog(
                                getActivity(),
                                "Error",
                                "Original transaction didn't get approved,"
                        ).show();
                    }
                } else {
                    Utils.newDialog(
                            getActivity(),
                            "Error",
                            "Run a credit sale before trying to adjust"
                    ).show();
                }
            }
        } else if (buttonClickedId == R.id.fragment_payment_btn_credit_resale) {
            if (!shouldReversePendingTransactions()) {
                Log.v(TAG, "Credit Re-Sale");
                showDialog = true;
                if (cachedTransactionResponse != null) {
                    if (cachedTransactionResponseCode == ResponseCode.Success) {
                        showSaleAmountDialog();
                    } else {
                        Utils.newDialog(
                                getActivity(),
                                "Error",
                                "Original transaction didn't get approved,"
                        ).show();
                    }
                } else {
                    Utils.newDialog(
                            getActivity(),
                            "Error",
                            "Run a credit sale before trying to do re-sale"
                    ).show();
                }
            }
        } else if (buttonClickedId == R.id.fragment_payment_btn_credit_reauth) {
            if (!shouldReversePendingTransactions()) {
                Log.v(TAG, "Credit Re-Auth");
                showDialog = true;
                if (cachedTransactionResponse != null) {
                    if (cachedTransactionResponseCode == ResponseCode.Success) {
                        showSaleAmountDialog();
                    } else {
                        Utils.newDialog(
                                getActivity(),
                                "Error",
                                "Original transaction didn't get approved,"
                        ).show();
                    }
                } else {
                    Utils.newDialog(
                            getActivity(),
                            "Error",
                            "Run a credit auth before trying to do re-auth"
                    ).show();
                }
            }
        } else if (buttonClickedId == R.id.fragment_payment_btn_credit_auth_adjust) {
            if (!shouldReversePendingTransactions()) {
                Log.v(TAG, "Credit Auth Adjust");
                showDialog = true;
                TransactionType cachedTransactionType = mListener.getCachedTransactionType();
                if (cachedTransactionResponse != null) {
                    if (cachedTransactionResponseCode == ResponseCode.Success) {
                        showSaleAmountDialog();
                    } else {
                        Utils.newDialog(
                                getActivity(),
                                "Error",
                                "Original transaction didn't get approved,"
                        ).show();
                    }
                } else {
                    Utils.newDialog(
                            getActivity(),
                            "Error",
                            "Run a credit auth before trying to adjust"
                    ).show();
                }
            }
        }
        else if (buttonClickedId
                == R.id.fragment_payment_btn_secure_card_entry_credit_refund){
            if (!shouldReversePendingTransactions()) {
                showOpenRefundDialog();
            }
        }
        else if (buttonClickedId
                == R.id.fragment_payment_btn_cash_refund) {
            if (mListener.getCachedTransactionId() == null) {
                Utils.newDialog(getActivity(), "Error",
                        "Please first run cash sale").show();
            } else {
                if (!shouldReversePendingTransactions()) {
                    showRefundAmountDialogIfTransactionNotFullyRefunded(
                            (mListener.getCachedTransactionId()));
                }
            }
        }
        else if (buttonClickedId == R.id.fragment_payment_btn_abort_transaction){
            Ingenico.getInstance().payment().abortTransaction();
        }
        else if (buttonClickedId == R.id.fragment_payment_btn_get_current_capabilities){
            Log.v(TAG, Ingenico.getInstance().getCurrentCapabilities().toString());
        }
        else if (buttonClickedId == R.id.fragment_payment_btn_update_preference){
            View view = getActivity().getLayoutInflater().inflate(R.layout.fragment_preference, null);
            Spinner localeSpinner = view.findViewById(R.id.fragment_setup_spinner_locale);
            Utils.CustomArrayAdapter localeArrayAdapter = new Utils.CustomArrayAdapter(
                    getActivity(),
                    IngenicoConstants.SUPPORTED_LOCALES
            );
            localeSpinner.setAdapter(localeArrayAdapter);
            localeSpinner.setSelection(
                    IngenicoConstants.SUPPORTED_LOCALES.indexOf(
                            Ingenico.getInstance().getPreference().getMerchantLocale()));

            Preference.Builder prefBuilder = new Preference.Builder();
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity())
                    .setTitle("Update Preference")
                    .setView(view)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            RadioGroup configMode = view.findViewById(R.id.rg_config_mode);
                            switch (configMode.getCheckedRadioButtonId()) {
                                case R.id.fragment_setup_rb_manual:
                                    prefBuilder.setConfigMode(ConfigMode.Manual);
                                    break;
                                case R.id.fragment_setup_rb_optimal:
                                    prefBuilder.setConfigMode(ConfigMode.Optimal);
                                    break;
                                case R.id.fragment_setup_rb_auto:
                                    prefBuilder.setConfigMode(ConfigMode.Auto);
                                    break;
                            }

                            RadioGroup rgRetryCount = view.findViewById(R.id.rg_retry_count);
                            RadioButton rbRetryCount = view.findViewById(rgRetryCount.getCheckedRadioButtonId());
                            int retryCount = Integer.parseInt(rbRetryCount.getText().toString());
                            prefBuilder.setRetryCount(retryCount)
                                    .setMerchantLocale((Locale) localeSpinner.getSelectedItem());
                            Preference pref = prefBuilder.build();
                            Log.v(TAG, "Update preference to " + pref.toString());
                            Ingenico.getInstance().updatePreference(pref);
                        }
                    })
                    .setNegativeButton("Cancel", null);
            builder.create().show();
        }
        else if (buttonClickedId == R.id.fragment_payment_btn_vas_only){
            Log.v(TAG, "VAS only transaction");
            showDialog = true;
            mTransactionType = "Vas Only Transaction";
            mProgressDialogListener.showProgressMessage("processing VAS only transaction");
            Ingenico.getInstance().payment().processVasOnlyTransactionWithCardReader(
                    new VasOnlyTransactionCallbackImpl()
            );
        }
        else {
            if (!shouldReversePendingTransactions()) {
                showSaleAmountDialog();
            }
        }
    }

    private void setTransactionProps() {
        canEnrollToken =
                        buttonClickedId == R.id.fragment_payment_btn_credit_auth_transaction
                        || buttonClickedId == R.id.fragment_payment_btn_credit_sale_transaction
                        || buttonClickedId == R.id.fragment_payment_btn_keyed_transaction
                        || buttonClickedId == R.id.fragment_payment_btn_manual_keyed_transaction
                        || buttonClickedId == R.id.fragment_payment_btn_keyed_credit_auth_transaction
                        || buttonClickedId == R.id.fragment_payment_btn_token_enrollment
                        || buttonClickedId == R.id.fragment_payment_btn_keyed_token_enrollment
                        || buttonClickedId == R.id.fragment_payment_btn_token_update
                        || buttonClickedId == R.id.fragment_payment_btn_keyed_token_update
                        || buttonClickedId == R.id.fragment_payment_btn_secure_card_entry_credit_sale
                        || buttonClickedId == R.id.fragment_payment_btn_secure_card_entry_credit_auth
                        || buttonClickedId == R.id.fragment_payment_btn_card_refund
                        || buttonClickedId == R.id.fragment_payment_btn_secure_card_entry_credit_refund
                        || buttonClickedId == R.id.fragment_payment_btn_credit_resale
                        || buttonClickedId == R.id.fragment_payment_btn_credit_reauth
                        || buttonClickedId == R.id.fragment_payment_btn_manual_keyed_credit_auth
                        || buttonClickedId == R.id.fragment_payment_btn_manual_keyed_credit_refund
                        || buttonClickedId == R.id.fragment_payment_btn_manual_keyed_token_enroll;

        canUpdateToken =
                buttonClickedId == R.id.fragment_payment_btn_token_update
                        || buttonClickedId == R.id.fragment_payment_btn_keyed_token_update
                        || buttonClickedId == R.id.fragment_payment_btn_card_refund
                        || buttonClickedId == R.id.fragment_payment_btn_credit_resale
                        || buttonClickedId == R.id.fragment_payment_btn_credit_reauth
                        || buttonClickedId == R.id.fragment_payment_btn_manual_keyed_token_update;

        canSetCustomRef =
                        buttonClickedId != R.id.fragment_payment_btn_token_enrollment
                        && buttonClickedId != R.id.fragment_payment_btn_keyed_token_enrollment
                        && buttonClickedId != R.id.fragment_payment_btn_token_update
                        && buttonClickedId != R.id.fragment_payment_btn_keyed_token_update
                        && buttonClickedId != R.id.fragment_payment_btn_manual_keyed_token_enroll
                        && buttonClickedId != R.id.fragment_payment_btn_manual_keyed_token_update;

        isKeyedWithDevice =
                        buttonClickedId == R.id.fragment_payment_btn_manual_keyed_transaction
                        || buttonClickedId == R.id.fragment_payment_btn_manual_keyed_credit_auth
                        || buttonClickedId == R.id.fragment_payment_btn_manual_keyed_credit_refund
                        || buttonClickedId == R.id.fragment_payment_btn_manual_keyed_token_enroll
                        || buttonClickedId == R.id.fragment_payment_btn_manual_keyed_token_update;

        isKeyed =
                buttonClickedId == R.id.fragment_payment_btn_keyed_transaction
                || buttonClickedId == R.id.fragment_payment_btn_keyed_credit_auth_transaction
                || buttonClickedId == R.id.fragment_payment_btn_keyed_credit_force_transaction
                || buttonClickedId == R.id.fragment_payment_btn_secure_card_entry_credit_sale
                || buttonClickedId == R.id.fragment_payment_btn_secure_card_entry_credit_auth
                || buttonClickedId == R.id.fragment_payment_btn_secure_card_entry_credit_refund
                || buttonClickedId == R.id.fragment_payment_btn_partial_auth;
        avsOnly =
                buttonClickedId == R.id.fragment_payment_btn_avs_only;

        canDisplayShowNoteAndInvoiceOnReceiptCheckbox =
                buttonClickedId != R.id.fragment_payment_btn_credit_auth_complete;

        canSetTransactionNote = buttonClickedId == R.id.fragment_payment_btn_void_transaction
                              ||buttonClickedId == R.id.fragment_payment_btn_void_transaction_with_reader;

        canSetOrderNumber = buttonClickedId != R.id.fragment_payment_btn_cash_transaction
                && buttonClickedId != R.id.fragment_payment_btn_cash_refund;

    }

    @Override
    public void onSaleAmountCaptured(String totalAmount, String subtotalAmount, String tipAmount,
                                     String taxAmount, String discountAmount, String surchargeAmount,
                                     String currencyCode,
                                     String clerkId, String authCode,
                                     String systemTraceAuditNumber,
                                     String transactionNote,
                                     String merchantInvoiceID,
                                     boolean shouldEnrollForToken,
                                     boolean shouldUpdateForToken,
                                     boolean shouldRequestCvv,
                                     boolean shouldRequestAvs,
                                     String tokenFeeAmount,
                                     String customReference,
                                     String tokenId,
                                     boolean isCardPresent,
                                     boolean showNoteAndInvoiceOnReceipt,
                                     String orderNumber,
                                     boolean validateExpiryDate,
                                     Locale cardholderLocale) {
        int tokenFee = Utils.convertStringToInt(tokenFeeAmount);
        this.saleAmount = createNewAmount(totalAmount, subtotalAmount, tipAmount, taxAmount,
                discountAmount, surchargeAmount, currencyCode);
        this.isCardPresent = isCardPresent;
        this.showNoteAndInvoiceOnReceipt = showNoteAndInvoiceOnReceipt;
        if (cardholderLocale != null) {
            this.cardholderLocale = cardholderLocale;
        }
        if (transactionNote != null) {
            this.transactionNote = transactionNote;
        }
        if (merchantInvoiceID != null) {
            this.merchantInvocieID = merchantInvoiceID;
        }
        if (customReference != null) {
            this.customReference = customReference;
        }
        if (shouldEnrollForToken || shouldUpdateForToken) {
            TokenRequestParameters.Builder builder = new TokenRequestParameters.Builder()
                    .setTokenReferenceNumber(TOKEN_REFERENCE_NO)
                    .setTokenFeeInCents(tokenFee)
                    .setCardholderFirstName("Roam")
                    .setCardholderLastName("Data")
                    .setBillToEmail("roam@roamdata.com")
                    .setBillToAddress1("1 Federal St")
                    .setBillToAddress2("Suite 1")
                    .setBillToCity("Boston")
                    .setBillToState("MA")
                    .setBillToCountry("USA")
                    .setBillToZip("02110");
            if (shouldUpdateForToken) {
                builder.setTokenIdentifier(tokenId);
                tokenRequest = builder.createTokenUpdateRequestParameters();
            } else {
                tokenRequest = builder.createTokenEnrollmentRequestParameters();
            }
        } else {
            tokenRequest = null;
        }
        if (clerkId != null && !clerkId.isEmpty() && clerkId.length() > 4) {
            showInvalidClerkIdDialog(false);
        } else if ((authCode == null || authCode.isEmpty())&&
                (buttonClickedId == R.id.fragment_payment_btn_credit_force_transaction||
                 buttonClickedId == R.id.fragment_payment_btn_keyed_credit_force_transaction)) {
            showInvalidAuthCodeDialog();
        } else {
            if (clerkId != null) {
                this.clerkId = clerkId;
            }
            if (authCode != null) {
                this.authCode = authCode;
            }
            if (orderNumber != null) {
                this.orderNumber = orderNumber;
            }
            if (!TextUtils.isEmpty(systemTraceAuditNumber)){
                this.systemTraceAuditNumber = Utils.convertStringToInt(systemTraceAuditNumber);
            } else {
                this.systemTraceAuditNumber = null;
            }
            Intent sceIntent = new Intent(getActivity(), SecureCardEntryActivity.class);
            switch (buttonClickedId) {
                case R.id.fragment_payment_btn_cash_transaction:
                    Log.v(TAG, "CASH SALE");
                    mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Cash Transaction...");
                    mListener.cacheTransactionType(TransactionType.CashSale);
                    showDialog = true;
                    Ingenico.getInstance().payment().processCashTransaction(
                            getCashSaleTransactionRequest(),
                            new CashSaleTransactionCallbackImpl()
                    );
                    break;
                case R.id.fragment_payment_btn_keyed_transaction:
                    Log.v(TAG, "KEYED CARD SALE");
                    mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Keyed Transaction...");
                    mListener.cacheTransactionType(TransactionType.CreditSale);
                    showDialog = true;
                    Ingenico.getInstance().payment().processKeyedTransaction(
                            getKeyedCardSaleTransactionRequest(),
                            new CreditSaleTransactionCallbackImpl()
                    );
                    break;
                case R.id.fragment_payment_btn_secure_card_entry_credit_sale:
                    Log.v(TAG, "SECURE CARD ENTRY CREDIT SALE");
                    mListener.cacheTransactionType(TransactionType.CreditSale);
                    showDialog = true;
                    sceIntent.putExtra(SecureCardEntryActivity.ARGKEY_SCE_CREDIT_SALE_TRANSACTION_REQUEST, getSCECreditSaleTransactionRequest());
                    startActivityForResult(sceIntent, 1);
                    break;
                case R.id.fragment_payment_btn_secure_card_entry_credit_auth:
                    Log.v(TAG, "SECURE CARD ENTRY CREDIT AUTH");
                    mListener.cacheTransactionType(TransactionType.CreditAuth);
                    showDialog = true;
                    sceIntent.putExtra(SecureCardEntryActivity.ARGKEY_SCE_CREDIT_AUTH_TRANSACTION_REQUEST, getSCECreditAuthTransactionRequest());
                    startActivityForResult(sceIntent, 1);
                    break;
                case R.id.fragment_payment_btn_credit_sale_transaction:
                    Log.v(TAG, "CARD SALE");
                    mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Credit Sale Transaction...");
                    mListener.cacheTransactionType(TransactionType.CreditSale);
                    showDialog = true;
                    Ingenico.getInstance().payment().processCreditSaleTransactionWithCardReader(
                            getCardSaleTransactionRequest(),
                            new CreditSaleTransactionCallbackImpl()
                    );
                    break;
                case R.id.fragment_payment_btn_keyed_credit_auth_transaction:
                    Log.v(TAG, "KEYED CREDIT AUTH");
                    mProgressDialogListener.showTransactionProgressMessageWithCancelButton(
                            "Processing Keyed Credit Auth Transaction...");
                    mListener.cacheTransactionType(TransactionType.CreditAuth);
                    showDialog = true;
                    Ingenico.getInstance().payment().processKeyedCreditAuthTransaction(
                            getKeyedCreditAuthTransactionRequest(),
                            new CreditSaleTransactionCallbackImpl()
                    );
                    break;
                case R.id.fragment_payment_btn_credit_auth_transaction:
                    Log.v(TAG, "CARD AUTH");
                    mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Credit Auth Transaction...");
                    mListener.cacheTransactionType(TransactionType.CreditAuth);
                    showDialog = true;
                    Ingenico.getInstance().payment().processCreditAuthTransactionWithCardReader(
                            getCardAuthTransactionRequest(),
                            new CreditSaleTransactionCallbackImpl()
                    );
                    break;
                case R.id.fragment_payment_btn_debit_sale_transaction:
                    Log.v(TAG, "DEBIT SALE");
                    mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Debit Sale Transaction...");
                    mListener.cacheTransactionType(TransactionType.DebitSale);
                    showDialog = true;
                    Ingenico.getInstance().payment().processDebitSaleTransactionWithCardReader(
                            getDebitSaleTransactionRequest(),
                            new DebitSaleTransactionCallbackImpl()
                    );
                    break;
                case R.id.fragment_payment_btn_credit_auth_complete:
                    Log.v(TAG, "AUTH COMPLETE");
                    mListener.cacheTransactionType(TransactionType.CreditAuthCompletion);
                    mTransactionType = "Auth Complete";
                    showDialog = true;
                    mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Auth Complete...");
                    Ingenico.getInstance().payment().processCreditAuthCompleteTransaction(
                            getCreditAuthCompleteTransactionRequest(
                                    mListener.getCachedTransactionId()),
                            new CreditSaleTransactionCallbackImpl());
                    Log.v(TAG, "auth complete request sent");
                    break;
                case R.id.fragment_payment_btn_manual_keyed_transaction:
                    Log.v(TAG, "MANUAL KEYED CREDIT SALE");
                    mListener.cacheTransactionType(TransactionType.CreditSale);
                    mTransactionType = "Manual Keyed Credit Sale With Card Reader";
                    showDialog = true;
                    mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Manual Keyed Credit Sale...");
                    Ingenico.getInstance().payment().processKeyedTransactionWithCardReader(
                            getKeyedCardSaleRequestWithCardReader(shouldRequestCvv, shouldRequestAvs),
                            new CreditSaleTransactionCallbackImpl());
                    Log.v(TAG, "manual keyed sale request sent");
                    break;
                case R.id.fragment_payment_btn_manual_keyed_credit_auth:
                    Log.v(TAG, "MANUAL KEYED CREDIT AUTH");
                    mListener.cacheTransactionType(TransactionType.CreditAuth);
                    mTransactionType = "Manual Keyed Credit Auth With Card Reader";
                    showDialog = true;
                    mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Manual Keyed Credit Auth...");
                    Ingenico.getInstance().payment().processKeyedCreditAuthTransactionWithCardReader(
                            getKeyedCreditAuthTransactionWithCardReaderRequest(shouldRequestCvv, shouldRequestAvs),
                            new CreditSaleTransactionCallbackImpl());
                    Log.v(TAG, "manual keyed auth request sent");
                    break;
                case R.id.fragment_payment_btn_credit_force_transaction:
                    Log.v(TAG, "Credit Force Sale");
                    showDialog = true;
                    mTransactionType = "Credit Force";
                    mListener.cacheTransactionType(TransactionType.CreditForceSale);
                    mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Credit Force Sale...");
                    Ingenico.getInstance().payment().processCreditForceSaleTransactionWithCardReader(
                            getCreditForceRequest(),
                            new CreditSaleTransactionCallbackImpl());
                    Log.v(TAG, "Credit force sale request sent");
                    break;
                case R.id.fragment_payment_btn_keyed_credit_force_transaction:
                    Log.v(TAG, "Keyed Credit Force Sale");
                    showDialog = true;
                    mTransactionType = "Keyed Credit Force";
                    mListener.cacheTransactionType(TransactionType.CreditForceSale);
                    mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Keyed Credit Force Sale...");
                    Ingenico.getInstance().payment().processKeyedCreditForceSaleTransaction(
                            getKeyedCreditForceRequest(),
                            new CreditSaleTransactionCallbackImpl());
                    Log.v(TAG, "Keyed Credit force sale request sent");
                    break;
                case R.id.fragment_payment_btn_keyed_token_sale:
                    Log.v(TAG, "TOKEN SALE");
                    mListener.cacheTransactionType(TransactionType.CreditSale);
                    mTransactionType = "Token Sale";
                    showDialog = true;
                    mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Token Sale...");
                    Ingenico.getInstance().payment().processTokenSaleTransaction(
                            getTokenSaleTransactionRequest(tokenId),
                            new CreditSaleTransactionCallbackImpl());
                    Log.v(TAG, "Token sale request sent");
                    break;
                case R.id.fragment_payment_btn_keyed_token_auth:
                    Log.v(TAG, "TOKEN AUTH");
                    mListener.cacheTransactionType(TransactionType.CreditAuth);
                    mTransactionType = "Token Auth";
                    showDialog = true;
                    mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Token Auth...");
                    Ingenico.getInstance().payment().processTokenAuthTransaction(
                            getTokenAuthTransactionRequest(tokenId),
                            new CreditSaleTransactionCallbackImpl());
                    Log.v(TAG, "Token sale request sent");
                    break;
                case R.id.fragment_payment_btn_credit_sale_adjust:
                    Log.v(TAG, "CREDIT SALE ADJUST");
                    mListener.cacheTransactionType(TransactionType.CreditSaleAdjust);
                    mTransactionType = "Credit Sale Adjust";
                    showDialog = true;
                    mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Credit Sale Adjust...");
                    Ingenico.getInstance().payment().processCreditSaleAdjustTransaction(
                            getCreditSaleAdjustTransactionRequest(mListener.getCachedTransactionId()),
                            new CreditSaleAdjustTransactionCallbackImpl());
                    Log.v(TAG, "Credit sale adjust request sent");
                    break;
                case R.id.fragment_payment_btn_credit_auth_adjust:
                    Log.v(TAG, "CREDIT AUTH ADJUST");
                    mListener.cacheTransactionType(TransactionType.CreditAuthAdjust);
                    mTransactionType = "Credit Auth Adjust";
                    showDialog = true;
                    mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Credit Auth Adjust...");
                    Ingenico.getInstance().payment().processCreditAuthAdjustTransaction(
                            getCreditAuthAdjustTransactionRequest(mListener.getCachedTransactionId()),
                            new CreditAuthAdjustTransactionCallbackImpl());
                    Log.v(TAG, "Credit sale adjust request sent");
                    break;
                case R.id.fragment_payment_btn_partial_auth:
                    Log.v(TAG, "PARTIAL AUTH");
                    mListener.cacheTransactionType(TransactionType.CreditSale);
                    mTransactionType = "Partial Auth";
                    showDialog = false;
                    mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Credit Sale ...");
                    Ingenico.getInstance().payment().processKeyedTransaction(
                            getPartialAuthTransactionRequest(),
                            new PartialAuthTransactionCallbackImpl());
                    break;
                case R.id.fragment_payment_btn_credit_resale:
                    Log.v(TAG, "CREDIT RE-SALE");
                    mListener.cacheTransactionType(TransactionType.CreditSale);
                    mTransactionType = "Credit Re-Sale";
                    showDialog = true;
                    mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Credit Re-Sale ...");
                    Ingenico.getInstance().payment().processCreditResaleTransaction(
                            getCreditResaleTransactionRequest(mListener.getCachedTransactionId()),
                            new CreditResaleTransactionCallbackImpl()
                    );
                    break;
                case R.id.fragment_payment_btn_credit_reauth:
                    Log.v(TAG, "CREDIT RE-AUTH");
                    mListener.cacheTransactionType(TransactionType.CreditAuth);
                    mTransactionType = "Credit Re-Auth";
                    showDialog = true;
                    mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Credit Re-Auth ...");
                    Ingenico.getInstance().payment().processCreditReauthTransaction(
                            getCreditReauthTransactionRequest(mListener.getCachedTransactionId()),
                            new CreditReauthTransactionCallbackImpl()
                    );
                    break;
                case R.id.fragment_payment_btn_sale:
                    Log.v(TAG, "SALE");
                    mListener.cacheTransactionType(TransactionType.Sale);
                    mTransactionType = "Sale";
                    showDialog = true;
                    mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Sale ...");
                    Ingenico.getInstance().payment().processSaleTransactionWithCardReader(
                            getSaleTransactionRequest(),
                            new CreditSaleTransactionCallbackImpl(),
                            new TransactionTypeSelectionImpl()
                    );
                    break;

                default:
                    break;
            }
            Log.v(TAG, mTransactionType + " Request Sent");
        }
    }

    @Override
    public void onRefundAmountCaptured(String refundAmount, String subtotalAmount,
            String tipAmount, String taxAmount, String discountAmount,
            String surchargeAmount, String currencyCode, String customReference, String clerkId, String transactionNote,
            String orderNumber, boolean showNotesAndInvoiceOnReceipt, Locale cardholderLocale) {
        this.refundAmount = createNewAmount(refundAmount, subtotalAmount, tipAmount, taxAmount,
                discountAmount, surchargeAmount, currencyCode);
        this.showNoteAndInvoiceOnReceipt = showNotesAndInvoiceOnReceipt;
        if (customReference != null) {
            this.customReference = customReference;
        }
        if (clerkId != null){
            this.clerkId = clerkId;
        }
        if (transactionNote != null){
            this.transactionNote = transactionNote;
        }
        if (orderNumber != null) {
            this.orderNumber = orderNumber;
        }
        if (cardholderLocale != null) {
            this.cardholderLocale = cardholderLocale;
        }
        switch (buttonClickedId) {
            case R.id.fragment_payment_btn_cash_refund:
                mTransactionType = "Cash Refund";
                showDialog = true;
                mProgressDialogListener.showTransactionProgressMessageWithCancelButton(
                        "Processing Cash Refund...");
                Ingenico.getInstance().payment().processCashRefundTransaction(
                        getCashRefundTransactionRequest(
                                mListener.getCachedTransactionId(),
                                this.refundAmount),
                        new CashSaleTransactionCallbackImpl()
                );
                break;
            case R.id.fragment_payment_btn_credit_refund:
                CreditRefundTransactionRequest creditRefundRequest =
                        getCreditRefundTransactionRequest(
                                mListener.getCachedCreditRefundableTransactionId(),
                                this.refundAmount
                        );
                mTransactionType = "Credit Refund";
                showDialog = true;
                mProgressDialogListener.showTransactionProgressMessageWithCancelButton(
                        "Processing Credit Refund...");
                Ingenico.getInstance().payment().processCreditRefundTransaction(
                        creditRefundRequest,
                        new CreditRefundTransactionCallbackImpl()
                );
                break;
            case R.id.fragment_payment_btn_partial_void_transaction:
                PartialVoidTransactionRequest partialVoidRequest = new PartialVoidTransactionRequest(this.refundAmount,
                        mListener.getCachedTransactionId(),
                        clerkId,
                        longitude,
                        latitude,
                        customReference,
                        transactionNote,
                        orderNumber);
                mTransactionType = "Partial Void";
                showDialog = true;
                mProgressDialogListener.showTransactionProgressMessageWithCancelButton(
                        "Processing Partial Void...");
                Ingenico.getInstance().payment().processPartialVoidTransaction(
                        partialVoidRequest,
                        new VoidTransactionCallbackImpl()
                );
                break;
            default:
                break;
        }
        Log.v(TAG, "\nOriginal transaction approved, refund request sent");
    }

    @Override
    public void onOpenRefundAmountCaptured(String refundAmount, String taxAmount, String discountAmount,
            String surchargeAmount, String currencyCode, String transactionNote, String merchantInvoiceID, String customReference,
            boolean shouldEnrollForToken, boolean shouldUpdateForToken, String tokenFeeAmount, boolean isCardPresent, String clerkID, boolean showNoteAndInvoiceOnReceipt, String orderNumber, Locale cardholderLocale) {
        this.refundAmount = createNewAmount(refundAmount, "0", "0", taxAmount, discountAmount,
                surchargeAmount, currencyCode);
        this.isCardPresent = isCardPresent;
        if (customReference != null) {
            this.customReference = customReference;
        }
        if (clerkID != null){
            this.clerkId = clerkID;
        }
        this.showNoteAndInvoiceOnReceipt = showNoteAndInvoiceOnReceipt;
        if (transactionNote != null) {
            this.transactionNote = transactionNote;
        }
        if (merchantInvoiceID != null) {
            this.merchantInvocieID = merchantInvoiceID;
        }
        if (orderNumber != null) {
            this.orderNumber = orderNumber;
        }
        if (cardholderLocale != null) {
            this.cardholderLocale = cardholderLocale;
        }
        int tokenFee = Utils.convertStringToInt(tokenFeeAmount);
        if (shouldEnrollForToken || shouldUpdateForToken) {
            TokenRequestParameters.Builder builder = new TokenRequestParameters.Builder()
                    .setTokenReferenceNumber(TOKEN_REFERENCE_NO)
                    .setTokenFeeInCents(tokenFee)
                    .setCardholderFirstName("Roam")
                    .setCardholderLastName("Data")
                    .setBillToEmail("roam@roamdata.com")
                    .setBillToAddress1("1 Federal St")
                    .setBillToAddress2("Suite 1")
                    .setBillToCity("Boston")
                    .setBillToState("MA")
                    .setBillToCountry("USA")
                    .setBillToZip("02110");
            if (shouldUpdateForToken) {
                if (TextUtils.isEmpty(mListener.getCachedTokenId())) {
                    Utils.newDialog(
                            getActivity(),
                            "Error",
                            "Enroll a token before trying to do a token update"
                    ).show();
                    return;
                }
                builder.setTokenIdentifier(mListener.getCachedTokenId());
                tokenRequest = builder.createTokenUpdateRequestParameters();
            }
            else {
                tokenRequest = builder.createTokenEnrollmentRequestParameters();
            }
        } else {
            tokenRequest = null;
        }
        if (buttonClickedId == R.id.fragment_payment_btn_card_refund) {
            Log.v(TAG, "CREDIT CARD REFUND");
            mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Credit Card Refund...");
            mListener.cacheTransactionType(TransactionType.CreditRefund);
            showDialog = true;
            Ingenico.getInstance().payment().processCreditRefundWithCardReader(
                    getCardRefundTransactionRequest(),
                    new CardRefundTransactionCallbackImpl()
            );
        } else if (buttonClickedId == R.id.fragment_payment_btn_debit_card_refund) {
            Log.v(TAG, "Debit CARD REFUND");
            mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Debit Card Refund...");
            mListener.cacheTransactionType(TransactionType.DebitRefund);
            showDialog = true;
            Ingenico.getInstance().payment().processDebitRefundWithCardReader(
                    getDebitCardRefundTransactionRequest(),
                    new CardRefundTransactionCallbackImpl()
            );
        } else if (buttonClickedId == R.id.fragment_payment_btn_secure_card_entry_credit_refund){
            Log.v(TAG, "SECURE CARD ENTRY CREDIT REFUND");
            mListener.cacheTransactionType(TransactionType.CreditRefund);
            showDialog = true;
            Intent intentSCECreditRefund = new Intent(getActivity(), SecureCardEntryActivity.class);
            intentSCECreditRefund.putExtra(SecureCardEntryActivity.ARGKEY_SCE_CREDIT_REFUND_TRANSACTION_REQUEST, getSCETransactionRequestCreditRefund());
            startActivityForResult(intentSCECreditRefund, 1);
        } else if (buttonClickedId == R.id.fragment_payment_btn_refund){
            Log.v(TAG, "REFUND");
            mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Refund ...");
            mListener.cacheTransactionType(TransactionType.Refund);
            showDialog = true;
            Ingenico.getInstance().payment().processRefundWithCardReader(
                    getRefundTransactionRequest(),
                    new CardRefundTransactionCallbackImpl(),
                    new TransactionTypeSelectionImpl()
            );
        }
        else if (buttonClickedId == R.id.fragment_payment_btn_manual_keyed_credit_refund) {
            Log.v(TAG, "MANUAL KEYED CREDIT REFUND");
            mListener.cacheTransactionType(TransactionType.CreditRefund);
            mTransactionType = "Manual Keyed Credit Refund With Card Reader";
            showDialog = true;
            mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Manual Keyed Credit Refund...");
            Ingenico.getInstance().payment().processKeyedCreditRefundTransactionWithCardReader(
                    getKeyedCreditRefundTransactionWithCardReaderRequest(),
                    new CreditSaleTransactionCallbackImpl());
            Log.v(TAG, "manual keyed refund request sent");
        }
    }

    @Override
    public void onTransactionCancelled() {
        if (isPerformingPartialAuth &&
                !partialTransactionIds.isEmpty()) {
            resetPartialAuthState();
            voidPartialAuthTransactions();
        }
    }

    @Override
    public void onClerkIdCaptured(String originalTxnId, String clerkId, String tokenFee, String tokenId,
            String customReference, String avsZipCode, String avsAddress, String transactionNote,
            String orderNumber, boolean validateExpiryDate, boolean requestAVS, boolean requestCVV,
            boolean cardPresent, boolean showNoteAndInvoiceOnReceipt, Locale cardholderLocale) {
        if (clerkId != null && !clerkId.isEmpty() && clerkId.length() > 4) {
            showInvalidClerkIdDialog(true);
        } else {
            if (clerkId != null) {
                this.clerkId = clerkId;
            }
            if (customReference != null) {
                this.customReference = customReference;
            }
            if (transactionNote != null) {
                this.transactionNote = transactionNote;
            }
            if (orderNumber != null) {
                this.orderNumber = orderNumber;
            }
            if (cardholderLocale != null) {
                this.cardholderLocale = cardholderLocale;
            }
            this.showNoteAndInvoiceOnReceipt = showNoteAndInvoiceOnReceipt;
            TransactionResponse cachedTransactionResponse =
                    mListener.getCachedTransactionResponse();
            int cachedTransactionResponseCode = mListener.getCachedTransactionResponseCode();
            switch (buttonClickedId) {
                case R.id.fragment_payment_btn_void_transaction:
                    Log.v(TAG, "VOID");
                    showDialog = true;
                    if (cachedTransactionResponse != null) {
                        if (cachedTransactionResponseCode == ResponseCode.Success) {
                            mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Void...");
                            mListener.cacheTransactionType(TransactionType.Unknown);
                            Ingenico.getInstance().payment().processVoidTransaction(
                                    getVoidTransactionRequest(
                                            originalTxnId),
                                    new VoidTransactionCallbackImpl()
                            );
                            Log.v(TAG, "Original transaction approved, void request sent");
                        } else {
                            Utils.newDialog(
                                    getActivity(),
                                    "Error",
                                    "Original transaction didn't get approved, " +
                                            "can't process void transaction"
                            ).show();
                        }
                    } else {
                        Utils.newDialog(
                                getActivity(),
                                "Error",
                                "Please do a credit/debit/auth/authcomplete/creditforce/creditrefund/debitrefund/adjust transaction first"
                        ).show();
                    }
                    break;
                case R.id.fragment_payment_btn_void_transaction_with_reader:
                    Log.v(TAG, "VOID with reader");
                    showDialog = true;
                    if (cachedTransactionResponse != null) {
                        if (cachedTransactionResponseCode == ResponseCode.Success) {
                            mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Void With Card Reader...");
                            mListener.cacheTransactionType(TransactionType.Unknown);
                            Ingenico.getInstance().payment().processVoidTransactionWithCardReader(
                                    getVoidTransactionRequest(
                                            originalTxnId),
                                    new VoidTransactionCallbackImpl()
                            );
                            Log.v(TAG, "Original transaction approved, void request sent");
                        } else {
                            Utils.newDialog(
                                    getActivity(),
                                    "Error",
                                    "Original transaction didn't get approved, " +
                                            "can't process void transaction"
                            ).show();
                        }
                    } else {
                        Utils.newDialog(
                                getActivity(),
                                "Error",
                                "Please do a credit/debit/auth/authcomplete/creditforce/creditrefund/debitrefund/adjust transaction first"
                        ).show();
                    }
                    break;
                case R.id.fragment_payment_btn_credit_balance_inquiry:
                    Log.v(TAG, "Credit Balance Inquiry");
                    showDialog = true;
                    mProgressDialogListener.showProgressMessage("Inquiring for credit balance");
                    Ingenico.getInstance().payment().processCreditBalanceInquiryWithCardReader(
                            getCreditBalanceInquiryTransactionRequest(),
                            new BalanceInquiryTransactionCallbackImpl()
                    );
                    break;
                case R.id.fragment_payment_btn_debit_balance_inquiry:
                    Log.v(TAG, "Debit Balance Inquiry");
                    showDialog = true;
                    mProgressDialogListener.showProgressMessage("Inquiring for debit balance");
                    Ingenico.getInstance().payment().processDebitBalanceInquiryWithCardReader(
                            getDebitBalanceInquiryTransactionRequest(),
                            new BalanceInquiryTransactionCallbackImpl()
                    );
                    break;
                case R.id.fragment_payment_btn_balance_inquiry:
                    Log.v(TAG, "Balance Inquiry");
                    showDialog = true;
                    mProgressDialogListener.showProgressMessage("Inquiring for balance");
                    Ingenico.getInstance().payment().processBalanceInquiryWithCardReader(
                            getBalanceInquiryTransactionRequest(),
                            new BalanceInquiryTransactionCallbackImpl(),
                            new TransactionTypeSelectionImpl()
                    );
                    break;
                case R.id.fragment_payment_btn_token_enrollment:
                    Log.v(TAG, "Token Enrollment");
                    showDialog = true;
                    mProgressDialogListener.showProgressMessage("Requesting token");
                    Ingenico.getInstance().payment().processTokenEnrollmentWithCardReader(
                            getTokenEnrollmentTransactionRequest(tokenFee),
                            new TokenEnrollmentRequestCallbackImpl()
                    );
                    break;
                case R.id.fragment_payment_btn_keyed_token_enrollment:
                    Log.v(TAG, "Keyed Token Enrollment");
                    showDialog = true;
                    mProgressDialogListener.showProgressMessage("Requesting token");
                    Ingenico.getInstance().payment().processKeyedTokenEnrollment(
                            getKeyedTokenEnrollmentTransactionRequest(tokenFee),
                            new TokenEnrollmentRequestCallbackImpl()
                    );
                    break;
                case R.id.fragment_payment_btn_manual_keyed_token_enroll:
                    Log.v(TAG, "Manual Keyed Token Enrollment");
                    showDialog = true;
                    mProgressDialogListener.showProgressMessage("Requesting token");
                    Ingenico.getInstance().payment().processKeyedTokenEnrollmentTransactionWithCardReader(
                            getKeyedTokenEnrollmentWithCardReaderTransactionRequest(tokenFee, requestAVS, requestCVV, cardPresent),
                            new TokenEnrollmentRequestCallbackImpl()
                    );
                    break;
                case R.id.fragment_payment_btn_token_update:
                    Log.v(TAG, "Token Update");
                    showDialog = true;
                    mProgressDialogListener.showProgressMessage("Updating token");
                    Ingenico.getInstance().payment().processTokenEnrollmentWithCardReader(
                            getTokenUpdateTransactionRequest(tokenFee, tokenId),
                            new TokenEnrollmentRequestCallbackImpl()
                    );
                    break;
                case R.id.fragment_payment_btn_keyed_token_update:
                    Log.v(TAG, "Keyed Token Update");
                    showDialog = true;
                    mProgressDialogListener.showProgressMessage("Updating token");
                    Ingenico.getInstance().payment().processKeyedTokenEnrollment(
                            getKeyedTokenUpdateTransactionRequest(tokenFee, tokenId),
                            new TokenEnrollmentRequestCallbackImpl()
                    );
                    break;
                case R.id.fragment_payment_btn_manual_keyed_token_update:
                    Log.v(TAG, "Manual Keyed Token Update");
                    showDialog = true;
                    mProgressDialogListener.showProgressMessage("Updating token");
                    Ingenico.getInstance().payment().processKeyedTokenEnrollmentTransactionWithCardReader(
                            getKeyedTokenUpdateWithCardReaderTransactionRequest(tokenId, tokenFee, requestAVS, requestAVS, cardPresent),
                            new TokenEnrollmentRequestCallbackImpl()
                    );
                    break;
                case R.id.fragment_payment_btn_avs_only:
                    Log.v(TAG, "AVS Only Transaction");
                    showDialog = true;
                    mProgressDialogListener.showProgressMessage("Processing AVS");
                    Ingenico.getInstance().payment().processAVSOnlyTransactionWithCardReader(
                            getAVSOnlyTransactionRequest(avsZipCode, avsAddress),
                            new TokenEnrollmentRequestCallbackImpl()
                    );

                default:
                    break;
            }
        }
    }

    @Override
    public void onActionPicked(int btnID, String txnID) {
        TransactionResponse cachedTransactionResponse = mListener.getCachedTransactionResponse();
        Integer cachedCode = mListener.getCachedTransactionResponseCode();
        if (btnID == R.id.upload_signature) {
            if (cachedTransactionResponse != null) {
                logResult(cachedCode, cachedTransactionResponse, showDialog);
            }
            uploadSignature(txnID);
        } else if (btnID == R.id.void_transaction) {
            mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Void...");
            mListener.cacheTransactionType(TransactionType.Unknown);
            Ingenico.getInstance().payment().processVoidTransaction(
                    getVoidTransactionRequest(txnID),
                    new VoidTransactionCallbackImpl()
            );
            Log.v(TAG, "Original transaction approved, void request sent");
        } else if (btnID == DialogInterface.BUTTON_NEGATIVE) {
            // Dialog cancelled
            sendEmailReceipt(txnID);
        }
    }

    @Override
    public void onApplicationSelected(ApplicationIdentifier applicationIdentifier) {
        this.applicationSelectionCallback.done(applicationIdentifier);
    }

    @Override
    public void onLocationChanged(Location location) {
        longitude = String.valueOf(location.getLongitude());
        latitude = String.valueOf(location.getLatitude());
        if (ActivityCompat.checkSelfPermission(getActivity(),
                Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(getActivity(),
                Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            locationManager.removeUpdates(this);
        }
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {
        showToast("Enabled new provider " + provider);
    }

    @Override
    public void onProviderDisabled(String provider) {
        showToast("Disabled new provider " + provider);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == SCEActivity.SECURE_CARD_ENTRY_CODE) {
            if (null != data) {
                int responseCode = data.getIntExtra(SCEActivity.PAYMENT_RESPONSE_CODE,
                        ResponseCode.TransactionDeclined);
                Log.v(TAG, "\nonActivityResult::" + responseCode);
                TransactionResponse response = data.getParcelableExtra(SCEActivity.PAYMENT_RESPONSE);
                if (responseCode == ResponseCode.Success && response != null) {
                    Log.v(TAG, "\nSecureCardEntry::onActivityResult::" + responseCode);
                    mListener.cacheTransactionResponse(response, responseCode);
                    String txnId = null;
                    logTransactionResponse(TAG, response);
                    if (!TextUtils.isEmpty(response.getTransactionId())) {
                        txnId = response.getTransactionId();
                    } else if (!TextUtils.isEmpty(response.getClientTransactionId())) {
                        txnId = response.getClientTransactionId();
                    }
                    if (response.getTransactionType() != TransactionType.CreditRefund) {
                        mListener.cacheCreditRefundableTransactionId(getTransactionIdFromResponse(response));
                    }
                    sendEmailReceipt(txnId);
                    logTransactionResponse(TAG, response);
                }
                logResult(responseCode, response, showDialog);
            }
        }
    }

    private CreditCardRefundTransactionRequest getCardRefundTransactionRequest() {
        mTransactionType = "Card Refund";
        CreditCardRefundTransactionRequest request = new CreditCardRefundTransactionRequest(refundAmount, clerkId, longitude, latitude,
                transactionNote, merchantInvocieID, showNoteAndInvoiceOnReceipt, customReference, tokenRequest, UCIFormat.Ingenico, orderNumber);
        request.setLocale(cardholderLocale);
        return request;
    }

    private RefundTransactionRequest getRefundTransactionRequest() {
        mTransactionType = "Refund";
        RefundTransactionRequest request = new RefundTransactionRequest(refundAmount, clerkId, longitude, latitude,
                transactionNote, merchantInvocieID, Boolean.TRUE, customReference, tokenRequest, UCIFormat.Ingenico, orderNumber);
        request.setLocale(cardholderLocale);
        return request;
    }

    private DebitCardRefundTransactionRequest getDebitCardRefundTransactionRequest() {
        mTransactionType = "Debit Refund";
        DebitCardRefundTransactionRequest request = new DebitCardRefundTransactionRequest(refundAmount, clerkId, longitude, latitude,
                transactionNote, merchantInvocieID, showNoteAndInvoiceOnReceipt, customReference, UCIFormat.Ingenico, orderNumber);
        request.setLocale(cardholderLocale);
        return request;
    }

    private CreditBalanceInquiryTransactionRequest getCreditBalanceInquiryTransactionRequest() {
        mTransactionType = "Credit Balance Inquiry";
        CreditBalanceInquiryTransactionRequest request = new CreditBalanceInquiryTransactionRequest(clerkId, longitude, latitude, customReference, UCIFormat.Ingenico, orderNumber);
        request.setLocale(cardholderLocale);
        return request;
    }

    private DebitBalanceInquiryTransactionRequest getDebitBalanceInquiryTransactionRequest() {
        mTransactionType = "Debit Balance Inquiry";
        DebitBalanceInquiryTransactionRequest request = new DebitBalanceInquiryTransactionRequest(clerkId, longitude, latitude, customReference, UCIFormat.Ingenico, orderNumber);
        request.setLocale(cardholderLocale);
        return request;
    }

    private BalanceInquiryTransactionRequest getBalanceInquiryTransactionRequest() {
        mTransactionType = "Balance Inquiry";
        BalanceInquiryTransactionRequest request = new BalanceInquiryTransactionRequest(clerkId, longitude, latitude, customReference, UCIFormat.Ingenico, orderNumber);
        request.setLocale(cardholderLocale);
        return request;
    }

    private TokenEnrollmentTransactionRequest getTokenEnrollmentTransactionRequest(String tokenFee) {
        mTransactionType = "Token Enrollment";
        TokenRequestParameters.Builder builder = new TokenRequestParameters.Builder()
                .setTokenFeeInCents(Utils.convertStringToInt(tokenFee))
                .setTokenReferenceNumber("TokenReq-123")
                .setCardholderFirstName("Roam")
                .setCardholderLastName("Data")
                .setBillToEmail("roam@roamdata.com")
                .setBillToAddress1("1 Federal St")
                .setBillToAddress2("Suite 1")
                .setBillToCity("Boston")
                .setBillToState("MA")
                .setBillToCountry("USA")
                .setBillToZip("02110")
                .setIgnoreAVSResut(true);
        TokenEnrollmentTransactionRequest request = new TokenEnrollmentTransactionRequest(builder.createTokenEnrollmentRequestParameters(),
                clerkId,
                longitude,
                latitude,
                UCIFormat.Ingenico,
                orderNumber);
        request.setLocale(cardholderLocale);
        return request;
    }

    private KeyedTokenEnrollmentTransactionRequest getKeyedTokenEnrollmentTransactionRequest(String tokenFee) {
        mTransactionType = "Keyed Token Enrollment";
        TokenRequestParameters.Builder builder = new TokenRequestParameters.Builder()
                .setTokenFeeInCents(Utils.convertStringToInt(tokenFee))
                .setTokenReferenceNumber("TokenReq-123")
                .setCardholderFirstName("Roam")
                .setCardholderLastName("Data")
                .setBillToEmail("roam@roamdata.com")
                .setBillToAddress1("1 Federal St")
                .setBillToAddress2("Suite 1")
                .setBillToCity("Boston")
                .setBillToState("MA")
                .setBillToCountry("USA")
                .setBillToZip("02110")
                .setIgnoreAVSResut(true);
        KeyedTokenEnrollmentTransactionRequest request = new KeyedTokenEnrollmentTransactionRequest(builder.createTokenEnrollmentRequestParameters(),
                card,
                clerkId,
                longitude,
                latitude,
                UCIFormat.Ingenico,
                orderNumber);
        request.setLocale(cardholderLocale);
        return request;
    }

    private KeyedTokenEnrollmentWithCardReaderTransactionRequest getKeyedTokenEnrollmentWithCardReaderTransactionRequest(String tokenFee, boolean requestAVS, boolean requestCVV, boolean cardPresent) {
        mTransactionType = "Manual Keyed Token Enrollment";
        TokenRequestParameters.Builder builder = new TokenRequestParameters.Builder()
                .setTokenFeeInCents(Utils.convertStringToInt(tokenFee))
                .setTokenReferenceNumber("TokenReq-123")
                .setCardholderFirstName("Roam")
                .setCardholderLastName("Data")
                .setBillToEmail("roam@roamdata.com")
                .setBillToAddress1("1 Federal St")
                .setBillToAddress2("Suite 1")
                .setBillToCity("Boston")
                .setBillToState("MA")
                .setBillToCountry("USA")
                .setBillToZip("02110")
                .setIgnoreAVSResut(true);
        KeyedTokenEnrollmentWithCardReaderTransactionRequest request = new KeyedTokenEnrollmentWithCardReaderTransactionRequest(
                builder.createTokenEnrollmentRequestParameters(),
                clerkId,
                longitude,
                latitude,
                requestAVS,
                requestCVV,
                UCIFormat.Ingenico,
                isCardPresent,
                orderNumber);
        request.setLocale(cardholderLocale);
        return request;
    }

    private KeyedTokenEnrollmentWithCardReaderTransactionRequest getKeyedTokenUpdateWithCardReaderTransactionRequest(String tokenId, String tokenFee, boolean requestAVS, boolean requestCVV, boolean cardPresent) {
        mTransactionType = "Manual Keyed Token Update";
        TokenRequestParameters.Builder builder = new TokenRequestParameters.Builder()
                .setTokenFeeInCents(Utils.convertStringToInt(tokenFee))
                .setTokenIdentifier(tokenId)
                .setTokenReferenceNumber("TokenReq-123")
                .setCardholderFirstName("Roam")
                .setCardholderLastName("Data")
                .setBillToEmail("roam@roamdata.com")
                .setBillToAddress1("1 Federal St")
                .setBillToAddress2("Suite 1")
                .setBillToCity("Boston")
                .setBillToState("MA")
                .setBillToCountry("USA")
                .setBillToZip("02110")
                .setIgnoreAVSResut(true);
        KeyedTokenEnrollmentWithCardReaderTransactionRequest request = new KeyedTokenEnrollmentWithCardReaderTransactionRequest(
                builder.createTokenUpdateRequestParameters(),
                clerkId,
                longitude,
                latitude,
                requestAVS,
                requestCVV,
                UCIFormat.Ingenico,
                cardPresent,
                orderNumber);
        request.setLocale(cardholderLocale);
        return request;
    }

    private TokenEnrollmentTransactionRequest getTokenUpdateTransactionRequest(String tokenFee, String tokenIdentifier) {
        mTransactionType = "Token Update";
        TokenRequestParameters.Builder builder = new TokenRequestParameters.Builder()
                .setTokenIdentifier(tokenIdentifier)
                .setTokenFeeInCents(Utils.convertStringToInt(tokenFee))
                .setTokenReferenceNumber("TokenReq-123")
                .setCardholderFirstName("Roam")
                .setCardholderLastName("Data")
                .setBillToEmail("roam@roamdata.com")
                .setBillToAddress1("1 Federal St")
                .setBillToAddress2("Suite 1")
                .setBillToCity("Boston")
                .setBillToState("MA")
                .setBillToCountry("USA")
                .setBillToZip("02110")
                .setIgnoreAVSResut(true);
        TokenEnrollmentTransactionRequest request = new TokenEnrollmentTransactionRequest(builder.createTokenUpdateRequestParameters(),
                clerkId,
                longitude,
                latitude,
                UCIFormat.Ingenico,
                orderNumber);
        request.setLocale(cardholderLocale);
        return request;
    }

    private KeyedTokenEnrollmentTransactionRequest getKeyedTokenUpdateTransactionRequest(String tokenFee, String tokenIdentifier) {
        mTransactionType = "Keyed Token Update";
        TokenRequestParameters.Builder builder = new TokenRequestParameters.Builder()
                .setTokenIdentifier(tokenIdentifier)
                .setTokenFeeInCents(Utils.convertStringToInt(tokenFee))
                .setTokenReferenceNumber("TokenReq-123")
                .setCardholderFirstName("Roam")
                .setCardholderLastName("Data")
                .setBillToEmail("roam@roamdata.com")
                .setBillToAddress1("1 Federal St")
                .setBillToAddress2("Suite 1")
                .setBillToCity("Boston")
                .setBillToState("MA")
                .setBillToCountry("USA")
                .setBillToZip("02110")
                .setIgnoreAVSResut(true);
        KeyedTokenEnrollmentTransactionRequest request = new KeyedTokenEnrollmentTransactionRequest(builder.createTokenUpdateRequestParameters(),
                card,
                clerkId,
                longitude,
                latitude,
                UCIFormat.Ingenico,
                orderNumber);
        request.setLocale(cardholderLocale);
        return request;
    }

    private AVSOnlyTransactionRequest getAVSOnlyTransactionRequest(String avsZipCode, String avsAddress) {
        mTransactionType = "AVS Only";
        AVSOnlyTransactionRequest request = new AVSOnlyTransactionRequest(clerkId,
                longitude,
                latitude,
                customReference,
                UCIFormat.Ingenico,
                avsZipCode,
                avsAddress,
                orderNumber);
        request.setLocale(cardholderLocale);
        return request;
    }

    private KeyedCardSaleTransactionRequest getKeyedCardSaleTransactionRequest() {
        mTransactionType = "Keyed Card Sale";
        KeyedCardSaleTransactionRequest request = new KeyedCardSaleTransactionRequest(
                card,
                saleAmount,
                getProductList(saleAmount),
                clerkId,
                longitude,
                latitude,
                null,
                transactionNote,
                merchantInvocieID,
                showNoteAndInvoiceOnReceipt,
                tokenRequest,
                customReference,
                Boolean.FALSE,
                UCIFormat.Ingenico,
                isCardPresent,
                orderNumber
        );
        request.setLocale(cardholderLocale);
        return request;
    }

    private SCECreditSaleTransactionRequest getSCECreditSaleTransactionRequest() {
        mTransactionType = "Secure Card Entry Credit Sale";
        return new SCECreditSaleTransactionRequest(
                saleAmount,
                getProductList(saleAmount),
                clerkId,
                longitude,
                latitude,
                cardholderLocale,
                null,
                transactionNote,
                merchantInvocieID,
                showNoteAndInvoiceOnReceipt,
                tokenRequest,
                customReference,
                Boolean.TRUE,
                UCIFormat.Ingenico,
                isCardPresent,
                orderNumber
        );
    }

    private SCECreditRefundTransactionRequest getSCETransactionRequestCreditRefund() {
            mTransactionType = "Secure Card Entry Credit Refund";
        SCECreditRefundTransactionRequest request = new SCECreditRefundTransactionRequest(
                    refundAmount,
                    clerkId,
                    longitude,
                    latitude,
                    transactionNote,
                    merchantInvocieID,
                    showNoteAndInvoiceOnReceipt,
                    customReference,
                    tokenRequest,
                    UCIFormat.Ingenico,
                    isCardPresent,
                    orderNumber
            );
        request.setLocale(cardholderLocale);
        return request;
    }

    private SCECreditAuthTransactionRequest getSCECreditAuthTransactionRequest() {
        mTransactionType = "Secure Card Entry Credit Auth";
        return new SCECreditAuthTransactionRequest(
                saleAmount,
                getProductList(saleAmount),
                clerkId,
                longitude,
                latitude,
                cardholderLocale,
                null,
                transactionNote,
                merchantInvocieID,
                showNoteAndInvoiceOnReceipt,
                tokenRequest,
                customReference,
                Boolean.TRUE,
                UCIFormat.Ingenico,
                isCardPresent,
                orderNumber
        );
    }

    private CashSaleTransactionRequest getCashSaleTransactionRequest() {
        mTransactionType = "Cash Sale";
        CashSaleTransactionRequest request = new CashSaleTransactionRequest(saleAmount, getProductList(saleAmount), clerkId,
                longitude, latitude, null, transactionNote, merchantInvocieID, showNoteAndInvoiceOnReceipt,
                Boolean.TRUE, customReference);
        request.setLocale(cardholderLocale);
        return request;
    }

    private KeyedCreditAuthTransactionRequest getKeyedCreditAuthTransactionRequest() {
        mTransactionType = "Keyed Credit Auth";
        KeyedCreditAuthTransactionRequest request = new KeyedCreditAuthTransactionRequest(
                card,
                saleAmount,
                getProductList(saleAmount),
                clerkId,
                longitude,
                latitude,
                null,
                transactionNote,
                merchantInvocieID,
                showNoteAndInvoiceOnReceipt,
                tokenRequest,
                customReference,
                false,
                UCIFormat.Ingenico,
                isCardPresent,
                orderNumber);
        request.setLocale(cardholderLocale);
        return request;
    }

    private CreditSaleTransactionRequest getCardSaleTransactionRequest() {
        mTransactionType = "Card Sale";
        CreditSaleTransactionRequest request = new CreditSaleTransactionRequest(
                saleAmount,
                getProductList(saleAmount),
                clerkId,
                longitude,
                latitude,
                null,
                transactionNote,
                merchantInvocieID,
                showNoteAndInvoiceOnReceipt,
                tokenRequest,
                customReference,
                false,
                UCIFormat.Ingenico,
                orderNumber
        );
        request.setLocale(cardholderLocale);
        return request;
    }

    private SaleTransactionRequest getSaleTransactionRequest() {
        mTransactionType = "Sale";
        SaleTransactionRequest request = new SaleTransactionRequest(
                saleAmount,
                getProductList(saleAmount),
                clerkId,
                longitude,
                latitude,
                null,
                transactionNote,
                merchantInvocieID,
                showNoteAndInvoiceOnReceipt,
                tokenRequest,
                customReference,
                false,
                UCIFormat.Ingenico,
                orderNumber
        );
        request.setLocale(cardholderLocale);
        return request;
    }

    private CreditAuthCompleteTransactionRequest getCreditAuthCompleteTransactionRequest(
            String originalTransactionID) {
        CreditAuthCompleteTransactionRequest request = new CreditAuthCompleteTransactionRequest(
                originalTransactionID,
                saleAmount,
                getProductList(saleAmount),
                clerkId,
                longitude,
                latitude,
                null,
                customReference,
                false,
                transactionNote,
                orderNumber
        );
        request.setLocale(cardholderLocale);
        return request;
    }

    private KeyedCardSaleTransactionWithCardReaderRequest getKeyedCardSaleRequestWithCardReader(
            boolean shouldRequestCvv,
            boolean shouldRequestAvs){
        KeyedCardSaleTransactionWithCardReaderRequest request = new KeyedCardSaleTransactionWithCardReaderRequest(
                saleAmount,
                getProductList(saleAmount),
                clerkId,
                longitude,
                latitude,
                null,
                transactionNote,
                merchantInvocieID,
                showNoteAndInvoiceOnReceipt,
                tokenRequest,
                customReference,
                Boolean.FALSE,
                shouldRequestAvs,
                shouldRequestCvv,
                UCIFormat.Ingenico,
                isCardPresent,
                orderNumber
        );
        request.setLocale(cardholderLocale);
        return request;
    }

    private KeyedCreditAuthTransactionWithCardReaderRequest getKeyedCreditAuthTransactionWithCardReaderRequest(
            boolean shouldRequestCvv,
            boolean shouldRequestAvs){
        KeyedCreditAuthTransactionWithCardReaderRequest request = new KeyedCreditAuthTransactionWithCardReaderRequest(
                saleAmount,
                getProductList(saleAmount),
                clerkId,
                longitude,
                latitude,
                null,
                transactionNote,
                merchantInvocieID,
                showNoteAndInvoiceOnReceipt,
                tokenRequest,
                customReference,
                Boolean.FALSE,
                shouldRequestAvs,
                shouldRequestCvv,
                UCIFormat.Ingenico,
                isCardPresent,
                orderNumber
        );
        request.setLocale(cardholderLocale);
        return request;
    }

    private KeyedCreditRefundTransactionWithCardReaderRequest getKeyedCreditRefundTransactionWithCardReaderRequest(){
        KeyedCreditRefundTransactionWithCardReaderRequest request = new KeyedCreditRefundTransactionWithCardReaderRequest(
                refundAmount,
                clerkId,
                longitude,
                latitude,
                transactionNote,
                merchantInvocieID,
                showNoteAndInvoiceOnReceipt,
                customReference,
                tokenRequest,
                UCIFormat.Ingenico,
                isCardPresent,
                orderNumber
        );
        request.setLocale(cardholderLocale);
        return request;
    }

    private KeyedCreditForceSaleTransactionRequest getKeyedCreditForceRequest(){
        KeyedCreditForceSaleTransactionRequest request = new KeyedCreditForceSaleTransactionRequest(
                card,
                saleAmount,
                getProductList(saleAmount),
                clerkId,
                longitude,
                latitude,
                null,
                this.authCode,
                this.systemTraceAuditNumber,
                transactionNote,
                merchantInvocieID,
                showNoteAndInvoiceOnReceipt,
                customReference,
                Boolean.FALSE,
                UCIFormat.Ingenico,
                isCardPresent,
                orderNumber
        );
        request.setLocale(cardholderLocale);
        return request;
    }

    private CreditForceSaleTransactionRequest getCreditForceRequest(){
        CreditForceSaleTransactionRequest request = new CreditForceSaleTransactionRequest(
                saleAmount,
                getProductList(saleAmount),
                clerkId,
                longitude,
                latitude,
                null,
                this.authCode,
                this.systemTraceAuditNumber,
                transactionNote,
                merchantInvocieID,
                showNoteAndInvoiceOnReceipt,
                customReference,
                Boolean.FALSE,
                UCIFormat.Ingenico,
                orderNumber
        );
        request.setLocale(cardholderLocale);
        return request;
    }

    private CreditAuthTransactionRequest getCardAuthTransactionRequest() {
        mTransactionType = "Card Sale";
        CreditAuthTransactionRequest request = new CreditAuthTransactionRequest(saleAmount, getProductList(saleAmount), clerkId,
                longitude, latitude, null,transactionNote, merchantInvocieID, showNoteAndInvoiceOnReceipt, tokenRequest, customReference, false, UCIFormat.Ingenico, orderNumber);
        request.setLocale(cardholderLocale);
        return request;
    }

    private DebitSaleTransactionRequest getDebitSaleTransactionRequest() {
        mTransactionType = "Debit Sale";
        DebitSaleTransactionRequest request = new DebitSaleTransactionRequest(saleAmount, getProductList(saleAmount), clerkId,
                longitude, latitude, null, transactionNote, merchantInvocieID, showNoteAndInvoiceOnReceipt, customReference, false, UCIFormat.Ingenico, orderNumber);
        request.setLocale(cardholderLocale);
        return request;
    }

    private CreditRefundTransactionRequest getCreditRefundTransactionRequest(
            String originalTransactionID,
            Amount amount
    ) {
        CreditRefundTransactionRequest request = new CreditRefundTransactionRequest(
                originalTransactionID,
                amount,
                clerkId,
                longitude,
                latitude,
                customReference,
                transactionNote,
                orderNumber,
                showNoteAndInvoiceOnReceipt
        );
        request.setLocale(cardholderLocale);
        return request;
    }

    private CashRefundTransactionRequest getCashRefundTransactionRequest(
            String originalTransactionID,
            Amount amount
    ) {
        CashRefundTransactionRequest request = new CashRefundTransactionRequest(
                originalTransactionID,
                amount,
                clerkId,
                longitude,
                latitude,
                customReference,
                transactionNote,
                showNoteAndInvoiceOnReceipt
        );
        request.setLocale(cardholderLocale);
        return request;
    }

    private VoidTransactionRequest getVoidTransactionRequest(String txnID) {
        mTransactionType = "Void";
        VoidTransactionRequest request = new VoidTransactionRequest(
                txnID, 
                clerkId, 
                longitude, 
                latitude, 
                customReference, 
                transactionNote, 
                orderNumber,
                showNoteAndInvoiceOnReceipt
        );
        request.setLocale(cardholderLocale);
        return request;
    }

    private TokenSaleTransactionRequest getTokenSaleTransactionRequest(String tokenId) {
        TokenSaleTransactionRequest request = new TokenSaleTransactionRequest(saleAmount,
                TOKEN_REFERENCE_NO,
                tokenId,
                getProductList(saleAmount),
                clerkId,
                longitude,
                latitude,
                null,
                transactionNote,
                merchantInvocieID,
                showNoteAndInvoiceOnReceipt,
                customReference,
                false,
                orderNumber);
        request.setLocale(cardholderLocale);
        return request;
    }

    private TokenAuthTransactionRequest getTokenAuthTransactionRequest(String tokenId) {
        TokenAuthTransactionRequest request = new TokenAuthTransactionRequest(saleAmount,
                TOKEN_REFERENCE_NO,
                tokenId,
                getProductList(saleAmount),
                clerkId,
                longitude,
                latitude,
                null,
                transactionNote,
                merchantInvocieID,
                showNoteAndInvoiceOnReceipt,
                customReference,
                false,
                orderNumber);
        request.setLocale(cardholderLocale);
        return request;
    }

    private CreditSaleAdjustTransactionRequest getCreditSaleAdjustTransactionRequest(String originalTxnId) {
        CreditSaleAdjustTransactionRequest request = new CreditSaleAdjustTransactionRequest(originalTxnId,
                saleAmount,
                getProductList(saleAmount),
                clerkId,
                longitude,
                latitude,
                null,
                transactionNote,
                merchantInvocieID,
                showNoteAndInvoiceOnReceipt,
                customReference,
                false,
                orderNumber);
        request.setLocale(cardholderLocale);
        return request;
    }

    private CreditAuthAdjustTransactionRequest getCreditAuthAdjustTransactionRequest(String originalTxnId) {
        CreditAuthAdjustTransactionRequest request = new CreditAuthAdjustTransactionRequest(originalTxnId,
                saleAmount,
                getProductList(saleAmount),
                clerkId,
                longitude,
                latitude,
                null,
                transactionNote,
                merchantInvocieID,
                showNoteAndInvoiceOnReceipt,
                customReference,
                false,
                orderNumber);
        request.setLocale(cardholderLocale);
        return request;
    }

    private KeyedCardSaleTransactionRequest getPartialAuthTransactionRequest() {
        KeyedCardSaleTransactionRequest request = new KeyedCardSaleTransactionRequest(
                card,
                saleAmount,
                getProductList(saleAmount),
                clerkId,
                longitude,
                latitude,
                transactionGroupId,
                transactionNote,
                merchantInvocieID,
                showNoteAndInvoiceOnReceipt,
                tokenRequest,
                customReference,
                false,
                UCIFormat.Ingenico,
                isCardPresent,
                orderNumber
        );
        request.setLocale(cardholderLocale);
        return request;
    }

    private CreditResaleTransactionRequest getCreditResaleTransactionRequest(String originalTransactionID) {
        CreditResaleTransactionRequest request = new CreditResaleTransactionRequest(
                originalTransactionID,
                saleAmount,
                getProductList(saleAmount),
                clerkId,
                longitude,
                latitude,
                transactionGroupId,
                transactionNote,
                merchantInvocieID,
                showNoteAndInvoiceOnReceipt,
                customReference,
                false,
                tokenRequest,
                orderNumber
        );
        request.setLocale(cardholderLocale);
        return request;
    }

    private CreditReauthTransactionRequest getCreditReauthTransactionRequest(String originalTransactionID) {
        CreditReauthTransactionRequest request = new CreditReauthTransactionRequest(
                originalTransactionID,
                saleAmount,
                getProductList(saleAmount),
                clerkId,
                longitude,
                latitude,
                transactionGroupId,
                transactionNote,
                merchantInvocieID,
                showNoteAndInvoiceOnReceipt,
                customReference,
                false,
                tokenRequest,
                orderNumber
        );
        request.setLocale(cardholderLocale);
        return request;
    }

    private void showSaleAmountDialog() {
        AmountDialogFragment.Builder builder = new AmountDialogFragment.Builder()
                .setIsCreditForce(buttonClickedId == R.id.fragment_payment_btn_credit_force_transaction ||
                        buttonClickedId == R.id.fragment_payment_btn_keyed_credit_force_transaction)
                .setIsAuthComplete(buttonClickedId == R.id.fragment_payment_btn_credit_auth_complete)
                .setCanEnrollToken(canEnrollToken)
                .setCanSetCustomRef(canSetCustomRef)
                .setIsKeyedWithDevice(isKeyedWithDevice)
                .setCachedTokenId(mListener.getCachedTokenId())
                .setIsKeyed(isKeyed)
                .setShowNoteAndInvoiceOnReceipt(canDisplayShowNoteAndInvoiceOnReceiptCheckbox)
                .setCanSetOrderNumber(canSetOrderNumber)
                .setIsTokenSale(buttonClickedId == R.id.fragment_payment_btn_keyed_token_sale
                        || buttonClickedId == R.id.fragment_payment_btn_keyed_token_auth);
        DialogFragment dialogFragment = builder.build();
        dialogFragment.setTargetFragment(this, 0);
        dialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
    }

    private void showPartialAuthAmountDialog(int remainingAmount) {
        AmountDialogFragment.Builder builder = new AmountDialogFragment.Builder()
                .setMessage("Partial auth amount should be less than or equal to " + remainingAmount)
                .setCanSetCustomRef(canSetCustomRef)
                .setIsPartialAuth(true)
                .setMinValueForAmount(1)
                .setMaxValueForAmount(remainingAmount)
                .setIsKeyed(isKeyed)
                .setShowNoteAndInvoiceOnReceipt(canDisplayShowNoteAndInvoiceOnReceiptCheckbox)
                .setCanSetOrderNumber(canSetOrderNumber);
        DialogFragment dialogFragment = builder.build();
        dialogFragment.setCancelable(false);
        dialogFragment.setTargetFragment(this, 0);
        dialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
    }

    private void showOpenRefundDialog() {
        AmountDialogFragment.Builder builder = new AmountDialogFragment.Builder()
                .setIsRefund(true)
                .setIsOpenRefund(true)
                .setCanSetCustomRef(canSetCustomRef)
				.setCanEnrollToken(canEnrollToken)
                .setCachedTokenId(mListener.getCachedTokenId())
                .setIsKeyed(isKeyed)
                .setIsKeyedWithDevice((isKeyedWithDevice))
                .setShowNoteAndInvoiceOnReceipt(canDisplayShowNoteAndInvoiceOnReceiptCheckbox)
                .setCanSetOrderNumber(canSetOrderNumber);
        DialogFragment dialogFragment = builder.build();
        dialogFragment.setTargetFragment(this, 0);
        dialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
    }

    private void showRefundAmountDialog(int refundableAmount) {
        AmountDialogFragment.Builder builder = new AmountDialogFragment.Builder()
                .setMessage("Refund amount should be less than or equal to " + refundableAmount)
                .setIsRefund(true)
                .setCanSetCustomRef(canSetCustomRef)
                .setMinValueForAmount(1)
                .setMaxValueForAmount(refundableAmount)
                .setShowNoteAndInvoiceOnReceipt(canDisplayShowNoteAndInvoiceOnReceiptCheckbox)
                .setCanSetOrderNumber(canSetOrderNumber);
        DialogFragment dialogFragment = builder.build();
        dialogFragment.setTargetFragment(this, 0);
        dialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
    }

    private void showPartialVoidAmountDialog() {
        AmountDialogFragment.Builder builder = new AmountDialogFragment.Builder()
                .setIsRefund(true)
                .setCanSetCustomRef(canSetCustomRef)
                .setShowNoteAndInvoiceOnReceipt(canDisplayShowNoteAndInvoiceOnReceiptCheckbox)
                .setIsPartialVoid(true)
                .setCanSetOrderNumber(canSetOrderNumber);
        DialogFragment dialogFragment = builder.build();
        dialogFragment.setTargetFragment(this, 0);
        dialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
    }

    private void showRefundAmountDialogIfTransactionNotFullyRefunded(String transactionId) {
        mProgressDialogListener.showProgressMessage("Fetching transaction details...");
        Ingenico.getInstance().user().getTransactionDetails(
                transactionId,
                new GetTransactionDetailsCallback() {
                    @Override
                    public void done(
                            Integer responseCode,
                            TransactionHistoryDetail transaction
                    ) {
                        mProgressDialogListener.hideProgress();
                        if (ResponseCode.Success == responseCode) {
                            if (transaction.getRefundableAmount() > 0) {
                                showRefundAmountDialog(transaction.getRefundableAmount());
                            } else {
                                Utils.newDialog(
                                        getActivity(),
                                        "Error",
                                        "Transaction has been fully refunded or is not refundable. Please first run a credit sale/credit force/cash sale transaction"
                                ).show();
                            }
                        } else {
                            Utils.newDialog(
                                    getActivity(),
                                    "Error",
                                    "Error retrieving Transaction Details for transaction id " + transactionId + "\n" +
                                            "ErrorCode: " + responseCode
                            ).show();
                        }
                    }
                }
        );

    }

    private void showInvalidClerkIdDialog(boolean onlyClerkID) {
        if (onlyClerkID) {
            ClerkIdDialogFragment.Builder builder = new ClerkIdDialogFragment.Builder()
                    .setMessage("ClerkID is up-to 4 alphanumerics")
                    .setCanCaptureTokenFee(canEnrollToken)
                    .setCanSetCustomRef(canSetCustomRef)
                    .setCachedTokenId(mListener.getCachedTokenId());
            DialogFragment dialogFragment = builder.build();
            dialogFragment.setTargetFragment(this, 0);
            dialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
        } else {
            AmountDialogFragment.Builder builder = new AmountDialogFragment.Builder()
                    .setMessage("ClerkID is up-to 4 alphanumerics")
                    .setIsCreditForce(buttonClickedId == R.id.fragment_payment_btn_credit_force_transaction ||
                            buttonClickedId == R.id.fragment_payment_btn_keyed_credit_force_transaction)
                    .setIsAuthComplete(buttonClickedId == R.id.fragment_payment_btn_credit_auth_complete)
                    .setCanEnrollToken(canEnrollToken)
                    .setCanSetCustomRef(canSetCustomRef)
                    .setCachedTokenId(mListener.getCachedTokenId())
                    .setIsKeyed(isKeyed)
                    .setShowNoteAndInvoiceOnReceipt(canDisplayShowNoteAndInvoiceOnReceiptCheckbox)
                    .setCanSetOrderNumber(canSetOrderNumber);
            DialogFragment dialogFragment = builder.build();
            dialogFragment.setTargetFragment(this, 0);
            dialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
        }
    }

    private void showInvalidAuthCodeDialog() {
        AmountDialogFragment.Builder builder = new AmountDialogFragment.Builder()
                .setMessage("Please provide valid authorization code(6 digit)")
                .setIsCreditForce(true)
                .setCanEnrollToken(canEnrollToken)
                .setCanSetCustomRef(canSetCustomRef)
                .setCachedTokenId(mListener.getCachedTokenId())
                .setIsKeyed(isKeyed)
                .setShowNoteAndInvoiceOnReceipt(canDisplayShowNoteAndInvoiceOnReceiptCheckbox)
                .setCanSetOrderNumber(canSetOrderNumber);
        DialogFragment dialogFragment = builder.build();
        dialogFragment.setTargetFragment(this, 0);
        dialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
    }

    private void showClerkIdDialog() {
        ClerkIdDialogFragment.Builder builder = new ClerkIdDialogFragment.Builder()
                .setCanCaptureTokenFee(canEnrollToken)
                .setCanUpdateToken(canUpdateToken)
                .setCanSetCustomRef(canSetCustomRef)
                .setCachedTokenId(mListener.getCachedTokenId())
                .setAvsOnly(avsOnly)
                .setCanSetTransactionNote(canSetTransactionNote)
                .setOrderNumber(canSetOrderNumber)
                .setIsCardReaderKeyed(isKeyedWithDevice);
        if (buttonClickedId == R.id.fragment_payment_btn_void_transaction || buttonClickedId == R.id.fragment_payment_btn_void_transaction_with_reader) {
                builder.setShowNoteAndInvoiceOnReceipt(true)
                        .setOrigTxnId(mListener.getCachedTransactionId());
        }
        DialogFragment dialogFragment = builder.build();
        dialogFragment.setTargetFragment(this, 0);
        dialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
    }

    private void showApplicationSelectionDialog(
            List<ApplicationIdentifier> applicationIdentifiers,
            ApplicationSelectionCallback applicationSelectionCallback) {
        this.applicationSelectionCallback = applicationSelectionCallback;
        Log.v(TAG, "Application count::" + applicationIdentifiers.size());
        DialogFragment dialogFragment = ApplicationSelectionDialog.newInstance(
                applicationIdentifiers);
        dialogFragment.setTargetFragment(this, 0);
        dialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
    }

    private void uploadSignature(final String transactionId) {
        mProgressDialogListener.showProgressMessageWithCancelButton("Uploading Signature ...", (dialog, which) -> {
            updateTransaction(transactionId);
        });
        Ingenico.getInstance().user().uploadSignature(
                transactionId,
                mSignatureImage,
                new UploadSignatureCallback() {
                    @Override
                    public void done(Integer responseCode) {
                        updateTransaction(transactionId);
                    }
                }
        );
    }

    private void sendEmailReceipt(String txnId) {
        if (txnId != null) {
            Ingenico.getInstance().user().sendEmailReceipt(
                    null,
                    txnId,
                    new EmailReceiptCallback() {
                        @Override
                        public void done(Integer responseCode) {

                        }
                    }
            );
        }
    }

    private void nextAction(final TransactionResponse response, final Integer responseCode) {
        String txnId = getTransactionIdFromResponse(response);
        if (ResponseCode.Success == responseCode
                && !TextUtils.isEmpty(txnId) &&
                response != null &&
                !TextUtils.isEmpty(response.getTransactionId())) {
            CardVerificationMethod cvm = response.getCardVerificationMethod();
            POSEntryMode entrymode = response.getPosEntryMode();
            if(response.getTransactionType() == TransactionType.CreditBalanceInquiry ||
               response.getTransactionType() == TransactionType.DebitBalanceInquiry ||
               response.getTransactionType() == TransactionType.TokenEnrollment ||
               response.getTransactionType() == TransactionType.AVSOnly) {
                logResult(responseCode, response, showDialog);
                updateTransaction(response.getTransactionId());
            }
            else if ((cvm == CardVerificationMethod.Signature
                    || cvm == CardVerificationMethod.PinAndSignature) &&
                    (entrymode == POSEntryMode.ContactEMV ||
                     entrymode == POSEntryMode.ContactlessEMV ||
                     entrymode == POSEntryMode.MagStripeEMVFail)) {
                DialogFragment dialogFragment = PendingSignatureDialog.newInstance(
                        response.getTransactionId());
                dialogFragment.setTargetFragment(this, 0);
                FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
                ft.add(dialogFragment, null);
                ft.commitAllowingStateLoss();
            } else if (response.getCardVerificationMethod() == CardVerificationMethod.Signature
                    || response.getCardVerificationMethod()
                    == CardVerificationMethod.PinAndSignature) {
                logResult(responseCode, response, showDialog);
                uploadSignature(response.getTransactionId());
            } else {
                logResult(responseCode, response, showDialog);
                updateTransaction(response.getTransactionId());
            }
        } else {
            logResult(responseCode, response, showDialog);
            if (!TextUtils.isEmpty(txnId)) {
                sendEmailReceipt(txnId);
            }
        }
    }

    private String getTransactionIdFromResponse(TransactionResponse response) {
        if (response != null) {
            if (!TextUtils.isEmpty(response.getTransactionId())) {
                return response.getTransactionId();
            } else if (!TextUtils.isEmpty(response.getClientTransactionId())) {
                return response.getClientTransactionId();
            }
        }
        return null;
    }

    private void promptForCardRemovalIfRequired(Integer responseCode, TransactionResponse response) {
        if (response.getPosEntryMode() == POSEntryMode.ContactEMV && BuildConfig.promptForCardRemoval) {
            mProgressDialogListener.showProgressMessage("Please Remove Card");
            Ingenico.getInstance().device().waitForCardRemoval(30,
                    new WaitForCardRemovalCallbackImpl(responseCode, response));
        } else {
            nextAction(response, responseCode);
        }
    }

    private void updateTransaction(final String transactionId) {
        mProgressDialogListener.showProgressMessageWithCancelButton("Updating Transaction ...", (dialog, which) -> {
            mProgressDialogListener.hideProgress();
            sendEmailReceipt(transactionId);
        });
        Ingenico.getInstance().user().updateTransaction(
                transactionId,
                new CardholderInfo(
                        "First_"+transactionId,
                        "Last_"+transactionId,
                        "X",
                        "Email_"+transactionId+"@gmail.com",
                        "1234567890",
                        "280 Summer St",
                        "Lobby Level",
                        "Boston",
                        "MA",
                        "12345"),
                null,
                true,
                false,
                new UpdateTransactionCallback() {
                    @Override
                    public void done(Integer responseCode) {
                        mProgressDialogListener.hideProgress();
                        sendEmailReceipt(transactionId);
                    }
                }
        );
    }

    private void voidPartialAuthTransactions() {
        final int size = partialTransactionIds.size();
        if (size > 0) {
            Log.i(TAG, "Voiding partial auth transaction [" + size + "]");
            mProgressDialogListener.showProgressMessage("Voiding Transactions");
            Ingenico.getInstance().payment().processVoidTransaction(
                    getVoidTransactionRequest(partialTransactionIds.get(size - 1)),
                    new TransactionCallback() {
                        @Override
                        public void updateProgress(Integer progressCode, String extraMessage) {
                            Log.d(TAG, "updateProgress::" + progressCode + "::" + extraMessage);
                            mProgressDialogListener.showProgressMessage(Utils.getProgressMessage(progressCode));
                        }

                        @Override
                        public void applicationSelection(List<ApplicationIdentifier> appList, ApplicationSelectionCallback applicationcallback) {

                        }

                        @Override
                        public void done(Integer responseCode, TransactionResponse response) {
                            Log.v(TAG, "\nTransactionCallback::done::" + responseCode);
                            if (response != null) {
                                logTransactionResponse(TAG, response);
                                partialTransactionIds.remove(size - 1);
                                logResult(responseCode, response, false);
                                voidPartialAuthTransactions();
                            } else {
                                logResult(responseCode, null, true);
                            }
                        }
                    }
            );
        } else {
            mProgressDialogListener.hideProgress();
            Utils.newDialog(getActivity(), "Success", "Voided all partial transactions. See log for details").show();
        }
    }

    /**
     * Given amount fields as strings, return a new Amount object
     */
    private Amount createNewAmount(String totalAmount, String subtotalAmount,
            String tipAmount, String taxAmount, String discountAmount,
            String surchargeAmount, String currencyCode) {
        int total = Utils.convertStringToInt(totalAmount);
        int subtotal = Utils.convertStringToInt(subtotalAmount);
        int tip = Utils.convertStringToInt(tipAmount);
        int tax = Utils.convertStringToInt(taxAmount);
        int discount = Utils.convertStringToInt(discountAmount);
        int surcharge = Utils.convertStringToInt(surchargeAmount);
        return new Amount(
                currencyCode,
                total,
                subtotal,
                tax,
                discount,
                "ROAM Discount",
                tip,
                surcharge
        );
    }

    private void logResult(int responseCode, TransactionResponse response, boolean showDialog) {
        mProgressDialogListener.hideProgress();
        String title;
        String msg = null;
        if (ResponseCode.Success == responseCode) {
            title = mTransactionType + " Complete";
        } else {
            title = mTransactionType + " Failed";
            msg = "Error code : " + responseCode;
        }
        if (response != null) {
            msg = String.format(
                    "\nResponse Code : %s \n" +
                            "TransactionID : %s \n" +
                            "TransactionGUID : %s \n" +
                            "ClerkDisplay : %s\n" +
                            "POSEntryMode : %s\n" +
                            "AuthorizedAmount : %s\n" +
                            "InvoiceID : %s\n" +
                            "Available Balance: %s\n" +
                            "Token Response Code: %s\n" +
                            "Redacted Card Number: %s\n" +
                            "Transaction Response Code: %s\n" +
                            "Card Type: %s\n" +
                            "Card Holder Name: %s\n" +
                            "Expiration Date: %s\n",
                    Utils.getResponseCodeString(responseCode),
                    response.getTransactionId(),
                    response.getTransactionGUID(),
                    response.getClerkDisplay(),
                    response.getPosEntryMode(),
                    response.getAuthorizedAmount(),
                    response.getInvoiceId(),
                    response.getAvailableBalance(),
                    Utils.getTokenResponseString(response.getTokenResponseParameters().getTokenResponseCode()),
                    BuildConfig.showResultDialogs ? response.getRedactedCardNumber() : response.getRedactedCardNumber().replaceAll("\\*", "X"),
                    response.getTransactionResponseCode(),
                    response.getCardType(),
                    response.getCardholderName(),
                    response.getCardExpirationDate()
            );
            Log.v(TAG, msg);
        }
        if (showDialog && BuildConfig.showResultDialogs) {
            Utils.newDialog(getActivity(), title, msg).show();
        }
    }

    private List<Product> getProductList(Amount saleAmount) {
        List<Product> products = new ArrayList<>();
        products.add(
                new Product(
                        "Coffee Beans",
                        saleAmount.getTotal(),
                        "Ethiopian Coffee Whole Beans",
                        mProductImage,
                        1
                )
        );
        return products;
    }

    private boolean shouldReversePendingTransactions() {
        if (!ignoreReversalBeforeTxn &&
                Ingenico.getInstance().payment().hasPendingTransactions() &&
                BuildConfig.checkForPendingTransactions) {
            Utils.newDialog(getActivity(), "Error", "Found pending transactions. Reverse them to proceed.").show();
            return true;
        }
        return false;
    }

    private void resetPartialAuthState() {
        isPerformingPartialAuth = false;
        initialSubmittedAmount = 0;
        partialAuthAmount = 0;
        transactionGroupId = null;
    }

    public interface OnFragmentInteractionListener {
        boolean isDeviceConnected();

        void cacheTransactionResponse(TransactionResponse transactionResponse, int responseCode);

        TransactionResponse getCachedTransactionResponse();

        void cacheTransactionType(TransactionType transactionType);

        int getCachedTransactionResponseCode();

        TransactionType getCachedTransactionType();

        void cacheCreditRefundableTransactionId(String transactionId);

        String getCachedCreditRefundableTransactionId();

        String getCachedTokenId();

        boolean isCancelledByUser();

        String getCachedTransactionId();
    }

    private class CashSaleTransactionCallbackImpl implements TransactionCallback {
        @Override
        public void updateProgress(Integer progressCode, String extraMessage) {
            Log.d(TAG, "updateProgress::" + progressCode + "::" + extraMessage);
            mProgressDialogListener.showTransactionProgressMessageWithCancelButton(Utils.getProgressMessage(progressCode));
        }

        @Override
        public void applicationSelection(
                List<ApplicationIdentifier> appList,
                ApplicationSelectionCallback applicationcallback) {
            showApplicationSelectionDialog(appList, applicationcallback);
        }

        @Override
        public void done(Integer responseCode, TransactionResponse response) {
            Log.v(TAG, "\nTransactionCallback::done::" + responseCode);
            logResult(responseCode, response, showDialog);
            if (response != null) {
                logTransactionResponse(TAG, response);
            }
            mProgressDialogListener.hideProgress();
            mListener.cacheTransactionResponse(response, responseCode);
            sendEmailReceipt(getTransactionIdFromResponse(response));
        }
    }

    private class BalanceInquiryTransactionCallbackImpl implements TransactionCallback {

        @Override
        public void updateProgress(Integer progressCode, String extraMessage) {
            Log.d(TAG, "updateProgress::" + progressCode + "::" + extraMessage);
            mProgressDialogListener.showTransactionProgressMessageWithCancelButton(Utils.getProgressMessage(progressCode));
        }

        @Override
        public void applicationSelection(
                List<ApplicationIdentifier> appList,
                ApplicationSelectionCallback applicationcallback) {
            showApplicationSelectionDialog(appList, applicationcallback);
        }

        @Override
        public void done(Integer responseCode, TransactionResponse response) {
            Log.v(TAG, "\nTransactionCallback::done::" + responseCode);
            mListener.cacheTransactionResponse(response, responseCode);
            mProgressDialogListener.hideProgress();
            if (response != null) {
                logTransactionResponse(TAG, response);
                promptForCardRemovalIfRequired(responseCode, response);
            } else {
                logResult(responseCode, null, showDialog);
            }
        }
    }

    private class TokenEnrollmentRequestCallbackImpl extends BaseCardReaderTransactionCallbackImpl {

        @Override
        public void updateProgress(Integer progressCode, String extraMessage) {
            super.updateProgress(progressCode, extraMessage);
            Log.d(TAG, "updateProgress::" + progressCode + "::" + extraMessage);
            mProgressDialogListener.showTransactionProgressMessageWithCancelButton(Utils.getProgressMessage(progressCode));
        }
    }

    private class VoidTransactionCallbackImpl implements TransactionCallback {
        @Override
        public void updateProgress(Integer progressCode, String extraMessage) {
            Log.d(TAG, "updateProgress::" + progressCode + "::" + extraMessage);
            mProgressDialogListener.showTransactionProgressMessageWithCancelButton(Utils.getProgressMessage(progressCode));
        }

        @Override
        public void applicationSelection(
                List<ApplicationIdentifier> appList,
                ApplicationSelectionCallback applicationcallback) {
            showApplicationSelectionDialog(appList, applicationcallback);
        }

        @Override
        public void done(Integer responseCode, TransactionResponse response) {
            Log.v(TAG, "\nTransactionCallback::done::" + responseCode);
            logResult(responseCode, response, showDialog);
            if (response != null) {
                logTransactionResponse(TAG, response);
                sendEmailReceipt(getTransactionIdFromResponse(response));
            }
            mProgressDialogListener.hideProgress();
            mListener.cacheTransactionResponse(response, responseCode);
        }
    }

    private class VasOnlyTransactionCallbackImpl implements TransactionCallback {

        @Override
        public void updateProgress(Integer progressCode, String extraMessage) {
            Log.d(TAG, "updateProgress::" + progressCode + "::" + extraMessage);
            mProgressDialogListener.showTransactionProgressMessageWithCancelButton(Utils.getProgressMessage(progressCode));
        }

        @Override
        public void applicationSelection(
                List<ApplicationIdentifier> appList,
                ApplicationSelectionCallback applicationcallback) {
        }

        @Override
        public void done(Integer responseCode, TransactionResponse response) {
            Log.v(TAG, "\nTransactionCallback::done::" + responseCode);
            mListener.cacheTransactionResponse(response, responseCode);
            mProgressDialogListener.hideProgress();
            logResult(responseCode, null, showDialog);
            if (response != null) {
                logTransactionResponse(TAG, response);
            }
        }
    }

    private class PartialAuthTransactionCallbackImpl implements TransactionCallback {
        @Override
        public void updateProgress(Integer progressCode, String extraMessage) {
            Log.d(TAG, "updateProgress::" + progressCode + "::" + extraMessage);
            mProgressDialogListener.showTransactionProgressMessageWithCancelButton(Utils.getProgressMessage(progressCode));
        }

        @Override
        public void applicationSelection(List<ApplicationIdentifier> appList, ApplicationSelectionCallback applicationcallback) {

        }

        @Override
        public void done(Integer responseCode, final TransactionResponse response) {
            Log.v(TAG, "\nTransactionCallback::done::" + responseCode);
            mListener.cacheTransactionResponse(response, responseCode);
            mProgressDialogListener.hideProgress();
            logResult(responseCode, response, showDialog);
            if (response != null) {
                logTransactionResponse(TAG, response);
                String tid = getTransactionIdFromResponse(response);
                mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Uploading signature ...");
                Ingenico.getInstance().user().uploadSignature(
                        tid,
                        mSignatureImage,
                        new UploadSignatureCallback() {
                            @Override
                            public void done(Integer responseCode) {
                                mProgressDialogListener.hideProgress();
                                int remainingAmount;
                                if (!isPerformingPartialAuth) {
                                    // for first txn
                                    initialSubmittedAmount = saleAmount.getTotal();
                                    if (response.getAuthorizedAmount() < initialSubmittedAmount) {
                                        transactionGroupId = response.getTransactionGroupId();
                                        isPerformingPartialAuth = true;
                                    } else {
                                        updateTransaction(getTransactionIdFromResponse(response));
                                        Utils.newDialog(getActivity(), "Success", "Partial Auth Completed").show();
                                    }
                                }
                                if (isPerformingPartialAuth) {
                                    partialAuthAmount += response.getAuthorizedAmount();
                                    if (partialAuthAmount < initialSubmittedAmount) {
                                        remainingAmount = initialSubmittedAmount - partialAuthAmount;
                                        if (response.getTransactionResponseCode() == TransactionResponseCode.Approved) {
                                            partialTransactionIds.add(response.getTransactionGUID());
                                            Log.i(TAG, "Transaction partially approved"
                                                    + "\n partialAuthAmount = " + partialAuthAmount
                                                    + "\n remainingAmount = " + remainingAmount);
                                        } else {
                                            Log.i(TAG, "Transaction declined"
                                                    + "\n partialAuthAmount = " + partialAuthAmount
                                                    + "\n remainingAmount = " + remainingAmount);
                                        }
                                        showPartialAuthAmountDialog(remainingAmount);
                                    } else {
                                        Log.i(TAG, "Partial auth transaction complete. "
                                                + "Updating initial transaction");
                                        updateTransaction(partialTransactionIds.get(0));
                                        Utils.newDialog(getActivity(), "Success", "Partial Auth Completed").show();
                                        partialTransactionIds.clear();
                                        resetPartialAuthState();
                                    }
                                }
                            }
                        }
                );
            } else {
                logResult(responseCode, null, true);
            }
        }
    }

    private abstract class BaseCardReaderTransactionCallbackImpl implements TransactionCallback {
        private StopWatch mStopWatch;
        private double cardReaderInteractionTime;

        /**
         * Invoked when there has been a progress in the transaction.
         *
         * @param progressCode code indicating a particular progress message
         * @param extraMessage string indicating extra message info
         */
        @Override
        public void updateProgress(Integer progressCode, String extraMessage) {
            Log.d(TAG, "updateProgress::" + Utils.getProgressMessage(progressCode) + "::" + progressCode
                    + "::" + extraMessage);
            if (ProgressMessage.CardInserted == progressCode && mStopWatch == null) {
                mStopWatch = new StopWatch();
            }
            if (null != mStopWatch
                    && (ProgressMessage.PleaseRemoveCard == progressCode || ProgressMessage.UpdatingTransaction == progressCode)) {
                cardReaderInteractionTime = mStopWatch.elapsedTime();
                String message =
                        "Cardholder interaction time :: " + cardReaderInteractionTime + "seconds";
                Log.d(TAG, message);
                showToast(message, Toast.LENGTH_LONG);
                mStopWatch = null;
            }
        }

        @Override
        public void applicationSelection(
                List<ApplicationIdentifier> appList,
                ApplicationSelectionCallback applicationcallback) {
            showApplicationSelectionDialog(appList, applicationcallback);
        }

        @Override
        public void done(Integer responseCode, TransactionResponse response) {
            if (null != mStopWatch) {
                cardReaderInteractionTime = mStopWatch.elapsedTime();
                String message =
                        "Cardholder interaction time :: " + cardReaderInteractionTime + "seconds";
                Log.d(TAG, message);
                showToast(message, Toast.LENGTH_LONG);
                mStopWatch = null;
            }
            Log.v(TAG, "\nTransactionCallback::done::" + responseCode);
            mListener.cacheTransactionResponse(response, responseCode);
            mProgressDialogListener.hideProgress();
            if (response != null) {
                logTransactionResponse(TAG, response);
                promptForCardRemovalIfRequired(responseCode, response);
            } else {
                logResult(responseCode, null, showDialog);
            }
        }
    }

    private class CreditSaleTransactionCallbackImpl extends BaseCardReaderTransactionCallbackImpl {

        @Override
        public void updateProgress(Integer progressCode, String extraMessage) {
            super.updateProgress(progressCode, extraMessage);
            if(!mListener.isCancelledByUser()) {
                if(progressCode == 1500 || progressCode == 1501){
                    mProgressDialogListener.showImplicitDeviceSetupProgressMessage(Utils.getProgressMessage(progressCode), extraMessage);
                }else{
                    mProgressDialogListener.showTransactionProgressMessageWithCancelButton(Utils.getProgressMessage(progressCode));
                }

            } else {
                mProgressDialogListener.showProgressMessage("Cancelling...");
            }
        }

        @Override
        public void done(Integer responseCode, TransactionResponse response) {
            super.done(responseCode, response);
            mListener.cacheCreditRefundableTransactionId(getTransactionIdFromResponse(response));
        }
    }

    private class CreditSaleAdjustTransactionCallbackImpl implements TransactionCallback {
        @Override
        public void updateProgress(Integer progressCode, String extraMessage) {
            Log.d(TAG, "updateProgress::" + progressCode + "::" + extraMessage);
            if(!mListener.isCancelledByUser()) {
                mProgressDialogListener.showTransactionProgressMessageWithCancelButton(Utils.getProgressMessage(progressCode));
            } else {
                mProgressDialogListener.showProgressMessage("Cancelling...");
            }
        }

        @Override
        public void applicationSelection(
                List<ApplicationIdentifier> appList,
                ApplicationSelectionCallback applicationcallback) {
            showApplicationSelectionDialog(appList, applicationcallback);
        }

        @Override
        public void done(Integer responseCode, TransactionResponse response) {
            Log.v(TAG, "\nTransactionCallback::done::" + responseCode);
            mListener.cacheTransactionResponse(response, responseCode);
            mProgressDialogListener.hideProgress();
            if (response != null) {
                logTransactionResponse(TAG, response);
                mListener.cacheCreditRefundableTransactionId(getTransactionIdFromResponse(response));
                nextAction(response, responseCode);
            } else {
                logResult(responseCode, null, showDialog);
            }
        }
    }

    private class TransactionTypeSelectionImpl implements TransactionTypeSelectionCallback {
        @Override
        public void transactionTypeSelection(TransactionTypeSelectionResponseCallback response) {
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setTitle("Transaction type");
            builder.setItems(new CharSequence[] {"Credit", "Debit"},
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int position) {
                            ApplicationType option = ApplicationType.Unknown;
                            switch (position) {
                                case 0:
                                    option = ApplicationType.Credit;
                                    break;
                                case 1:
                                    option = ApplicationType.Debit;
                                    break;
                            }
                            response.done(option);
                        }
                    });
            builder.setNegativeButton("Cancel",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int position) {
                            response.done(ApplicationType.Unknown);
                        }
                    });
            builder.setCancelable(false);
            builder.create().show();
        }
    }

    private class CreditAuthAdjustTransactionCallbackImpl implements TransactionCallback {
        @Override
        public void updateProgress(Integer progressCode, String extraMessage) {
            Log.d(TAG, "updateProgress::" + progressCode + "::" + extraMessage);
            if(!mListener.isCancelledByUser()) {
                mProgressDialogListener.showTransactionProgressMessageWithCancelButton(Utils.getProgressMessage(progressCode));
            } else {
                mProgressDialogListener.showProgressMessage("Cancelling...");
            }
        }

        @Override
        public void applicationSelection(
                List<ApplicationIdentifier> appList,
                ApplicationSelectionCallback applicationcallback) {
            showApplicationSelectionDialog(appList, applicationcallback);
        }

        @Override
        public void done(Integer responseCode, TransactionResponse response) {
            Log.v(TAG, "\nTransactionCallback::done::" + responseCode);
            mListener.cacheTransactionResponse(response, responseCode);
            mProgressDialogListener.hideProgress();
            if (response != null) {
                logTransactionResponse(TAG, response);
                mListener.cacheCreditRefundableTransactionId(getTransactionIdFromResponse(response));
                nextAction(response, responseCode);
            } else {
                logResult(responseCode, null, showDialog);
            }
        }
    }

    private class WaitForCardRemovalCallbackImpl implements WaitForCardRemovalCallback {
        Integer responseCode;
        TransactionResponse response;

        public WaitForCardRemovalCallbackImpl(Integer responseCode, TransactionResponse response) {
            this.responseCode = responseCode;
            this.response = response;
        }

        @Override
        public void done(Integer responseCode) {
            Log.v(TAG, "\nWaitForCardRemovalCallback::done::" + responseCode);
            mProgressDialogListener.hideProgress();
            nextAction(response, this.responseCode);
        }
    }

    private class CardRefundTransactionCallbackImpl extends BaseCardReaderTransactionCallbackImpl {

        @Override
        public void updateProgress(Integer progressCode, String extraMessage) {
            super.updateProgress(progressCode, extraMessage);
            Log.d(TAG, "updateProgress::" + progressCode + "::" + extraMessage);
            mProgressDialogListener.showTransactionProgressMessageWithCancelButton(Utils.getProgressMessage(progressCode));
        }
    }

    private class DebitSaleTransactionCallbackImpl extends BaseCardReaderTransactionCallbackImpl {

        @Override
        public void updateProgress(Integer progressCode, String extraMessage) {
            super.updateProgress(progressCode, extraMessage);
            Log.d(TAG, "updateProgress::" + progressCode + "::" + extraMessage);
            mProgressDialogListener.showTransactionProgressMessageWithCancelButton(Utils.getProgressMessage(progressCode));
        }
    }

    private class CreditRefundTransactionCallbackImpl implements TransactionCallback {

        @Override
        public void updateProgress(Integer progressCode, String extraMessage) {
            Log.d(TAG, "\nupdateProgress::" + progressCode + "::" + extraMessage);
            mProgressDialogListener.showTransactionProgressMessageWithCancelButton(Utils.getProgressMessage(progressCode));
        }

        @Override
        public void applicationSelection(
                List<ApplicationIdentifier> appList,
                ApplicationSelectionCallback applicationcallback) {

        }

        @Override
        public void done(Integer responseCode, TransactionResponse response) {
            Log.v(TAG, "\nCreditRefundTransactionCallbackImpl::done::" + responseCode);
            mProgressDialogListener.hideProgress();
            mListener.cacheTransactionResponse(response, responseCode);
            logResult(responseCode, response, false);
            if (response != null) {
                logTransactionResponse(TAG, response);
                promptForCardRemovalIfRequired(responseCode, response);
            }
        }
    }

    private class CreditResaleTransactionCallbackImpl implements TransactionCallback {
        @Override
        public void updateProgress(Integer progressCode, String extraMessage) {
            Log.d(TAG, "updateProgress::" + progressCode + "::" + extraMessage);
            mProgressDialogListener.showTransactionProgressMessageWithCancelButton(Utils.getProgressMessage(progressCode));
        }

        @Override
        public void applicationSelection(
                List<ApplicationIdentifier> appList,
                ApplicationSelectionCallback applicationcallback) {
            showApplicationSelectionDialog(appList, applicationcallback);
        }

        @Override
        public void done(Integer responseCode, TransactionResponse response) {
            Log.v(TAG, "\nTransactionCallback::done::" + responseCode);
            mProgressDialogListener.hideProgress();
            mListener.cacheTransactionResponse(response, responseCode);
            String txnId = getTransactionIdFromResponse(response);
            mListener.cacheCreditRefundableTransactionId(txnId);
            sendEmailReceipt(txnId);
            logResult(responseCode, response, showDialog);
            if (response != null) {
                logTransactionResponse(TAG, response);
            }
        }
    }

    private class CreditReauthTransactionCallbackImpl implements TransactionCallback {
        @Override
        public void updateProgress(Integer progressCode, String extraMessage) {
            Log.d(TAG, "updateProgress::" + progressCode + "::" + extraMessage);
            mProgressDialogListener.showTransactionProgressMessageWithCancelButton(Utils.getProgressMessage(progressCode));
        }

        @Override
        public void applicationSelection(
                List<ApplicationIdentifier> appList,
                ApplicationSelectionCallback applicationcallback) {
            showApplicationSelectionDialog(appList, applicationcallback);
        }

        @Override
        public void done(Integer responseCode, TransactionResponse response) {
            Log.v(TAG, "\nTransactionCallback::done::" + responseCode);
            mProgressDialogListener.hideProgress();
            mListener.cacheTransactionResponse(response, responseCode);
            sendEmailReceipt(getTransactionIdFromResponse(response));
            logResult(responseCode, response, showDialog);
            if (response != null) {
                logTransactionResponse(TAG, response);
            }
        }
    }

}
