package com.ingenico.mpos.app.sample;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import androidx.fragment.app.DialogFragment;

import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.ingenico.mpos.app.sample.common.logger.Log;
import com.ingenico.mpos.sdk.Ingenico;
import com.ingenico.mpos.sdk.callbacks.ConfigureBeepCallback;
import com.ingenico.mpos.sdk.callbacks.ConfigureIdleShutdownTimeoutCallback;
import com.ingenico.mpos.sdk.callbacks.GetBatteryLevelCallback;
import com.ingenico.mpos.sdk.callbacks.GetBatteryLevelWithChargingStatusCallback;
import com.ingenico.mpos.sdk.callbacks.GetCardDetailsCallback;
import com.ingenico.mpos.sdk.callbacks.GetSerialNumberCallback;
import com.ingenico.mpos.sdk.callbacks.ReadMagneticCardDataCallback;
import com.ingenico.mpos.sdk.callbacks.RetrieveDeviceLogCallback;
import com.ingenico.mpos.sdk.callbacks.RetrieveTipAmountCallback;
import com.ingenico.mpos.sdk.callbacks.SetVasMerchantCallback;
import com.ingenico.mpos.sdk.constants.ApplicationSelectionOption;
import com.ingenico.mpos.sdk.constants.POSEntryMode;
import com.ingenico.mpos.sdk.constants.ResponseCode;
import com.ingenico.mpos.sdk.data.Amount;
import com.ingenico.mpos.sdk.data.CardDetails;
import com.roam.roamreaderunifiedapi.constants.CommunicationType;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class PaymentDeviceFragment extends FragmentBase implements View.OnClickListener,
        ConfigureBeepDialogFragment.ConfigureBeepDialogListener,
        DisplayTextDialogFragment.DisplayTextDialogFragmentListener,
        ConfigureIdleShutdownTimeoutDialogFragment.ConfigureIdleShutdownTimeoutDialogListener,
        AmountDialogFragment.AmountDialogListener{
    private final static String TAG = PaymentDeviceFragment.class.getSimpleName();

    private OnFragmentInteractionListener mListener;
    private DialogFragment mDialogFragment;

    private final List<String> customMenuOptions = new ArrayList<>();


    public PaymentDeviceFragment() {
        // Required empty public constructor
    }

    public static PaymentDeviceFragment newInstance() {
        return new PaymentDeviceFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_payment_device, container, false);
        view.findViewById(
                R.id.fragment_payment_device_btn_get_allowed_pos_entry_mode).setOnClickListener(
                this);
        view.findViewById(R.id.fragment_payment_device_btn_get_battery_level).setOnClickListener(
                this);
        view.findViewById(R.id.fragment_payment_device_btn_get_battery_level_with_charging_status).setOnClickListener(
                this);
        view.findViewById(
                R.id.fragment_payment_device_btn_check_device_setup).setOnClickListener(this);
        view.findViewById(R.id.fragment_payment_device_btn_setup_device).setOnClickListener(this);
        view.findViewById(R.id.fragment_payment_device_btn_get_serial_number).setOnClickListener(
                this);
        view.findViewById(R.id.fragment_payment_device_btn_check_firmware_update).setOnClickListener(
                this);
        view.findViewById(R.id.fragment_payment_device_btn_firmware_update).setOnClickListener(
                this);
        view.findViewById(R.id.fragment_payment_device_btn_get_communication_type).setOnClickListener
                (this);
        view.findViewById(R.id.fragment_payment_device_btn_configure_beep).setOnClickListener
                (this);
        view.findViewById(R.id.fragment_payment_device_btn_read_magnetic_card_data).setOnClickListener
                (this);
        view.findViewById(R.id.fragment_payment_device_btn_read_magnetic_card_data_with_amount).setOnClickListener
                (this);
        view.findViewById(R.id.fragment_payment_device_btn_configure_idle_shutdown_timeout).setOnClickListener
                (this);
        view.findViewById(R.id.fragment_payment_device_btn_display_text).setOnClickListener
                (this);
        view.findViewById(R.id.fragment_payment_device_btn_show_home_screen).setOnClickListener
                (this);
        view.findViewById(R.id.fragment_payment_device_btn_configure_application_selection).setOnClickListener
                (this);
        view.findViewById(R.id.fragment_payment_device_btn_retrieve_tip_amount).setOnClickListener
                (this);
        view.findViewById(R.id.fragment_payment_device_btn_reset_device).setOnClickListener
                (this);
        view.findViewById(R.id.fragment_payment_device_btn_get_firmware_package_info).setOnClickListener
                (this);
        view.findViewById(R.id.fragment_payment_device_btn_show_menu_options).setOnClickListener
                (this);
        view.findViewById(R.id.fragment_payment_device_btn_enable_device_logging).setOnClickListener
                (this);
        view.findViewById(R.id.fragment_payment_device_btn_disable_device_logging).setOnClickListener
                (this);
        view.findViewById(R.id.fragment_payment_device_btn_retrieve_log).setOnClickListener
                (this);
        view.findViewById(R.id.fragment_payment_device_btn_select_e2e_key).setOnClickListener
                (this);
        view.findViewById(R.id.fragment_payment_device_btn_get_card_details).setOnClickListener(this);
        view.findViewById(R.id.fragment_payment_device_btn_set_vas_merchant).setOnClickListener
                (this);
        view.findViewById(R.id.fragment_payment_device_btn_update_working_keys).setOnClickListener
                (this);
        view.findViewById(R.id.fragment_payment_device_btn_set_brightness_level).setOnClickListener
                (this);
        return view;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mListener = (OnFragmentInteractionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onClick(View v) {
        Log.v(TAG, Utils.SEPARATOR);
        Utils.logTimeStamp(TAG);
        if (!mListener.isDeviceConnected()) {
            Utils.newDialog(getActivity(), "Warning", "Please connect the device!").show();
            return;
        }
        switch (v.getId()) {
            case R.id.fragment_payment_device_btn_get_battery_level:
                mProgressDialogListener.showProgressMessage("Getting Battery Level...");
                Ingenico.getInstance().device().getBatteryLevel(
                        new GetBatteryLevelCallback() {
                            @Override
                            public void done(Integer responseCode, Integer batteryLevel) {
                                mProgressDialogListener.hideProgress();
                                Log.v(TAG, "Battery Level ");
                                Log.v(TAG, "responseCode: " + responseCode);
                                Log.v(TAG, "batteryLevel= " + batteryLevel);

                            }
                        }
                );
                break;
            case R.id.fragment_payment_device_btn_get_battery_level_with_charging_status:
                mProgressDialogListener.showProgressMessage("Getting Battery Level With Charging Status...");
                Ingenico.getInstance().device().getBatteryLevelWithChargingStatus(
                        new GetBatteryLevelWithChargingStatusCallback() {
                            @Override
                            public void done(Integer responseCode, boolean isCharging, Integer batteryLevel) {
                                mProgressDialogListener.hideProgress();
                                Log.v(TAG, "Battery Level ");
                                Log.v(TAG, "responseCode: " + responseCode);
                                Log.v(TAG, "batteryLevel= " + batteryLevel);
                                Log.v(TAG, "is charging= " + isCharging);
                            }
                        }
                );
                break;
            case R.id.fragment_payment_device_btn_check_device_setup:
                mListener.onCheckDeviceSetup();
                break;
            case R.id.fragment_payment_device_btn_setup_device:
                mListener.onSetupDevice();
                break;
            case R.id.fragment_payment_device_btn_get_serial_number:
                mProgressDialogListener.showProgressMessage("Getting Serial Number...");
                Ingenico.getInstance().device().getDeviceSerialNumber(
                        new GetSerialNumberCallback() {
                            @Override
                            public void done(Integer responseCode, String serialNumber) {
                                mProgressDialogListener.hideProgress();
                                Log.v(TAG, "Get Serial Number ");
                                Log.v(TAG, "responseCode: " + responseCode);
                                Log.v(TAG, "serialNumber= " + serialNumber);

                            }
                        }
                );
                break;
            case R.id.fragment_payment_device_btn_get_allowed_pos_entry_mode:
                mProgressDialogListener.showProgressMessage("Getting Allowed POS Entry Mode...");
                List<POSEntryMode> posList = Ingenico.getInstance().device().allowedPOSEntryModes();
                mProgressDialogListener.hideProgress();
                if (posList != null) {
                    Log.v(TAG, "allowedPOSEntryModes= " + posList.toString());
                }
                break;
            case R.id.fragment_payment_device_btn_check_firmware_update:
               mListener.onCheckFirmwareUpdate();
                break;
            case R.id.fragment_payment_device_btn_firmware_update:
                mListener.onDoFirmwareUpdate();
                break;
            case R.id.fragment_payment_device_btn_get_communication_type:
                mProgressDialogListener.showProgressMessage("Getting Active CommunicationType...");
                CommunicationType communicationType = Ingenico.getInstance().device().
                        getActiveCommunicationType();
                mProgressDialogListener.hideProgress();
                if (communicationType != null) {
                    Log.v(TAG, communicationType.toString());
                }
                break;
            case R.id.fragment_payment_device_btn_configure_beep:
                mDialogFragment = ConfigureBeepDialogFragment.newInstance();
                mDialogFragment.setTargetFragment(this, 0);
                mDialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
                break;
            case R.id.fragment_payment_device_btn_read_magnetic_card_data:
                Log.v(TAG, "Read Magnetic Card Data");
                mProgressDialogListener.showProgressMessageWithCancelButton("Read magnetic card data in progress...",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Ingenico.getInstance().device().abortReadMagneticCardData();
                            }
                        });
                Ingenico.getInstance().device().readMagneticCardData(new ReadMagneticCardDataCallbackImpl());
                break;
            case R.id.fragment_payment_device_btn_read_magnetic_card_data_with_amount:
                Log.v(TAG, "Read Magnetic Card Data With Amount");
                AmountDialogFragment.Builder amountBuilder = new AmountDialogFragment.Builder();
                amountBuilder.setShowOnlyAmount(true);
                DialogFragment amountDialog = amountBuilder.build();
                amountDialog.setTargetFragment(this, 0);
                amountDialog.show(getActivity().getSupportFragmentManager(), TAG);
                break;
            case R.id.fragment_payment_device_btn_configure_idle_shutdown_timeout:
                Log.v(TAG, "Configure Idle Shutdown Timeout");
                mDialogFragment = ConfigureIdleShutdownTimeoutDialogFragment.newInstance();
                mDialogFragment.setTargetFragment(this, 0);
                mDialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
                break;
            case R.id.fragment_payment_device_btn_display_text:
                Log.v(TAG, "Display Text");
                DisplayTextDialogFragment dialogFragment = DisplayTextDialogFragment.newInstance();
                dialogFragment.setTargetFragment(this, 0);
                dialogFragment.show(
                        getActivity().getSupportFragmentManager(),
                        DisplayTextDialogFragment.class.getSimpleName()
                );
                break;
            case R.id.fragment_payment_device_btn_show_home_screen:
                Log.v(TAG, "Show Home Screen");
                mProgressDialogListener.showProgressMessage("Showing home screen..");
                Ingenico.getInstance().device().showHomeScreen(
                        responseCode -> {
                            mProgressDialogListener.hideProgress();
                            Log.v(TAG, "responseCode: " + responseCode);
                        }
                );
                break;
            case R.id.fragment_payment_device_btn_configure_application_selection:
                Log.v(TAG, "Configure Application Selection");
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setTitle("Application Selection Option");
                builder.setItems(new CharSequence[] {"External Device", "Pin Pad"},
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int position) {
                                ApplicationSelectionOption option = ApplicationSelectionOption.ExternalDevice;
                                switch (position) {
                                    case 0:
                                        option = ApplicationSelectionOption.ExternalDevice;
                                        break;
                                    case 1:
                                        option = ApplicationSelectionOption.PinPad;
                                        break;
                                }
                                Ingenico.getInstance().device().configureApplicationSelection(option,
                                        responseCode -> {
                                            Log.v(TAG, "responseCode: " + responseCode);
                                        }
                                );
                            }
                        });
                builder.setNegativeButton("Cancel", null);
                builder.create().show();
                break;
             case R.id.fragment_payment_device_btn_retrieve_tip_amount:
                 Log.v(TAG, "Retrieve Tip Amount");
                 mProgressDialogListener.showProgressMessage("Retrieving tip amount...");
                 Ingenico.getInstance().device().retrieveTipAmount(
                         new RetrieveTipAmountCallback() {
                             @Override
                             public void done(Integer responseCode, Integer tipAmount) {
                                 mProgressDialogListener.hideProgress();
                                 Log.v(TAG, "responseCode: " + responseCode);
                                 Log.v(TAG, "Tip Amount= " + tipAmount);
                             }
                         }
                 );
                 break;
            case R.id.fragment_payment_device_btn_reset_device:
                Log.v(TAG, "Reset Device");
                mProgressDialogListener.showProgressMessage("Resetting Device..");
                Ingenico.getInstance().device().resetDevice(
                        responseCode -> {
                            mProgressDialogListener.hideProgress();
                            Log.v(TAG, "responseCode: " + responseCode);
                        }
                );
                break;
            case R.id.fragment_payment_device_btn_get_firmware_package_info:
                Log.v(TAG, "Get Firmware package Info");
                mProgressDialogListener.showProgressMessage("Getting firmware package info..");
                Ingenico.getInstance().device().getFirmwarePackageInfo(
                        (responseCode, firmwarePackageInfo) -> {
                            mProgressDialogListener.hideProgress();
                            Log.v(TAG, "responseCode: " + responseCode);
                            if (firmwarePackageInfo != null) {
                                Log.v(TAG, "firmwarePackageInfo: " + firmwarePackageInfo.toString());
                            }
                        }
                );
                break;
            case R.id.fragment_payment_device_btn_show_menu_options:
                Log.v(TAG, "Show menu options");
                customMenuOptions.clear();
                showMenuOptionsDialog();
                break;
            case R.id.fragment_payment_device_btn_select_e2e_key:
                Log.v(TAG, "Select E2E Key");
                AlertDialog.Builder keyInputDialogBuilder = new AlertDialog.Builder(getActivity());

                final EditText input = new EditText(getContext());
                input.setHint("Enter Key Location Index 1 - 20");

                keyInputDialogBuilder.setTitle("Select E2E key")
                        .setView(input)
                        .setPositiveButton("OK", ((dialog, which) -> {
                            try {
                                Ingenico.getInstance().device().selectE2EKey(Integer.parseInt(input.getText().toString()),
                                        (responseCode -> {
                                            showToast("Response Code: " + responseCode);
                                            Log.v(TAG, "responseCode: " + responseCode);
                                        }));
                            } catch (NumberFormatException e) {
                                e.printStackTrace();
                            }
                        }))
                        .setNegativeButton("Cancel", ((dialog, which) -> {
                            dialog.cancel();
                        }));
                keyInputDialogBuilder.create().show();
                break;
            case R.id.fragment_payment_device_btn_enable_device_logging:
                Log.v(TAG, "Enable device logging");
                mProgressDialogListener.showProgressMessage("Enabling device logging..");
                Ingenico.getInstance().device().enableDeviceLogging(
                        true,
                        responseCode -> {
                            mProgressDialogListener.hideProgress();
                            Log.v(TAG, "responseCode: " + responseCode);
                        }
                );
                break;
            case R.id.fragment_payment_device_btn_disable_device_logging:
                Log.v(TAG, "Disable device logging");
                mProgressDialogListener.showProgressMessage("Disabling device logging..");
                Ingenico.getInstance().device().enableDeviceLogging(
                        false,
                        responseCode -> {
                            mProgressDialogListener.hideProgress();
                            Log.v(TAG, "responseCode: " + responseCode);
                        }
                );
                break;
            case R.id.fragment_payment_device_btn_retrieve_log:
                Log.v(TAG, "Retrieve log");
                mProgressDialogListener.showProgressMessage("Retrieving log");
                Ingenico.getInstance().device().retrieveDeviceLog(
                        new RetrieveDeviceLogCallback() {
                            @Override
                            public void done(Integer responseCode, String log) {
                                mProgressDialogListener.hideProgress();
                                Log.v(TAG, "Retrieve log responseCode: " + responseCode);
                                Log.v(TAG, "Device log retrieved: " + log);
                            }

                            @Override
                            public void updateProgress(Integer progressCode, String additionalMessage) {
                                Log.d(TAG, "updateProgress::" + progressCode + "::" + additionalMessage);
                            }
                        }
                );
                break;
            case R.id.fragment_payment_device_btn_get_card_details:
                Log.v(TAG, "Get card details");
                mProgressDialogListener.showProgressMessageWithCancelButton("Getting card details...",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Ingenico.getInstance().device().abortGetCardDetails();
                            }
                        });
                Ingenico.getInstance().device().getCardDetails(
                        new GetCardDetailsCallback() {
                            @Override
                            public void done(Integer responseCode, CardDetails cardDetails) {
                                mProgressDialogListener.hideProgress();
                                Log.v(TAG, "Get card details responseCode: " + responseCode);
                                Log.v(TAG, "Card details: " + cardDetails);
                            }

                            @Override
                            public void updateProgress(Integer progressCode, String additionalMessage) {
                                mProgressDialogListener.showProgressMessageWithCancelButton(Utils.getProgressMessage(progressCode),
                                        new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                Ingenico.getInstance().device().abortGetCardDetails();
                                            }
                                        });
                                Log.d(TAG, "updateProgress::" + progressCode + "::" + additionalMessage);
                            }
                        }
                );
                break;
            case R.id.fragment_payment_device_btn_set_vas_merchant:
                Log.v(TAG, "Set VAS merchant");
                mProgressDialogListener.showProgressMessage("Setting vas merchant");
                Ingenico.getInstance().device().setVasMerchant(
                            "pass.com.ingenico.loyaltycard2",
                            "https://www.ingenico-labs.com/ws/vas/url_coffeebar.php",
                            responseCode -> {
                                mProgressDialogListener.hideProgress();
                                Log.v(TAG, "responseCode: " + responseCode);
                            }
                    );
                break;
            case R.id.fragment_payment_device_btn_update_working_keys:
                Log.v(TAG, "Update Working Keys");
                mProgressDialogListener.showProgressMessage("Updating Working Keys");
                Ingenico.getInstance().device().updateWorkingKeys(
                        responseCode -> {
                            mProgressDialogListener.hideProgress();
                            Log.v(TAG, "responseCode: " + responseCode);
                        }
                );
                break;
            case R.id.fragment_payment_device_btn_set_brightness_level:
                Log.v(TAG, "Set Brightness Level");
                AlertDialog.Builder setBrightnessLevelInputDialogBuilder = new AlertDialog.Builder(getActivity());

                final EditText setBrightnessLevelInput = new EditText(getContext());
                setBrightnessLevelInput.setHint("Enter Brightness Level 5 - 100");
                setBrightnessLevelInput.setInputType(InputType.TYPE_CLASS_NUMBER);
                setBrightnessLevelInputDialogBuilder.setTitle("Set Brightness Level")
                        .setView(setBrightnessLevelInput)
                        .setPositiveButton("OK", ((dialog, which) -> {
                            try {
                                Ingenico.getInstance().device().setBrightnessLevel(Integer.parseInt(setBrightnessLevelInput.getText().toString()),
                                        (responseCode -> {
                                            showToast("Response Code: " + responseCode);
                                            Log.v(TAG, "responseCode: " + responseCode);
                                        }));
                            } catch (NumberFormatException e) {
                                e.printStackTrace();
                                Log.v(TAG, "set brightness level failed");
                            }
                        }))
                        .setNegativeButton("Cancel", ((dialog, which) -> {
                            dialog.cancel();
                        }));
                setBrightnessLevelInputDialogBuilder.create().show();
                break;
        }
    }

    private void showMenuOptionsDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Custom Menu Options (max 9)");

        final EditText input = new EditText(getContext());
        input.setHint("Enter Menu Option #" + customMenuOptions.size()+1);
        builder.setView(input);

        // Set up the buttons
        builder.setPositiveButton("Done", (dialog, which) -> {
            customMenuOptions.add(input.getText().toString());
            Ingenico.getInstance().device().showMenuOptions("Test Menu Title", customMenuOptions,
                    (responseCode, menuOptionSelected) -> {
                        showToast("Response Code: " + responseCode + "\n Menu Option Selected: " + menuOptionSelected);
                        Log.v(TAG, "MenuOptionSelected: " + menuOptionSelected);
                    });
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> {
            dialog.cancel();
        });
        builder.setNeutralButton("Add another option", (dialog, which) -> {
            customMenuOptions.add(input.getText().toString());
            showMenuOptionsDialog();
        });
        builder.show();
    }

    @Override
    public void displayTextParametersCaptured(Integer row, Integer column, String message) {
        if (null != row && null != column && null != message) {
            mProgressDialogListener.showProgressMessage("Displaying Text");
            Ingenico.getInstance().device().displayText(
                    row,
                    column,
                    message,
                    responseCode -> {
                        mProgressDialogListener.hideProgress();
                        Log.v(TAG, "responseCode: " + responseCode);
                        showToast(responseCode == ResponseCode.Success ? "Success" : "Failed");
                    }
            );
        }
    }

    public interface OnFragmentInteractionListener {
        void onCheckDeviceSetup();
        void onSetupDevice();
        void onCheckFirmwareUpdate();
        void onDoFirmwareUpdate();
        boolean isDeviceConnected();
    }

    @Override
    public void onConfigureBeepCaptured(boolean disableCardRemoval,
                                        boolean disableCardPresentment){
        mProgressDialogListener.showProgressMessage("Configuring Beeps...");
        Ingenico.getInstance().device().configureBeep(
                disableCardRemoval,disableCardPresentment,new ConfigureBeepCallbackImp());
    }

    @Override
    public void onTimeoutCaptured(int timeout) {
        mProgressDialogListener.showProgressMessage("Configuring idle shutdown timeout");
        Ingenico.getInstance().device().configureIdleShutdownTimeout(timeout, new ConfigureIdleShutdownTimeoutCallbackImpl());
    }

    @Override
    public void onSaleAmountCaptured(String totalAmount,
                                     String subtotalAmount,
                                     String tipAmount,
                                     String taxAmount,
                                     String discountAmount,
                                     String surchargeAmount,
                                     String currencyCode,
                                     String clerkId,
                                     String authCode,
                                     String systemTrackAuditNumber,
                                     String transactionNote,
                                     String merchantInvoiceID,
                                     boolean shouldEnrollForToken,
                                     boolean shouldUpdateForToken,
                                     boolean shouldRequestCvv,
                                     boolean shouldRequestAvs,
                                     String tokenFee,
                                     String customReference,
                                     String tokenId,
                                     boolean isCardPresent,
                                     boolean showNoteAndInvoiceOnReceipt,
                                     String orderNumber,
                                     boolean validateExpiryDate,
                                     Locale cardholderLocale) {

        mProgressDialogListener.showProgressMessageWithCancelButton("Read magnetic card data in progress...",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Ingenico.getInstance().device().abortReadMagneticCardData();
                    }
                });
        int total = Utils.convertStringToInt(totalAmount);
        int subtotal = Utils.convertStringToInt(subtotalAmount);
        int tip = Utils.convertStringToInt(tipAmount);
        int tax = Utils.convertStringToInt(taxAmount);
        int discount = Utils.convertStringToInt(discountAmount);
        int surcharge = Utils.convertStringToInt(surchargeAmount);
        Amount amount = new Amount(
                currencyCode,
                total,
                subtotal,
                tax,
                discount,
                "ROAM Discount",
                tip,
                surcharge);
        Ingenico.getInstance().device().readMagneticCardDataWithAmountDisplay(amount, new ReadMagneticCardDataCallbackImpl());
    }

    @Override
    public void onRefundAmountCaptured(String refundAmount,
            String subtotalAmount, String tipAmount, String taxAmount,
            String discountAmount,
            String surchargeAmount,
            String currencyCode,
            String customReference,
            String clerkID,
            String transactionNote,
            String orderNumber,
            boolean showNotesAndInvoiceOnReceipt,
            Locale cardholderLocale) {

    }

    @Override
    public void onOpenRefundAmountCaptured(String refundAmount,
                                           String taxAmount,
                                           String discountAmount,
                                           String surchargeAmount,
                                           String currencyCode,
                                           String transactionNote,
                                           String merchantInvoiceID,
                                           String customReference,
                                           boolean shouldEnrollForToken,
                                           boolean shouldUpdateForToken,
                                           String tokenFee,
                                           boolean isCardPresent,
                                           String clerkID,
                                           boolean showNoteAndInvoiceOnReceipt,
                                           String orderNumber,
                                           Locale cardholderLocale) {

    }

    @Override
    public void onTransactionCancelled() {

    }

    private class ConfigureIdleShutdownTimeoutCallbackImpl implements ConfigureIdleShutdownTimeoutCallback{
        public void done(Integer responseCode) {
            mProgressDialogListener.hideProgress();
            Log.v(TAG,"Configure Idle Shutdown Timeout:");
            Log.v(TAG, "responseCode: " + responseCode);
            showToast(responseCode == ResponseCode.Success ? "Success" : "Failed");
        }
    }

    private class ConfigureBeepCallbackImp implements ConfigureBeepCallback{
        @Override
        public void done(Integer responseCode){
            mProgressDialogListener.hideProgress();
            Log.v(TAG, "Configure Beep");
            Log.v(TAG, "responseCode: " + responseCode);
        }
    }

    private class ReadMagneticCardDataCallbackImpl implements ReadMagneticCardDataCallback{
        @Override
        public void done(Integer responseCode, String decryptedTrackData) {
            mProgressDialogListener.hideProgress();
            Log.v(TAG,"Read magnetic card data finished with response code:"+responseCode+
                    " with decrypted track data:"+decryptedTrackData);
            if(responseCode == ResponseCode.Success){
                Utils.newDialog(
                        getActivity(),
                        "Success",
                        "Read magnetic card data succeeded with decrypted track data:"+
                                decryptedTrackData
                ).show();
            }
            else{
                Utils.newDialog(
                        getActivity(),
                        "Error",
                        "Read magnetic card data failed with:"+responseCode
                ).show();
            }
        }
    }
}
