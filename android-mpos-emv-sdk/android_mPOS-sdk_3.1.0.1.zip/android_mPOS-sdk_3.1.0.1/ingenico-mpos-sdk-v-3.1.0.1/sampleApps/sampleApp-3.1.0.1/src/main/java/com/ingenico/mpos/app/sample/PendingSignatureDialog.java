package com.ingenico.mpos.app.sample;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import androidx.fragment.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class PendingSignatureDialog extends DialogFragment implements View.OnClickListener {
    private static final String ARG_DIALOG_MSG = "ARG_DIALOG_MSG";
    private PendingSignatureDialogListener mListener;
    private String mtxnID;

    public PendingSignatureDialog() {
    }

    public static PendingSignatureDialog newInstance(String txnID) {
        PendingSignatureDialog fragment = new PendingSignatureDialog();
        Bundle args = new Bundle();
        args.putString(ARG_DIALOG_MSG, txnID);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mtxnID = getArguments().getString(ARG_DIALOG_MSG);
        }
        setCancelable(true);
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_pendingsignature, null);
        setCancelable(false);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setView(view);
        builder.setTitle(getActivity().getString(R.string.select_action))
        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mListener.onActionPicked(which, mtxnID);
            }
        });
        TextView txtView = (TextView) view.findViewById(R.id.select_action);
        String text = getResources().getString(R.string.select_action_message);
        txtView.setText(text + "" + mtxnID);
        Button btnUploadSignature = (Button) view.findViewById(R.id.upload_signature);
        Button btnVoid = (Button) view.findViewById(R.id.void_transaction);
        btnUploadSignature.setOnClickListener(this);
        btnVoid.setOnClickListener(this);
        builder.setView(view);
        return builder.create();
    }

    @Override
    public void onClick(View v) {
        mListener.onActionPicked(v.getId(), mtxnID);
        dismiss();
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mListener = (PendingSignatureDialogListener) getTargetFragment();
        } catch (ClassCastException e) {
            throw new ClassCastException(
                    "Calling fragment must implement PendingSignatureDialogListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    public interface PendingSignatureDialogListener {
        void onActionPicked(int btnID, String txnID);
    }
}