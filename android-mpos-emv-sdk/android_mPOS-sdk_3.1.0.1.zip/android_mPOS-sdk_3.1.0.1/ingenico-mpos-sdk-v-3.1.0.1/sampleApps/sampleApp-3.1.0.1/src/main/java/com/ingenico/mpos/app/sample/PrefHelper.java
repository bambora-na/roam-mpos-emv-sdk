package com.ingenico.mpos.app.sample;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.text.TextUtils;

import com.ingenico.mpos.sdk.Ingenico;
import com.roam.roamreaderunifiedapi.constants.CommunicationType;
import com.roam.roamreaderunifiedapi.constants.DeviceType;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class PrefHelper {

    public final static String USER_NAME = "USER_NAME";
    public final static String HOST_NAME = "HOST_NAME";
    public final static String API_KEY = "API_KEY";
    public final static String LOCALE_INDEX = "LOCALE_INDEX";
    public final static String PREF_KEY_CURRENCY = "PREF_KEY_CURRENCY";
    protected final static String COMM_TYPE = "COMM_TYPE";
    private final static String PREF_KEY_CONFIGURED_DEVICE_SIZE = "PREF_KEY_CONFIGURED_DEVICE_SIZE";
    private final static String PREF_KEY_SERIAL_NUMBER = "PREF_KEY_SERIAL_NUMBER_";
    private final static String PREF_KEY_USB_PREFERRED_DEVICES = "PREF_KEY_USB_PREFERRED_DEVICES";
    private final static String PREF_KEY_MANUAL_SEARCH_COMM_TYPES = "PREF_KEY_MANUAL_SEARCH_COMM_TYPES";
    private final static String PREF_KEY_RECENT_HOST_NAMES = "PREF_KEY_RECENT_HOST_NAMES";

    public static Set<String> getConfiguredDevices(Context context) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        Set<String> configuredDevicesSerialNumbers = new HashSet<>();
        int size = sp.getInt(PREF_KEY_CONFIGURED_DEVICE_SIZE, 0);
        String serialNumber;
        for (int i = 0; i < size; i++) {
            serialNumber = sp.getString(PREF_KEY_SERIAL_NUMBER + i, null);
            if (!TextUtils.isEmpty(serialNumber)) {
                configuredDevicesSerialNumbers.add(serialNumber);
            }
        }
        return configuredDevicesSerialNumbers;
    }

    public static boolean setConfiguredDevices(
            Context context,
            Set<String> configuredDevicesSerialNumbers) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(PREF_KEY_CONFIGURED_DEVICE_SIZE, configuredDevicesSerialNumbers.size());
        int i = 0;
        for (String str : configuredDevicesSerialNumbers) {
            editor.remove(PREF_KEY_SERIAL_NUMBER + i);
            editor.putString(PREF_KEY_SERIAL_NUMBER + i, str);
            i++;
        }
        return editor.commit();
    }

    public static List<DeviceType> getUsbPreferredDevices(Context context) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        Set<String> deviceTypesSet = sp.getStringSet(PREF_KEY_USB_PREFERRED_DEVICES, null);
        if (deviceTypesSet != null) {
            List<DeviceType> deviceTypes = new ArrayList<>();
            for (String type : deviceTypesSet) {
                deviceTypes.add(DeviceType.getEnum(type));
            }
            return deviceTypes;
        }
        return null;
    }

    public static boolean setUsbPreferredDevices(
            Context context,
            List<String> preferredDeviceTypes) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = prefs.edit();
        Set<String> deviceTypesSet = new HashSet<>();
        deviceTypesSet.addAll(preferredDeviceTypes);
        editor.putStringSet(PREF_KEY_USB_PREFERRED_DEVICES, deviceTypesSet);
        return editor.commit();
    }

    public static ArrayList<CommunicationType> getManualSearchCommTypes(Context context) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        Set<String> commTypesSet = sp.getStringSet(PREF_KEY_MANUAL_SEARCH_COMM_TYPES, null);
        ArrayList<CommunicationType> commTypes = new ArrayList<>();
        if (commTypesSet != null) {
            for (String type : commTypesSet) {
                commTypes.add(CommunicationType.getEnum(type));
            }
        }
        return commTypes;
    }

    public static boolean setManualSearchCommTypes(
            Context context,
            List<CommunicationType> commTypes) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = prefs.edit();
        Set<String> commTypesSet = new HashSet<>();
        for (CommunicationType type : commTypes) {
            commTypesSet.add(type.name());
        }
        editor.putStringSet(PREF_KEY_MANUAL_SEARCH_COMM_TYPES, commTypesSet);
        return editor.commit();
    }

    public static Set<String> getRecentHostNames(Context context) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        Set<String> defaultHostnames = new HashSet<>();
        defaultHostnames.add(IngenicoConstants.URL);
        return sp.getStringSet(PREF_KEY_RECENT_HOST_NAMES, defaultHostnames);
    }

    private static boolean updateRecentHostNames(Context context, String hostName) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = prefs.edit();
        Set<String> recentHostNames = getRecentHostNames(context);
        recentHostNames.add(hostName);
        editor.putStringSet(PREF_KEY_RECENT_HOST_NAMES, recentHostNames);
        return editor.commit();
    }

    public static boolean clear(Context context) {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = sp.edit();
        editor.clear();
        return editor.commit();
    }

    public static boolean contains(Context ctx, String preferenceName) {
        return PreferenceManager.getDefaultSharedPreferences(ctx).contains(preferenceName);
    }

    // setters
    public static void set(Context ctx, String preferenceName, boolean value) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(ctx);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(preferenceName, value);
        editor.commit();
    }

    public static void set(Context ctx, String preferenceName, String value) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(ctx);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(preferenceName, value);
        editor.commit();
        if (preferenceName.equals(HOST_NAME)) {
            updateRecentHostNames(ctx, value);
        }
    }

    public static void set(Context ctx, String preferenceName, long value) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(ctx);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putLong(preferenceName, value);
        editor.commit();
    }

    public static void remove(Context ctx, String preferenceName) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(ctx);
        SharedPreferences.Editor editor = prefs.edit();
        editor.remove(preferenceName);
        editor.commit();
    }

    public static void clearAllPrefs(Context ctx) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(ctx);
        SharedPreferences.Editor editor = prefs.edit();
        editor.clear();
        editor.commit();
    }

    // getters
    public static Boolean get(Context ctx, String preferenceName, boolean fallback) {
        return PreferenceManager.getDefaultSharedPreferences(ctx).getBoolean(
                preferenceName,
                fallback
        );
    }

    public static String get(Context ctx, String preferenceName, String fallback) {
        return PreferenceManager.getDefaultSharedPreferences(ctx).getString(
                preferenceName,
                fallback
        );
    }

    public static Long get(Context ctx, String preferenceName, long fallback) {
        return PreferenceManager.getDefaultSharedPreferences(ctx).getLong(
                preferenceName,
                fallback
        );
    }
}
