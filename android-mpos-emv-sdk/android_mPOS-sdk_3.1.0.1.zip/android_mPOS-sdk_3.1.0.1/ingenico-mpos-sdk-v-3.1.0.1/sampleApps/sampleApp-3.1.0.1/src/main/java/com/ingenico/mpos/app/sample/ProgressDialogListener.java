package com.ingenico.mpos.app.sample;

import android.content.DialogInterface;

public interface ProgressDialogListener {
    void showProgressMessage(String message);

    void hideProgress();

    void showFirmwareUpdateProgressMessageWithCancelButton(String message);

    void showTransactionProgressMessageWithCancelButton(String message);

    void showProgressMessageWithCancelButton(String message, DialogInterface.OnClickListener listener);

    void showImplicitDeviceSetupProgressMessage(String message, String extraMessage);

}