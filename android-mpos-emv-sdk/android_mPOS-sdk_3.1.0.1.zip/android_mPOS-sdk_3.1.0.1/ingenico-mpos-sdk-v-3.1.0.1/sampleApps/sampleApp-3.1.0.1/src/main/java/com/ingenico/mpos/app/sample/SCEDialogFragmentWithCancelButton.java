/*
 * //////////////////////////////////////////////////////////////////////////////
 * //
 * // Copyright (c) 2018 ROAM, Inc. All rights reserved.
 * //
 * //////////////////////////////////////////////////////////////////////////////
 */

package com.ingenico.mpos.app.sample;

import android.app.Dialog;
import android.os.Bundle;
import androidx.annotation.NonNull;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import com.ingenico.mpos.sdk.SCEDialogFragment;
import com.ingenico.mpos.sdk.request.SCECreditAuthTransactionRequest;
import com.ingenico.mpos.sdk.request.SCECreditRefundTransactionRequest;
import com.ingenico.mpos.sdk.request.SCECreditSaleTransactionRequest;

/**
 * This fragment renders the secure card entry content as a dialog with a cancel button.
 * to create an instance of this dialog fragment.
 */
public class SCEDialogFragmentWithCancelButton extends SCEDialogFragment {

    private static final String ARGKEY_SCE_CREDIT_SALE_TRANSACTION_REQUEST = "ARGKEY_SCE_CREDIT_SALE_TRANSACTION_REQUEST";
    private static final String ARGKEY_SCE_CREDIT_REFUND_TRANSACTION_REQUEST = "ARGKEY_SCE_CREDIT_REFUND_TRANSACTION_REQUEST";
    private static final String ARGKEY_SCE_CREDIT_AUTH_TRANSACTION_REQUEST = "ARGKEY_SCE_CREDIT_AUTH_TRANSACTION_REQUEST";

    private SCECreditSaleTransactionRequest mCreditSaleTransactionRequest;
    private SCECreditRefundTransactionRequest mCreditRefundTransactionRequest;

    /**
     * Creates an instance of this secure card entry dialog fragment.
     * Must implement {@link com.ingenico.mpos.sdk.callbacks.TransactionCallback}
     * @param request secure card entry credit sale transaction request. See {@link SCECreditSaleTransactionRequest}
     * @return Instance of SCEDialogFragment
     * @throws IllegalArgumentException if TransactionRequest or Amount is null
     * @throws RuntimeException if OnFragmentInteractionListener is not implemented.
     */
    public static SCEDialogFragmentWithCancelButton newInstance(SCECreditSaleTransactionRequest request) {
        SCEDialogFragmentWithCancelButton fragment = new SCEDialogFragmentWithCancelButton();
        if (request != null) {
            Bundle args = new Bundle();
            args.putParcelable(ARGKEY_SCE_CREDIT_SALE_TRANSACTION_REQUEST, request);
            fragment.setArguments(args);
        } else {
            throw new IllegalArgumentException("Transaction request cannot be null");
        }
        return fragment;
    }

    /**
     * Creates an instance of this secure card entry dialog fragment.
     * Must implement {@link com.ingenico.mpos.sdk.callbacks.TransactionCallback}
     * @param request secure card entry credit refund transaction request. See {@link SCECreditRefundTransactionRequest}
     * @return Instance of SCEDialogFragment
     * @throws IllegalArgumentException if TransactionRequest or Amount is null
     * @throws RuntimeException if OnFragmentInteractionListener is not implemented.
     */
    public static SCEDialogFragmentWithCancelButton newInstance(SCECreditRefundTransactionRequest request) {
        SCEDialogFragmentWithCancelButton fragment = new SCEDialogFragmentWithCancelButton();
        if (request != null) {
            Bundle args = new Bundle();
            args.putParcelable(ARGKEY_SCE_CREDIT_REFUND_TRANSACTION_REQUEST, request);
            fragment.setArguments(args);
        } else {
            throw new IllegalArgumentException("Transaction request cannot be null");
        }
        return fragment;
    }

    /**
     * Creates an instance of this secure card entry dialog fragment.
     * Must implement {@link com.ingenico.mpos.sdk.callbacks.TransactionCallback}
     * @param request secure card entry credit auth transaction request. See {@link SCECreditAuthTransactionRequest}
     * @return Instance of SCEDialogFragment
     * @throws IllegalArgumentException if TransactionRequest or Amount is null
     * @throws RuntimeException if OnFragmentInteractionListener is not implemented.
     */
    public static SCEDialogFragmentWithCancelButton newInstance(SCECreditAuthTransactionRequest request) {
        SCEDialogFragmentWithCancelButton fragment = new SCEDialogFragmentWithCancelButton();
        if (request != null) {
            Bundle args = new Bundle();
            args.putParcelable(ARGKEY_SCE_CREDIT_AUTH_TRANSACTION_REQUEST, request);
            fragment.setArguments(args);
        } else {
            throw new IllegalArgumentException("Transaction request cannot be null");
        }
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        return super.onCreateDialog(savedInstanceState);
    }

    @Override
    public View onCreateView(
            LayoutInflater inflater,
            ViewGroup container,
            Bundle savedInstanceState
    ) {
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    /**
     * Inflate custom layout
     */
    @Override
    public View inflateLayout(LayoutInflater inflater, ViewGroup container) {
        View view = inflater.inflate(R.layout.dialog_sce_with_cancel_button, container, false);
        ImageButton cancel = view.findViewById(R.id.dialog_sce_btn_cancel);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
        return view;
    }
}
