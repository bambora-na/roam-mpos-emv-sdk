/*
 * //////////////////////////////////////////////////////////////////////////////
 * //
 * // Copyright (c) 2017 ROAM, Inc. All rights reserved.
 * //
 * //////////////////////////////////////////////////////////////////////////////
 */

package com.ingenico.mpos.app.sample;

import static com.ingenico.mpos.sdk.SCEActivity.PAYMENT_RESPONSE;
import static com.ingenico.mpos.sdk.SCEActivity.PAYMENT_RESPONSE_CODE;
import static com.ingenico.mpos.sdk.SCEActivity.PAYMENT_RESULT;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import androidx.fragment.app.DialogFragment;
import androidx.appcompat.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;

import com.ingenico.mpos.app.sample.common.logger.Log;
import com.ingenico.mpos.sdk.SCEActivity;
import com.ingenico.mpos.sdk.SCEDialogFragment;
import com.ingenico.mpos.sdk.callbacks.ApplicationSelectionCallback;
import com.ingenico.mpos.sdk.callbacks.TransactionCallback;
import com.ingenico.mpos.sdk.constants.ResponseCode;
import com.ingenico.mpos.sdk.request.SCECreditAuthTransactionRequest;
import com.ingenico.mpos.sdk.request.SCECreditRefundTransactionRequest;
import com.ingenico.mpos.sdk.request.SCECreditSaleTransactionRequest;
import com.ingenico.mpos.sdk.response.TransactionResponse;
import com.roam.roamreaderunifiedapi.data.ApplicationIdentifier;

import java.util.List;

public class SecureCardEntryActivity extends AppCompatActivity implements
        View.OnClickListener,
        TransactionCallback {
    private static final String TAG = SecureCardEntryActivity.class.getSimpleName();
    public static final String ARGKEY_SCE_CREDIT_SALE_TRANSACTION_REQUEST = "ARGKEY_SCE_CREDIT_SALE_TRANSACTION_REQUEST";
    public static final String ARGKEY_SCE_CREDIT_AUTH_TRANSACTION_REQUEST = "ARGKEY_SCE_CREDIT_AUTH_TRANSACTION_REQUEST";
    public static final String ARGKEY_SCE_CREDIT_REFUND_TRANSACTION_REQUEST = "ARGKEY_SCE_CREDIT_REFUND_TRANSACTION_REQUEST";
    public static final String SAVEKEY_SCE_CREDIT_SALE_TRANSACTION_REQUEST = "SAVEKEY_SCE_CREDIT_SALE_TRANSACTION_REQUEST";
    public static final String SAVEKEY_SCE_CREDIT_AUTH_TRANSACTION_REQUEST = "SAVEKEY_SCE_CREDIT_AUTH_TRANSACTION_REQUEST";
    public static final String SAVEKEY_SCE_CREDIT_REFUND_TRANSACTION_REQUEST = "SAVEKEY_SCE_CREDIT_REFUND_TRANSACTION_REQUEST";

    SCECreditRefundTransactionRequest mCreditRefundTransactionRequest;
    SCECreditSaleTransactionRequest mCreditSaleTransactionRequest;
    SCECreditAuthTransactionRequest mCreditAuthTransactionRequest;
    private boolean mResponseReceived;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secure_card_entry);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        if (savedInstanceState != null) {
                mCreditSaleTransactionRequest = savedInstanceState.getParcelable(SAVEKEY_SCE_CREDIT_SALE_TRANSACTION_REQUEST);
                mCreditRefundTransactionRequest = savedInstanceState.getParcelable(SAVEKEY_SCE_CREDIT_REFUND_TRANSACTION_REQUEST);
                mCreditAuthTransactionRequest = savedInstanceState.getParcelable(SAVEKEY_SCE_CREDIT_AUTH_TRANSACTION_REQUEST);
        }
        else
        {
            if(getIntent().hasExtra(ARGKEY_SCE_CREDIT_SALE_TRANSACTION_REQUEST)){
                mCreditSaleTransactionRequest = getIntent().getExtras().getParcelable(ARGKEY_SCE_CREDIT_SALE_TRANSACTION_REQUEST);
            }
            else if(getIntent().hasExtra(ARGKEY_SCE_CREDIT_AUTH_TRANSACTION_REQUEST)){
                mCreditAuthTransactionRequest = getIntent().getExtras().getParcelable(ARGKEY_SCE_CREDIT_AUTH_TRANSACTION_REQUEST);
            }
            else if(getIntent().hasExtra(ARGKEY_SCE_CREDIT_REFUND_TRANSACTION_REQUEST)){
                mCreditRefundTransactionRequest = getIntent().getExtras().getParcelable(ARGKEY_SCE_CREDIT_REFUND_TRANSACTION_REQUEST);
            }
            else{
                throw new IllegalArgumentException("Transaction request cannot be null");
            }
        }

        findViewById(R.id.activity_sce_btn_secure_card_entry).setOnClickListener(this);
        findViewById(R.id.activity_sce_btn_secure_card_entry_dialog).setOnClickListener(this);
        findViewById(R.id.activity_sce_btn_secure_card_entry_dialog_with_cancel_btn).setOnClickListener(this);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelable(SAVEKEY_SCE_CREDIT_SALE_TRANSACTION_REQUEST, mCreditSaleTransactionRequest);
        outState.putParcelable(SAVEKEY_SCE_CREDIT_REFUND_TRANSACTION_REQUEST, mCreditRefundTransactionRequest);
        outState.putParcelable(SAVEKEY_SCE_CREDIT_AUTH_TRANSACTION_REQUEST, mCreditAuthTransactionRequest);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                setResult(RESULT_CANCELED);
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View view) {
        DialogFragment fragment;
        switch (view.getId()) {
            case R.id.activity_sce_btn_secure_card_entry:
                if(mCreditSaleTransactionRequest!=null){
                    startActivityForResult(
                            SCEActivity.createIntent(this, mCreditSaleTransactionRequest),
                            SCEActivity.SECURE_CARD_ENTRY_CODE
                    );
                }
                else if(mCreditAuthTransactionRequest!=null){
                    startActivityForResult(
                            SCEActivity.createIntent(this, mCreditAuthTransactionRequest),
                            SCEActivity.SECURE_CARD_ENTRY_CODE
                    );
                }
                else if(mCreditRefundTransactionRequest!=null){
                    startActivityForResult(
                            SCEActivity.createIntent(this, mCreditRefundTransactionRequest),
                            SCEActivity.SECURE_CARD_ENTRY_CODE
                    );
                }
                break;
            case R.id.activity_sce_btn_secure_card_entry_dialog:
                if(mCreditSaleTransactionRequest!=null){
                    fragment = SCEDialogFragment.newInstance(mCreditSaleTransactionRequest);
                    fragment.show(getSupportFragmentManager(), "tag");
                }
                else if(mCreditAuthTransactionRequest!=null){
                    fragment = SCEDialogFragment.newInstance(mCreditAuthTransactionRequest);
                    fragment.show(getSupportFragmentManager(), "tag");
                }
                else if(mCreditRefundTransactionRequest!=null){
                    fragment = SCEDialogFragment.newInstance(mCreditRefundTransactionRequest);
                    fragment.show(getSupportFragmentManager(), "tag");
                }
                break;
            case R.id.activity_sce_btn_secure_card_entry_dialog_with_cancel_btn:
                if(mCreditSaleTransactionRequest!=null){
                    fragment = SCEDialogFragmentWithCancelButton.newInstance(mCreditSaleTransactionRequest);
                    fragment.show(getSupportFragmentManager(), "tag");
                }
                else if(mCreditAuthTransactionRequest!=null){
                    fragment = SCEDialogFragmentWithCancelButton.newInstance(mCreditAuthTransactionRequest);
                    fragment.show(getSupportFragmentManager(), "tag");
                }
                else if(mCreditRefundTransactionRequest!=null){
                    fragment = SCEDialogFragmentWithCancelButton.newInstance(mCreditRefundTransactionRequest);
                    fragment.show(getSupportFragmentManager(), "tag");
                }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == SCEActivity.SECURE_CARD_ENTRY_CODE) {
            if (resultCode == RESULT_CANCELED) {
                sendResult(ResponseCode.TransactionCancelled, null);
            }
            if (null != data) {
                sendResult((data.getIntExtra(SCEActivity.PAYMENT_RESPONSE_CODE,
                        ResponseCode.TransactionDeclined)),
                        (TransactionResponse) data.getParcelableExtra(SCEActivity.PAYMENT_RESPONSE));
            }
        }
    }

    /**
     * Invoked when there has been a progress in the transaction.
     *
     * @param progressCode code indicating a particular progress message
     * @param extraMessage string indicating extra message info
     */
    @Override
    public void updateProgress(Integer progressCode, String extraMessage) {
        Log.w(TAG, "updateProgress::" + progressCode );
    }

    /**
     * Invoked when it is required to prompt the customer to select an application.
     *
     * @param appList             list of available applications
     * @param applicationcallback callback used to indicate when customer finishes application
     */
    @Override
    public void applicationSelection(List<ApplicationIdentifier> appList,
            ApplicationSelectionCallback applicationcallback) {

    }

    /**
     * Invoked when the transaction process is complete.
     *
     * @param responseCode code to indicate whether the action has succeeded or failed
     *                     See {@link ResponseCode}
     * @param response     transactionResponse object
     */
    @Override
    public void done(Integer responseCode, TransactionResponse response) {
        mResponseReceived = true;
        sendResult(responseCode, response);
    }

    private void sendResult(Integer responseCode, TransactionResponse response) {
        Intent result = new Intent();
        result.putExtra(PAYMENT_RESPONSE_CODE, responseCode);
        result.putExtra(PAYMENT_RESPONSE, (Parcelable) response);
        setResult(PAYMENT_RESULT, result);
        finish();
    }
}
