package com.ingenico.mpos.app.sample;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.ingenico.mpos.app.sample.common.logger.Log;
import com.ingenico.mpos.sdk.Ingenico;
import com.roam.roamreaderunifiedapi.callback.SearchListener;
import com.roam.roamreaderunifiedapi.constants.CommunicationType;
import com.roam.roamreaderunifiedapi.constants.DeviceType;
import com.roam.roamreaderunifiedapi.constants.Parameter;
import com.roam.roamreaderunifiedapi.data.Device;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class SelectDeviceFragment extends FragmentBase implements
        SearchListener, View.OnClickListener, ListView.OnItemClickListener {
    private final static String TAG = SelectDeviceFragment.class.getSimpleName();
    private static final String DEVICE_TYPE = "DEVICE_TYPE";
    private static final String COMM_TYPES = "COMM_TYPES";
    private List<DeviceListItem> availableDevices;
    private ArrayAdapter<DeviceListItem> availableDeviceAdapter;
    private Device selectedDevice;
    private CommunicationType commType;

    private ListView lvAvailableDevices;
    private Button btnSelect;
    private Button btnPair;
    private Button btnTurnOnDevice;
    private ProgressBar progressBar;

    private OnFragmentInteractionListener mListener;
    private DeviceType mDeviceType;
    private ArrayList<CommunicationType> mCommTypes;

    public SelectDeviceFragment() {
        // Required empty public constructor
    }

    public static SelectDeviceFragment newInstance() {
        return new SelectDeviceFragment();
    }

    public static SelectDeviceFragment newInstance(DeviceType deviceType, ArrayList<CommunicationType> manualSearchCommTypes) {
        SelectDeviceFragment fragment = new SelectDeviceFragment();
        Bundle args = new Bundle();
        args.putString(DEVICE_TYPE, deviceType.toString());
        args.putSerializable(COMM_TYPES, manualSearchCommTypes);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        mDeviceType = DeviceType.getEnum(
                getArguments().getString(DEVICE_TYPE, DeviceType.UNKNOWN.toString())
        );
        mCommTypes = (ArrayList<CommunicationType>) getArguments().getSerializable(COMM_TYPES);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_select_device, container, false);
        lvAvailableDevices = (ListView) view.findViewById(
                R.id.fragment_select_device_lv_bluetooth_devices);
        btnSelect = (Button) view.findViewById(R.id.fragment_select_device_btn_select);
        btnPair = (Button) view.findViewById(R.id.fragment_select_device_btn_pair);
        btnTurnOnDevice = (Button) view.findViewById(R.id.fragment_select_device_btn_turn_on);
        progressBar = (ProgressBar) view.findViewById(R.id.fragment_select_device_progress_bar);

        btnSelect.setEnabled(false);
        if (DeviceType.RP450c == mDeviceType) {
            btnPair.setVisibility(View.VISIBLE);
            btnTurnOnDevice.setVisibility(View.VISIBLE);
            btnPair.setOnClickListener(this);
            btnTurnOnDevice.setOnClickListener(this);
        }
        btnSelect.setOnClickListener(this);
        setupBluetoothDevicesListView();
        return view;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mListener = (OnFragmentInteractionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onBackPressed() {
        Ingenico.getInstance().device().stopSearch();
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    private void setupBluetoothDevicesListView() {
        availableDevices = new ArrayList<>();
        availableDeviceAdapter = new DeviceArrayAdapter(
                getActivity(),
                android.R.layout.simple_list_item_1,
                android.R.id.text1,
                availableDevices
        );
        lvAvailableDevices.setAdapter(availableDeviceAdapter);
        lvAvailableDevices.setOnItemClickListener(this);
        Ingenico.getInstance().device().search(
                getActivity(),
                true,
                15000L,
                mCommTypes,
                this
        );
        progressBar.setVisibility(View.VISIBLE);
    }

    @Override
    public void onDeviceDiscovered(Device device) {
        Log.v(TAG, "onDeviceDiscovered::" + device);
        if (deviceNameMatchesDeviceType(device, mDeviceType)) {
            if (device.getConnectionType() == CommunicationType.Usb) {
                Log.v(TAG, device.getDeviceInfo().get(Parameter.UsbDeviceInfo).toString() + "\n");
            }
            availableDevices.add(new DeviceListItem(device));
            availableDeviceAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onDiscoveryComplete() {
        Log.v(TAG, "onDiscoveryComplete");
        progressBar.setVisibility(View.INVISIBLE);
        availableDeviceAdapter.notifyDataSetChanged();
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (R.id.fragment_select_device_btn_select == id) {
            if (mDeviceType == DeviceType.RP450c
                    && commType == CommunicationType.Bluetooth
                    && !isPaired()
                    ) {
                showToast(
                        "Reader not paired",
                        Toast.LENGTH_SHORT
                );
            } else {
                mListener.onDeviceSelected(selectedDevice);
            }
        } else if (R.id.fragment_select_device_btn_pair == id) {
            mListener.onPairButtonClicked();
        } else if (R.id.fragment_select_device_btn_turn_on == id) {
            mListener.onTurnOnDeviceButtonClicked();
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Log.v(TAG, "selectedDevice::" + selectedDevice);
        view.setSelected(true);
        selectedDevice = availableDevices.get(position).getDevice();
        commType = selectedDevice.getConnectionType();
        if (commType == CommunicationType.AudioJack
                && selectedDevice.getDeviceType() == DeviceType.RP450c) {
            btnPair.setEnabled(true);
            btnSelect.setEnabled(false);
        } else {
            btnPair.setEnabled(false);
            btnSelect.setEnabled(true);
        }
    }

    private boolean isPaired() {
        Set<BluetoothDevice> pairedDevices =
                BluetoothAdapter.getDefaultAdapter().getBondedDevices();
        for (BluetoothDevice device : pairedDevices) {
            if (selectedDevice != null && device.getAddress().equals(
                    selectedDevice.getIdentifier())) {
                return true;
            }
        }
        return false;
    }

    private String getBluetoothDeviceNamePrefix(DeviceType deviceType) {
        String prefix = null;
        switch (deviceType) {
            case RP750x:
                prefix = "RP75";
                break;
            case UNKNOWN:
                break;
            case RP450c:
                prefix = "RP45";
                break;
            case MOBY3000:
                prefix = "MOB30";
                break;
            case RP45BT:
                prefix = "RP45BT";
                break;
            case MOBY8500:
                prefix = "MOB85";
                break;
            case MOBY5500:
                prefix = "MOB55";
                break;
            case MOBYTAP:
                prefix = "MOBYTAP";
                break;
        }
        return prefix;
    }
    private boolean deviceNameMatchesDeviceType(Device device, DeviceType deviceType) {
        if (device.getConnectionType() == CommunicationType.Bluetooth) {
            String deviceNamePrefix = getBluetoothDeviceNamePrefix(deviceType);
            return (device.getName() != null && device.getName().startsWith(deviceNamePrefix));
        }
        return true;
    }

    class DeviceListItem {
        private final Device mDevice;

        DeviceListItem(Device device) {
            mDevice = device;
        }

        public Device getDevice() {
            return mDevice;
        }

        @Override
        public String toString() {
            return  mDevice.getName() + " - " + mDevice.getConnectionType()  + "\n(" + mDevice.getIdentifier() + ")";
        }
    }

    class DeviceArrayAdapter extends ArrayAdapter{
        public DeviceArrayAdapter(@NonNull Context context, int resource, int textViewResourceId, @NonNull List objects) {
            super(context, resource, textViewResourceId, objects);
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            DeviceListItem deviceListItem = availableDevices.get(position);
            TextView tvDeviceName = (TextView)super.getView(position, convertView, parent);
            tvDeviceName.setContentDescription("textview_device_id_" + deviceListItem.getDevice().getName());
            return tvDeviceName;
        }
    }

    public interface OnFragmentInteractionListener {
        void onDeviceSelected(Device device);
        void onTurnOnDeviceButtonClicked();
        void onPairButtonClicked();
    }

}
