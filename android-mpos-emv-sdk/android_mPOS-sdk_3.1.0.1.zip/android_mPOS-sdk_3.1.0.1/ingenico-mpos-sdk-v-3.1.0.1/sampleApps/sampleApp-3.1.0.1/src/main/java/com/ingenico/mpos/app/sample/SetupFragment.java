package com.ingenico.mpos.app.sample;

import android.os.Bundle;

import com.ingenico.mpos.sdk.Ingenico;
import com.ingenico.mpos.sdk.data.Preference;
import com.roam.roamreaderunifiedapi.constants.CommunicationType;
import java.util.Locale;

public class SetupFragment extends BaseSetupFragment {

    public SetupFragment() {
        // Required empty public constructor
    }

    public static SetupFragment newInstance(CommunicationType type, String apiKey,
            String hostname, int localeIndex) {
        SetupFragment fragment = new SetupFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_COMMUNICATION_TYPE_ORDINAL, type.ordinal());
        args.putString(ARG_HOST_NAME, hostname);
        args.putString(ARG_API_KEY, apiKey);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    void initializeSDK() {
        PrefHelper.set(getActivity().getApplicationContext(), PrefHelper.HOST_NAME, mHostname);
        PrefHelper.set(getActivity().getApplicationContext(), PrefHelper.API_KEY, mAPIKey);
        final Ingenico ingenico = Ingenico.getInstance();
        if(mConfigMode == null){
            ingenico.initialize(
                    getActivity().getApplicationContext(),
                    mHostname,
                    mAPIKey,
                    "0.1"
            );
        }else{
            Preference.Builder prefBuilder = new Preference.Builder();
            prefBuilder.setConfigMode(mConfigMode)
                    .setRetryCount(mRetryCount)
                    .setMerchantLocale(Locale.US);
            ingenico.initialize(
                    getActivity().getApplicationContext(),
                    mHostname,
                    mAPIKey,
                    "0.1",
                    60000,
                    60000,
                    prefBuilder.build()
            );
        }
        ingenico.setLogging(true);

        setupIngenicoSDK();
    }
}
