package com.ingenico.mpos.app.sample;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.core.app.ActivityCompat;
import androidx.fragment.app.DialogFragment;

import com.ingenico.mpos.app.sample.common.logger.Log;
import com.ingenico.mpos.app.sample.dialogs.UpdateTransactionDialogFragment;
import com.ingenico.mpos.sdk.Ingenico;
import com.ingenico.mpos.sdk.callbacks.ApplicationSelectionCallback;
import com.ingenico.mpos.sdk.callbacks.DeleteStoredTransactionCallback;
import com.ingenico.mpos.sdk.callbacks.GetStoredTransactionCallback;
import com.ingenico.mpos.sdk.callbacks.GetStoredTransactionsCallback;
import com.ingenico.mpos.sdk.callbacks.StoreReceiptForStoredTransactionCallback;
import com.ingenico.mpos.sdk.callbacks.TransactionCallback;
import com.ingenico.mpos.sdk.constants.ResponseCode;
import com.ingenico.mpos.sdk.constants.TransactionType;
import com.ingenico.mpos.sdk.constants.UCIFormat;
import com.ingenico.mpos.sdk.data.Amount;
import com.ingenico.mpos.sdk.data.CardholderInfo;
import com.ingenico.mpos.sdk.data.Product;
import com.ingenico.mpos.sdk.data.StoredTransactionSummary;
import com.ingenico.mpos.sdk.data.TokenRequestParameters;
import com.ingenico.mpos.sdk.request.StoreAndForwardCashSaleTransactionRequest;
import com.ingenico.mpos.sdk.request.StoreAndForwardCreditAuthTransactionRequest;
import com.ingenico.mpos.sdk.request.StoreAndForwardCreditSaleTransactionRequest;
import com.ingenico.mpos.sdk.request.StoreAndForwardKeyedCardSaleTransactionRequest;
import com.ingenico.mpos.sdk.request.StoreAndForwardKeyedTokenEnrollmentTransactionRequest;
import com.ingenico.mpos.sdk.request.StoreAndForwardTokenEnrollmentTransactionRequest;
import com.ingenico.mpos.sdk.request.StoreAndForwardVoidTransactionRequest;
import com.ingenico.mpos.sdk.response.TransactionResponse;
import com.roam.roamreaderunifiedapi.data.ApplicationIdentifier;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class StoreAndForwardFragment extends FragmentBase
        implements View.OnClickListener,
        AmountDialogFragment.AmountDialogListener,
        GetEmailDialogFragment.GetEmailDialogListener,
        ClerkIdDialogFragment.ClerkIdDialogListener,
        ApplicationSelectionDialog.Listener,
        UpdateTransactionDialogFragment.UpdateTransactionDialogFragmentListener,
        LocationListener {
    private final static String TAG = StoreAndForwardFragment.class.getSimpleName();

    private final static String TOKEN_REFERENCE_NO = "Test-123";

    private LocationManager locationManager;
    private String longitude = "-71.056711";    // set default lat and long in case fragment detaches
    private String latitude = "42.354929";      // before getting real location
    private String clerkId;
    private String transactionNote;
    private String merchantInvocieID;
    private OnFragmentInteractionListener mListener;
    private int buttonClickedId;
    private String mSignatureImage;
    private String mProductImage;
    private String mTransactionType;
    private Amount saleAmount;
    private boolean showNoteAndInvoiceOnReceipt;
    private String orderNumber;
    private String clientTransactionID;
    private String customReference;
    private Locale cardholderLocale;

    private List<StoredTransactionSummary> storedTransactions = new ArrayList<>();
    private int totalStoredTransactionsCount;
    private int currentStoredTransactionsCount;
    private int successfullyUploadedTranasctionCount;
    private  int declinedTransactionCount;
    private boolean canSetCustomRef;
    private boolean isKeyedWithDevice;
    private boolean isCardPresent;
    private boolean canSetOrderNumber;
    private boolean canEnrollToken;
    private boolean isTokenEnroll;
    private int tokenFeeAmount;
    private boolean isTokenUpdate;
    private boolean validateExpiryDate;
    private String customRef;
    private String tokenID;
    private ApplicationSelectionCallback applicationSelectionCallback = null;

    public StoreAndForwardFragment() {
        // Required empty public constructor
    }

    public static StoreAndForwardFragment newInstance() {
        StoreAndForwardFragment fragment = new StoreAndForwardFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        clientTransactionID = null;
        locationManager = (LocationManager) getActivity().getSystemService(
                Context.LOCATION_SERVICE);
        Criteria criteria = new Criteria();
        String provider = locationManager.getBestProvider(criteria, true);
        if (locationManager != null) {
            if (ActivityCompat.checkSelfPermission(getActivity(),
                    Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                    || ActivityCompat.checkSelfPermission(getActivity(),
                    Manifest.permission.ACCESS_COARSE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {
                Location location = locationManager.getLastKnownLocation(provider);
                if (location != null) {
                    onLocationChanged(location);
                } else {
                    locationManager.requestLocationUpdates(provider, 1000, 0, this);
                }
            }
        }
    }

    @Override
    public View onCreateView(
            LayoutInflater inflater,
            ViewGroup container,
            Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_store_and_forward, container, false);

        Button btnStoreAndForwardCreditSaleTransaction = (Button) view.findViewById(
                R.id.fragment_store_and_forward_btn_store_and_forward_credit_sale_transaction);
        Button btnStoreAndForwardCreditAuthTransaction = (Button) view.findViewById(
                R.id.fragment_store_and_forward_btn_store_and_forward_credit_auth_transaction);
        Button btnKeyedStoreAndForwardTransaction = (Button) view.findViewById(
                R.id.fragment_store_and_forward_btn_keyed_store_and_forward_transaction);
        Button btnUploadStoreTransaction = (Button) view.findViewById(
                R.id.fragment_store_and_forward_btn_upload_stored_transaction);
        Button btnVoidStoredTransaction = (Button) view.findViewById(
                R.id.fragment_store_and_forward_btn_void_stored_transaction);
        Button btnUpdateStoredTransaction = (Button) view.findViewById(
                R.id.fragment_store_and_forward_btn_update_stored_transaction);
        Button btnGetStoredTransaction = (Button) view.findViewById(
                R.id.fragment_store_and_forward_btn_get_stored_transaction);
        Button btnRetrieveStoredTransactions = (Button) view.findViewById(
                R.id.fragment_store_and_forward_btn_get_stored_transactions);
        Button btnUploadEmailForStoredTransaction = (Button) view.findViewById(
                R.id.fragment_store_and_forward_btn_store_receipt_for_stored_transaction);
        view.findViewById(R.id.fragment_store_and_forward_btn_upload_stored_transactions).setOnClickListener(this);
        view.findViewById(R.id.fragment_store_and_forward_btn_delete_stored_transaction).setOnClickListener(this);
        view.findViewById(R.id.fragment_store_and_forward_btn_store_cash_transaction).setOnClickListener(this);
        view.findViewById(R.id.fragment_store_and_forward_btn_get_stored_transactions_group).setOnClickListener(this);
        view.findViewById(R.id.fragment_store_and_forward_btn_upload_stored_transactions_group).setOnClickListener(this);
        view.findViewById(R.id.fragment_store_and_forward_btn_token_enrollment).setOnClickListener(this);
        view.findViewById(R.id.fragment_store_and_forward_btn_keyed_token_enrollment).setOnClickListener(this);
        view.findViewById(R.id.fragment_emv_store_and_forward_btn_store_and_forward_credit_sale_transaction).setOnClickListener(this);
        view.findViewById(R.id.fragment_emv_store_and_forward_btn_store_and_forward_credit_auth_transaction).setOnClickListener(this);
        view.findViewById(R.id.fragment_emv_store_and_forward_btn_token_enrollment).setOnClickListener(this);
        btnUploadEmailForStoredTransaction.setOnClickListener(this);
        btnStoreAndForwardCreditSaleTransaction.setOnClickListener(this);
        btnStoreAndForwardCreditAuthTransaction.setOnClickListener(this);
        btnKeyedStoreAndForwardTransaction.setOnClickListener(this);
        btnUploadStoreTransaction.setOnClickListener(this);
        btnVoidStoredTransaction.setOnClickListener(this);
        btnUpdateStoredTransaction.setOnClickListener(this);
        btnGetStoredTransaction.setOnClickListener(this);
        btnRetrieveStoredTransactions.setOnClickListener(this);

        mProductImage = Utils.getBase64EncodedString(
                BitmapFactory.decodeResource(
                        getResources(),
                        R.drawable.coffee_beans
                )
        );
        mSignatureImage = Utils.getBase64EncodedString(
                BitmapFactory.decodeResource(
                        getResources(),
                        R.drawable.signature
                )
        );
        return view;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mListener = (OnFragmentInteractionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
        if (locationManager != null) {
            locationManager.removeUpdates(this);
        }
    }

    @Override
    public void onClick(View v) {
        Log.v(TAG, Utils.SEPARATOR);
        Utils.logTimeStamp(TAG);
        buttonClickedId = v.getId();
        setTransactionProps();
        if (buttonClickedId == R.id.fragment_store_and_forward_btn_store_and_forward_credit_sale_transaction
                || buttonClickedId == R.id.fragment_store_and_forward_btn_store_and_forward_credit_auth_transaction
                || buttonClickedId == R.id.fragment_store_and_forward_btn_keyed_store_and_forward_transaction
                || buttonClickedId == R.id.fragment_emv_store_and_forward_btn_store_and_forward_credit_sale_transaction
                || buttonClickedId == R.id.fragment_emv_store_and_forward_btn_store_and_forward_credit_auth_transaction) {
            if (!mListener.isDeviceConnected()) {
                Utils.newDialog(getActivity(), "Warning", "Please connect the device!").show();
            } else {
                showSaleAmountDialog(buttonClickedId != R.id.fragment_store_and_forward_btn_keyed_store_and_forward_transaction);
            }
        } else if (buttonClickedId == R.id.fragment_store_and_forward_btn_upload_stored_transaction) {
            Log.v(TAG, "Upload Stored Transaction");
            if (null != clientTransactionID) {
                mProgressDialogListener.showProgressMessage("Processing Upload Stored Transaction...");
                Ingenico.getInstance().storeAndForward().uploadStoredTransaction(
                        clientTransactionID,
                        new UploadStoredTransactionCallbackImpl()
                );
            }
            else{
                showToast("Process a Store and Forward Sale / Auth transaction first or call GetStoredTransactions.");
            }
        }else if (buttonClickedId == R.id.fragment_store_and_forward_btn_void_stored_transaction) {
            Log.v(TAG, "Void Stored Transaction");
            if (null != clientTransactionID) {
                ClerkIdDialogFragment.Builder builder = new ClerkIdDialogFragment.Builder()
                        .setCanSetCustomRef(true)
                        .setOrderNumber(true)
                        .setShowNoteAndInvoiceOnReceipt(true)
                        .setOrigTxnId(clientTransactionID);
                DialogFragment dialogFragment = builder.build();
                dialogFragment.setTargetFragment(this, 0);
                dialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
            }
            else{
                showToast("Process a Store and Forward Sale / Auth transaction first or call GetStoredTransactions.");
            }
        }else if (buttonClickedId == R.id.fragment_store_and_forward_btn_update_stored_transaction) {
            Log.v(TAG, "Update Stored Transaction");
            if (null != clientTransactionID) {
                UpdateTransactionDialogFragment dialogFragment =
                        UpdateTransactionDialogFragment.newInstance(true, clientTransactionID);
                dialogFragment.setTargetFragment(this, 0);
                dialogFragment.show(getActivity().getSupportFragmentManager(),
                        UpdateTransactionDialogFragment.class.getSimpleName());
            } else {
                showToast("Process a Store and Forward Sale / Auth transaction first or call GetStoredTransactions.");
            }
        }else if (buttonClickedId == R.id.fragment_store_and_forward_btn_store_receipt_for_stored_transaction) {
            Log.v(TAG, "Upload Email Address for Stored Transaction");
            showEmailDialog();
        }else if(buttonClickedId == R.id.fragment_store_and_forward_btn_get_stored_transaction) {
            Log.v(TAG, "Get Stored Transaction");
            if (null != clientTransactionID) {
                mProgressDialogListener.showProgressMessage("Getting Stored Transaction...");
                Ingenico.getInstance().storeAndForward().getStoredTransactionWithClientTransactionID(
                        clientTransactionID,
                        new GetStoredTransactionCallbackImpl()
                );
            }
            else{
                showToast("Process a Store and Forward Sale / Auth transaction first or call GetStoredTransactions.");
            }
        }else if (buttonClickedId == R.id.fragment_store_and_forward_btn_get_stored_transactions) {
                Log.v(TAG, "Get All Stored Transactions");
                mProgressDialogListener.showProgressMessage("Getting all Stored Transactions...");
                Ingenico.getInstance().storeAndForward().getStoredTransactions(
                        true,
                        new GetStoredTransactionsCallbackImpl()
                );
        }else if (buttonClickedId == R.id.fragment_store_and_forward_btn_get_stored_transactions_group) {
            Log.v(TAG, "Get All Stored Transactions in Service Group");
            mProgressDialogListener.showProgressMessage("Getting all Stored Transactions in Service Group...");
            Ingenico.getInstance().storeAndForward().getStoredTransactions(
                    true,
                    true,
                    new GetStoredTransactionsCallbackImpl()
            );
        } else if (buttonClickedId == R.id.fragment_store_and_forward_btn_upload_stored_transactions){
            Log.v(TAG, "Uploading All Stored Transactions");
            mProgressDialogListener.showProgressMessage("Uploading All Stored Transactions...");
            Ingenico.getInstance().storeAndForward().getStoredTransactions(
                        true,
                        new UploadAllTransactionsGetStoredTransactionsCallbackImpl()
            );
        } else if (buttonClickedId == R.id.fragment_store_and_forward_btn_upload_stored_transactions_group) {
            Log.v(TAG, "Uploading All Stored Transactions");
            mProgressDialogListener.showProgressMessage("Uploading All Stored Transactions...");
            Ingenico.getInstance().storeAndForward().getStoredTransactions(
                    true,
                    true,
                    new UploadAllTransactionsGetStoredTransactionsCallbackImpl());
        } else if (buttonClickedId == R.id.fragment_store_and_forward_btn_delete_stored_transaction) {
            Log.v(TAG, "Delete Stored Transaction");
            if (null != clientTransactionID) {
                mProgressDialogListener.showProgressMessage("Deleting Stored Transaction...");
                Ingenico.getInstance().storeAndForward().deleteStoredTransactionWithClientTransactionID(
                        clientTransactionID,
                        new DeleteStoredTransactionCallbackImpl()
                );
            } else {
                showToast("Process a Store and Forward Sale / Auth transaction first or call GetStoredTransactions.");
            }
        } else if (buttonClickedId == R.id.fragment_store_and_forward_btn_token_enrollment
                || buttonClickedId == R.id.fragment_store_and_forward_btn_keyed_token_enrollment
                || buttonClickedId == R.id.fragment_emv_store_and_forward_btn_token_enrollment) {
            if (!mListener.isDeviceConnected()) {
                Utils.newDialog(getActivity(), "Warning", "Please connect the device!").show();
            } else {
                tokenFeeAmount = 0;
                if (buttonClickedId != R.id.fragment_store_and_forward_btn_keyed_token_enrollment) {
                    Log.v(TAG, "Stored Token Enrollment Transaction");
                    mTransactionType = "Token Enrollment";
                    showClerkIdDialogForTokenEnrollment(true, false);
                }
                else {
                    Log.v(TAG, "Stored Keyed Token Enrollment Transaction");
                    mTransactionType = "Keyed Token Enrollment";
                    showClerkIdDialogForTokenEnrollment(false, true);
                }
            }
        }
        else {
            //The execution reaches here for cash transactions
            showSaleAmountDialog(false);
        }
    }

    private void setTransactionProps() {
        canSetCustomRef =
                buttonClickedId != R.id.fragment_store_and_forward_btn_store_cash_transaction;

        isKeyedWithDevice =
                buttonClickedId == R.id.fragment_store_and_forward_btn_keyed_store_and_forward_transaction;

        canSetOrderNumber = buttonClickedId != R.id.fragment_store_and_forward_btn_store_cash_transaction;

        canEnrollToken =
                buttonClickedId != R.id.fragment_store_and_forward_btn_store_cash_transaction;
    }

    private boolean isLoggedInOffline() {
        TextView sessionTokenView = getActivity().findViewById(R.id.activity_main_tv_session_token);
        String sessionToken = sessionTokenView.getText().toString();
        return sessionToken.equalsIgnoreCase(getString(R.string.offline_authenticated));
    }

    @Override
    public void onSaleAmountCaptured(String totalAmount, String subtotalAmount, String tipAmount,
                                     String taxAmount, String discountAmount, String surchargeAmount,
                                     String currencyCode,
                                     String clerkId, String authCode,
                                     String systemTrackAuditNumber,
                                     String transactionNote,
                                     String merchantInvoiceID,
                                     boolean shouldEnrollForToken,
                                     boolean shouldUpdateForToken,
                                     boolean shouldRequestCvv,
                                     boolean shouldRequestAvs,
                                     String tokenFeeAmount,
                                     String customReference,
                                     String tokenId,
                                     boolean isCardPresent,
                                     boolean showNoteAndInvoiceOnReceipt,
                                     String orderNumber,
                                     boolean validateExpiryDate,
                                     Locale cardholderLocale) {
        try {
            int total = Utils.convertStringToInt(totalAmount);
            int subtotal = Utils.convertStringToInt(subtotalAmount);
            int tip = Utils.convertStringToInt(tipAmount);
            int tax = Utils.convertStringToInt(taxAmount);
            int discount = Utils.convertStringToInt(discountAmount);
            int surcharge = Utils.convertStringToInt(surchargeAmount);
            this.saleAmount = new Amount(
                    currencyCode,
                    total,
                    subtotal,
                    tax,
                    discount,
                    "ROAM Discount",
                    tip,
                    surcharge
            );
            this.isCardPresent = isCardPresent;
            this.showNoteAndInvoiceOnReceipt = showNoteAndInvoiceOnReceipt;
            if(transactionNote != null){
                this.transactionNote = transactionNote;
            }
            if(merchantInvoiceID != null){
                this.merchantInvocieID = merchantInvoiceID;
            }
            if (customReference != null) {
                this.customRef = customReference;
            }
            this.isTokenEnroll = shouldEnrollForToken;
            this.isTokenUpdate = shouldUpdateForToken;
            this.tokenID = tokenId;
            this.tokenFeeAmount = Utils.convertStringToInt(tokenFeeAmount);
            this.validateExpiryDate = validateExpiryDate;
            if (cardholderLocale != null) {
                this.cardholderLocale = cardholderLocale;
            }
            if (clerkId != null && !clerkId.isEmpty() && clerkId.length() > 4) {
                showInvalidClerkIdDialog(false);
            } else {
                if (clerkId != null && !clerkId.isEmpty()) {
                    this.clerkId = clerkId;
                }
                if (orderNumber != null) {
                    this.orderNumber = orderNumber;
                }
                switch (buttonClickedId) {
                    case R.id.fragment_store_and_forward_btn_store_and_forward_credit_sale_transaction:
                        Log.v(TAG, "Store and Forward Credit Sale Transaction");
                        mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Store and Forward Credit Sale Transaction...");
                        mListener.cacheTransactionType(TransactionType.CreditSale);
                        Ingenico.getInstance().storeAndForward().processStoreAndForwardCreditSaleTransactionWithCardReader(
                                getStoreAndForwardCreditSaleTransactionRequest(),
                                new StoreAndForwardCreditSaleTransactionCallbackImpl()
                        );
                        break;
                    case R.id.fragment_store_and_forward_btn_store_and_forward_credit_auth_transaction:
                        Log.v(TAG, "Store and Forward Credit Auth Transaction");
                        mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Store and Forward Credit Auth Transaction...");
                        mListener.cacheTransactionType(TransactionType.CreditAuth);
                        Ingenico.getInstance().storeAndForward().processStoreAndForwardCreditAuthTransactionWithCardReader(
                                getStoreAndForwardCreditAuthTransactionRequest(),
                                new StoreAndForwardCreditAuthTransactionCallbackImpl()
                        );
                        break;
                    case R.id.fragment_emv_store_and_forward_btn_store_and_forward_credit_sale_transaction:
                        Log.v(TAG, "Store and Forward Credit Sale Transaction");
                        mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Store and Forward Credit Sale Transaction...");
                        mListener.cacheTransactionType(TransactionType.CreditSale);
                        Ingenico.getInstance().storeAndForward().processEmvStoreAndForwardCreditSaleTransactionWithCardReader(
                                getStoreAndForwardCreditSaleTransactionRequest(),
                                new StoreAndForwardCreditSaleTransactionCallbackImpl()
                        );
                        break;
                    case R.id.fragment_emv_store_and_forward_btn_store_and_forward_credit_auth_transaction:
                        Log.v(TAG, "Store and Forward Credit Auth Transaction");
                        mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Store and Forward Credit Auth Transaction...");
                        mListener.cacheTransactionType(TransactionType.CreditAuth);
                        Ingenico.getInstance().storeAndForward().processEmvStoreAndForwardCreditAuthTransactionWithCardReader(
                                getStoreAndForwardCreditAuthTransactionRequest(),
                                new StoreAndForwardCreditAuthTransactionCallbackImpl()
                        );
                        break;
                    case R.id.fragment_store_and_forward_btn_keyed_store_and_forward_transaction:
                        Log.v(TAG, "Keyed Store and Forward Transaction");
                        mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Store and Forward Credit Auth Transaction...");
                        mListener.cacheTransactionType(TransactionType.CreditAuth);
                        Ingenico.getInstance().storeAndForward().processKeyedStoreAndForwardTransactionWithCardReader(
                                getStoreAndForwardKeyedCardSaleTransactionRequest(shouldRequestCvv, shouldRequestAvs),
                                new StoreAndForwardCreditAuthTransactionCallbackImpl()
                        );
                        break;
                    case R.id.fragment_store_and_forward_btn_store_cash_transaction:
                        Log.v(TAG, "Store and Forward Cash Transaction");
                        mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Processing Store and Forward Cash Sale Transaction...");
                        mListener.cacheTransactionType(TransactionType.CashSale);
                        Ingenico.getInstance().storeAndForward().processStoreAndForwardCashTransaction(
                                getStoreAndForwardCashSaleTransactionRequest(),
                                new StoreAndForwardCreditSaleTransactionCallbackImpl()
                        );
                        break;
                    default:
                        break;
                }
                Log.v(TAG, mTransactionType + " Request Sent");
            }
        } catch (NumberFormatException e) {
            showSaleAmountDialog(false);
        }
    }

    @Override
    public void onRefundAmountCaptured(String refundAmount, String subtotalAmount,
            String tipAmount, String taxAmount, String discountAmount,
            String surchargeAmount, String currencyCode, String customReference, String clerkId, String transactionNote,
            String orderNumber, boolean showNotesAndInvoiceOnReceipt, Locale cardholderLocale) {
        // no-op
    }

    @Override
    public void onOpenRefundAmountCaptured(String refundAmount, String taxAmount, String discountAmount,
            String surchargeAmount,  String currencyCode, String transactionNote, String merchantInvoiceID, String customReference,
            boolean shouldEnrollForToken, boolean shouldUpdateForToken, String tokenFee, boolean isCardPresent, String clerkId, boolean showNoteAndInvoiceOnReceipt, String orderNumber, Locale cardholderLocale) {
        // no-op
    }

    @Override
    public void onTransactionCancelled() {
        // no-op
    }

    @Override
    public void onLocationChanged(Location location) {
        longitude = String.valueOf(location.getLongitude());
        latitude = String.valueOf(location.getLatitude());
        if (ActivityCompat.checkSelfPermission(getActivity(),
                Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(getActivity(),
                Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            locationManager.removeUpdates(this);
        }
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {
        showToast("Enabled new provider " + provider);
    }

    @Override
    public void onProviderDisabled(String provider) {
        showToast("Disabled new provider " + provider);
    }

    private StoreAndForwardCreditSaleTransactionRequest getStoreAndForwardCreditSaleTransactionRequest() {
        mTransactionType = "Store And Forward Credit Sale";
        StoreAndForwardCreditSaleTransactionRequest request = new StoreAndForwardCreditSaleTransactionRequest(
                saleAmount,
                getProductList(saleAmount),
                clerkId,
                longitude,
                latitude,
                null,
                transactionNote,
                merchantInvocieID,
                showNoteAndInvoiceOnReceipt,
                customRef,
                Boolean.FALSE,
                UCIFormat.Ingenico,
                orderNumber,
                getTokenRequestParameters(),
                validateExpiryDate
        );
        request.setLocale(cardholderLocale);
        return request;
    }

    private StoreAndForwardCashSaleTransactionRequest getStoreAndForwardCashSaleTransactionRequest() {
        mTransactionType = "Store And Forward Cash Sale";
        StoreAndForwardCashSaleTransactionRequest request = new StoreAndForwardCashSaleTransactionRequest(
                saleAmount,
                getProductList(saleAmount),
                clerkId,
                longitude,
                latitude,
                null,
                transactionNote,
                merchantInvocieID,
                showNoteAndInvoiceOnReceipt,
                customRef,
                Boolean.FALSE
        );
        request.setLocale(cardholderLocale);
        return request;
    }

    private StoreAndForwardCreditAuthTransactionRequest getStoreAndForwardCreditAuthTransactionRequest() {
        mTransactionType = "Store And Forward Credit Auth Sale";
        StoreAndForwardCreditAuthTransactionRequest request = new StoreAndForwardCreditAuthTransactionRequest(
                saleAmount,
                getProductList(saleAmount),
                clerkId,
                longitude,
                latitude,
                null,
                transactionNote,
                merchantInvocieID,
                showNoteAndInvoiceOnReceipt,
                customRef,
                Boolean.FALSE,
                UCIFormat.Ingenico,
                orderNumber,
                getTokenRequestParameters(),
                validateExpiryDate
        );
        request.setLocale(cardholderLocale);
        return request;
    }

    private StoreAndForwardKeyedCardSaleTransactionRequest getStoreAndForwardKeyedCardSaleTransactionRequest(
            boolean shouldRequestCvv,
            boolean shouldRequestAvs) {
        mTransactionType = "Store And Forward Credit Auth Sale";
        StoreAndForwardKeyedCardSaleTransactionRequest request = new StoreAndForwardKeyedCardSaleTransactionRequest(
                saleAmount,
                getProductList(saleAmount),
                clerkId,
                longitude,
                latitude,
                null,
                transactionNote,
                merchantInvocieID,
                showNoteAndInvoiceOnReceipt,
                customRef,
                Boolean.FALSE,
                shouldRequestAvs,
                shouldRequestCvv,
                UCIFormat.Ingenico,
                isCardPresent,
                orderNumber,
                getTokenRequestParameters()
        );
        request.setLocale(cardholderLocale);
        return request;
    }



    private StoreAndForwardKeyedTokenEnrollmentTransactionRequest getStoreAndForwardKeyedTokenEnrollmentTransactionRequest(TokenRequestParameters tokenEnrollmentUpdateParameters,
                                                                                                                           boolean requestAVS,
                                                                                                                           boolean requestCVV,
                                                                                                                           boolean cardPresent) {
        StoreAndForwardKeyedTokenEnrollmentTransactionRequest request = new StoreAndForwardKeyedTokenEnrollmentTransactionRequest(
                tokenEnrollmentUpdateParameters,
                clerkId,
                longitude,
                latitude,
                UCIFormat.Unknown,
                orderNumber,
                requestAVS,
                requestCVV,
                cardPresent
        );
        request.setLocale(cardholderLocale);
        return request;
    }

    private StoreAndForwardTokenEnrollmentTransactionRequest getStoreAndForwardTokenEnrollmentTransactionRequest(TokenRequestParameters tokenEnrollmentUpdateParameters) {
        StoreAndForwardTokenEnrollmentTransactionRequest request = new StoreAndForwardTokenEnrollmentTransactionRequest(
                tokenEnrollmentUpdateParameters,
                clerkId,
                longitude,
                latitude,
                UCIFormat.Unknown,
                orderNumber,
                validateExpiryDate
        );
        request.setLocale(cardholderLocale);
        return request;
    }

    private StoreAndForwardVoidTransactionRequest getStoreAndForwardVoidTransactionRequest(String originalTxnId) {
        StoreAndForwardVoidTransactionRequest request = new StoreAndForwardVoidTransactionRequest(
                originalTxnId,
                clerkId,
                longitude,
                latitude,
                customReference,
                orderNumber,
                showNoteAndInvoiceOnReceipt);
        request.setLocale(cardholderLocale);
        return request;
    }

    private TokenRequestParameters getTokenRequestParameters() {
        if (isTokenEnroll) {
            return getTokenEnrollmentRequestParameters();
        }
        if (isTokenUpdate) {
            return getTokenEnrollmentUpdateParameters();
        }
        return null;
    }

    private void showSaleAmountDialog(boolean canValidateExpiryDate) {
        AmountDialogFragment.Builder builder = new AmountDialogFragment.Builder()
                .setCanSetCustomRef(canSetCustomRef)
                .setIsKeyedWithDevice(isKeyedWithDevice).setShowNoteAndInvoiceOnReceipt(true)
                .setCanSetOrderNumber(canSetOrderNumber)
                .setCanEnrollToken(canEnrollToken)
                .setCachedTokenId(mListener.getCachedTokenId())
                .setCanValidateExpiryDate(canValidateExpiryDate);
        DialogFragment dialogFragment = builder.build();
        dialogFragment.setTargetFragment(this, 0);
        dialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
    }

    private void showClerkIdDialogForTokenEnrollment(boolean canValidateExpiryDate, boolean isKeyedWithDevice) {
        ClerkIdDialogFragment.Builder builder = new ClerkIdDialogFragment.Builder()
                .setCanCaptureTokenFee(true)
                .setCanUpdateToken(true)
                .setCachedTokenId(mListener.getCachedTokenId())
                .setOrderNumber(canSetOrderNumber)
                .setCanValidateExpiryDate(canValidateExpiryDate)
                .setIsCardReaderKeyed(isKeyedWithDevice);
        DialogFragment dialogFragment = builder.build();
        dialogFragment.setTargetFragment(this, 0);
        dialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
    }


    private void showInvalidClerkIdDialog(boolean onlyClerkID) {
        if (onlyClerkID) {
            ClerkIdDialogFragment.Builder builder = new ClerkIdDialogFragment.Builder()
                    .setMessage("ClerkID is up-to 4 alphanumerics");
            DialogFragment dialogFragment = builder.build();
            dialogFragment.setTargetFragment(this, 0);
            dialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
        } else {
            AmountDialogFragment.Builder builder = new AmountDialogFragment.Builder()
                    .setMessage("ClerkID is up-to 4 alphanumerics")
                    .setCanSetCustomRef(canSetCustomRef);
            DialogFragment dialogFragment = builder.build();
            dialogFragment.setTargetFragment(this, 0);
            dialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
        }
    }

    private void logResult(int responseCode, TransactionResponse response, boolean showDialog) {
        mProgressDialogListener.hideProgress();
        String title;
        String msg = null;
        if (ResponseCode.Success == responseCode) {
            title = mTransactionType + " Complete";
        } else {
            title = mTransactionType + " Failed";
            msg = "Error code : " + responseCode;
        }
        if (response != null) {
            msg = String.format(
                    "\nResponse Code : %s \n" +
                            "Client TransactionID : %s \n" +
                            "TransactionID : %s \n" +
                            "TransactionGUID : %s \n" +
                            "ClerkDisplay : %s\n" +
                            "POSEntryMode : %s\n" +
                            "AuthorizedAmount : %s\n" +
                            "InvoiceID : %s\n" +
                            "Available Balance: %s\n" +
                            "Token Response Code: %s\n" +
                            "Redacted Card Number: %s\n" +
                            "Transaction Response Code: %s\n" +
                            "Card Type: %s\n",
                    Utils.getResponseCodeString(responseCode),
                    response.getClientTransactionId(),
                    response.getTransactionId(),
                    response.getTransactionGUID(),
                    response.getClerkDisplay(),
                    response.getPosEntryMode(),
                    response.getAuthorizedAmount(),
                    response.getInvoiceId(),
                    response.getAvailableBalance(),
                    Utils.getTokenResponseString(response.getTokenResponseParameters().getTokenResponseCode()),
                    response.getRedactedCardNumber(),
                    response.getTransactionResponseCode(),
                    response.getCardType()
            );
            Log.v(TAG, msg);
        }
        if (showDialog) {
            Utils.newDialog(getActivity(), title, msg).show();
        }
    }

    private List<Product> getProductList(Amount saleAmount) {
        List<Product> products = new ArrayList<>();
        products.add(
                new Product(
                        "Coffee Beans",
                        saleAmount.getSubtotal(),
                        "Ethiopian Coffee Whole Beans",
                        mProductImage,
                        1
                )
        );
        return products;
    }

    private void showEmailDialog() {
        DialogFragment dialogFragment = new GetEmailDialogFragment();
        dialogFragment.setTargetFragment(this, 0);
        dialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
    }

    @Override
    public void onEmailCaptured(String email) {
        if (null != clientTransactionID) {
            mProgressDialogListener.showProgressMessage("Storing receipt...");
            Ingenico.getInstance().storeAndForward().storeReceiptForStoredTransaction(
                    clientTransactionID,
                    email,
                    new StoreReceiptForStoredTransactionCallbackImpl());
        } else {
            showToast("Process a Store and Forward Sale / Auth transaction first.");
        }
    }

    @Override
    public void onClerkIdCaptured(String originalTxnId, String clerkId, String tokenFee, String tokenId,
            String customReference, String avsZipCode, String avsAddress, String transactionNote,
            String orderNumber, boolean validateExpiryDate, boolean requestAVS, boolean requestCVV,
            boolean cardPresent, boolean showNoteAndInvoiceOnReceipt, Locale cardholderLocale) {
        this.tokenFeeAmount = Utils.convertStringToInt(tokenFee);
        this.tokenID = tokenId;
        this.validateExpiryDate = validateExpiryDate;
        if (cardholderLocale != null) {
            this.cardholderLocale = cardholderLocale;
        }
        this.clerkId = clerkId;
        this.customReference = customReference;
        this.orderNumber = orderNumber;
        this.showNoteAndInvoiceOnReceipt = showNoteAndInvoiceOnReceipt;
        if (buttonClickedId == R.id.fragment_store_and_forward_btn_void_stored_transaction) {
            Ingenico.getInstance().storeAndForward().processVoidStoredTransaction(
                    getStoreAndForwardVoidTransactionRequest(originalTxnId),
                    new StoreAndForwardVoidTransactionCallbackImpl()
            );
        }
        else if (buttonClickedId == R.id.fragment_store_and_forward_btn_token_enrollment ||
                buttonClickedId == R.id.fragment_store_and_forward_btn_keyed_token_enrollment ||
                buttonClickedId == R.id.fragment_emv_store_and_forward_btn_token_enrollment) {
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity())
                    .setTitle("Token Enroll/Update")
                    .setMessage("Please select action")
                    .setPositiveButton("Enroll", (dialog, which) -> {
                        if (buttonClickedId == R.id.fragment_store_and_forward_btn_token_enrollment) {
                            Ingenico.getInstance().storeAndForward().processStoreAndForwardTokenEnrollmentWithCardReader(
                                    getStoreAndForwardTokenEnrollmentTransactionRequest(getTokenEnrollmentRequestParameters()),
                                    new TokenEnrollmentCallback()
                            );
                        } else if (buttonClickedId == R.id.fragment_store_and_forward_btn_keyed_token_enrollment) {
                            Ingenico.getInstance().storeAndForward().processStoreAndForwardKeyedTokenEnrollmentWithCardReader(
                                    getStoreAndForwardKeyedTokenEnrollmentTransactionRequest(getTokenEnrollmentRequestParameters(), requestAVS, requestCVV, cardPresent),
                                    new TokenEnrollmentCallback()
                            );
                        } else if (buttonClickedId == R.id.fragment_emv_store_and_forward_btn_token_enrollment) {
                            Ingenico.getInstance().storeAndForward().processEmvStoreAndForwardTokenEnrollmentWithCardReader(
                                    getStoreAndForwardTokenEnrollmentTransactionRequest(getTokenEnrollmentRequestParameters()),
                                    new TokenEnrollmentCallback()
                            );
                        }
                    })
                    .setNegativeButton("Update", (dialog, which) -> {
                        if (buttonClickedId == R.id.fragment_store_and_forward_btn_token_enrollment) {
                            Ingenico.getInstance().storeAndForward().processStoreAndForwardTokenEnrollmentWithCardReader(
                                    getStoreAndForwardTokenEnrollmentTransactionRequest(getTokenEnrollmentUpdateParameters()),
                                    new TokenEnrollmentCallback()
                            );
                        } else if (buttonClickedId == R.id.fragment_store_and_forward_btn_keyed_token_enrollment) {
                            Ingenico.getInstance().storeAndForward().processStoreAndForwardKeyedTokenEnrollmentWithCardReader(
                                    getStoreAndForwardKeyedTokenEnrollmentTransactionRequest(getTokenEnrollmentUpdateParameters(), requestAVS, requestCVV, cardPresent),
                                    new TokenEnrollmentCallback()
                            );
                        } else if (buttonClickedId == R.id.fragment_emv_store_and_forward_btn_token_enrollment) {
                            Ingenico.getInstance().storeAndForward().processEmvStoreAndForwardTokenEnrollmentWithCardReader(
                                    getStoreAndForwardTokenEnrollmentTransactionRequest(getTokenEnrollmentUpdateParameters()),
                                    new TokenEnrollmentCallback()
                            );
                        }
                    })
                    .setNeutralButton("Cancel", (dialog, which) -> {
                        dialog.dismiss();
                    });
            builder.show();
        }
    }

    @Override
    public void onApplicationSelected(ApplicationIdentifier applicationIdentifier) {
        this.applicationSelectionCallback.done(applicationIdentifier);
    }

    @Override
    public void updateTransaction(String txnId, CardholderInfo cardholderInfo, String transactionNote,
            Boolean displayNotesAndInvoice, Boolean isCompleted, String signatureImage) {
        mProgressDialogListener.showProgressMessage("Processing Update Stored Transaction...");
        Ingenico.getInstance().storeAndForward().updateStoredTransaction(
                txnId,
                cardholderInfo,
                transactionNote,
                displayNotesAndInvoice,
                isCompleted,
                signatureImage,
                responseCode -> {
                    Log.v(TAG, "\nUpdateTransactionCallback::done::" + responseCode);
                    mProgressDialogListener.hideProgress();
                    if (responseCode == 0) {
                        Utils.newDialog(getActivity(), "Update Stored Transaction", "Update Suceess").show();
                        Log.v(TAG, "Store and Forward Update Transaction success");
                    }else{
                        Utils.newDialog(getActivity(), "Update Stored Transaction", "Update failed with response code:"+responseCode).show();
                        Log.v(TAG, "Error processing store and forward Update transaction. Response code: "+responseCode);
                    }
                }
        );

    }

    public interface OnFragmentInteractionListener {
        boolean isDeviceConnected();

        void cacheTransactionResponse(TransactionResponse transactionResponse, int responseCode);

        void cacheTransactionType(TransactionType transactionType);

        String getCachedTokenId();
    }

    private class StoreAndForwardCreditSaleTransactionCallbackImpl implements TransactionCallback {
        @Override
        public void updateProgress(Integer progressCode, String extraMessage) {
            Log.d(TAG, "updateProgress::" + progressCode + "::" + extraMessage);
            mProgressDialogListener.showTransactionProgressMessageWithCancelButton(Utils.getProgressMessage(progressCode));
        }

        @Override
        public void applicationSelection(
                List<ApplicationIdentifier> appList,
                ApplicationSelectionCallback applicationcallback) {
            showApplicationSelectionDialog(appList, applicationcallback);
        }

        @Override
        public void done(Integer responseCode, TransactionResponse response) {
            Log.v(TAG, "\nStoreAndForwardCreditSaleTransactionCallbackImpl::done::" + responseCode);
            mProgressDialogListener.hideProgress();
            logResult(responseCode, response, true);
            if (response != null) {
                if(responseCode == ResponseCode.Success){
                    logTransactionResponse(TAG, response);
                    clientTransactionID = response.getClientTransactionId();
                }
            }else{
                Log.v(TAG, "Error processing store and forward Credit Sale transaction: Response : " + responseCode);
            }
        }
    }

    private class StoreAndForwardCreditAuthTransactionCallbackImpl implements TransactionCallback {
        @Override
        public void updateProgress(Integer progressCode, String extraMessage) {
            Log.d(TAG, "updateProgress::" + progressCode + "::" + extraMessage);
            // if doing a keyed transaction, show the actual progress response code since this should not happen in a happy case
            if (isLoggedInOffline()
                    || buttonClickedId == R.id.fragment_store_and_forward_btn_keyed_store_and_forward_transaction
                    || buttonClickedId == R.id.fragment_emv_store_and_forward_btn_store_and_forward_credit_auth_transaction
                    || buttonClickedId == R.id.fragment_emv_store_and_forward_btn_store_and_forward_credit_sale_transaction
                    || buttonClickedId == R.id.fragment_emv_store_and_forward_btn_token_enrollment
            ) {
                mProgressDialogListener.showTransactionProgressMessageWithCancelButton(Utils.getProgressMessage(progressCode));
            }
            // if we are online and performing an offline transaction, allowedPOSEntryModes will be incorrect
            // and getProgressMessage should not be used
            else {
                mProgressDialogListener.showTransactionProgressMessageWithCancelButton("Please swipe card");
            }
        }

        @Override
        public void applicationSelection(
                List<ApplicationIdentifier> appList,
                ApplicationSelectionCallback applicationcallback) {

            showApplicationSelectionDialog(appList, applicationcallback);
        }

        @Override
        public void done(Integer responseCode, TransactionResponse response) {
            Log.v(TAG, "\nStoreAndForwardCreditAuthTransactionCallbackImpl::done::" + responseCode);
            mProgressDialogListener.hideProgress();
            logResult(responseCode, response, true);
            if (response != null) {
                if(responseCode == ResponseCode.Success){
                    logTransactionResponse(TAG, response);
                    clientTransactionID = response.getClientTransactionId();
                }
            }else{
                Log.v(TAG, "Error processing store and forward Credit Auth transaction: Response : " + responseCode);
            }
        }
    }

    private class UploadStoredTransactionCallbackImpl implements TransactionCallback {
        @Override
        public void updateProgress(Integer progressCode, String extraMessage) {
            Log.d(TAG, "updateProgress::" + progressCode + "::" + extraMessage);
            mProgressDialogListener.showProgressMessage(Utils.getProgressMessage(progressCode));
        }

        @Override
        public void applicationSelection(
                List<ApplicationIdentifier> appList,
                ApplicationSelectionCallback applicationcallback) {

        }

        @Override
        public void done(Integer responseCode, TransactionResponse response) {
            Log.v(TAG, "\nStoreAndForwardSaleTransactionCallbackImpl::done::" + responseCode);
            mListener.cacheTransactionResponse(response, responseCode);
            mProgressDialogListener.hideProgress();
            if (response != null) {
                if(responseCode == ResponseCode.Success){
                    mListener.cacheTransactionResponse(response, responseCode);
                    Utils.newDialog(getActivity(), "Upload Stored Transaction", "Upload Success").show();
                    logTransactionResponse(TAG, response);
                }
                else {
                    Utils.newDialog(getActivity(), "Upload Stored Transaction Failed", response.toString()).show();
                }
            }else {
                Utils.newDialog(getActivity(), "Upload Stored Transaction", "Upload failed with response code: "+responseCode).show();
                Log.v(TAG, "Error processing upload stored transaction: Response : " + responseCode);
            }
        }
    }

    private class StoreAndForwardVoidTransactionCallbackImpl implements TransactionCallback {
        @Override
        public void updateProgress(Integer progressCode, String extraMessage) {
        }

        @Override
        public void applicationSelection(
                List<ApplicationIdentifier> appList,
                ApplicationSelectionCallback applicationcallback) {

        }

        @Override
        public void done(Integer responseCode, TransactionResponse response) {
            Log.v(TAG, "\nStoreAndForwardVoidTransactionCallbackImpl::done::" + responseCode);
            mProgressDialogListener.hideProgress();
            if (response != null) {
                if(responseCode == ResponseCode.Success){
                    Utils.newDialog(getActivity(), "Void Stored Transaction", "Void Success").show();
                    logTransactionResponse(TAG, response);
                    clientTransactionID = response.getClientTransactionId();
                }
            }else{
                Utils.newDialog(getActivity(), "Void Stored Transaction", "Void failed with response code: "+responseCode).show();
                Log.v(TAG, "Error processing store and forward void transaction: Response : " + responseCode);
            }
        }
    }

    private class GetStoredTransactionsCallbackImpl implements GetStoredTransactionsCallback{

        @Override
        public void done(Integer responseCode, Integer totalMatches, List<StoredTransactionSummary> storedTransactionSummaryList){
            Log.v(TAG, "\nGetStoredTransactionsCallbackImpl::done::" + responseCode);
            mProgressDialogListener.hideProgress();
            StringBuilder alertBody = new StringBuilder();
            if (responseCode == ResponseCode.Success){
                if (totalMatches == 0){
                    alertBody.append("No Stored Transactions");
                }else{
                    alertBody.append("Total matches: ").append(totalMatches).append("\n");
                    for(StoredTransactionSummary storedTransactionSummary : storedTransactionSummaryList){
                        Log.v(TAG, "\n" + storedTransactionSummary);
                        alertBody.append("ClientTransactionID: ")
                                .append(storedTransactionSummary.hasStoredVoid() ? "(has stored void) " : "")
                                .append(storedTransactionSummary.getClientTransactionId()).append("\n");
                    }
                    clientTransactionID = storedTransactionSummaryList.get(
                            totalMatches-1).getClientTransactionId();
                }
            }else{
                alertBody.append("Failed With Response Code: ").append(responseCode);
                Log.v(TAG, "GetStoredTransactionsCallbackImpl failed with Response Code: " + responseCode);
            }
            Utils.newDialog(getActivity(), "Get All Stored Transactions", alertBody.toString()).show();
        }
    }

    private class GetStoredTransactionCallbackImpl implements GetStoredTransactionCallback{
        @Override
        public void done(Integer responseCode, StoredTransactionSummary storedTransactionSummary){
            Log.v(TAG, "\nGetStoredTransactionCallbackImpl::done::" + responseCode);
            mProgressDialogListener.hideProgress();
            StringBuilder alertBody = new StringBuilder();
            if (responseCode == ResponseCode.Success){
                alertBody.append("Success");
                Log.v(TAG, "\n" + storedTransactionSummary);
            }else{
                alertBody.append("Failed With Response Code: ").append(responseCode);
                Log.v(TAG, "GetStoredTransactionCallbackImpl failed with Response Code: " + responseCode);
            }
            Utils.newDialog(getActivity(), "Get Stored Transaction", alertBody.toString()).show();
        }
    }

    private void uploadNextStoredTransaction() {
        currentStoredTransactionsCount++;
        Log.d(TAG, "Uploading " + currentStoredTransactionsCount + " of " + totalStoredTransactionsCount + " transactions");
        Ingenico.getInstance().storeAndForward().uploadStoredTransaction(
                storedTransactions.remove(0).getClientTransactionId(),
                new UploadAllStoredTransactionsCallbackImpl()
        );
    }
    private class UploadAllStoredTransactionsCallbackImpl implements TransactionCallback {

        @Override
        public void updateProgress(Integer progressCode, String extraMessage) {
            Log.d(TAG, "Uploading " + currentStoredTransactionsCount + " of " + totalStoredTransactionsCount + " updateProgress::" + progressCode + "::" + extraMessage);
            mProgressDialogListener.showProgressMessage( "Uploading " + currentStoredTransactionsCount + " of " + totalStoredTransactionsCount + " - "+ Utils.getProgressMessage(progressCode));

        }

        @Override
        public void applicationSelection(
                List<ApplicationIdentifier> appList,
                ApplicationSelectionCallback applicationcallback) {
        }

        @Override
        public void done(Integer responseCode, TransactionResponse response) {
            Log.v(TAG, "\nUploadAllStoredTransactionsCallbackImpl::done::" + responseCode);
            if (response != null) {
                if(responseCode == ResponseCode.Success){
                    logTransactionResponse(TAG, response);
                    mListener.cacheTransactionResponse(response, responseCode);
                    successfullyUploadedTranasctionCount ++;
                }
            } else {
                declinedTransactionCount++;
                Log.v(TAG, "Error processing upload stored transaction: Response : " + responseCode);
            }
            if (currentStoredTransactionsCount < totalStoredTransactionsCount) {
                uploadNextStoredTransaction();
            } else {
                mProgressDialogListener.hideProgress();
                StringBuilder dialogMsg = new StringBuilder("Uploaded transaction count = " + successfullyUploadedTranasctionCount);
                if (declinedTransactionCount > 0) {
                    dialogMsg.append("\n" + "Declined transaction count = " + declinedTransactionCount);
                }
                Utils.newDialog(getActivity(), "Upload all Stored Transactions", dialogMsg.toString()).show();
            }
        }
    }

    private class UploadAllTransactionsGetStoredTransactionsCallbackImpl implements GetStoredTransactionsCallback{

        @Override
        public void done(Integer responseCode, Integer totalMatches, List<StoredTransactionSummary> storedTransactionSummaryList){
            Log.v(TAG, "\nUploadAllTransactionsGetStoredTransactionsCallbackImpl::done::" + responseCode);
            StringBuilder alertBody = new StringBuilder();
            storedTransactions.clear();
            if (responseCode == ResponseCode.Success){
                clientTransactionID = null;
                storedTransactions.clear();
                totalStoredTransactionsCount = 0;
                currentStoredTransactionsCount = 0;
                successfullyUploadedTranasctionCount = 0;
                declinedTransactionCount = 0;
                if (totalMatches == 0) {
                    alertBody.append("No Stored Transactions");
                    mProgressDialogListener.hideProgress();
                } else {
                    totalStoredTransactionsCount = totalMatches;
                    storedTransactions.addAll(storedTransactionSummaryList);
                    uploadNextStoredTransaction();
                    return;
                }
            } else {
                mProgressDialogListener.hideProgress();
                alertBody.append("Failed With Response Code: ").append(responseCode);
                Log.v(TAG, "UploadAllTransactionsGetStoredTransactionsCallbackImpl failed with Response Code: " + responseCode);
            }
            Utils.newDialog(getActivity(), "Upload all Stored Transactions", alertBody.toString()).show();
        }
    }

    private class DeleteStoredTransactionCallbackImpl implements DeleteStoredTransactionCallback{
        @Override
        public void done(Integer responseCode) {
            mProgressDialogListener.hideProgress();
            Log.v(TAG, "DeleteStoredTransactionCallback::done::" + responseCode);
            if (ResponseCode.Success == responseCode) {
                clientTransactionID = null;
                Log.v(TAG, "DeleteStoredTransactionCallbackImpl Success" );
                showToast("Success");
            } else {
                Log.v(TAG, "DeleteStoredTransactionCallbackImpl failed with Response Code: " + responseCode);
                showToast("Failed with error:"+responseCode);
            }
        }
    }

    private class StoreReceiptForStoredTransactionCallbackImpl implements StoreReceiptForStoredTransactionCallback{
        @Override
        public void done(Integer responseCode) {
            mProgressDialogListener.hideProgress();
            Log.v(TAG, "UploadEmailAddressForStoredTransactionCallback::done::" + responseCode);
            if (ResponseCode.Success == responseCode) {
                Log.v(TAG, "UploadEmailAddressForStoredTransactionCallbackImpl Success" );
                showToast("Success");
            } else {
                Log.v(TAG, "UploadEmailAddressForStoredTransactionCallbackImpl failed with Response Code: " + responseCode);
                showToast("Failed with error:"+responseCode);
            }
        }
    }

    private class TokenEnrollmentCallback implements TransactionCallback {

        @Override
        public void updateProgress(Integer progressCode, String extraMessage) {
            Log.d(TAG, "updateProgress::" + progressCode + "::" + extraMessage);
            mProgressDialogListener.showTransactionProgressMessageWithCancelButton(Utils.getProgressMessage(progressCode));
        }

        @Override
        public void applicationSelection(List<ApplicationIdentifier> appList,
                ApplicationSelectionCallback applicationcallback) {
            showApplicationSelectionDialog(appList, applicationcallback);
        }

        @Override
        public void done(Integer responseCode, TransactionResponse response) {
            Log.v(TAG, "\nStoreAndForwardTokenEnrollmentTransactionCallbackImpl::done::" + responseCode);
            logResult(responseCode, response, true);
            if (response != null) {
                if(responseCode == ResponseCode.Success){
                    logTransactionResponse(TAG, response);
                    clientTransactionID = response.getClientTransactionId();
                }
            }else{
                Log.v(TAG, "Error processing token enrollment transaction: Response : " + responseCode);
            }
        }
    }

    private TokenRequestParameters getTokenEnrollmentRequestParameters() {
        TokenRequestParameters.Builder builder = getTokenParamBuilder();
        return builder.createTokenEnrollmentRequestParameters();
    }


    private TokenRequestParameters getTokenEnrollmentUpdateParameters() {
        TokenRequestParameters.Builder builder = getTokenParamBuilder();
        builder.setTokenIdentifier(tokenID);
        return builder.createTokenUpdateRequestParameters();
    }

    private TokenRequestParameters.Builder getTokenParamBuilder() {
        return new TokenRequestParameters.Builder()
                .setTokenReferenceNumber(TOKEN_REFERENCE_NO)
                .setTokenFeeInCents(tokenFeeAmount)
                .setCardholderFirstName("Roam")
                .setCardholderLastName("Data")
                .setBillToEmail("roam@roamdata.com")
                .setBillToAddress1("1 Federal St")
                .setBillToAddress2("Suite 1")
                .setBillToCity("Boston")
                .setBillToState("MA")
                .setBillToCountry("USA")
                .setBillToZip("02110");
    }

    private void showApplicationSelectionDialog(
            List<ApplicationIdentifier> applicationIdentifiers,
            ApplicationSelectionCallback applicationSelectionCallback) {
        this.applicationSelectionCallback = applicationSelectionCallback;
        DialogFragment dialogFragment = ApplicationSelectionDialog.newInstance(
                applicationIdentifiers);
        dialogFragment.setTargetFragment(this, 0);
        dialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
    }
}