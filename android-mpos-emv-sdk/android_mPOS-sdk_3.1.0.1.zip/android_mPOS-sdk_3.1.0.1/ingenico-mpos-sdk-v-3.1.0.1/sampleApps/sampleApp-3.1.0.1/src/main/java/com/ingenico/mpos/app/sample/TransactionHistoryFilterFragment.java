/*
 * //////////////////////////////////////////////////////////////////////////////
 * //
 * // Copyright (c) 2016 ROAM, Inc. All rights reserved.
 * //
 * //////////////////////////////////////////////////////////////////////////////
 */

package com.ingenico.mpos.app.sample;

import android.app.Activity;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import com.ingenico.mpos.app.sample.dialogs.FilterOptionsDialogFragment;
import com.ingenico.mpos.sdk.constants.CardType;
import com.ingenico.mpos.sdk.constants.POSEntrySource;
import com.ingenico.mpos.sdk.constants.TransactionStatus;
import com.ingenico.mpos.sdk.constants.TransactionType;
import com.ingenico.mpos.sdk.data.TransactionQuery;
import com.ingenico.mpos.sdk.data.TransactionQueryBuilder;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

public class TransactionHistoryFilterFragment extends FragmentBase
        implements FilterOptionsDialogFragment.OnFilterOptionsSelectedListener,
        View.OnClickListener {
    private static final String TAG = TransactionHistoryFilterFragment.class.getSimpleName();
    private static final String ARG_INVOICE_VIEW = "ARG_INVOICE_VIEW";

    // UI
    private OnFragmentInteractionListener listener;

    private DatesTextWatcher datesTextWatcher = new DatesTextWatcher();
    private PastDaysTextWatcher pastDaysTextWatcher = new PastDaysTextWatcher();

    private EditText etStartDate;
    private EditText etEndDate;
    private EditText etPastDays;
    private EditText etPageNo;
    private EditText etPageSize;
    private EditText etClerkId;
    private EditText etInvoiceId;
    private EditText etTransactionID;
    private EditText etTransactionGUID;
    private EditText etCustomerName;
    private EditText etCardholderName;
    private EditText etCustomerEmail;
    private EditText etLastFourDigitsOfCard;
    private EditText etAuthAmountInCents;
    private EditText etInvoiceAmountInCents;
    private EditText etTransactionNote;
    private EditText etMerchantInvoiceId;
    private EditText etTransactedBy;
    private EditText etAuthCode;
    private EditText etBatchNumber;
    private EditText etOrderNumber;

    private TextView transactionTypesSummary;
    private TextView cardTypesSummary;
    private TextView transactionStatusSummary;
    private TextView paymentSourceSummary;
    private TextView optionalFieldsSummary;

    private CheckBox includeSubmerchantTransactions;

    private boolean isInvoiceView;

    // NON-UI
    private static LinkedHashMap<String, Boolean> transactionTypeMap = new LinkedHashMap<>();
    private static LinkedHashMap<String, Boolean> cardTypeMap = new LinkedHashMap<>();
    private static LinkedHashMap<String, Boolean> transactionStatusMap = new LinkedHashMap<>();
    private static LinkedHashMap<String, Boolean> paymentSourceMap = new LinkedHashMap<>();
    private static LinkedHashMap<String, Boolean> optionalFieldsMap = new LinkedHashMap<>();

    static {
        for (TransactionType type : TransactionType.values()) {
            transactionTypeMap.put(type.name(), false);
        }
        for (CardType type : CardType.values()) {
            cardTypeMap.put(type.name(), false);
        }
        for (TransactionStatus status : TransactionStatus.values()) {
            transactionStatusMap.put(status.name(), false);
        }
        for (POSEntrySource source : POSEntrySource.values()) {
            paymentSourceMap.put(source.name(), false);
        }
        for (TransactionQuery.OptionalTransactionHistoryField field : TransactionQuery.OptionalTransactionHistoryField.values()) {
            optionalFieldsMap.put(field.name(), false);
        }
    }

    public TransactionHistoryFilterFragment() {
        // Required empty public constructor
    }

    public static TransactionHistoryFilterFragment newInstance(boolean isInvoiceView) {
        TransactionHistoryFilterFragment fragment = new TransactionHistoryFilterFragment();
        Bundle args = new Bundle();
        args.putBoolean(ARG_INVOICE_VIEW, isInvoiceView);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            isInvoiceView = getArguments().getBoolean(ARG_INVOICE_VIEW);
        }
    }

    @NonNull
    @Override
    public View onCreateView(LayoutInflater inflater,
            ViewGroup container,
            Bundle savedInstanceState) {
        View view = getActivity().getLayoutInflater().inflate(
                R.layout.fragment_transaction_history_filter, null);

        view.findViewById(R.id.fragment_transaction_history_filter_txn_type).setOnClickListener(this);
        view.findViewById(R.id.fragment_transaction_history_filter_card_type).setOnClickListener(this);
        view.findViewById(R.id.fragment_transaction_history_filter_status).setOnClickListener(this);
        view.findViewById(R.id.fragment_transaction_history_filter_payment_source).setOnClickListener(this);
        view.findViewById(R.id.fragment_transaction_history_filter_optional_fields).setOnClickListener(this);

        view.findViewById(R.id.fragment_transaction_history_filter_btn_search).setOnClickListener(this);

        transactionTypesSummary =
                view.findViewById(R.id.fragment_transaction_history_filter_txn_type_summary);
        cardTypesSummary =
                view.findViewById(R.id.fragment_transaction_history_filter_card_type_summary);
        transactionStatusSummary =
                view.findViewById(R.id.fragment_transaction_history_filter_status_summary);
        paymentSourceSummary =
                view.findViewById(R.id.fragment_transaction_history_filter_payment_source_summary);
        optionalFieldsSummary =
                view.findViewById(R.id.fragment_transaction_history_filter_optional_fields_summary);

        etStartDate = view.findViewById(
                R.id.fragment_transaction_history_filter_et_start_date);
        etEndDate = view.findViewById(
                R.id.fragment_transaction_history_filter_et_end_date);
        etPastDays = view.findViewById(
                R.id.fragment_transaction_history_filter_et_past_days);
        etPageNo = view.findViewById(
                R.id.fragment_transaction_history_filter_et_page_number);
        etPageSize = view.findViewById(
                R.id.fragment_transaction_history_filter_et_page_size);
        etClerkId = view.findViewById(
                R.id.fragment_transaction_history_filter_et_clerk_id);
        etInvoiceId = view.findViewById(
                R.id.fragment_transaction_history_filter_et_invoice_id);
        etTransactionID = view.findViewById(
                R.id.fragment_transaction_history_filter_et_transaction_id);
        etTransactionGUID = view.findViewById(
                R.id.fragment_transaction_history_filter_et_Transaction_guid);
        etCustomerName = view.findViewById(
                R.id.fragment_transaction_history_filter_et_customer_name);
        etCardholderName = view.findViewById(
                R.id.fragment_transaction_history_filter_et_cardholder_name);
        etCustomerEmail = view.findViewById(
                R.id.fragment_transaction_history_filter_et_customer_email);
        etLastFourDigitsOfCard = view.findViewById(
                R.id.fragment_transaction_history_filter_et_last_four_digits_of_card);
        etAuthAmountInCents = view.findViewById(
                R.id.fragment_transaction_history_filter_et_auth_amount_in_cents);
        etInvoiceAmountInCents = view.findViewById(
                R.id.fragment_transaction_history_filter_et_invoice_amount_in_cents);
        etTransactionNote = view.findViewById(
                R.id.fragment_transaction_history_filter_et_transaction_note);
        etMerchantInvoiceId = view.findViewById(
                R.id.fragment_transaction_history_filter_et_merchant_invoice_id);
        etTransactedBy = view.findViewById(
                R.id.fragment_transaction_history_filter_et_transacted_by);
        etAuthCode = view.findViewById(
                R.id.fragment_transaction_history_filter_et_auth_code);
        etBatchNumber = view.findViewById(
                R.id.fragment_transaction_history_filter_et_batch_number);
        etOrderNumber = view.findViewById(
                R.id.fragment_transaction_history_filter_et_order_number);
        includeSubmerchantTransactions = view.findViewById(R.id.includeSubmerchantTransactionsCheckbox);

        updateSummaries();

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        etStartDate.addTextChangedListener(datesTextWatcher);
        etEndDate.addTextChangedListener(datesTextWatcher);
        etPastDays.addTextChangedListener(pastDaysTextWatcher);
    }

    @Override
    public void onPause() {
        super.onPause();
        etStartDate.removeTextChangedListener(datesTextWatcher);
        etEndDate.removeTextChangedListener(datesTextWatcher);
        etPastDays.removeTextChangedListener(pastDaysTextWatcher);
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            listener = (OnFragmentInteractionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(
                    "Calling fragment must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }

    @Override
    public void onClick(View v) {
        int clickedBtnId = v.getId();
        if (clickedBtnId == R.id.fragment_transaction_history_filter_btn_search) {
            if (isInvoiceView) {
                listener.onInvoiceFilterCriteriaCreated(getTransactionQuery());
            } else {
                listener.onTransactionFilterCriteriaCreated(getTransactionQuery());
            }
        } else {
            DialogFragment dialogFragment = null;
            switch (clickedBtnId) {
                case R.id.fragment_transaction_history_filter_txn_type:
                    dialogFragment = FilterOptionsDialogFragment.getInstance(TRANSACTION_TYPE, transactionTypeMap);
                    break;
                case R.id.fragment_transaction_history_filter_card_type:
                    dialogFragment = FilterOptionsDialogFragment.getInstance(CARD_TYPE, cardTypeMap);
                    break;
                case R.id.fragment_transaction_history_filter_status:
                    dialogFragment = FilterOptionsDialogFragment.getInstance(TRANSACTION_STATUS, transactionStatusMap);
                    break;
                case R.id.fragment_transaction_history_filter_payment_source:
                    dialogFragment = FilterOptionsDialogFragment.getInstance(PAYMENT_SOURCE, paymentSourceMap);
                    break;
                case R.id.fragment_transaction_history_filter_optional_fields:
                    dialogFragment = FilterOptionsDialogFragment.getInstance(OPTIONAL_FIELDS, optionalFieldsMap);
            }

            dialogFragment.setTargetFragment(TransactionHistoryFilterFragment.this, 0);
            dialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
        }
    }

    @Override
    public void onFilterOptionsSelected(@FilterType String filterType, LinkedHashMap<String, Boolean> optionSelectionMap) {
        switch (filterType) {
            case TRANSACTION_TYPE:
                transactionTypeMap = optionSelectionMap;
                break;
            case CARD_TYPE:
                cardTypeMap = optionSelectionMap;
                break;
            case TRANSACTION_STATUS:
                transactionStatusMap = optionSelectionMap;
                break;
            case PAYMENT_SOURCE:
                paymentSourceMap = optionSelectionMap;
                break;
            case OPTIONAL_FIELDS:
                optionalFieldsMap = optionSelectionMap;
                break;
        }
        updateSummaries();
    }

    private TransactionQuery getTransactionQuery() {
        TransactionQueryBuilder builder = new TransactionQueryBuilder();
        String startDate = etStartDate.getText().toString();
        String endDate = etEndDate.getText().toString();
        String clerkId = etClerkId.getText().toString();
        String invoiceId = etInvoiceId.getText().toString();
        String pastDays = etPastDays.getText().toString();
        String pageSize = etPageSize.getText().toString();
        String pageNumber = etPageNo.getText().toString();
        String transactionID = etTransactionID.getText().toString();
        String transactionGuid = etTransactionGUID.getText().toString();
        String customerName = etCustomerName.getText().toString();
        String cardholderName = etCardholderName.getText().toString();
        String customerEmail = etCustomerEmail.getText().toString();
        String lastFourDigitsOfCard = etLastFourDigitsOfCard.getText().toString();
        String authAmountInCents = etAuthAmountInCents.getText().toString();
        String invoiceAmountInCents = etInvoiceAmountInCents.getText().toString();
        String transactionNote = etTransactionNote.getText().toString();
        String merchantInvoiceID = etMerchantInvoiceId.getText().toString();
        String transactedBy = etTransactedBy.getText().toString();
        String authCode = etAuthCode.getText().toString();
        String batchNumber = etBatchNumber.getText().toString();
        String orderNumber = etOrderNumber.getText().toString();

        builder.setCardTypes((ArrayList<CardType>) getSelectedOptions(CARD_TYPE, cardTypeMap));
        builder.setTransactionTypes((ArrayList<TransactionType>) getSelectedOptions(TRANSACTION_TYPE, transactionTypeMap));
        builder.setTransactionStatuses((ArrayList<TransactionStatus>) getSelectedOptions(TRANSACTION_STATUS, transactionStatusMap));
        builder.setPosEntrySources((ArrayList<POSEntrySource>) getSelectedOptions(PAYMENT_SOURCE, paymentSourceMap));
        builder.includeOptionalFields((ArrayList<TransactionQuery.OptionalTransactionHistoryField>) getSelectedOptions(OPTIONAL_FIELDS, optionalFieldsMap));

        if (!startDate.isEmpty()) {
            builder.setStartDate(startDate);
        }
        if (!endDate.isEmpty()) {
            builder.setEndDate(endDate);
        }
        if (!clerkId.isEmpty()) {
            builder.setClerkId(clerkId);
        }
        if (!invoiceId.isEmpty()) {
            builder.setInvoiceId(invoiceId);
        }
        if (!pastDays.isEmpty()) {
            builder.setPastDays(Integer.parseInt(pastDays));
        }
        if (!pageNumber.isEmpty()) {
            builder.setPageNumber(Integer.parseInt(pageNumber));
        }
        if (!pageSize.isEmpty()) {
            builder.setPageSize(Integer.parseInt(pageSize));
        }
        if (!transactionID.isEmpty()) {
            builder.setTransactionID(transactionID);
        }
        if (!transactionGuid.isEmpty()) {
            builder.setTransactionGuid(transactionGuid);
        }
        if (!customerName.isEmpty()) {
            builder.setCustomerName(customerName);
        }
        if (!cardholderName.isEmpty()) {
            builder.setCardholderName(cardholderName);
        }
        if (!customerEmail.isEmpty()) {
            builder.setCustomerEmail(customerEmail);
        }
        if (!lastFourDigitsOfCard.isEmpty()) {
            builder.setLastFourDigitsOfCard(lastFourDigitsOfCard);
        }
        if (!authAmountInCents.isEmpty()) {
            builder.setAuthAmountInCents(Integer.parseInt(authAmountInCents));
        }
        if (!invoiceAmountInCents.isEmpty()) {
            builder.setInvoiceAmountInCents(Integer.parseInt(invoiceAmountInCents));
        }
        if (!transactionNote.isEmpty()) {
            builder.setTransactionNote(transactionNote);
        }
        if (!merchantInvoiceID.isEmpty()) {
            builder.setMerchantInvoiceId(merchantInvoiceID);
        }
        if (!transactedBy.isEmpty()) {
            builder.setTransactedBy(transactedBy);
        }
        if (!authCode.isEmpty()) {
            builder.setAuthCode(authCode);
        }
        if (!batchNumber.isEmpty()) {
            builder.setBatchNumber(batchNumber);
        }
        if (!orderNumber.isEmpty()) {
            builder.setOrderNumber(orderNumber);
        }
        builder.setIncludeSubmerchantTransaction(includeSubmerchantTransactions.isChecked());
        return builder.createQueryCriteria();
    }

    private void updateSummaries() {
        transactionTypesSummary.setText(getSummaryText(transactionTypeMap));
        cardTypesSummary.setText(getSummaryText(cardTypeMap));
        transactionStatusSummary.setText(getSummaryText(transactionStatusMap));
        paymentSourceSummary.setText(getSummaryText(paymentSourceMap));
        optionalFieldsSummary.setText(getOptionalFieldsSummary(optionalFieldsMap));
    }

    private List<?> getSelectedOptions(@FilterType String filterType,
                                       LinkedHashMap<String, Boolean> optionSelectionMap) {
        List<?> selectedOptionsList = null;
        List<String> selectedOptionStrings = getSelectedOptionStrings(optionSelectionMap);
        switch (filterType) {
            case TRANSACTION_TYPE:
                List<TransactionType> transactionTypes = new ArrayList<>();
                for (String str : selectedOptionStrings) {
                    transactionTypes.add(TransactionType.valueOf(str));
                }
                selectedOptionsList = transactionTypes;
                break;
            case CARD_TYPE:
                List<CardType> cardTypes = new ArrayList<>();
                for (String str : selectedOptionStrings) {
                    cardTypes.add(CardType.valueOf(str));
                }
                selectedOptionsList = cardTypes;
                break;
            case TRANSACTION_STATUS:
                List<TransactionStatus> statuses = new ArrayList<>();
                for (String str : selectedOptionStrings) {
                    statuses.add(TransactionStatus.valueOf(str));
                }
                selectedOptionsList = statuses;
                break;
            case PAYMENT_SOURCE:
                List<POSEntrySource> sources = new ArrayList<>();
                for (String str : selectedOptionStrings) {
                    sources.add(POSEntrySource.valueOf(str));
                }
                selectedOptionsList = sources;
                break;
            case OPTIONAL_FIELDS:
                List<TransactionQuery.OptionalTransactionHistoryField> fields = new ArrayList<>();
                for (String str : selectedOptionStrings) {
                    fields.add(TransactionQuery.OptionalTransactionHistoryField.valueOf(str));
                }
                selectedOptionsList = fields;
        }
        return selectedOptionsList;
    }

    private String getSummaryText(LinkedHashMap<String, Boolean> optionSelectionMap) {
        List<String> selectedOptions = getSelectedOptionStrings(optionSelectionMap);
        if (selectedOptions.isEmpty() || selectedOptions.size() == optionSelectionMap.size()) {
            return getActivity().getString(R.string.str_fragment_transaction_history_filter_summary_default);
        }

        StringBuilder summary = new StringBuilder();
        for (String option : selectedOptions) {
            summary.append(option + ", ");
        }
        return summary.substring(0, summary.length() - 2);
    }

    private String getOptionalFieldsSummary(LinkedHashMap<String, Boolean> optionSelectionMap) {
        List<String> selectedOptions = getSelectedOptionStrings(optionSelectionMap);
        if (selectedOptions.isEmpty()) {
            return getActivity().getString(R.string.str_fragment_transaction_history_filter_summary_optional_fields_default);
        }
        if (selectedOptions.size() == optionSelectionMap.size()) {
            return getActivity().getString(R.string.str_fragment_transaction_history_filter_summary_default);
        }

        StringBuilder summary = new StringBuilder();
        for (String option : selectedOptions) {
            summary.append(option + ", ");
        }
        return summary.substring(0, summary.length() - 2);
    }

    public interface OnFragmentInteractionListener {
        void onTransactionFilterCriteriaCreated(TransactionQuery query);

        void onInvoiceFilterCriteriaCreated(TransactionQuery query);
    }

    private class DatesTextWatcher implements TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            if (etPastDays.getText().length() > 0) {
                etPastDays.removeTextChangedListener(pastDaysTextWatcher);
                etPastDays.setText("");
                etPastDays.addTextChangedListener(pastDaysTextWatcher);
            }
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    }

    private class PastDaysTextWatcher implements TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            if (etStartDate.getText().length() > 0) {
                etStartDate.removeTextChangedListener(datesTextWatcher);
                etStartDate.setText("");
                etStartDate.addTextChangedListener(datesTextWatcher);
            }
            if (etEndDate.getText().length() > 0) {
                etEndDate.removeTextChangedListener(datesTextWatcher);
                etEndDate.setText("");
                etEndDate.addTextChangedListener(datesTextWatcher);
            }
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    }
}
