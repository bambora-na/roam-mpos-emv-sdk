/*
 * //////////////////////////////////////////////////////////////////////////////
 * //
 * // Copyright (c) 2016 ROAM, Inc. All rights reserved.
 * //
 * //////////////////////////////////////////////////////////////////////////////
 */

package com.ingenico.mpos.app.sample;

import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ingenico.mpos.app.sample.common.logger.Log;
import com.ingenico.mpos.sdk.Ingenico;
import com.ingenico.mpos.sdk.callbacks.GetInvoiceHistoryCallback;
import com.ingenico.mpos.sdk.callbacks.GetTransactionDetailsCallback;
import com.ingenico.mpos.sdk.callbacks.GetTransactionHistoryCallback;
import com.ingenico.mpos.sdk.constants.ResponseCode;
import com.ingenico.mpos.sdk.constants.TransactionType;
import com.ingenico.mpos.sdk.data.InvoiceHistorySummary;
import com.ingenico.mpos.sdk.data.TransactionHistoryDetail;
import com.ingenico.mpos.sdk.data.TransactionHistorySummary;
import com.ingenico.mpos.sdk.data.TransactionQuery;
import com.ingenico.mpos.sdk.response.TransactionResponse;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class TransactionHistoryFragment extends FragmentBase {
    private static final String TAG = TransactionHistoryFragment.class.getSimpleName();
    private static final String ARG_HISTORY_QUERY = "arg_history_query";
    private static final String ARG_INVOICE_VIEW = "ARG_INVOICE_VIEW";

    private RecyclerView rvSummaryList;

    private TextView tvDetail;

    private List<TransactionHistorySummary> transactionHistoryList = new ArrayList<>();

    private TransactionQuery query;

    private boolean isInvoiceView;

    private OnFragmentInteractionListener mListener;

    public TransactionHistoryFragment() {
        // Required empty public constructor
    }

    public static TransactionHistoryFragment newInstance(TransactionQuery query, boolean isInvoiceView) {
        TransactionHistoryFragment fragment = new TransactionHistoryFragment();
        Bundle args = new Bundle();
        args.putParcelable(ARG_HISTORY_QUERY, query);
        args.putBoolean(ARG_INVOICE_VIEW, isInvoiceView);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            query = getArguments().getParcelable(ARG_HISTORY_QUERY);
            isInvoiceView = getArguments().getBoolean(ARG_INVOICE_VIEW);
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {
        View view = getActivity().getLayoutInflater().inflate(R.layout.fragment_transaction_history,
                null);

        rvSummaryList = (RecyclerView) view.findViewById(
                R.id.fragment_transaction_history_rv_results);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getActivity());
        rvSummaryList.setLayoutManager(layoutManager);
        rvSummaryList.addItemDecoration(
                new DividerItemDecoration(getActivity(), LinearLayoutManager.VERTICAL));

        rvSummaryList.addOnItemTouchListener(
                new RecyclerTouchListener(getActivity(), rvSummaryList, new ClickListener() {
                    @Override
                    public void onClick(View view, int position) {
                        String transactionId = transactionHistoryList.get(position).getTransactionId();
                        getTransactionDetails(transactionId);
                    }

                    @Override
                    public void onLongClick(View view, int position) {

                    }
                }));

        tvDetail = (TextView) view.findViewById(R.id.fragment_transaction_history_tv_detail);

        if (isInvoiceView) {
            getInvoiceHistory();
        } else {
            getTransactionHistory();
        }
        return view;
    }

    private void getTransactionHistory() {
        mProgressDialogListener.showProgressMessage("Getting Transactions...");
        Ingenico.getInstance().user().getTransactionHistory(query,
                new GetTransactionHistoryCallbackImpl());
    }

    private void getInvoiceHistory() {
        mProgressDialogListener.showProgressMessage("Getting Invoices...");
        Ingenico.getInstance().user().getInvoiceHistory(query,
                new GetInvoiceHistoryCallbackImpl());
    }

    private void getTransactionDetails(String transactionId) {
        mProgressDialogListener.showProgressMessage("Getting Transaction Details...");
        Ingenico.getInstance().user().getTransactionDetails(
                transactionId,
                new GetTransactionDetailsCallbackImpl()
        );
    }

    private interface ClickListener {
        void onClick(View view, int position);

        void onLongClick(View view, int position);
    }

    private static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private TransactionHistoryFragment.ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView,
                final TransactionHistoryFragment.ClickListener clickListener) {
            this.clickListener = clickListener;
            gestureDetector = new GestureDetector(context,
                    new GestureDetector.SimpleOnGestureListener() {
                        @Override
                        public boolean onSingleTapUp(MotionEvent e) {
                            return true;
                        }

                        @Override
                        public void onLongPress(MotionEvent e) {
                            View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                            if (child != null && clickListener != null) {
                                clickListener.onLongClick(child,
                                        recyclerView.getChildPosition(child));
                            }
                        }
                    });
        }

        @Override
        public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {

            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(RecyclerView rv, MotionEvent e) {
        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }

    private class HistoryAdapter extends
            RecyclerView.Adapter<HistoryAdapter.TransactionViewHolder> {

        private List<TransactionHistorySummary> transactionHistoryList;

        public HistoryAdapter(List<TransactionHistorySummary> transactionHistoryList) {
            this.transactionHistoryList = transactionHistoryList;
        }

        @Override
        public TransactionViewHolder onCreateViewHolder(
                ViewGroup parent,
                int viewType) {
            View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.list_item_transaction_history, parent, false);
            return new TransactionViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(TransactionViewHolder holder,
                int position) {
            TransactionHistorySummary item = transactionHistoryList.get(position);
            holder.tvAmount.setText("$" + Integer.toString(item.getAmount().getTotal()));
            holder.tvClerkId.setText("ClerkId::" + item.getClerkId());
            holder.tvStatus.setText("Status::" + item.getTransactionStatus());
            holder.tvInvoiceId.setText("InvoiceId::" + item.getInvoiceId());
            SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
            try {
                holder.tvTimestamp.setText(formatter.format(
                        new SimpleDateFormat("yyyyMMddHHmmss").parse(item.getDeviceTimestamp())));
            } catch (ParseException e) {

            }
        }

        @Override
        public int getItemCount() {
            return transactionHistoryList.size();
        }

        public class TransactionViewHolder extends RecyclerView.ViewHolder {
            TextView tvAmount;
            TextView tvClerkId;
            TextView tvTimestamp;
            TextView tvStatus;
            TextView tvInvoiceId;

            public TransactionViewHolder(View view) {
                super(view);
                tvAmount = (TextView) view.findViewById(R.id.list_item_transaction_history_amount);
                tvClerkId = (TextView) view.findViewById(
                        R.id.list_item_transaction_history_clerkid);
                tvTimestamp = (TextView) view.findViewById(
                        R.id.list_item_transaction_history_timestamp);
                tvStatus = (TextView) view.findViewById(R.id.list_item_transaction_history_status);
                tvInvoiceId = (TextView) view.findViewById(
                        R.id.list_item_transaction_history_invoiceid);
                if (isInvoiceView) {
                    tvInvoiceId.setTypeface(null, Typeface.BOLD_ITALIC);
                }
            }
        }
    }

    private class DividerItemDecoration extends RecyclerView.ItemDecoration {

        public static final int HORIZONTAL_LIST = LinearLayoutManager.HORIZONTAL;
        public static final int VERTICAL_LIST = LinearLayoutManager.VERTICAL;
        private final int[] ATTRS = new int[]{
                android.R.attr.listDivider
        };
        private Drawable mDivider;

        private int mOrientation;

        public DividerItemDecoration(Context context, int orientation) {
            final TypedArray a = context.obtainStyledAttributes(ATTRS);
            mDivider = a.getDrawable(0);
            a.recycle();
            setOrientation(orientation);
        }

        public void setOrientation(int orientation) {
            if (orientation != HORIZONTAL_LIST && orientation != VERTICAL_LIST) {
                throw new IllegalArgumentException("invalid orientation");
            }
            mOrientation = orientation;
        }

        @Override
        public void onDrawOver(Canvas c, RecyclerView parent, RecyclerView.State state) {
            if (mOrientation == VERTICAL_LIST) {
                drawVertical(c, parent);
            } else {
                drawHorizontal(c, parent);
            }
        }

        public void drawVertical(Canvas c, RecyclerView parent) {
            final int left = parent.getPaddingLeft();
            final int right = parent.getWidth() - parent.getPaddingRight();

            final int childCount = parent.getChildCount();
            for (int i = 0; i < childCount; i++) {
                final View child = parent.getChildAt(i);
                final RecyclerView.LayoutParams params = (RecyclerView.LayoutParams) child
                        .getLayoutParams();
                final int top = child.getBottom() + params.bottomMargin;
                final int bottom = top + mDivider.getIntrinsicHeight();
                mDivider.setBounds(left, top, right, bottom);
                mDivider.draw(c);
            }
        }

        public void drawHorizontal(Canvas c, RecyclerView parent) {
            final int top = parent.getPaddingTop();
            final int bottom = parent.getHeight() - parent.getPaddingBottom();

            final int childCount = parent.getChildCount();
            for (int i = 0; i < childCount; i++) {
                final View child = parent.getChildAt(i);
                final RecyclerView.LayoutParams params = (RecyclerView.LayoutParams) child
                        .getLayoutParams();
                final int left = child.getRight() + params.rightMargin;
                final int right = left + mDivider.getIntrinsicHeight();
                mDivider.setBounds(left, top, right, bottom);
                mDivider.draw(c);
            }
        }

        @Override
        public void getItemOffsets(Rect outRect, View view, RecyclerView parent,
                RecyclerView.State state) {
            if (mOrientation == VERTICAL_LIST) {
                outRect.set(0, 0, 0, mDivider.getIntrinsicHeight());
            } else {
                outRect.set(0, 0, mDivider.getIntrinsicWidth(), 0);
            }
        }
    }


    private class GetTransactionHistoryCallbackImpl implements GetTransactionHistoryCallback {
        @Override
        public void done(Integer responseCode,
                Integer totalMatches,
                List<TransactionHistorySummary> transactions) {
            Log.v(TAG, "GetTransactions::done::" + responseCode);
            Log.v(TAG, "GetTransactions total matches::" + totalMatches);
            mProgressDialogListener.hideProgress();
            if (ResponseCode.Success == responseCode) {
                showToast("Success");
                transactionHistoryList = transactions;
                Log.v(TAG, transactionHistoryList.toString());
                RecyclerView.Adapter adapter = new HistoryAdapter(transactionHistoryList);
                rvSummaryList.setAdapter(adapter);
                adapter.notifyDataSetChanged();
            } else {
                showToast("Failed");
            }
        }
    }

    private class GetInvoiceHistoryCallbackImpl implements GetInvoiceHistoryCallback {
        @Override
        public void done(Integer responseCode, Integer totalMatches,
                List<InvoiceHistorySummary> invoices) {
            Log.v(TAG, "GetInvoices::done::" + responseCode);
            Log.v(TAG, "GetInvoices total matches::" + totalMatches);
            mProgressDialogListener.hideProgress();
            if (ResponseCode.Success == responseCode) {
                showToast("Success");
                for(InvoiceHistorySummary summary : invoices) {
                    transactionHistoryList.addAll(summary.getTransactions());
                }
                Log.v(TAG, transactionHistoryList.toString());
                RecyclerView.Adapter adapter = new HistoryAdapter(transactionHistoryList);
                rvSummaryList.setAdapter(adapter);
                adapter.notifyDataSetChanged();
            } else {
            showToast("Failed");
        }
        }
    }


    private class GetTransactionDetailsCallbackImpl implements GetTransactionDetailsCallback {
        @Override
        public void done(Integer responseCode, TransactionHistoryDetail transaction) {
            Log.v(TAG, "GetTransactionDetails::done::" + responseCode);
            mListener.setCachedTransactionId(transaction.getTransactionId());
            if (transaction.getTransactionType() == TransactionType.CreditSale ||
                    transaction.getTransactionType() == TransactionType.CreditAuth ||
                    transaction.getTransactionType() == TransactionType.CreditSaleAdjust ||
                    transaction.getTransactionType() == TransactionType.CreditAuthAdjust
            ) {
                mListener.cacheCreditRefundableTransactionId(transaction.getTransactionId());
            }
            tvDetail.setText(transaction.toString());
            mProgressDialogListener.hideProgress();
            if (ResponseCode.Success == responseCode) {
                showToast("Success");
            } else {
                showToast("Failed");
            }
        }
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mListener = (OnFragmentInteractionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    public interface OnFragmentInteractionListener {
        void setCachedTransactionId(String transactionId);
        String getCachedTransactionId();
        void cacheCreditRefundableTransactionId(String transactionId);
    }
}
