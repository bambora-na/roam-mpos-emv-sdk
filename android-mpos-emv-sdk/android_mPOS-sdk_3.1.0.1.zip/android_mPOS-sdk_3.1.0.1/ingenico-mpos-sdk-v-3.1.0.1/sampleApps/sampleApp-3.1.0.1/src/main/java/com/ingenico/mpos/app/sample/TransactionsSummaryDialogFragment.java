/*
 * Copyright (c) 2018. All Rights Reserved, ROAM Data, Inc.
 */

package com.ingenico.mpos.app.sample;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import androidx.fragment.app.DialogFragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

public class TransactionsSummaryDialogFragment extends DialogFragment implements
        View.OnClickListener, DatePickerDialog.OnDateSetListener {

    private LinearLayout startDateLayout;
    private LinearLayout endDateLayout;
    private TextView startDateText;
    private TextView endDateText;
    private View layoutClicked;
    private String startDate;
    private String endDate;
    private TransactionsSummaryListener mListener;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_transactions_summary, null);
        startDateLayout = view.findViewById(R.id.dialog_transactions_summary_start_date);
        endDateLayout = view.findViewById(R.id.dialog_transactions_summary_end_date);
        startDateText = view.findViewById(R.id.dialog_transactions_summary_start_date_text);
        endDateText = view.findViewById(R.id.dialog_transactions_summary_end_date_text);
        startDateLayout.setOnClickListener(this);
        endDateLayout.setOnClickListener(this);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Enter start and end date. Should not exceed 10 days")
                .setView(view)
                .setPositiveButton(
                R.string.str_common_btn_ok,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (startDate == null || endDate == null && BuildConfig.showResultDialogs) {
                            Toast.makeText(getContext(), "Start and end date cannot be empty",
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }
                        mListener.onTransactionsSummaryCaptured(startDate, endDate);
                    }
                });
        return builder.create();
    }

    @Override
    public void onClick(View v) {
        layoutClicked = v;
        final Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog dialog = new DatePickerDialog(getActivity(), this, year, month, day);
        dialog.show();
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mListener = (TransactionsSummaryDialogFragment.TransactionsSummaryListener) getTargetFragment();
        } catch (ClassCastException e) {
            throw new ClassCastException("Calling fragment must implement TransactionsSummaryListener");
        }
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        month++; //month starts at 0
        String date = String.format("%s/%s/%s", Integer.toString(month),
                Integer.toString(dayOfMonth), Integer.toString(year));
        String fullDate = String.format(Locale.getDefault(), "%d%02d%02d",
                year, month, dayOfMonth);
        if (layoutClicked == startDateLayout) {
            startDate = fullDate.concat("000000");
            startDateText.setText(date);
        }
        else {
            final Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
            if (c.get(Calendar.YEAR) == year && c.get(Calendar.MONTH) == month &&
                    c.get(Calendar.DATE) == dayOfMonth) {
                endDate = fullDate.concat(String.format(Locale.getDefault(), "%02d%02d%02d",
                        c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), c.get(Calendar.SECOND)));
            }
            else {
                endDate = fullDate.concat("235959");
            }
            endDateText.setText(date);
        }
    }

    public interface TransactionsSummaryListener {
        void onTransactionsSummaryCaptured(String startDate, String endDate);
    }
}
