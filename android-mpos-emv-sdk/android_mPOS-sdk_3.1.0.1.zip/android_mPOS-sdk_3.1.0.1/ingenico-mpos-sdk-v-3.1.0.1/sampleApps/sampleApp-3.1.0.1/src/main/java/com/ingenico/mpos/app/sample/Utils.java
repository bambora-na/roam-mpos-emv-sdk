package com.ingenico.mpos.app.sample;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;

import android.text.TextUtils;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.ingenico.mpos.app.sample.common.logger.Log;
import com.ingenico.mpos.sdk.Ingenico;
import com.ingenico.mpos.sdk.constants.FirmwareUpdateAction;
import com.ingenico.mpos.sdk.constants.POSEntryMode;
import com.ingenico.mpos.sdk.constants.ProgressMessage;
import com.ingenico.mpos.sdk.constants.ResponseCode;
import com.ingenico.mpos.sdk.data.TokenResponseParameters;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class Utils {

    public static final String SEPARATOR = "\n\t*--*--*\t";
    private static final String LOGCAT_FILTERS = "ValidationHelper_CPP:W *:V "
            + "BluetoothCommManager:S FRAMEUTIL:S "
            + "ViewRootImpl:S BubblePopupHelper:S " 
            + "CliptrayUtils:S art:S "
            + "Choreographer:S PhoneWindow:S "
            + "PhoneWindowEx:S libc-netbsd:S "
            + "g:S General_JNI:S";
    private static final String LOGCAT_COMMAND = "logcat -v time -d " + LOGCAT_FILTERS;

    public static String getBase64EncodedString(Bitmap image) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        image.compress(Bitmap.CompressFormat.JPEG, 50, baos);
        byte[] b = baos.toByteArray();
        return Base64.encodeToString(b, Base64.NO_WRAP);
    }

    private static String getAppVersion(Context context) {
        String appVersion = null;
        try {
            appVersion = context.getPackageManager().getPackageInfo(context.getPackageName(),
                    0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return appVersion;
    }

    public static String getAboutInfo(Context context) {
        StringBuilder buf = new StringBuilder();
        String appVersion = getAppVersion(context);
        if (appVersion != null) {
            buf.append("SAMPLE.APP.VERSION: ").append(appVersion);
        }
        buf.append("\nMPOS.SDK.VERSION: ").append(Ingenico.getInstance().getVersion());
        buf.append("\nVERSION.RELEASE :").append(Build.VERSION.RELEASE);
        buf.append("\nVERSION.SDK_INT :").append(Build.VERSION.SDK_INT);
        buf.append("\nVERSION.INCREMENTAL :").append(Build.VERSION.INCREMENTAL);
        buf.append("\nMANUFACTURER :").append(Build.MANUFACTURER);
        buf.append("\nMODEL :").append(Build.MODEL);
        buf.append("\nBRAND :").append(Build.BRAND);
        buf.append("\nCPU ARCH :").append(System.getProperty("os.arch"));

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            buf.append("\nCPU_ABI :").append(Build.CPU_ABI);
            buf.append("\nCPU_ABI2 :").append(Build.CPU_ABI2);
        } else {
            buf.append("\nSUPPORTED_ABIS:");
            for (String abi : Build.SUPPORTED_ABIS) {
                buf.append(abi).append(",");
            }
        }
        return buf.toString();
    }

    public static String getTimeStamp() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
       return "[" + format.format(new Date()) + "]";
    }

    public static void logTimeStamp(String tag) {
        Log.v(tag,  getTimeStamp());
    }

    public static AlertDialog newDialog(Context context, String title, String msg) {
        return newDialog(context,
                title,
                msg,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
    }

    public static AlertDialog newDialog(Context context, String title, String msg, DialogInterface.OnClickListener positiveListener) {
        AlertDialog dialog;
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(title)
                .setMessage(msg)
                .setPositiveButton(R.string.str_common_btn_ok, positiveListener);
        dialog = builder.create();
        return dialog;
    }


    public static StringBuilder readLogcat(String[] filters) {
        StringBuilder log = new StringBuilder();
        BufferedReader bufferedReader = null;
        try {
            Process process = Runtime.getRuntime().exec(LOGCAT_COMMAND);
            bufferedReader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                if (filters != null) {
                    for (int i = 0; i < filters.length; i++) {
                        if (line.contains(filters[i])) {
                            log.append(line);
                            log.append("\r\n");
                        }
                    }
                } else {
                    log.append(line);
                    log.append("\r\n");
                }
            }
        } catch (IOException e) {

        } finally {
            if (bufferedReader != null) {
                try {
                    bufferedReader.close();
                } catch (IOException e) {}
            }
        }
        return (log);
    }

    public static void clearLogcat(Context ctx) {
        try {
            Runtime.getRuntime().exec("logcat -c");
        } catch (IOException e) {
        }
    }

    public static String captureLogcat(Context ctx) {
        String fileName = ctx.getString(R.string.app_name) + "_" + getAppVersion(ctx);
        SimpleDateFormat s = new SimpleDateFormat("MMddyyyyhhmmss", Locale.getDefault());
        String currentDateandTime = s.format(new Date());
        String fname = "logcat_" + fileName + "_" + currentDateandTime + ".txt";
        File file = new File(ctx.getExternalFilesDir(null), fname);
        try {
            FileOutputStream f = new FileOutputStream(file);
            PrintWriter pw = new PrintWriter(f);
            pw.append(readLogcat(null));
            pw.flush();
            pw.close();
            f.close();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return file.getAbsolutePath();
    }

    /**
     * Check that all given permissions have been granted by verifying that each entry in the
     * given array is of the value {@link PackageManager#PERMISSION_GRANTED}.
     *
     * @see Activity#onRequestPermissionsResult(int, String[], int[])
     */
    public static boolean verifyPermissions(int[] grantResults) {
        // At least one result must be checked.
        if (grantResults.length < 1) {
            return false;
        }

        // Verify that each required permission has been granted, otherwise return false.
        for (int result : grantResults) {
            if (result != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    public static int convertStringToInt(String strValue){
        int val;
        try {
            val = Integer.parseInt(strValue);
        } catch (NumberFormatException ex) {
            val = 0;
        }
        return val;
    }

    public static boolean isBluetoothEnabled() {
        BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        return bluetoothAdapter != null && bluetoothAdapter.isEnabled();
    }

    public static String getResponseCodeString(int responseCode) {
        switch (responseCode) {
            case ResponseCode.Success:
                return "Success";
            case ResponseCode.PaymentDeviceNotAvailable:
                return "Payment Device Not Available";
            case ResponseCode.PaymentDeviceError:
                return "Payment Device Not Error";
            case ResponseCode.PaymentDeviceTimeout:
                return "Payment Device Timeouts";
            case ResponseCode.NotSupportedByPaymentDevice:
                return "Not Supported by Payment Device";
            case ResponseCode.CardBlocked:
                return "Card Blocked";
            case ResponseCode.ApplicationBlocked:
                return "Application Blocked";
            case ResponseCode.InvalidCard:
                return "Invalid Card";
            case ResponseCode.InvalidApplication:
                return "Invalid Card Application";
            case ResponseCode.TransactionCancelled:
                return "Transaction Cancelled";
            case ResponseCode.CardReaderGeneralError:
                return "Card Reader General Error";
            case ResponseCode.CardInterfaceGeneralError:
                return "Card Not Accepted";
            case ResponseCode.BatteryTooLowError:
                return "Battery Too Low";
            case ResponseCode.BadCardSwipe:
                return "Bad Card Swipe";
            case ResponseCode.TransactionDeclined:
                return "Transaction Declined";
            case ResponseCode.TransactionReversalCardRemovedFailed:
                return "Transaction Reversal Card Removed Failed";
            case ResponseCode.TransactionReversalCardRemovedSuccess:
                return "Transaction Reversal Card Removed Success";
            case ResponseCode.TransactionReversalChipDeclineFailed:
                return "Transaction Reversal Chip Decline  Failed";
            case ResponseCode.TransactionReversalChipDeclineSuccess:
                return "Transaction Reversal Chip Decline Success";
            case ResponseCode.TransactionReversalNetworkTimeoutFailed:
                return "Transaction Reversal Network Timeout Failed";
            case ResponseCode.TransactionReversalNetworkTimeoutSuccess:
                return "Transaction Reversal Network Timeout Success";
            case ResponseCode.UnsupportedCard:
                return "Unsupported Card";
        }
        return String.valueOf(responseCode);
    }

    public static String getTokenResponseString(TokenResponseParameters.TokenResponseCode responseCode) {
        switch (responseCode) {
            case Approved:
                return "Approved";
            case Declined:
                return "Token not requested because the transaction authorization was declined";
            case Error:
                return "Service provider error. See TokenSourceData for details.";
            case CommunicationError:
                return "Error connecting to the tokenization service provider.";
            default:
                return "Unknown";
        }
    }

    public static String getProgressMessage(int progressMessage) {
        switch (progressMessage) {
            case ProgressMessage.ApplicationSelectionCompleted:
                return "Application Selection Completed";
            case ProgressMessage.ApplicationSelectionStarted:
                return "Application Selection Started";
            case ProgressMessage.CardInserted:
                return "Card Inserted";
            case ProgressMessage.CardHolderPressedCancelKey:
                return "Card Holder Pressed Cancel Key";
            case ProgressMessage.DeviceBusy:
                return "Device Busy";
            case ProgressMessage.ErrorReadingContactlessCard:
                return "Error Reading Contactless Card";
            case ProgressMessage.FirstPinEntryPrompt:
                return "First Pin Entry Prompt";
            case ProgressMessage.ICCErrorSwipeCard:
                return "ICC Error Swipe Card";
            case ProgressMessage.LastPinEntryPrompt:
                return "Last Pin Entry Prompt";
            case ProgressMessage.PinEntryFailed:
                return "Pin Entry Failed";
            case ProgressMessage.PinEntryInProgress:
                return "Pin Entry In Progress";
            case ProgressMessage.PinEntrySuccessful:
                return "Pin Entry Successful";
            case ProgressMessage.PleaseInsertCard:{
                List<POSEntryMode> posList = Ingenico.getInstance().device().allowedPOSEntryModes();
                List<String> inputMethods = new ArrayList<>();
                if(posList.contains(POSEntryMode.ContactlessEMV) ||
                        posList.contains(POSEntryMode.ContactlessMSR)) {
                    inputMethods.add("tap");
                }
                if(posList.contains(POSEntryMode.ContactEMV)) {
                    inputMethods.add("insert");
                }
                if (posList.contains(POSEntryMode.MagStripe)) {
                    inputMethods.add("swipe");
                }
                return "Please " + TextUtils.join("/", inputMethods) + " card";
            }
            case ProgressMessage.ChipCardSwipeFailed: {
                return "Cannot swipe chip card. Please insert card instead";
            }
            case ProgressMessage.RetryPinEntryPrompt:
                return "Retry Pin Entry";
            case ProgressMessage.SwipeDetected:
                return "Swipe Detected";
            case ProgressMessage.SwipeErrorReswipeMagStripe:
                return "Swipe Error Re-swipe MagStripe";
            case ProgressMessage.TapDetected:
                return "Tap Detected";
            case ProgressMessage.UseContactInterfaceInsteadOfContactless:
                return "Use Contact Interface Instead Of Contactless";
            case ProgressMessage.WaitingforCardSwipe:
                return "Please swipe card";
            case ProgressMessage.RecordingTransaction:
                return "Recording Transaction";
            case ProgressMessage.GettingOnlineAuthorization:
                return "Getting Payment Authorization";
            case ProgressMessage.GettingCardVerification:
                return "Getting Card Verification";
            case ProgressMessage.SendingReversal:
                return "Sending Reversal";
            case ProgressMessage.UpdatingTransaction:
                return "Updating Transaction";
            case ProgressMessage.RestartingContactlessInterface:
                return "Restarting Contactless Interface";
            case ProgressMessage.TryContactInterface:
                return "Try Contact Interface";
            case ProgressMessage.PleaseRemoveCard:
                return "Please Remove Card";
            case ProgressMessage.PleaseSeePhone:
                return "Please See Phone";
            case ProgressMessage.MultipleContactlessCardsDetected:
                return "Please Present One Card Only";
            case ProgressMessage.PresentCardAgain:
                return "Please Present Card Again";
            case ProgressMessage.CardRemoved:
                return "Card Removed";
            case ProgressMessage.ReinsertCard:
                return "Reinsert card properly";
            case ProgressMessage.RestartingTransactionDueToIncorrectPin:
                return "Restarting Transaction Due To Incorrect Pin";
            case ProgressMessage.ContactlessInterfaceFailedTryContact:
                return "Contactless Failed, Try Contact";
            case ProgressMessage.WaitingforChipCard:
                return "Waiting for Chip Card";
            case ProgressMessage.WaitingforSwipeCard:
                return "Waiting for Swipe Card";
            case ProgressMessage.WaitingforChipAndSwipe:
                return "Waiting for Chip And Swipe";
            case ProgressMessage.WaitingforTapCard:
                return "Waiting for Tap Card";
            case ProgressMessage.WaitingforChipAndTap:
                return "Waiting for Chip And Tap";
            case ProgressMessage.WaitingforSwipeAndTap:
                return "Waiting for Swipe And Tap";
            case ProgressMessage.WaitingforChipSwipeTap:
                return "Waiting for Chip Swipe Tap";
            case ProgressMessage.WaitingforFallbackSwipe:
                return "Waiting for Fallback Swipe";
            case ProgressMessage.WaitingforFallbackChip:
                return "Waiting for Fallback Chip";
            case ProgressMessage.UpdatingFirmware:
                return "Updating Firmware";
            case ProgressMessage.SettingUpDevice:
                return "Setting Up Device";
            case ProgressMessage.DownloadingFirmware:
                return "Downloading Firmware";
            case ProgressMessage.CheckingFirmwareUpdate:
                return "Checking for Firmware Update";
            case ProgressMessage.CheckingDeviceSetup:
                return "Checking for Device set up";
        }
        return "Progress Message:" + progressMessage;
    }

    public static String getFirmwareUpdateActionString(FirmwareUpdateAction action) {
        switch (action) {
            case Required:
                return "Required";
            case Optional:
                return "Optional";
            case No:
                return "Not required";
            case Unknown:
                return "Unknown";
        }
        return "Unknown";
    }

    // Use this to set content description for automation
    public static class CustomArrayAdapter extends ArrayAdapter {
        private List objects;

        public CustomArrayAdapter(@NonNull Context context, @NonNull List objects) {
            super(context, android.R.layout.simple_list_item_1, android.R.id.text1, objects);
            this.objects = objects;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            TextView tvDeviceName = (TextView)super.getView(position, convertView, parent);
            tvDeviceName.setContentDescription(objects.get(position).toString());
            return tvDeviceName;
        }
    }
}
