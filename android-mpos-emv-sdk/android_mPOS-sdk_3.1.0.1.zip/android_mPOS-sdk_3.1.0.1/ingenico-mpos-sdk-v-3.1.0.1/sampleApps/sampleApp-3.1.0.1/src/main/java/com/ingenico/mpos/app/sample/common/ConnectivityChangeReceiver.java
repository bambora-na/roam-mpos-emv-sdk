/*
 * Copyright (c) 2015 All Rights Reserved, ROAM Data, Inc.
 *
 */

package com.ingenico.mpos.app.sample.common;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public final class ConnectivityChangeReceiver extends BroadcastReceiver {

    private static final String TAG = ConnectivityChangeReceiver.class.getSimpleName();
    private static final Object lock = new Object();
    private static final List<Listener> listeners = new ArrayList<>();
    private static boolean hasConnectivity = true;
    private static ConnectivityChangeReceiver instance;
    private Context mContext;

    public static ConnectivityChangeReceiver getInstance() {
        if (null == instance) {
            instance = new ConnectivityChangeReceiver();
        }
        return instance;
    }

    private ConnectivityChangeReceiver() {

    }

    public void startup(Context context) {
        mContext = context;
        mContext.registerReceiver(
                this,
                new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION)
        );
    }

    public void cleanup() {
        try {
            mContext.unregisterReceiver(this);
        } catch (Exception e) {

        }
        mContext = null;

    }

    public void register(Listener listener) {
        synchronized (lock) {
            if (listener != null && !listeners.contains(listener)) {
                listeners.add(listener);
                notifyListener(listener);
            }
        }
    }

    public void unregister(Listener listener) {
        synchronized (lock) {
            listeners.remove(listener);
        }
    }

    public boolean hasConnectivity() {
        synchronized (lock) {
            return hasConnectivity;
        }
    }

    private void setHasConnectivity(boolean connectivity) {
        synchronized (lock) {
            hasConnectivity = connectivity;
        }
    }

    private void notifyListener(Listener listener) {
        synchronized (lock) {
            if (hasConnectivity()) {
                listener.hasConnectivity();
            } else {
                listener.noConnectivity();
            }
        }
    }

    private void notifyListeners() {
        synchronized (lock) {
            ArrayList<Listener> copyOfListeners = new ArrayList<>();
            copyOfListeners.addAll(listeners);
            for (Listener listener : copyOfListeners) {
                notifyListener(listener);
            }
        }
    }

    private NetworkInfo getNetworkInfo(Context context){
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo();
    }

    private boolean hasNetworkConnectivity(Context context){
        NetworkInfo info = getNetworkInfo(context);
        return (info != null && info.isConnected());
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        boolean hasExtraNoConnectivity = intent.hasExtra(ConnectivityManager.EXTRA_NO_CONNECTIVITY);
        boolean extraNoConnectivity = intent.getBooleanExtra(
                ConnectivityManager.EXTRA_NO_CONNECTIVITY, false);
        if (hasExtraNoConnectivity) {
            Log.w(TAG, "EXTRA_NO_CONNECTIVITY: " + extraNoConnectivity);
            setHasConnectivity(!extraNoConnectivity);
        } else {
            Log.w(TAG, "EXTRA_NO_CONNECTIVITY is missing.");
            setHasConnectivity(hasNetworkConnectivity(context));
        }
        notifyListeners();
    }

    public interface Listener {
        void hasConnectivity();

        void noConnectivity();
    }

}
