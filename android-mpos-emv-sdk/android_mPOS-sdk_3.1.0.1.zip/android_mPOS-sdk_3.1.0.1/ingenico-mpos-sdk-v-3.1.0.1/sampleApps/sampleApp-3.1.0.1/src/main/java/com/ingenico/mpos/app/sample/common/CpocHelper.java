/*
 * Copyright (c) 2015 - 2021. All Rights Reserved, Worldline SMB US Inc.
 */
package com.ingenico.mpos.app.sample.common;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;

public class CpocHelper {
    public static void initCpoc(Activity activity) {
        // no-op
    }

    public static void doStickShiftTransaction(Intent intent, String sessionToken,
            String hostUrl, Context context) {
        // no-op
    }
}
