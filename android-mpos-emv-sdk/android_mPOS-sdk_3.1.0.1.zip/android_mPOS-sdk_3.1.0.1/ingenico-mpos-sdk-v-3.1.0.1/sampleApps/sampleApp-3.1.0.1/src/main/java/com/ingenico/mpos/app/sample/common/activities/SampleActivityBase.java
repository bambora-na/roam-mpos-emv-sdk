/*
* Copyright 2013 The Android Open Source Project
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

package com.ingenico.mpos.app.sample.common.activities;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Toast;

import com.ingenico.mpos.app.sample.BuildConfig;
import com.ingenico.mpos.app.sample.R;
import com.ingenico.mpos.app.sample.Utils;
import com.ingenico.mpos.app.sample.common.logger.Log;
import com.ingenico.mpos.app.sample.common.logger.LogWrapper;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * Base launcher activity, to handle most of the common plumbing for samples.
 */
public abstract class SampleActivityBase extends AppCompatActivity {

    private static final String TAG = "SampleActivityBase";

    @Override
    protected void onStart() {
        super.onStart();
        initializeLogging();
    }

    /** Set up targets to receive log data */
    protected void initializeLogging() {
        // Using Log, front-end to the logging chain, emulates android.util.log method signatures.
        // Wraps Android's native log framework
        LogWrapper logWrapper = new LogWrapper();
        Log.setLogNode(logWrapper);
        Log.i(TAG, "Ready");
    }

    protected void showToast(String message) {
        showToast(message, Toast.LENGTH_SHORT);
    }

    public void showToast(String message, int duration) {
        if (BuildConfig.showResultDialogs) {
            Toast.makeText(this, message, duration).show();
        }
    }

    private String getCurrentTimeStamp() {
        SimpleDateFormat format = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z");
        return format.format(new Date());
    }

    protected boolean isWiredHeadsetOn(Context context) {
        AudioManager audioManager = null;
        if(null != context) {
            audioManager = (AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
        }

        return null != audioManager?audioManager.isWiredHeadsetOn():false;
    }

    public class SendEmailTask extends AsyncTask<Void, Void, Intent> {
        final Context context;
        final String log;

        public SendEmailTask(Context context, String log) {
            this.context = context;
            this.log = log;
        }

        @Override
        protected Intent doInBackground(Void... params) {
            Intent emailIntent = new Intent(Intent.ACTION_SEND_MULTIPLE);
            emailIntent.setType("text/plain");
            emailIntent.putExtra(Intent.EXTRA_SUBJECT,
                    getString(R.string.app_name) + " Log " + getCurrentTimeStamp());
            emailIntent.putExtra(Intent.EXTRA_TEXT,
                    Utils.getAboutInfo(context) + Utils.SEPARATOR + log);
            String logFilePath = Utils.captureLogcat(context);
            ArrayList<Uri> uris = new ArrayList<>();
            if (logFilePath != null) {
                File file = new File(logFilePath);
                if (file.exists() || file.canRead()) {
                    uris.add(FileProvider.getUriForFile(context, BuildConfig.APPLICATION_ID + ".provider", file));
                }
            }
            emailIntent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
            return uris.isEmpty() ? null : emailIntent;
        }

        @Override
        protected void onPostExecute(Intent result) {
            context.startActivity(Intent.createChooser(result, "Email Log"));
        }

        @TargetApi(Build.VERSION_CODES.HONEYCOMB)
        public void executeTask() {
            if (Build.VERSION_CODES.HONEYCOMB <= Build.VERSION.SDK_INT) {
                executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
            } else {
                execute();
            }
        }
    }
}
