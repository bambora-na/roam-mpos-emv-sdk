package com.ingenico.mpos.app.sample.dialogs;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.ingenico.mpos.app.sample.FragmentBase;
import com.ingenico.mpos.app.sample.R;
import com.ingenico.mpos.app.sample.TransactionHistoryFilterFragment;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

public class FilterOptionsDialogFragment extends DialogFragment{
    private static final String ARG_FILTER_TYPE = "ARG_FILTER_TYPE";
    private static final String ARG_ITEMS_MAP = "ARG_ITEMS_MAP";

    private @TransactionHistoryFilterFragment.FilterType String filterType;
    LinkedHashMap<String, Boolean> itemsMap;

    private OnFilterOptionsSelectedListener listener;

    public FilterOptionsDialogFragment() {
    }

    public static FilterOptionsDialogFragment getInstance(@TransactionHistoryFilterFragment.FilterType String filterType,
                                                          LinkedHashMap<String, Boolean> itemsMap) {
        FilterOptionsDialogFragment fragment = new FilterOptionsDialogFragment();
        Bundle args = new Bundle();
        args.putString(ARG_FILTER_TYPE, filterType);
        args.putSerializable(ARG_ITEMS_MAP, itemsMap);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            filterType = getArguments().getString(ARG_FILTER_TYPE);
            itemsMap = (LinkedHashMap<String, Boolean>) getArguments().getSerializable(ARG_ITEMS_MAP);
        }
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        String[] inputItems = getInputItems(itemsMap);
        boolean[] checkedItems = getCheckedItems(itemsMap);

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Select " + filterType)
                .setMultiChoiceItems(inputItems, checkedItems, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                        String item = inputItems[which];
                        itemsMap.put(item, isChecked);
                    }
                })
                .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        listener.onFilterOptionsSelected(filterType, itemsMap);
                        dismiss();
                    }
                })
                .setNegativeButton(R.string.str_common_btn_cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dismiss();
                    }
                });
        return builder.create();
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            listener = (OnFilterOptionsSelectedListener) getTargetFragment();
        } catch (ClassCastException e) {
            throw new ClassCastException("Calling fragment must implement OnFilterOptionsSelectedListener");
        }
    }

    private String[] getInputItems(LinkedHashMap<String, Boolean> itemsMap) {
        return itemsMap.keySet().toArray(new String[itemsMap.size()]);
    }

    private boolean[] getCheckedItems(LinkedHashMap<String, Boolean> itemsMap) {
        List<Boolean> checkedList = new ArrayList<>(itemsMap.values());

        boolean[] checkedArr = new boolean[checkedList.size()];
        for (int i = 0; i < checkedList.size(); i++) {
            checkedArr[i] = checkedList.get(i);
        }
        return checkedArr;
    }

    public interface OnFilterOptionsSelectedListener {
        public void onFilterOptionsSelected(@FragmentBase.FilterType String filterType, LinkedHashMap<String, Boolean> optionSelectionMap);
    }
}
