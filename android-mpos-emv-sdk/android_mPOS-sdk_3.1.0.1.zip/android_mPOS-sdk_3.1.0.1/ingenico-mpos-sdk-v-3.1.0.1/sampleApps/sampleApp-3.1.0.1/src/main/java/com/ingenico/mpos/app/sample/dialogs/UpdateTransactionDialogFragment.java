/*
 * © Ingenico Retail Enterprise US Inc., All Rights Reserved.
 */

package com.ingenico.mpos.app.sample.dialogs;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.CheckBox;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

import com.ingenico.mpos.app.sample.R;
import com.ingenico.mpos.app.sample.Utils;
import com.ingenico.mpos.sdk.data.CardholderInfo;

public class UpdateTransactionDialogFragment extends DialogFragment {
    private static final String ARG_DIALOG_IS_SNF = "ARG_DIALOG_IS_SNF";
    private static final String ARG_DIALOG_ORIG_TXN_ID = "ARG_DIALOG_ORIG_TXN_ID";

    private UpdateTransactionDialogFragmentListener mUpdateStoredTransactionFragmentListener;
    private boolean isSnF;
    private String origTxnId;

    public UpdateTransactionDialogFragment() {
        // Required empty public constructor
    }

    public static UpdateTransactionDialogFragment newInstance(boolean isSnF, String origTxnId) {
        UpdateTransactionDialogFragment fragment = new UpdateTransactionDialogFragment();
        Bundle args = new Bundle();
        args.putBoolean(ARG_DIALOG_IS_SNF, isSnF);
        args.putString(ARG_DIALOG_ORIG_TXN_ID, origTxnId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            isSnF = getArguments().getBoolean(ARG_DIALOG_IS_SNF);
            origTxnId = getArguments().getString(ARG_DIALOG_ORIG_TXN_ID);
        }
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_update_transaction, null);
        EditText etOrigtxnId = view.findViewById(R.id.dialog_update_orig_txn_id);
        CheckBox updateSignature = view.findViewById(R.id.dialog_update_signature);

        etOrigtxnId.setText(origTxnId);
        etOrigtxnId.setSelection(etOrigtxnId.getText().length());
        if (!isSnF) {
            updateSignature.setVisibility(View.GONE);
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Update Stored Transaction")
                .setView(view)
                .setPositiveButton(
                        R.string.str_common_btn_ok,
                        (dialog, which) -> {
                            InputMethodManager
                                    inputManager =
                                    (InputMethodManager) getActivity().getSystemService(
                                            Context.INPUT_METHOD_SERVICE
                                    );
                            inputManager.hideSoftInputFromWindow(
                                    view.getWindowToken(),
                                    InputMethodManager.HIDE_NOT_ALWAYS
                            );
                            mUpdateStoredTransactionFragmentListener.updateTransaction(
                                    etOrigtxnId.getText().toString(),
                                    new CardholderInfo(
                                            ((EditText)view.findViewById(R.id.dialog_update_first_name)).getText().toString(),
                                            ((EditText)view.findViewById(R.id.dialog_update_last_name)).getText().toString(),
                                            ((EditText)view.findViewById(R.id.dialog_update_middle_name)).getText().toString(),
                                            ((EditText)view.findViewById(R.id.dialog_update_email)).getText().toString(),
                                            ((EditText)view.findViewById(R.id.dialog_update_phone)).getText().toString(),
                                            ((EditText)view.findViewById(R.id.dialog_update_address1)).getText().toString(),
                                            ((EditText)view.findViewById(R.id.dialog_update_address2)).getText().toString(),
                                            ((EditText)view.findViewById(R.id.dialog_update_city)).getText().toString(),
                                            ((EditText)view.findViewById(R.id.dialog_update_state)).getText().toString(),
                                            ((EditText)view.findViewById(R.id.dialog_update_zip)).getText().toString()
                                    ),
                                    ((EditText)view.findViewById(R.id.dialog_update_transaction_note)).getText().toString(),
                                    ((CheckBox)view.findViewById(R.id.dialog_update_display_notes)).isChecked(),
                                    ((CheckBox)view.findViewById(R.id.dialog_update_complete)).isChecked(),
                                    updateSignature.isChecked() ?
                                            Utils.getBase64EncodedString(BitmapFactory.decodeResource(getResources(), R.drawable.signature))
                                            : null);
                        });
        return builder.create();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            mUpdateStoredTransactionFragmentListener = (UpdateTransactionDialogFragmentListener) getTargetFragment();
        } catch (ClassCastException e) {
            throw new ClassCastException("Calling fragment must implement DisplayTextDialogFragmentListener");
        }
    }

    public interface UpdateTransactionDialogFragmentListener {
        void updateTransaction(
                String txnId,
                CardholderInfo cardholderInfo,
                String transactionNote,
                Boolean displayNotesAndInvoice,
                Boolean isCompleted,
                String signatureImage
        );
    }
}
