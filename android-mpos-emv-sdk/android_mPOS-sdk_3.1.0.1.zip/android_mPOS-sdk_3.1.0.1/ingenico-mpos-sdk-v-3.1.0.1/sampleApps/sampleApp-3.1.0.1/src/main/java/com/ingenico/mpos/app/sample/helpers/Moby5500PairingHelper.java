package com.ingenico.mpos.app.sample.helpers;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;

import com.ingenico.mpos.app.sample.R;
import com.ingenico.mpos.app.sample.common.logger.Log;
import com.ingenico.mpos.sdk.Ingenico;
import com.ingenico.mpos.sdk.views.LedPairingView;
import com.roam.roamreaderunifiedapi.callback.LedPairingCallback;
import com.roam.roamreaderunifiedapi.callback.LedPairingConfirmationCallback;
import com.roam.roamreaderunifiedapi.data.LedSequence;

import java.util.List;

public class Moby5500PairingHelper {
    private static final String TAG = Moby5500PairingHelper.class.getSimpleName();
    private static AlertDialog dialog;

    public static void connect(Context context, UiCallback uiCallback) {
        uiCallback.onProgresssUpdate("Attempting to connect..");
        // Step 1: Initialize device
        Ingenico.getInstance().device().initialize(context, new LedPairingCallback() {
            @Override
            public void confirmLedSequence(List<LedSequence> sequenceList, LedPairingConfirmationCallback ledPairingConfirmationCallback) {
                Log.v(TAG, "LedPairingCallback::confirmLedSequence");
                uiCallback.onStatusUpdate(false, "Confirm Led Sequence");
                // Step 2: Show LED pairing dialog
                dialog = showPairingDialog(context, sequenceList, ledPairingConfirmationCallback);
            }

            @Override
            public void notSupported() {
                Log.v(TAG, "LedPairingCallback::notSupported");
                uiCallback.onStatusUpdate(false, "Pairing not supported by this device manager.");
            }

            @Override
            public void success() {
                Log.v(TAG, "LedPairingCallback::success");
                uiCallback.onStatusUpdate(true, "Pairing Successful");
            }

            @Override
            public void fail() {
                Log.v(TAG, "LedPairingCallback::fail");
                uiCallback.onStatusUpdate(false, "Pairing failed.");
                dialog.dismiss();
            }

            @Override
            public void canceled() {
                Log.v(TAG, "LedPairingCallback::canceled");
                uiCallback.onStatusUpdate(false, "Pairing cancelled");
            }
        });
    }

    private static AlertDialog showPairingDialog(Context context,
                                                    List<LedSequence> sequenceList,
                                                    final LedPairingConfirmationCallback ledPairingConfirmationCallback) {
        AlertDialog.Builder builder;
        builder = new AlertDialog.Builder(context);
        builder.setTitle("Confirm Led Sequence");
        View dialogView;
        dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_pairing_led, null);
        LedPairingView ledPairingView = dialogView.findViewById(R.id.pairingLedView);
        builder.setView(dialogView);
        builder.setCancelable(false);
        builder.setNeutralButton("Restart",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                ledPairingConfirmationCallback.restartLedPairingSequence();
                            }
                        }).start();
                    }
                });
        builder.setPositiveButton("Confirm",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                ledPairingConfirmationCallback.confirm();
                            }
                        }).start();
                    }
                });
        builder.setNegativeButton("Cancel",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                ledPairingConfirmationCallback.cancel();
                            }
                        }).start();

                    }
                });
        AlertDialog dialog = builder.create();
        dialog.show();
        ledPairingView.show(sequenceList);
        return dialog;
    }
    
    public interface UiCallback {
        void onProgresssUpdate(String message);
        void onStatusUpdate(boolean pairingSuccess, String message);
    }
}
