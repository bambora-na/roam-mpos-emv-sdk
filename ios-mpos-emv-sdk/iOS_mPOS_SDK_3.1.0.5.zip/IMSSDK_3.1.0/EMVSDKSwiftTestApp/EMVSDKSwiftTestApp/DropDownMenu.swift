/*
* //////////////////////////////////////////////////////////////////////////////
* //
* // Copyright © Ingenico Retail Enterprise US Inc., All Rights Reserved.
* //
* //////////////////////////////////////////////////////////////////////////////
*/

import Foundation
import UIKit

protocol DropDownMenuDelegate{
    func delegateMethod(_ sender:DropDownMenu)
}

class DropDownMenu: UIView, UITableViewDelegate, UITableViewDataSource{
    var animationDirection:NSString?
    var delegate:DropDownMenuDelegate?
    var table:UITableView?
    var list:NSMutableArray?
    var textField:UITextField?
    override init(frame:CGRect){
        super.init(frame:frame)
    }

    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }
    
    func showDropDown(_ textfiled:UITextField,withHeight height:CGFloat,withArray arr:NSArray,along direction:NSString) -> AnyObject{
        self.textField = textfiled
        self.animationDirection = direction
            // Initialization code
            let btn:CGRect = self.textField!.frame
            self.list = NSMutableArray(array: arr)
            if(animationDirection?.isEqual(to: "up") == true){
                self.frame = CGRect(x: btn.origin.x, y: btn.origin.y, width: btn.size.width,height: 0)
                self.layer.shadowOffset = CGSize(width: -5, height: -5)
            }
            else if (animationDirection?.isEqual(to: "down") == true) {
                self.frame = CGRect(x: btn.origin.x, y: btn.origin.y+btn.size.height, width: btn.size.width, height: 0)
                self.layer.shadowOffset = CGSize(width: -5, height: 5)
            }
            self.layer.masksToBounds = false
            self.layer.cornerRadius = 8
            self.layer.shadowRadius = 5
            self.layer.shadowOpacity = 0.5
            self.table = UITableView(frame: CGRect(x: 0, y: 0, width: btn.size.width, height: 0))
            self.table!.delegate = self
            self.table!.dataSource = self
            self.table!.layer.cornerRadius = 5
            self.table!.backgroundColor = UIColor.white
        self.table!.separatorStyle = UITableViewCell.SeparatorStyle.singleLine
            self.table!.separatorColor = UIColor.gray
        UIView.beginAnimations(nil, context: nil)
        UIView.setAnimationDuration(0.5)
        if(animationDirection?.isEqual(to: "up") == true){
            self.frame = CGRect(x: btn.origin.x, y: btn.origin.y-height, width: btn.size.width, height: height)
        }
        else if (animationDirection?.isEqual(to: "down") == true) {
            self.frame = CGRect(x: btn.origin.x, y: btn.origin.y+btn.size.height, width: btn.size.width, height: height)
        }
        self.table?.frame = CGRect(x: 0, y: 0, width: btn.size.width, height: height)
        UIView.commitAnimations()
        self.textField?.superview?.addSubview(self)
        self.addSubview(self.table!)
        return self;

    }
    func hideDropDown(_ textfield:UITextField){
        let btn:CGRect = textField!.frame
        UIView.beginAnimations(nil, context: nil)
        UIView.setAnimationDuration(0.5)
        if(animationDirection?.isEqual(to: "up") == true){
           self.frame = CGRect(x: btn.origin.x, y: btn.origin.y, width: btn.size.width,height: 0)
        }
        else if (animationDirection?.isEqual(to: "down") == true) {
           self.frame = CGRect(x: btn.origin.x, y: btn.origin.y+btn.size.height, width: btn.size.width, height: 0)
        }
        self.table?.frame = CGRect(x: 0, y: 0, width: btn.size.width, height: 0)
        UIView.commitAnimations()
    }
    func addItem(_ item:NSString){
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return list!.count
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell:UITableViewCell? = tableView.dequeueReusableCell(withIdentifier: "Cell")
        if(cell == nil){
            cell = UITableViewCell(style: UITableViewCell.CellStyle.default, reuseIdentifier:"Cell")
            cell!.textLabel?.font = UIFont.systemFont(ofSize: 15)
        }
        if let text :String = self.list?.object(at: indexPath.row) as? String{
            cell!.textLabel?.text = text
            cell!.textLabel?.textColor = UIColor.black
            let v:UIView = UIView()
            v.backgroundColor = UIColor.cyan
            cell!.backgroundView? = v
        }
        return cell!;
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.hideDropDown(textField!)
        let cell:UITableViewCell = tableView.cellForRow(at: indexPath)!
        textField?.text = cell.textLabel?.text
        self.myDelegate()
    }
    func myDelegate(){
       self.delegate?.delegateMethod(self)
    }
}
