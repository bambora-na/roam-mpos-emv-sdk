//
//  IMSNavigationViewController.swift
//  EMVSDKSwiftTestApp
//
//  Created by Abhiram Dinesh on 12/8/17.
//  Copyright © 2017 Ingenico. All rights reserved.
//

import UIKit

class IMSNavigationViewController: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationBar.topItem?.title = "Secured Card Entry"
        self.navigationBar.topItem?.leftBarButtonItem = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancel))
    }
    
    @objc func cancel() {
        self.dismiss(animated: true, completion: nil)
    }
    
    

}
