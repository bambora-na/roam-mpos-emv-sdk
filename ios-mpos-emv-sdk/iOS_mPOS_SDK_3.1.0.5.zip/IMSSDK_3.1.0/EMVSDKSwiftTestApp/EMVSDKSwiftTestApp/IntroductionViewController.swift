//
//  IntroductionViewController.swift
//  EMVSDKSwiftTestApp
//
//  Created by Mallikarjun Patil on 11/30/16.
//  Copyright © 2016 Ingenico. All rights reserved.
//

import UIKit

class IntroductionViewController: UIViewController {

    @IBOutlet weak var descriptionTextView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    override func viewWillAppear(_ animated: Bool) {
        
        descriptionTextView.text = loadDescriptionString()
        super.viewWillAppear(animated)
    }
    
    @IBAction func dismissButtonPresseda(_ sender: Any) {
        self.presentingViewController?.dismiss(animated: true, completion: nil)
    }
    
    override func viewWillLayoutSubviews() {
        descriptionTextView.setContentOffset(.zero, animated: true)
    }
    
    func loadDescriptionString() -> String {
        let descriptionString : NSMutableString = NSMutableString()
        descriptionString.append("This app supports following card readers\n")
        let bulletPoint: String = "\u{2022}"
        descriptionString.append("\(bulletPoint) RP450c\n")
        descriptionString.append("\(bulletPoint) RP750\n")
        descriptionString.append("\(bulletPoint) MOBY3000\n")
        descriptionString.append("\(bulletPoint) MOBY8500\n")
        descriptionString.append("\(bulletPoint) RP45BT\n\n")
        
        descriptionString.append("This app demonstrates the following APIs:\n\n")
        descriptionString.append("Payment APIs\n")
        descriptionString.append("\(bulletPoint) Login API\n")
        descriptionString.append("\(bulletPoint) Cash Sale \n")
        descriptionString.append("\(bulletPoint) Cash Refund \n")
        descriptionString.append("\(bulletPoint) Keyed Auth\n")
        descriptionString.append("\(bulletPoint) Keyed Sale\n")
        descriptionString.append("\(bulletPoint) Auth Trnasaction\n")
        descriptionString.append("\(bulletPoint) Auth Complete\n")
        descriptionString.append("\(bulletPoint) Void\n")
        descriptionString.append("\(bulletPoint) Credit Sale\n")
        descriptionString.append("\(bulletPoint) Credit Refund\n")
        descriptionString.append("\(bulletPoint) Debit Sale\n")
        descriptionString.append("\(bulletPoint) Debit Refund\n")
        descriptionString.append("\(bulletPoint) Get Pending Signature\n\n")
        
        descriptionString.append("Merchant APIs\n")
        descriptionString.append("\(bulletPoint) Send Email Receipt\n")
        descriptionString.append("\(bulletPoint) Set User Email\n")
        descriptionString.append("\(bulletPoint) Get Security Questions\n")
        descriptionString.append("\(bulletPoint) Set Security Questions\n")
        descriptionString.append("\(bulletPoint) Get Receipt Information\n")
        descriptionString.append("\(bulletPoint) Set Receipt Information\n")
        descriptionString.append("\(bulletPoint) Change Password\n")
        descriptionString.append("\(bulletPoint) Forgot Password\n")
        descriptionString.append("\(bulletPoint) Refresh User Session\n")
        descriptionString.append("\(bulletPoint) Update Transaction\n")
        descriptionString.append("\(bulletPoint) Upload Signature\n")
        descriptionString.append("\(bulletPoint) Filter Transaction History\n")
        descriptionString.append("\(bulletPoint) Get Invoice History\n")
        descriptionString.append("\(bulletPoint) Get Transaction Details\n")
        descriptionString.append("\(bulletPoint) Get Transaction History\n\n")
        
        descriptionString.append("Payment Device APIs\n")
        descriptionString.append("\(bulletPoint) Device Setup\n")
        descriptionString.append("\(bulletPoint) Get Battery Level\n")
        descriptionString.append("\(bulletPoint) Get Allowed POS Entry Mode\n\n")

        return descriptionString as String
    
    }
    
}
