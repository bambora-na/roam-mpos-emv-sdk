//
//  PaymentDeviceViewController.swift
//  EMVSDKSwiftTestApp
//
//  Created by Mallikarjun Patil on 9/12/16.
//  Copyright © 2016 Ingenico. All rights reserved.
//

import UIKit
class PaymentDeviceViewController: IMSBaseViewController, UITableViewDelegate, UITableViewDataSource {
    

    private var ingenico:Ingenico?
    @IBOutlet weak var deviceAPIsTableView: UITableView!
    var staticDataArray = [[String: [String]]] ()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ingenico = Ingenico.sharedInstance()
        deviceAPIsTableView.dataSource = self
        deviceAPIsTableView.delegate = self
        deviceAPIsTableView.tableFooterView = UIView()
        let firmwareAPIs:[String: [String]] = ["Firmware update API": ["* Check firmware update",
                                                                       "* Firmware update",
                                                                       "* Firmware Info"]]
        staticDataArray.append(firmwareAPIs)
        let setupAPIs:[String: [String]] = ["Setup API": ["* Check device setup",
                                                          "* Device setup"]]
        staticDataArray.append(setupAPIs)
        let otherAPIs:[String: [String]] = ["Other API": ["* Get battery level",
                                                          "* Get allowed pos entry mode",
                                                          "* Get communication type",
                                                          "* Configure beeps",
                                                          "* Read magnetic card data",
                                                          "* Configure idle shutdown timeout",
                                                          "* Get Device Serial Number",
                                                          "* Display Text",
                                                          "* Show Home Screen",
                                                          "* Configure Application Selection",
                                                          "* Retrieve tip amount",
                                                          "* Reset device",
                                                          "* Read magnetic card data with amount",
                                                          "* Get battery level with charging status",
                                                          "* Menu selection",
                                                          "* Enable device logging",
                                                          "* Disable device logging",
                                                          "* Retrieve log",
                                                          "* Select E2E Key",
                                                          "* Get card details",
                                                          "* Set VAS Merchant",
                                                          "* Update Working Key",
                                                          "* Set Brightness Level"
        ]]
        staticDataArray.append(otherAPIs)
        
        deviceStatusBarButton = UIBarButtonItem.init(customView: getDeviceStatusImage())
        tabBarController?.navigationItem.hidesBackButton = true
        tabBarController?.navigationItem.leftBarButtonItem = nil
        tabBarController?.navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Show Log", style: UIBarButtonItem.Style.plain, target: self, action: #selector(showLog))
        tabBarController?.navigationItem.rightBarButtonItems = nil
        tabBarController?.navigationItem.rightBarButtonItems = [UIBarButtonItem(title: "Logout", style: UIBarButtonItem.Style.plain, target: self, action:#selector(doLogoff)),
                                                                deviceStatusBarButton!]
    }

    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if isLogViewDisplayed == true {
            self.tabBarController?.navigationItem.leftBarButtonItem = nil
            self.tabBarController?.navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Hide Log", style: UIBarButtonItem.Style.plain, target: self, action: #selector(showLog))
            self.tabBarController?.navigationItem.rightBarButtonItems = nil
            self.tabBarController?.navigationItem.rightBarButtonItems = [UIBarButtonItem(title: "Clear Log", style: UIBarButtonItem.Style.plain, target: self, action:#selector(doLogoff)),
                                                                         deviceStatusBarButton!]
            
        }else {
            self.tabBarController?.navigationItem.leftBarButtonItem = nil
            self.tabBarController?.navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Show Log", style: UIBarButtonItem.Style.plain, target: self, action: #selector(showLog))
            self.tabBarController?.navigationItem.rightBarButtonItems = nil
            self.tabBarController?.navigationItem.rightBarButtonItems = [UIBarButtonItem(title: "Logout", style: UIBarButtonItem.Style.plain, target: self, action:#selector(doLogoff)),
                                                                         deviceStatusBarButton!]
        }
    }
    
    func checkPaymentDeviceSetup() {
        if !getIsDeviceConnected() {
            showDeviceNotConnectedErrorMessage()
        }else {
            self.showProgressMessage("Checking for device setup...")
            Ingenico.sharedInstance()?.paymentDevice.checkSetup({ (error, required) in
                if error != nil {
                    self.consoleLog("Check device setup failed: \((error! as NSError).code)")
                    self.showError("Check device setup failed")
                }
                else {
                    if (required) {
                        self.consoleLog( "Device setup required")
                        self.showSucess( "Device setup required")
                    }
                    else {
                        self.consoleLog( "Device setup not required")
                        self.showSucess( "Device setup not required")
                    }
                }
            })
        }
    }
    
    func checkDeviceFirmwareUpdate() {
        if !getIsDeviceConnected() {
            showDeviceNotConnectedErrorMessage()
        }else {
            self.showProgressMessage("Checking for firmware update...")
            Ingenico.sharedInstance()?.paymentDevice.checkFirmwareUpdate({ (error, updateAction, firmwareInfo) in
                if  error != nil {
                    self.showError("Check firmware update failed")
                    self.consoleLog("Check firmware update failed: \((error! as NSError).code)")
                }
                else {
                    switch updateAction {
                    case .FirmwareUpdateActionUnknown:
                        self.showError("Check firmware update failed")
                        self.consoleLog("Check firmware update failed")
                    case .FirmwareUpdateActionRequired:
                        self.showSucess( "Firmware update required")
                        self.consoleLog( "Firmware update required")
                    case .FirmwareUpdateActionOptional:
                        self.showSucess( "Firmware update optional")
                        self.consoleLog( "Firmware update optional")
                    case .FirmwareUpdateActionNo:
                        self.showSucess( "Firmware update not required")
                        self.consoleLog( "Firmware update not required")
                    default:
                        break
                    }
                }
            })
        }
    }
    
    func getFirmwareInfo() {
        self.showProgressMessage("getFirmwarePackageInfo...")
        Ingenico.sharedInstance()?.paymentDevice.getFirmwarePackageInfo({ (error, firmwarePackageInfo) in
            if (error == nil) {
                self.showSucess( "getFirmwarePackageInfo success")
                self.consoleLog("getFirmwarePackageInfo:\(firmwarePackageInfo!.description)")
            }
            else {
                self.showError("getFirmwarePackageInfo failed")
                self.consoleLog("getFirmwarePackageInfo failed with error: \((error! as NSError).code)")
            }
        })
    }
    
    
    func setupPaymentDevice() {
        if !getIsDeviceConnected() {
            showDeviceNotConnectedErrorMessage()
        }else {
            self.showProgressMessage("Setting up device...")
            Ingenico.sharedInstance()?.paymentDevice.setup(progressHandler: { (current, total) in
                self.showProgressPercent(Float(current)/Float(total), message: "Setting up device...")
            }, andOnDone: { (error) in
                if error == nil {
                    self.showSucess( "Device setup succeeded")
                }
                else {
                    self.showError("Device setup failed")
                }
            })
        }
    }
    
    func getBatteryLevel() {
        if !getIsDeviceConnected(){
            showDeviceNotConnectedErrorMessage()
        }else {
            self.showProgressMessage("Getting Battery Level")
            ingenico?.paymentDevice.getBatteryLevel({ (batteryLevel, error) in
                if error == nil{
                    self.showSucess( "Get Battery Level: \(batteryLevel)")
                    self.consoleLog("Get Battery Level: \(batteryLevel)")
                }else {
                    self.showError("Get Battery Level Failed")
                    self.consoleLog("Get Battery Level Failed")
                }
            })
        }
    }
    
    func getAllowedPosEntryModes() {
        if !getIsDeviceConnected() {
            showDeviceNotConnectedErrorMessage()
        }else {
            let posList:[NSNumber] = ingenico?.paymentDevice.allowedPOSEntryModes() as! [NSNumber]
            self.showSucess( "Get allowed POS Entry Modes Succeeded")
            consoleLog("Allowed POS Entry Modes: \n \(self.getPosEntryModeString(entryModes: posList)) \n")
        }
    }
    
    func getActiveComminicationType() {
        let interface = Ingenico.sharedInstance()?.paymentDevice.getActiveCommunicationType()
        let str = getStringFromCommunication(interface!)
        self.showSucess("\(str)")
        consoleLog("CommunicationType:\(str)")
    }
    
    func configureBeep() {
        let alert = UIAlertController(title: "Configure beep", message: "beep options", preferredStyle: .alert)
        var removalBeepCheckbox : UIButton?
        var presentmentBeepCheckbox : UIButton?
        alert.addCheckBoxWithTitle("card removal beep") { (checkbox) in
            removalBeepCheckbox = checkbox
            removalBeepCheckbox?.isSelected = true
        }
        alert.addCheckBoxWithTitle("card presentment beep") { (checkbox) in
            presentmentBeepCheckbox = checkbox
            presentmentBeepCheckbox?.isSelected = true
        }
        let okAction = UIAlertAction(title: "OK", style: .default) { (action) in
            Ingenico.sharedInstance()?.paymentDevice.configureCardRemovalBeep(!removalBeepCheckbox!.isSelected, andCardPresentmentBeep: !presentmentBeepCheckbox!.isSelected, andOnDone: { (error) in
                if error == nil{
                    self.showSucess( "configureBeep success")
                    self.consoleLog("configureBeep success")
                }else {
                    self.showError("configureBeep failed")
                    self.consoleLog("configureBeep failed with error: \((error! as NSError).code)")
                }
            })
        }
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alert.addAction(okAction)
        alert.addAction(cancel)
        present(alert, animated: false, completion: nil)
    }
    
    func configureShutdownTimeout() {
        let alert = UIAlertController(title: "configureShutdownTimeout", message: "Enter timeout in seconds", preferredStyle: .alert)
        var timeoutTF : UITextField?
        alert.addTextField { (textfield) in
            textfield.placeholder = "180 - 1800"
            textfield.keyboardType = .numberPad
            timeoutTF = textfield
        }
        let okAction = UIAlertAction(title: "OK", style: .default) { (action) in
            Ingenico.sharedInstance()?.paymentDevice.configureIdleShutdownTimeout(Int(timeoutTF!.text ?? "") ?? 0, andOnDone: { (error) in
                if error == nil{
                    self.showSucess( "configureShutdownTimeout success")
                    self.consoleLog("configureShutdownTimeout success")
                }else {
                    self.showError("configureShutdownTimeout failed")
                    self.consoleLog("configureShutdownTimeout failed with error: \((error! as NSError).code)")
                }
            })
        }
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alert.addAction(okAction)
        alert.addAction(cancel)
        present(alert, animated: false, completion: nil)
    }
    
    func readMagneticCardData() {
        self.showProgressMessage("readMagneticCardData...")
        Ingenico.sharedInstance()?.paymentDevice.readMagneticCardData({ (carddata, error) in
            if error == nil{
                self.showSucess( "readMagneticCardData success")
                self.consoleLog("readMagneticCardData success")
                self.consoleLog("magneticCarddata:\(carddata ?? "")")
            }else {
                self.showError("readMagneticCardData failed")
                self.consoleLog("readMagneticCardData failed with error: \((error! as NSError).code)")
            }
        })
    }
    
    func getDeviceSerialnumber() {
        self.showProgressMessage("getDeviceSerialnumber...")
        Ingenico.sharedInstance()?.paymentDevice.getSerialNumber({ (serialNumber, error) in
            if error == nil{
                self.showSucess( "getDeviceSerialnumber success")
                self.consoleLog("getDeviceSerialnumber success")
                self.consoleLog("serial number:\(serialNumber ?? "")")
            }else {
                self.showError("getDeviceSerialnumber failed")
                self.consoleLog("getDeviceSerialnumber failed with error: \((error! as NSError).code)")
            }
        })
    }
    
    func displayText() {
        let alert = UIAlertController(title: "displayText", message: "Enter the following:", preferredStyle: .alert)
        var textTF : UITextField?
        var rowTF : UITextField?
        var columnTF : UITextField?
        alert.addTextField { (textfield) in
            textfield.placeholder = "Display text"
            textfield.keyboardType = .default
            textTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.placeholder = "row (1-4)"
            textfield.keyboardType = .numberPad
            rowTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.placeholder = "column (1 - 21)"
            textfield.keyboardType = .numberPad
            columnTF = textfield
        }
        let okAction = UIAlertAction(title: "OK", style: .default) { (action) in
            Ingenico.sharedInstance()?.paymentDevice.displayText(textTF?.text ?? "", atRow: Int(rowTF?.text ?? "") ?? 0, andColumn: Int(columnTF?.text ?? "") ?? 0, andOnDone: { (error) in
                if error == nil{
                    self.showSucess( "displayText success")
                    self.consoleLog("displayText success")
                }else {
                    self.showError("displayText failed")
                    self.consoleLog("displayText failed with error: \((error! as NSError).code)")
                }
            })
        }
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alert.addAction(okAction)
        alert.addAction(cancel)
        present(alert, animated: false, completion: nil)
    }
    
    func showHomeScreen() {
        self.showProgressMessage("showHomeScreen...")
        Ingenico.sharedInstance()?.paymentDevice.showHomeScreen({ (error) in
            if error == nil{
                self.showSucess( "showHomeScreen success")
                self.consoleLog("showHomeScreen success")
            }else {
                self.showError("showHomeScreen failed")
                self.consoleLog("showHomeScreen failed with error: \((error! as NSError).code)")
            }
        })
    }
    
    func configureApplicationSelection() {
        let alert = UIAlertController(title: "configureApplicationSelection", message: "Select option", preferredStyle: .alert)
        let deviceAction = UIAlertAction(title: "ecternal device", style: .default) { (action) in
            self.configureApplicationSection(.ApplicationSelectionOptionExternalDevice)
        }
        let pinpadAction = UIAlertAction(title: "pinpad", style: .default) { (action) in
            self.configureApplicationSection(.ApplicationSelectionOptionPinPad)
        }
        let cancelAction = UIAlertAction(title: "cancel", style: .cancel, handler: nil)
        alert.addAction(deviceAction)
        alert.addAction(pinpadAction)
        alert.addAction(cancelAction)
        present(alert, animated: false, completion: nil)
    }
    
    func configureApplicationSection(_ option: IMSApplicationSelectionOption) {
        Ingenico.sharedInstance()?.paymentDevice.configureApplicationSelection(option, andOnDone: { (error) in
            if error == nil{
                self.showSucess( "configureApplicationSection success")
                self.consoleLog("configureApplicationSection success")
            }else {
                self.showError("configureApplicationSection failed")
                self.consoleLog("configureApplicationSection failed with error: \((error! as NSError).code)")
            }
        })
    }
    
    func retrieveTipAmount() {
        self.showProgressMessage("retrieveTipAmount...")
        Ingenico.sharedInstance()?.paymentDevice.retrieveTipAmount({ (error, tip) in
            if error == nil{
                self.showSucess( "retrieveTipAmount success")
                self.consoleLog("retrieveTipAmount success \n tip: \(tip)")
            }else {
                self.showError("retrieveTipAmount failed")
                self.consoleLog("retrieveTipAmount failed with error: \((error! as NSError).code)")
            }
        })
    }
    
    func resetDevice() {
        self.showProgressMessage("resetDevice...")
        Ingenico.sharedInstance()?.paymentDevice.resetDevice({ (error) in
            if error == nil{
                self.showSucess( "resetDevice success")
                self.consoleLog("resetDevice success")
            }else {
                self.showError("resetDevice failed")
                self.consoleLog("resetDevice failed with error: \((error! as NSError).code)")
            }
        })
    }
    
    func readMagneticCardDataWithAmount() {
        let alert = UIAlertController(title: "readMagneticCardDataWithAmount", message: "Enter the following:", preferredStyle: .alert)
        var totalTF : UITextField?
        var subtotalTF : UITextField?
        var tipTF : UITextField?
        var discountTF : UITextField?
        var taxTF : UITextField?
        var surchargeTF : UITextField?
        var currencyTF : UITextField?
        alert.addTextField{ (textfield) in
            textfield.keyboardType = .default
            textfield.placeholder = "Currency"
            textfield.text = "USD"
            currencyTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.keyboardType = .numberPad
            textfield.placeholder = "Total amount"
            totalTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.keyboardType = .numberPad
            textfield.placeholder = "Normalized Subtotal"
            subtotalTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.keyboardType = .numberPad
            textfield.placeholder = "Normalized Discount(optional)"
            discountTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.keyboardType = .numberPad
            textfield.placeholder = "Normalized Tax(optional)"
            taxTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.keyboardType = .numberPad
            textfield.placeholder = "Normalized Tip(optional)"
            tipTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.keyboardType = .numberPad
            textfield.placeholder = "Normalized Surcharge(optional)"
            surchargeTF = textfield
        }
        let okAction = UIAlertAction(title: "OK", style: .default) { (action) in
            self.showProgressMessage("readMagneticCardDataWithAmount...")
            let amount = IMSAmount(total: Int(totalTF?.text ?? "") ?? 0, andSubtotal: Int(subtotalTF?.text ?? "") ?? 0, andTax: Int(taxTF?.text ?? "") ?? 0, andDiscount: Int(discountTF?.text ?? "") ?? 0, andDiscountDescription: "ROAMDiscount", andTip: Int(tipTF?.text ?? "") ?? 0, andCurrency: currencyTF?.text ?? "USD", andSurcharge: Int(surchargeTF?.text ?? "") ?? 0)!
            Ingenico.sharedInstance()?.paymentDevice.readMagneticCardData(withAmountDisplay: amount, andOnDone: { (carddata, error) in
                if error == nil{
                    self.showSucess( "readMagneticCardData success")
                    self.consoleLog("readMagneticCardData success")
                    self.consoleLog("magneticCarddata:\(carddata ?? ""))")
                }else {
                    self.showError("readMagneticCardData failed")
                    self.consoleLog("readMagneticCardData failed with error: \((error! as NSError).code)")
                }
            })
        }
        alert.addAction(okAction)
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alert.addAction(cancelAction)
        present(alert, animated: false, completion: nil)
    }
    
    func getBatteryLevelWithChargingStatus() {
        Ingenico.sharedInstance()?.paymentDevice.getBatteryLevel(chargingStatus: { (batteryLevel, isCharging, error) in
            if error == nil{
                self.showSucess( "getBatteryLevelWithChargingStatus success: \(batteryLevel)")
                self.consoleLog("getBatteryLevelWithChargingStatus success")
                self.consoleLog("batteryLevel:\(batteryLevel))")
                self.consoleLog("isCharging:\(isCharging ? "true" : "false"))")
            }else {
                self.showError("getBatteryLevelWithChargingStatus failed")
                self.consoleLog("getBatteryLevelWithChargingStatus failed with error: \((error! as NSError).code)")
            }
        })
    }
    
    func customMenuSelection() {
        var menuOptions:[String] = []
        let alert = UIAlertController(title: "Custom menu selection", message: "", preferredStyle: .alert)
        var menuOptionTF : UITextField?
        alert.addTextField { (textfield) in
            textfield.placeholder = "menu option"
            menuOptionTF = textfield
        }
        let okAction = UIAlertAction(title: "OK", style: .default) { (action) in
            menuOptions.append(menuOptionTF?.text ?? "")
            Ingenico.sharedInstance()?.paymentDevice.showMenuOptions("Test Menu Title", andMenuOptions: menuOptions, andOnDone: { (error, optionSelected) in
                if (error == nil) {
                    self.consoleLog("customMenuSelection success")
                    self.consoleLog("selected option:\(optionSelected)")
                }
                else {
                    self.showError("customMenuSelection failed")
                    self.consoleLog("customMenuSelection failed with error: \((error! as NSError).code)")
                }
            })
        }
        alert.addAction(okAction)
        let addOption = UIAlertAction(title: "Add option", style: .default) { (action) in
            menuOptions.append(menuOptionTF?.text ?? "")
            menuOptionTF?.text = ""
            self.present(alert, animated: true, completion: nil)
        }
        alert.addAction(addOption)
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alert.addAction(cancel)

        present(alert, animated: true, completion: nil)
    }
    
    func enableDeviceLogging() {
        Ingenico.sharedInstance()?.paymentDevice.enableLogging(true, andOnDone: { (error) in
            if error == nil{
                self.showSucess( "enableDeviceLogging success")
                self.consoleLog("enableDeviceLogging success")
            }else {
                self.showError("enableDeviceLogging failed")
                self.consoleLog("enableDeviceLogging failed with error: \((error! as NSError).code)")
            }
        })
    }
    
    func disableDeviceLogging() {
        Ingenico.sharedInstance()?.paymentDevice.enableLogging(false, andOnDone: { (error) in
            if error == nil{
                self.showSucess( "disableDeviceLogging success")
                self.consoleLog("disableDeviceLogging success")
            }else {
                self.showError("disableDeviceLogging failed")
                self.consoleLog("disableDeviceLogging failed with error: \((error! as NSError).code)")
            }
        })
    }
    
    func retrieveLog() {
        Ingenico.sharedInstance()?.paymentDevice.retrieveDeviceLog({ (progress, extraMessage) in
            self.showProgressMessage("Retrieving logs...")
        }, andOnDone: { (error, log) in
            if error == nil{
                self.showSucess( "retrieveLog success")
                self.consoleLog("retrieveLog success:\(log ?? "")")
            }else {
                self.showError("retrieveLog failed")
                self.consoleLog("retrieveLog failed with error: \((error! as NSError).code)")
            }
        })
    }
    
    func selectE2EKey() {
        let alert = UIAlertController(title: "selectE2EKey", message: "Enter key location", preferredStyle: .alert)
        var keyLocTF : UITextField?
        alert.addTextField { (textfield) in
            textfield.placeholder = "1 - 20"
            textfield.keyboardType = .numberPad
            keyLocTF = textfield
        }
        let okAction = UIAlertAction(title: "OK", style: .default) { (action) in
            Ingenico.sharedInstance()?.paymentDevice.selectE2EKey(Int(keyLocTF!.text ?? "") ?? 0, andOnDone: { (error) in
                if error == nil{
                    self.showSucess( "selectE2EKey success")
                    self.consoleLog("selectE2EKey success")
                }else {
                    self.showError("selectE2EKey failed")
                    self.consoleLog("selectE2EKey failed with error: \((error! as NSError).code)")
                }
            })
        }
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alert.addAction(okAction)
        alert.addAction(cancel)
        present(alert, animated: false, completion: nil)
    }
    
    func getCardDetails() {
        self.showProgressMessage("Getting card details...")
        Ingenico.sharedInstance()?.paymentDevice.getCardDetails({ (progress, extraMessage) in
            self.showProgressMessage(self.getProgressStrFromMessage(progress)){
                Ingenico.sharedInstance()?.paymentDevice.abortGetCardDetails()
            }
        },
        andCardDetails: { (error, cardDetails) in
            if (error == nil) {
                self.showSucess( "getCardDetails success")
                self.consoleLog("getCardDetails:\(cardDetails!.description)")
            }
            else {
                self.showError("getCardDetails failed")
                self.consoleLog("getCardDetails failed with error: \((error! as NSError).code)")
            }
        })
    }
    
    func setVasMerchant() {
        self.showProgressMessage("Setting VAS details...")
        Ingenico.sharedInstance()?.paymentDevice.setVasMerchant("pass.com.ingenico.loyaltycard", merchantURL: "https://www.ingenico-labs.com/ws/vas/url_coffeebar.php", andOnDone: { (error) in
            if error == nil{
                self.showSucess( "setVasMerchant success")
                self.consoleLog("setVasMerchant success")
            }else {
                self.showError("setVasMerchant failed")
                self.consoleLog("setVasMerchant failed with error: \((error! as NSError).code)")
            }
        })
    }
    
    func updateWorkingKeys() {
        self.showProgressMessage("Updating working keys...")
        Ingenico.sharedInstance()?.paymentDevice.updateWorkingKeys({ error in
            if (error == nil) {
                self.showSucess( "updateWorkingKeys success")
                self.consoleLog("updateWorkingKeys success")
            }
            else {
                self.showError("updateWorkingKeys failed")
                self.consoleLog("updateWorkingKeys failed with error: \((error! as NSError).code)")
            }
        })
    }
    
    func setBrightnessLevel() {
        let alert = UIAlertController(title: "setBrightnessLevel", message: "Enter a brightness level from 5 - 100", preferredStyle: .alert)
        var brightnessLevelTF : UITextField?
        alert.addTextField { (textfield) in
            textfield.placeholder = "5 - 100"
            textfield.keyboardType = .numberPad
            brightnessLevelTF = textfield
        }
        let okAction = UIAlertAction(title: "OK", style: .default) { (action) in
            Ingenico.sharedInstance()?.paymentDevice.setBrightnessLevel(UInt(brightnessLevelTF!.text ?? "") ?? 0, andOnDone: { (error) in
                if error == nil{
                    self.showSucess( "setBrightnessLevel success")
                    self.consoleLog("setBrightnessLevel success")
                }else {
                    self.showError("setBrightnessLevel failed")
                    self.consoleLog("setBrightnessLevel failed with error: \((error! as NSError).code)")
                }
            })
        }
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alert.addAction(okAction)
        alert.addAction(cancel)
        present(alert, animated: false, completion: nil)
    }
    
    
    func getPosEntryModeString(entryModes:[NSNumber])->String{
        
        if entryModes.count > 0 {
            let result:NSMutableString = NSMutableString()
            for pos in entryModes {
                switch IMSPOSEntryMode(rawValue: UInt(pos.intValue))! {
                case .POSEntryModeKeyed:
                    result.append("Keyed \n")
                case .POSEntryModeContactEMV:
                    result.append("ContactEMV \n")
                case .POSEntryModeContactlessEMV:
                    result.append("Contactless EMV \n")
                case .POSEntryModeContactlessMSR:
                    result.append("Contactless MSR \n")
                case .POSEntryModeMagStripe:
                    result.append("MagStripe \n")
                default:
                    break
                }
            }
            return result as String
        }
        else{
            return "No allowed pos entry mode"
        }
        
    }
    
    
    
    func showDeviceNotConnectedErrorMessage(){
        let controller:UIAlertController = UIAlertController.init(title: "Error", message: "Please connect device first", preferredStyle: .alert)
        let action:UIAlertAction = UIAlertAction.init(title: "OK", style: .default, handler: nil)
        controller.addAction(action)
        self.present(controller, animated: true, completion: nil)
        
    }

    
    //MARK: - UI Tableview delegate
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let sectionTitle = (staticDataArray[section] as NSDictionary).allKeys[0] as! String
        return staticDataArray[section][sectionTitle]!.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.section {
        case 0:
            switch indexPath.row {
            case 0:
                checkDeviceFirmwareUpdate()
            case 1:
                updateFirmware()
            case 2:
                getFirmwareInfo()
            default:
                break
            }
        case 1:
            switch indexPath.row {
            case 0:
                checkPaymentDeviceSetup()
            case 1:
                setupPaymentDevice()
            default:
                break
            }
        case 2:
            switch indexPath.row {
            case 0:
                getBatteryLevel()
            case 1:
                getAllowedPosEntryModes()
            case 2:
                getActiveComminicationType()
            case 3:
                configureBeep()
            case 4:
                readMagneticCardData()
            case 5:
                configureShutdownTimeout()
            case 6:
                getDeviceSerialnumber()
            case 7:
                displayText()
            case 8:
                showHomeScreen()
            case 9:
                configureApplicationSelection()
            case 10:
                retrieveTipAmount()
            case 11:
                resetDevice()
            case 12:
                readMagneticCardDataWithAmount()
            case 13:
                getBatteryLevelWithChargingStatus()
            case 14:
                customMenuSelection()
            case 15:
                enableDeviceLogging()
            case 16:
                disableDeviceLogging()
            case 17:
                retrieveLog()
            case 18:
                selectE2EKey()
            case 19:
                getCardDetails()
            case 20:
                setVasMerchant()
            case 21:
                updateWorkingKeys()
            case 22:
                setBrightnessLevel()
            default:
                break
            }
        default:
            break
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.deviceAPIsTableView.dequeueReusableCell(withIdentifier: "Cell")! as UITableViewCell
        let sectionTitle = (staticDataArray[indexPath.section] as NSDictionary).allKeys[0] as! String
        cell.textLabel?.text = staticDataArray[indexPath.section][sectionTitle]?[indexPath.row]
        cell.textLabel?.textAlignment = .center
        cell.selectionStyle = .none;
        return cell
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return staticDataArray.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        let sectionTitle = (staticDataArray[section] as NSDictionary).allKeys[0] as! String
        return sectionTitle
    }
    
    
    
    
    
}
