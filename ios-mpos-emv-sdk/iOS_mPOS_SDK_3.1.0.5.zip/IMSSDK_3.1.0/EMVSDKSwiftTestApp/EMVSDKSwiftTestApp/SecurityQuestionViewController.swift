//
//  SecurityQuestionViewController.swift
//  EMVSDKSwiftTestApp
//
//  Created by Abhiram Dinesh on 10/19/21.
//  Copyright © 2021 Ingenico. All rights reserved.
//

import UIKit

class SecurityQuestionViewController: IMSBaseViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate{
    
    @IBOutlet weak var questionPicker1: UIPickerView!
    @IBOutlet weak var questionPicker2: UIPickerView!
    @IBOutlet weak var answerTextField1: UITextField!
    @IBOutlet weak var answerTextField2: UITextField!
    
    var questions:[IMSSecurityQuestion] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        questionPicker1.delegate = self
        questionPicker1.dataSource = self
        questionPicker2.delegate = self
        questionPicker2.dataSource = self
        answerTextField1.delegate = self
        answerTextField2.delegate = self
        
        loadSecurityQuestions()
    }
    
    func loadSecurityQuestions() {
        self.showProgressMessage("Getting Security Questions")
        Ingenico.sharedInstance()?.user.getSecurityQuestions({ [self] qs, error in
            self.dismissProgress()
            if (error != nil) {
                self.showError(String.init(format: "Get Security Questions failed with error code %d", (error as NSError?)!.code))
            }
            else {
                self.questions = qs as! [IMSSecurityQuestion]
                self.questionPicker1.reloadAllComponents()
                self.questionPicker2.reloadAllComponents()
            }
        })
    }

    @IBAction func submitSecurityQuestions(_ sender: Any) {
        self.showProgressMessage("Setting Security Questions")
        let question1 : IMSSecurityQuestion = questions[questionPicker1.selectedRow(inComponent: 0)]
        let question2 : IMSSecurityQuestion = questions[questionPicker2.selectedRow(inComponent: 0)]
        let answer1 = IMSSecurityQuestion(questionID: question1.questionId, andAnswer: answerTextField1.text)!
        let answer2 = IMSSecurityQuestion(questionID: question2.questionId, andAnswer: answerTextField2.text)!
        Ingenico.sharedInstance()?.user.setSecurityQuestions([answer1, answer2], andOnDone: { error in
            if (error != nil) {
                self.showError(String.init(format: "Set Security Questions failed with error code %d", (error as NSError?)!.code))
            }
            else {
                self.showSucess("Set Security Questions Success")
            }
        })
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return questions.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if (!questions.isEmpty) {
            let securityQuestion : IMSSecurityQuestion = questions[row]
            return securityQuestion.question
        }
        return nil
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(false)
        return true
    }
    
}
