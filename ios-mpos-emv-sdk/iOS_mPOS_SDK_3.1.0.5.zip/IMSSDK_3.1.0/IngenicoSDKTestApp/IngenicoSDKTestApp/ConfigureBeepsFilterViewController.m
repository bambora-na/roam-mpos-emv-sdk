//
//  ConfigureBeepsFilterViewController.m
//  IngenicoSDKTestApp
//
//  Created by Bin Lang on 9/25/17.
//  Copyright © 2017 RoamData. All rights reserved.
//

#import "ConfigureBeepsFilterViewController.h"
#import "ConfigureBeepsTableViewCell.h"

@interface ConfigureBeepsFilterViewController (){
    NSArray *dataSource;
}

@end

@implementation ConfigureBeepsFilterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _filterTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    _filterTableView.tableHeaderView = [[UIView alloc] initWithFrame:CGRectZero];

    dataSource = [[NSMutableArray alloc] initWithObjects:
                   @"DisableCardRemovalBeep",
                   @"DisableCardPresentmentBeep",nil];

    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Configure" style:UIBarButtonItemStylePlain target:self action:@selector(configureBeeps)];
    [self.navigationItem.rightBarButtonItem setTitleTextAttributes:@{
                                                                     NSFontAttributeName: [UIFont fontWithName:@"TrebuchetMS-Bold" size:16.0],
                                                                     NSForegroundColorAttributeName: [UIColor darkGrayColor]
                                                                     } forState:UIControlStateNormal];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"Goback"] style:UIBarButtonItemStylePlain target:self action:@selector(goBack)];
    [self.navigationItem.leftBarButtonItem setAccessibilityLabel:@"back_btn"];
    self.navigationItem.leftBarButtonItem.tintColor = [UIColor darkGrayColor];
}

- (void)viewDidLayoutSubviews{
    [super viewDidLayoutSubviews];
    _filterTableView.frame = CGRectMake(0, 0, _filterTableView.frame.size.width, _filterTableView.frame.size.height+[UIApplication sharedApplication].statusBarFrame.size.height+self.navigationController.navigationBar.frame.size.height);
}

#pragma UITableViewDelegate,UITableViewDataSource Implementation

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"configureBeepCell";
    ConfigureBeepsTableViewCell *cell = (ConfigureBeepsTableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[ConfigureBeepsTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    cell.categoryLabel.text = [dataSource objectAtIndex:indexPath.row];
    cell.categoryLabel.textColor = [UIColor darkGrayColor];
    cell.toggle.tag = (indexPath.row+1)*100;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}

#pragma Helper Methods

- (void)goBack{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)configureBeeps{
    [self.view endEditing:YES];
    if(_callback){
        _callback(((UISwitch *)[self.view viewWithTag:100]).on,
                  ((UISwitch *)[self.view viewWithTag:200]).on);
    }
}

@end
