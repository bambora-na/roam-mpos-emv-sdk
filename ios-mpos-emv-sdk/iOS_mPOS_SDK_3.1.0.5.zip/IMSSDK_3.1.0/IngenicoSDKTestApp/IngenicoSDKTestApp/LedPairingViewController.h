//
//  LedPairingViewController.h
//  IngenicoSDKTestApp
//
//  Created by Abhiram Dinesh on 9/16/19.
//  Copyright © 2019 RoamData. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IMSBaseViewController.h"


NS_ASSUME_NONNULL_BEGIN

@interface LedPairingViewController : UIViewController

@property (strong, nonatomic) id<RUALedPairingConfirmationCallback> confirmationCallback;
@property (strong, nonatomic) NSArray * ledSequence;

@end

NS_ASSUME_NONNULL_END
