//
//  LogHelper.h
//  IngenicoSDKTestApp
//
//  Created by Abhiram Dinesh on 3/2/21.
//  Copyright © 2021 RoamData. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LogHelper : NSObject

+ (id)sharedInstance;
-(NSString *) getLogString;
-(void) consoleLog:(NSString *) message;
-(void) clearLog;

@end

NS_ASSUME_NONNULL_END
