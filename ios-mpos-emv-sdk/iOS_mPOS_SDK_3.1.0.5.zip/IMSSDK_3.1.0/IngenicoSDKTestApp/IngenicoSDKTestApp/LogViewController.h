//
//  LogViewController.h
//  IngenicoSDKTestApp
//
//  Created by Abhiram Dinesh on 3/3/21.
//  Copyright © 2021 RoamData. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LogViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
