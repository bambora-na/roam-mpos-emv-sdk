//
//  SetupViewController.h
//  IngenicoSDKTestApp
//
//  Copyright © 2016 RoamData. All rights reserved.
//

#import "IMSBaseViewController.h"
#import <UIKit/UIKit.h>
#import <RUA_MFI/RUA.h>

@interface SetupViewController : IMSBaseViewController<RUADeviceSearchListener,UITableViewDataSource, UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UISwitch *sendDiagnosticSwitch;
@property (weak, nonatomic) IBOutlet UISwitch *ajAutodetectSwitch;
@property (weak, nonatomic) IBOutlet UITextField *baseURLTextField;
@property (strong, nonatomic) IBOutlet UIView *searchView;
@property (weak, nonatomic) IBOutlet UIButton *pairButton;
@property (weak, nonatomic) IBOutlet UIButton *turnOnButton;
@property (weak, nonatomic) IBOutlet UIButton *connectWithPairedButton;
@property (weak, nonatomic) IBOutlet UITableView *searchTableView;
@property (weak, nonatomic) IBOutlet UITextField *apiKeyTextField;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *rp450PairingViewHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *iconPairingViewHeight;

@property (weak, nonatomic) IBOutlet UIStackView *rp450pairingView;
@property (weak, nonatomic) IBOutlet UIStackView *iCONPairingView;
@property (weak, nonatomic) IBOutlet UIPickerView *deviceTypePicker;
@property (weak, nonatomic) IBOutlet UIPickerView *configModePicker;
@property (weak, nonatomic) IBOutlet UIPickerView *retryCountPicker;
@property (weak, nonatomic) IBOutlet UIPickerView *localePicker;
@property (weak, nonatomic) IBOutlet UISwitch *audiojackSwitch;
@property (weak, nonatomic) IBOutlet UISwitch *bluetoothSwitch;
@property (weak, nonatomic) IBOutlet UISwitch *usbSwitch;

- (IBAction)sendDiagnosticsSwitch:(id)sender;
- (IBAction)doPair:(id)sender;
-(void) pairWith450c;

@end
