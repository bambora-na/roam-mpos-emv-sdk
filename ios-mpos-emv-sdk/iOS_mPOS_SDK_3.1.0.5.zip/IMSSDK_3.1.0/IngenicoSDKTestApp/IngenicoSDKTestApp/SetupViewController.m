//
//  SetupViewController.m
//  IngenicoSDKTestApp
//
//  Copyright © 2016 RoamData. All rights reserved.
//

#import "SetupViewController.h"
#import "LoginViewController.h"
#import "SearchTableViewCell.h"
#import <AVFoundation/AVFoundation.h>
#import "Constants.h"
#import <UserNotifications/UserNotifications.h>
#import "DeviceManagementHelper.h"
#import "DropDownMenu.h"

@interface AudioJackPairingConnectionStatusHandlerImpl : NSObject <RUADeviceStatusHandler> {
 __weak  SetupViewController* viewController;
}
@end

@implementation AudioJackPairingConnectionStatusHandlerImpl

-(id) initWithViewController: (SetupViewController*) vc {
    if (self = [super init]) {
        viewController = vc;
    }
    return self;
}

-(void) onConnected {
    [viewController onConnected];
    [viewController pairWith450c];
    NSLog(@"AudioJackPairingConnectionStatusHandlerImpl::onConnected");
}

-(void) onDisconnected {
    [viewController onDisconnected];
    NSLog(@"AudioJackPairingConnectionStatusHandlerImpl::onDisconnected");
}

-(void) onError:(NSString *)message {
    [viewController onError:message];
    NSLog(@"AudioJackPairingConnectionStatusHandlerImpl::OnError : %@", message);
}


@end

@interface SetupViewController ()<UITextFieldDelegate, RUAPairingListener, RUATurnOnDeviceCallback, RUADebugLogListener, UIPickerViewDelegate, UIPickerViewDataSource, UNUserNotificationCenterDelegate, DropDownMenuDelegate>{
    Ingenico *_ingenico;
    NSMutableArray *deviceList;
    NSMutableArray *commInterfaces;
    BOOL isConnected;
    UIRefreshControl *refreshControl;
    RUADevice *pairedRP450;
    DropDownMenu *baseUrlListMenu;
}

@end

@implementation SetupViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _ingenico = [Ingenico sharedInstance];
    deviceList = [[NSMutableArray alloc] init];

    [self setNavigationRightBarItem];

    refreshControl = [[UIRefreshControl alloc] init];
    [refreshControl addTarget:self action:@selector(searchForDevice) forControlEvents:UIControlEventValueChanged];
    [_searchTableView addSubview:refreshControl];
    [_baseURLTextField setIsAccessibilityElement:YES];
    [_baseURLTextField setAccessibilityLabel:@"vc_setup_et_hostname"];
    [_baseURLTextField setDelegate:self];
    [_apiKeyTextField setIsAccessibilityElement:YES];
    [_apiKeyTextField setAccessibilityLabel:@"vc_setup_et_apikey"];
    [_sendDiagnosticSwitch setIsAccessibilityElement:YES];
    [_sendDiagnosticSwitch setAccessibilityLabel:@"vc_setup_switch_send_diagnostics"];
    [_deviceTypePicker setDelegate:self];
    [_deviceTypePicker setDataSource:self];
    [_configModePicker setDelegate:self];
    [_configModePicker setDataSource:self];
    [_retryCountPicker setDelegate:self];
    [_retryCountPicker setDataSource:self];
    [_localePicker setDelegate:self];
    [_localePicker setDataSource:self];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self setConnectingState:YES];

    if([[NSUserDefaults standardUserDefaults] valueForKey:@"DefaultURL"]){
        _baseURLTextField.text = [[NSUserDefaults standardUserDefaults] valueForKey:@"DefaultURL"];
    }
    else {
        _baseURLTextField.text = BASE_URL;
    }
}

- (void)viewWillLayoutSubviews{
    [super viewWillLayoutSubviews];
    CGRect screenFrame = self.view.frame;
    _searchView.frame = CGRectMake(screenFrame.origin.x, [UIApplication sharedApplication].statusBarFrame.size.height+self.navigationController.navigationBar.frame.size.height, screenFrame.size.width, screenFrame.size.height-([UIApplication sharedApplication].statusBarFrame.size.height+self.navigationController.navigationBar.frame.size.height));
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    if([API_KEY isEqualToString:@"Set your API key here"] || API_KEY.length == 0){
        UIAlertController *alertontroller = [UIAlertController
                                             alertControllerWithTitle:@"API key missing"
                                             message:@"If you have an API Key, please set API_KEY in Constants.h. If not, please contact apisupport.us@ingenico.com to obtain a key."
                                             preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *okAction = [UIAlertAction
                                   actionWithTitle:@"OK"
                                   style:UIAlertActionStyleDefault
                                   handler:nil];
        [alertontroller addAction:okAction];
        [self presentViewController:alertontroller animated:YES completion:nil];
    }
    else if ([[NSUserDefaults standardUserDefaults] valueForKey:@"APIKey"]) {
        _apiKeyTextField.text = [[NSUserDefaults standardUserDefaults] valueForKey:@"APIKey"];
    }
    else {
        _apiKeyTextField.text = API_KEY;
    }
}

- (void)setNavigationRightBarItem{
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"Setup" style:UIBarButtonItemStylePlain target:self action:@selector(setupDevice)];
    [self.navigationItem.rightBarButtonItem setIsAccessibilityElement:YES];
    [self.navigationItem.rightBarButtonItem setAccessibilityLabel:@"vc_setup_btn_setup"];
    [self.navigationItem.rightBarButtonItem setTitleTextAttributes:@{
                                                                     NSFontAttributeName: [UIFont fontWithName:@"TrebuchetMS-Bold" size:17.0],
                                                                     NSForegroundColorAttributeName: [UIColor darkGrayColor]
                                                                     } forState:UIControlStateNormal];
}


- (IBAction)sendDiagnosticsSwitch:(id)sender {
    BOOL enable = [(UISwitch *)sender isOn];
    [_ingenico sendDiagnostics:enable];
}

- (void)autodetectAudiojackDevice {
    [_ingenico.PaymentDevice setDeviceTypes:[[NSArray alloc] initWithObjects:
                                             [NSNumber numberWithInt:RUADeviceTypeRP450c],
                                             nil]];
    LoginViewController *loginVC = [self.storyboard instantiateViewControllerWithIdentifier:@"loginVC"];
    [self.navigationController pushViewController:loginVC animated:NO];
    [self setConnectingState:NO];
    [_ingenico.PaymentDevice initialize:self];
}

- (void)doDeviceSearch{
    [UIView transitionWithView:self.view
                      duration:0.3
                       options:UIViewAnimationOptionTransitionFlipFromLeft
                    animations:^{
                        self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"Back" style:UIBarButtonItemStylePlain target:self action:@selector(goBack)];
                        [self.navigationItem.leftBarButtonItem setAccessibilityLabel:@"back_btn"];
                        [self.navigationItem.leftBarButtonItem setTitleTextAttributes:@{
                                                                                        NSFontAttributeName: [UIFont fontWithName:@"TrebuchetMS-Bold" size:17.0],
                                                                                        NSForegroundColorAttributeName: [UIColor darkGrayColor]
                                                                                        } forState:UIControlStateNormal];
                        [_pairButton setTitle:@"Pair" forState:UIControlStateNormal];
                        _rp450PairingViewHeight.constant = 0;
                        _iconPairingViewHeight.constant = 0;
                        [_rp450pairingView setHidden:YES];
                        [_iCONPairingView setHidden:YES];
                        switch ([_deviceTypePicker selectedRowInComponent:0]) {
                            case 0:
                                [_ingenico.PaymentDevice setDeviceType:RUADeviceTypeRP450c];
                                [self setConnectingDeviceType:RUADeviceTypeRP450c];
                                _rp450PairingViewHeight.constant = 136;
                                [_rp450pairingView setHidden:NO];
                                [_connectWithPairedButton setEnabled:NO];
                                [_connectWithPairedButton setAlpha:0.5];
                                break;
                            case 1:
                                [_ingenico.PaymentDevice setDeviceType:RUADeviceTypeRP750x];
                                [self setConnectingDeviceType:RUADeviceTypeRP750x];
                                break;
                            case 2:
                                [_ingenico.PaymentDevice setDeviceType:RUADeviceTypeMOBY3000];
                                [self setConnectingDeviceType:RUADeviceTypeMOBY3000];
                                break;
                            case 3:
                                [_ingenico.PaymentDevice setDeviceType:RUADeviceTypeRP45BT];
                                [self setConnectingDeviceType:RUADeviceTypeRP45BT];
                                break;
                            case 4:
                                [_ingenico.PaymentDevice setDeviceType:RUADeviceTypeMOBY8500];
                                [self setConnectingDeviceType:RUADeviceTypeMOBY8500];
                                _iconPairingViewHeight.constant = 88;
                                [_iCONPairingView setHidden:NO];
                                
                                break;
                            case 5:
                                [_ingenico.PaymentDevice setDeviceType:RUADeviceTypeMOBY5500];
                                [self setConnectingDeviceType:RUADeviceTypeMOBY5500];
                                break;
                            default:
                                break;
                        }
                        commInterfaces = [[NSMutableArray alloc] init];
                        if (_audiojackSwitch.on) {
                            [commInterfaces addObject:[NSNumber numberWithInt:RUACommunicationInterfaceAudioJack]];
                        }
                        if (_usbSwitch.on) {
                            [commInterfaces addObject:[NSNumber numberWithInt:RUACommunicationInterfaceUSB]];
                        }
                        if (_bluetoothSwitch.on) {
                            [commInterfaces addObject:[NSNumber numberWithInt:RUACommunicationInterfaceBluetooth]];
                        }
                        [self searchForDevice];
                        CGRect screenFrame = self.view.frame;
                        _searchView.frame = CGRectMake(screenFrame.origin.x, ([UIApplication sharedApplication].statusBarFrame.size.height+self.parentViewController.navigationController.navigationBar.frame.size.height), screenFrame.size.width, screenFrame.size.height-([UIApplication sharedApplication].statusBarFrame.size.height+self.parentViewController.navigationController.navigationBar.frame.size.height));
                        _searchTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
                        [_searchTableView reloadData];
                        [self.view addSubview:_searchView];
                        self.navigationItem.rightBarButtonItem = nil;
                    }
                    completion:nil];
}

- (void)setupDevice{
    if(self.navigationItem.rightBarButtonItem && [self.navigationItem.rightBarButtonItem.title isEqualToString:@"Setup"]){
        [self saveUrlAndApiKeyToUserDefaults];
        [_ingenico setCustomLogger:self];

        IMSPreferenceBuilder *prefBuilder = [[IMSPreferenceBuilder alloc] init];
        NSInteger selectedIndex = [_configModePicker selectedRowInComponent:0];
        if(selectedIndex == 3){
            [self setConfigModeSet:false];
        [_ingenico initializeWithBaseURL:_baseURLTextField.text
                                  apiKey:_apiKeyTextField.text
                           clientVersion:CLIENT_VERSION
                           timeout:60];
        }else{
            switch (selectedIndex) {
                case 0:
                    [prefBuilder setConfigMode:IMSConfigModeManual];
                    break;
                case 1:
                    [prefBuilder setConfigMode:IMSConfigModeOptimal];
                    break;
                case 2:
                    [prefBuilder setConfigMode:IMSConfigModeAuto];
                    break;
                default:
                    break;
            }
            NSInteger retryCountPickerSelectedIndex = [_retryCountPicker selectedRowInComponent:0];
            [prefBuilder setRetryCount:retryCountPickerSelectedIndex];
            NSInteger selectedLocaleIndex = [_localePicker selectedRowInComponent:0];
            switch (selectedLocaleIndex) {
                case 0:
                    [prefBuilder setMerchantLocale:[[NSLocale alloc]initWithLocaleIdentifier:@"en_US"]];
                    break;
                case 1:
                    [prefBuilder setMerchantLocale:[[NSLocale alloc]initWithLocaleIdentifier:@"en_CA"]];
                    break;
                case 2:
                   [prefBuilder setMerchantLocale:[[NSLocale alloc]initWithLocaleIdentifier:@"fr_CA"]];
                    break;
                default:
                    [prefBuilder setMerchantLocale:[[NSLocale alloc]initWithLocaleIdentifier:@"en_US"]];
                    break;
            }
            [self setConfigModeSet:true];
            [_ingenico initializeWithBaseURL:_baseURLTextField.text
                                  apiKey:_apiKeyTextField.text
                           clientVersion:CLIENT_VERSION
                           timeout:60
                           preference:[prefBuilder build]];
        }
        [_ingenico setLogging:true];
        if (![self isReleasingState]) {
            if (_ajAutodetectSwitch.on) {
                [self autodetectAudiojackDevice ];
            }
            else {
                [self doDeviceSearch];
            }
        }
        else {
            [self showAlertMessage:@"Please wait until the device is released." withTitle:@"Device is releasing"];
        }
        
    }
}

- (void)d:(NSString *)tag :(NSString *)message{
    NSLog(@"debug: %@ %@", tag, message);
}

- (void)e:(NSString *)tag :(NSString *)message{
    NSLog(@"error: %@ %@", tag, message);
}

- (void)i:(NSString *)tag :(NSString *)message{
    NSLog(@"info: %@ %@", tag, message);
}

- (void)goBack{
    [_ingenico.PaymentDevice stopSearch];
    [UIView transitionWithView:self.view
                      duration:0.3
                       options:UIViewAnimationOptionTransitionFlipFromLeft
                    animations:^{
                        [_searchView removeFromSuperview];
                        [deviceList removeAllObjects];
                        [self setNavigationRightBarItem];
                    }
                    completion:nil];
    self.navigationItem.leftBarButtonItem = nil;
}


- (NSString *)getStrFromCommunicationType:(RUACommunicationInterface)type{
    switch (type) {
        case RUACommunicationInterfaceAudioJack:
            return @"CommunicationInterfaceAudioJack";
        case RUACommunicationInterfaceBluetooth:
            return @"CommunicationInterfaceBluetooth";
        case RUACommunicationInterfaceUSB:
            return @"CommunicationInterfaceUSB";
        default:
            return @"CommunicationInterfaceUnknown";
            break;
    }
}

- (void)showAlertMessage:(NSString *)message withTitle:(NSString *)title {
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
                                                        message:message
                                                       delegate:nil
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
    
    [alertView show];
}

- (BOOL)isWiredHeadSetOn {
    AVAudioSessionRouteDescription* route = [[AVAudioSession sharedInstance] currentRoute];
    for (AVAudioSessionPortDescription* desc in [route outputs]) {
        if ([[desc portType] isEqualToString:AVAudioSessionPortHeadphones])
            return YES;
    }
    return NO;
}

- (void) saveUrlAndApiKeyToUserDefaults {
    if(_baseURLTextField.text){
        [[NSUserDefaults standardUserDefaults] setValue:_baseURLTextField.text forKey:@"DefaultURL"];
        NSData *data = [[NSUserDefaults standardUserDefaults] objectForKey:@"urlList"];
        NSError *error;
        NSMutableSet *urls = [NSKeyedUnarchiver unarchivedObjectOfClass:NSMutableSet.class fromData:data error:&error];
        if (error != nil) {
            urls = [[NSMutableSet alloc] init];
        }
        [urls addObject:_baseURLTextField.text];
        data = [NSKeyedArchiver archivedDataWithRootObject:urls];
        [[NSUserDefaults standardUserDefaults] setObject:data forKey:@"urlList"];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    if(_apiKeyTextField.text){
        [[NSUserDefaults standardUserDefaults] setValue:_apiKeyTextField.text forKey:@"APIKey"];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
}

-(void)pairWith450c {
    if (isConnected) {
        [self dismissProgress];
        [_ingenico.PaymentDevice requestPairing:self];
        if(UIApplicationOpenSettingsURLString != nil)
        {
            UIAlertController *alertController = [UIAlertController
                                              alertControllerWithTitle:@""
                                              message:@"Pairing process in progress.\nPlease go to Settings-> Bluetooth app in your iOS device and select the RP450c device to complete the pairing process."
                                              preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *goSettingsAction = [UIAlertAction actionWithTitle:@"Go to Settings" style:UIAlertActionStyleCancel handler:^(UIAlertAction * action) {
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
                [self dismissViewControllerAnimated:YES completion:nil];
            }];
            [alertController addAction:goSettingsAction];
            [self presentViewController:alertController animated:YES completion:nil];
        }
    }
    else {
        [self showAlertMessage:@"Please make sure the card reader is connected first." withTitle:@""];
    }
}

- (IBAction)doPair:(id)sender {
    [refreshControl endRefreshing];
    if([self isWiredHeadSetOn]){
        [self showProgressMessage:@"Pairing with device" andIsTransactionStoppable:NO];
        __weak SetupViewController* weakself = self;
        AudioJackPairingConnectionStatusHandlerImpl* handler = [[AudioJackPairingConnectionStatusHandlerImpl alloc] initWithViewController:weakself];
        [_ingenico.PaymentDevice initialize:handler];
    }
    else {
        [self showAlertMessage:@"Please make sure the card reader is plugged in." withTitle:@""];
    }
}

- (IBAction)turnOnDeviceViaAudioJack:(id)sender {
    if([self isWiredHeadSetOn]) {
        [self showProgressMessage:@"Turning on device" andIsTransactionStoppable:NO];
        [_ingenico.PaymentDevice turnOnDeviceViaAudioJack:self];
    }
    else {
        [self showAlertMessage:@"Please plug in an RP450 into the audio jack" withTitle:@"Device not plugged in"];
    }
}


- (void)searchForDevice{
    [refreshControl beginRefreshing];
    [_ingenico.PaymentDevice searchForCommunicationInterfaces:(NSArray * _Nonnull)commInterfaces andDuration:(long)1000 andListener:self];
}

#pragma RUAStatusHandler implementation

- (void)onConnected{
    [super onConnected];
    [[DeviceManagementHelper sharedInstance] setDelegate:self];
    isConnected = true;
}

- (void)onDisconnected {
    [super onDisconnected];
    [[DeviceManagementHelper sharedInstance] setDelegate:self];
    isConnected = false;
    
}

- (void)onError:(NSString *)message {
    [super onError:message];
    isConnected = false;
}

#pragma RUADelegate implementation

- (void)discoveredDevice:(RUADevice *)reader{
    bool isIncluded = false;
    for(RUADevice *device in deviceList){
        if([device.identifier isEqualToString:reader.identifier]){
            isIncluded = true;
            break;
        }
    }
    if(!isIncluded && reader.name!= NULL){
        [deviceList addObject:reader];
        [_searchTableView reloadData];
    }
    NSLog(@"New device discovered");
}

- (void)discoveryComplete{
    [refreshControl endRefreshing];
    NSLog(@"Discovery Completed");
}

#pragma mark - RUAPairingListener

- (void)onPairConfirmation:(NSString *)readerPasskey mobileKey:(NSString *) mobilePasskey;
{
    [[UNUserNotificationCenter currentNotificationCenter] setDelegate:self];
    UNMutableNotificationContent *notificationContent = [[UNMutableNotificationContent alloc] init];
    [notificationContent setBody:[NSString stringWithFormat:@"Passkey : %@", readerPasskey]];
    [notificationContent setBadge:[NSNumber numberWithInt:1]];
    UNTimeIntervalNotificationTrigger *trigger = [UNTimeIntervalNotificationTrigger triggerWithTimeInterval:1 repeats:NO];
    UNNotificationRequest *request = [UNNotificationRequest requestWithIdentifier:@"PairingPasskey" content:notificationContent trigger:trigger];
    [[UNUserNotificationCenter currentNotificationCenter] addNotificationRequest:request withCompletionHandler:nil];
}

/**
 * Called to indicate that the pairing process has successfully completed.
 */

- (void)onPairSucceeded
{
}

/**
 * Called to indicate that the pairing process with specific device has successfully completed.
 */
- (void)onPairSucceeded:(RUADevice *)device{
    RUADeviceType deviceType = [[[Ingenico sharedInstance] PaymentDevice] getType];
    if (deviceType == RUADeviceTypeMOBY8500) {
        [self showProgressMessage:@"Pairing success" andIsSuccess:YES];
        [_ingenico.PaymentDevice select:device];
        [self proceedToLogin];
    }
    else {
        [_pairButton setTitle:[[NSString alloc] initWithFormat:@"Pairing with %@ succeeded.",device.name] forState:UIControlStateNormal];
        pairedRP450 = device;
        [_connectWithPairedButton setEnabled:YES];
        [_connectWithPairedButton setAlpha:1.0];
    }
}
/**
 * Called to indicate that the device manager does not support audio jack pairing.
 */
- (void) onPairNotSupported
{
    [self showProgressMessage:@"Pairing not supported" andIsSuccess:NO];
    [_pairButton setTitle:@"Pairing not supported." forState:UIControlStateNormal];
}

/**
 * Called to indicate that the pairing process failed.
 */
- (void) onPairFailed
{
    [self showProgressMessage:@"Pairing failed" andIsSuccess:NO];
    [_pairButton setTitle:@"Pairing failed." forState:UIControlStateNormal];
}


#pragma UITextFieldDelegate Implementation
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    if (textField == _baseURLTextField) {
        if (baseUrlListMenu == nil) {
            NSData *data = [[NSUserDefaults standardUserDefaults] objectForKey:@"urlList"];
            NSMutableSet *urls = [NSKeyedUnarchiver unarchivedObjectOfClass:NSMutableSet.class fromData:data error:nil];
            CGFloat height = 40 * urls.count;
            CGFloat maxHeight = 120;
            if (height > maxHeight) {
                height = maxHeight;
            }
            baseUrlListMenu = [[DropDownMenu alloc]showDropDown:textField withHeight:&height withArray:urls.allObjects along:@"down"];
            [baseUrlListMenu setDelegate:self];
        }
        else {
            [baseUrlListMenu hideDropDown:textField];
            baseUrlListMenu = nil;
        }
    }
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self.view endEditing:YES];
    if (textField == _baseURLTextField) {
        if (baseUrlListMenu != nil) {
            [baseUrlListMenu hideDropDown:textField];
            baseUrlListMenu = nil;
        }
    }
    return YES;
}

#pragma TableViewDelegate Implementation
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [deviceList count];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if(deviceList.count >0){
        _searchTableView.backgroundView = [[UIView alloc] init];
        return 1;
    }
    else{
        // Display a message when the table is empty
        UILabel *messageLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, _searchView.bounds.size.width, _searchView.bounds.size.height)];
        messageLabel.text = @"No devices is currently available. Please pull down to refresh.";
        messageLabel.textColor = [UIColor blackColor];
        messageLabel.numberOfLines = 0;
        messageLabel.textAlignment = NSTextAlignmentCenter;
        messageLabel.font = [UIFont fontWithName:@"Palatino-Italic" size:20];
        [messageLabel sizeToFit];
        _searchTableView.backgroundView = messageLabel;
        return 0;
    }
}

- (UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    return [[UIView alloc] init];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 80;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    SearchTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:@"searchTableViewCell"];
    if (cell == nil) {
        cell = (SearchTableViewCell *)[[[NSBundle mainBundle] loadNibNamed:@"SearchTableViewCell" owner:self options:nil] objectAtIndex:0];
    }
    RUADevice *device = [deviceList objectAtIndex:indexPath.row];
    cell.nameLabel.text = [[NSString alloc] initWithFormat:@"Name: %@",device.name];
    cell.identifierLabel.text = [[NSString alloc] initWithFormat:@"ID: %@",device.identifier];
    cell.communicationLabel.text = [self getStrFromCommunicationType:device.communicationInterface];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [_ingenico.PaymentDevice stopSearch];
    RUADevice *selectedDevice = [deviceList objectAtIndex:indexPath.row];
    [_ingenico.PaymentDevice select:selectedDevice];
    [self setConnectingDevice:selectedDevice];
    LoginViewController *loginVC = [self.storyboard instantiateViewControllerWithIdentifier:@"loginVC"];
    [_ingenico.PaymentDevice initialize:self ledPairingListener:loginVC];
    [self setIsInitializationInProgress:YES];
    if (selectedDevice.communicationInterface != RUACommunicationInterfaceUSB) {
        [self proceedToLogin:loginVC];
    }
}
- (IBAction)connectWithPairedRP450:(id)sender {
    if (pairedRP450) {
        [_ingenico.PaymentDevice stopSearch];
        [_ingenico.PaymentDevice select:pairedRP450];
        [self setConnectingDevice:pairedRP450];
        [_ingenico.PaymentDevice initialize:self];
        [self setIsInitializationInProgress:YES];
        [self proceedToLogin];
    }
    else {
        NSLog(@"No paired device found");
        [self showProgressMessage:@"No paired device found" andIsSuccess:NO];
    }
}

- (IBAction)pairIconViaUSB:(id)sender {
    if (isConnected) {
        [self dismissProgress];
        [_ingenico.PaymentDevice requestPairing:self];
    }
    else {
        [self showAlertMessage:@"Please make sure the card reader is connected first." withTitle:@""];
    }
}

- (IBAction)continueWithUSB:(id)sender {
    [self proceedToLogin];
}



- (void) proceedToLogin {
    LoginViewController *loginVC = [self.storyboard instantiateViewControllerWithIdentifier:@"loginVC"];
    [self proceedToLogin:loginVC];
}

- (void) proceedToLogin: (LoginViewController *) loginVC {
    [UIView transitionWithView:self.view
                      duration:0.3
                       options:UIViewAnimationOptionTransitionFlipFromLeft
                    animations:^{
                        [_searchView removeFromSuperview];
                        [deviceList removeAllObjects];
                        [self setNavigationRightBarItem];
                    }
                    completion:nil];
    self.navigationItem.leftBarButtonItem = nil;
    [self saveUrlAndApiKeyToUserDefaults];
    [self.navigationController pushViewController:loginVC animated:NO];
    [self setConnectingState:NO];
}

#pragma RUATurnOnDeviceCallback implementation

-(void) success {
    NSLog(@"Turn on device success");
    [self showProgressMessage:@"Turn on device success" andIsSuccess:YES];
    [self searchForDevice];
}

-(void) notSupported {
    NSLog(@"Turn on device not supported");
    [self showProgressMessage:@"Turn on device not supported" andIsSuccess:NO];
}

-(void) failed:(NSString *)errorMessage {
    NSLog(@"Turn on device failed: %@", errorMessage);
    [self showProgressMessage:@"Turn on device failed" andIsSuccess:NO];
}

#pragma UIPicker implementation

- (NSInteger)numberOfComponentsInPickerView:(nonnull UIPickerView *)pickerView {
    return 1;
}

- (NSInteger)pickerView:(nonnull UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    if(pickerView == _deviceTypePicker){
        return 6;
    }else if(pickerView == _configModePicker){
        return 4;
    }else{
        return 3;
    }
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    if(pickerView == _configModePicker && row == 3){
        _retryCountPicker.userInteractionEnabled = false;
        _retryCountPicker.alpha = 0.5;
        _localePicker.userInteractionEnabled = false;
        _localePicker.alpha = 0.5;
    }else {
        _retryCountPicker.userInteractionEnabled = true;
        _retryCountPicker.alpha = 1;
        _localePicker.userInteractionEnabled = true;
        _localePicker.alpha = 1;
    }
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    if(pickerView == _deviceTypePicker){
    switch (row) {
        case 0:
            return @"RP450c";
        case 1:
            return @"RP750x";
        case 2:
            return @"Moby3000";
        case 3:
            return @"RP45BT";
        case 4:
            return @"Moby8500";
        case 5:
            return @"Moby5500";
        default:
            return @"";
    }
    }else if(pickerView == _configModePicker){
        switch (row) {
            case 0:
                return @"Manual";
            case 1:
                return @"Optimal";
            case 2:
                return @"Auto";
            case 3:
                return @"Not Set";
            default:
                return @"";
        }
    }else if(pickerView == _retryCountPicker){
        switch (row) {
            case 0:
                return @"0";
            case 1:
                return @"1";
            case 2:
                return @"2";
            case 3:
                return @"3";
            default:
                return @"";
        }
    }else {
        switch (row) {
            case 0:
                return @"en_US";
            case 1:
                return @"en_CA";
            case 2:
                return @"fr_CA";
            default:
                return @"";
                
        }
    }
}


#pragma UNUserNotificationCenterDelegate implementation

- (void)userNotificationCenter:(UNUserNotificationCenter *)center willPresentNotification:(UNNotification *)notification withCompletionHandler:(nonnull void (^)(UNNotificationPresentationOptions))completionHandler {
    completionHandler(UNNotificationPresentationOptionBadge | UNNotificationPresentationOptionAlert | UNNotificationPresentationOptionSound);
}

#pragma mark - DropDownMenu Delegate

- (void)delegateMethod:(DropDownMenu *)sender {
    [_baseURLTextField resignFirstResponder];
    baseUrlListMenu = nil;
}

@end


