//
//  TransactionHistoryListViewController.m
//  IngenicoSDKTestApp
//
//  Created by Bin Lang on 8/9/17.
//  Copyright © 2017 RoamData. All rights reserved.
//

#import "TransactionHistoryListViewController.h"
#import "TransactionHistoryListTableViewCell.h"
#import "TransactionDetailViewController.h"
#import "IMSBaseViewController.h"

@interface TransactionHistoryListViewController ()<UITableViewDelegate, UITableViewDataSource>

@end

@implementation TransactionHistoryListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"Goback"] style:UIBarButtonItemStylePlain target:self action:@selector(goBack:)];
    [self.navigationItem.leftBarButtonItem setAccessibilityLabel:@"back_btn"];
    self.navigationItem.leftBarButtonItem.tintColor = [UIColor darkGrayColor];
    _historyTableView.tableHeaderView = [[UIView alloc] initWithFrame:CGRectZero];
    _historyTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
}

- (IBAction)goBack:(id)sender{
    [self.navigationController popViewControllerAnimated:NO];
}

#pragma UITableViewDelegate,UITableViewDataSource Implementation

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    if(_isInvoiceBased){
        IMSInvoiceHistorySummary *invoiceSummary = [_historyList objectAtIndex:section];
        UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.bounds.size.width, 35)];
        UILabel *sectionLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 0, tableView.bounds.size.width-20, 35)];
        sectionLabel.text = [[NSString alloc] initWithFormat:@"InvoiceID: %@",invoiceSummary.invoiceId];
        sectionLabel.font = [UIFont fontWithName:@"Palatino-Italic" size:16];
        [headerView setBackgroundColor:[UIColor lightGrayColor]];
        [headerView addSubview:sectionLabel];
        return headerView;
    }
    else{
        return [[UIView alloc] initWithFrame:CGRectZero];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if(_isInvoiceBased){
        return 30;
    }
    else{
        return 0;
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if(_isInvoiceBased){
        return _historyList.count;
    }
    else{
        return 1;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(_isInvoiceBased){
        IMSInvoiceHistorySummary *invoiceSummary = [_historyList objectAtIndex:section];
        return invoiceSummary.transactions.count;
    }
    else{
        return _historyList.count;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    TransactionHistoryListTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"historyListCell"];
    IMSTransactionHistorySummary *summary;
    if(_isInvoiceBased){
        summary = [((IMSInvoiceHistorySummary*)[_historyList objectAtIndex:indexPath.section]).transactions objectAtIndex:indexPath.row];
    }
    else{
        summary = [_historyList objectAtIndex:indexPath.row];
    }
    cell.transactionIDLabel.text = [[NSString alloc] initWithFormat:@"TransactionID: %@", summary.transactionId];
    cell.approvedAmountLabel.text = [[NSString alloc] initWithFormat:@"%@%.2f", [self getStringFromCurrency:summary.amount.currency], summary.approvedAmount/(double)100];
    cell.clientTransactionIDLabel.text = [[NSString alloc] initWithFormat:@"ClientID: %@", [summary.clientTransactionId substringFromIndex:summary.clientTransactionId.length-6]];
    cell.TransactionTypeLabel.text = [self getStringFromTransactionType:summary.transactionType];
    cell.payementServiceTimeStampLabel.text = summary.paymentServiceTimestamp;
    cell.statusLabel.text = [self getStringFromTransactionStatus:summary.transactionStatus];
    cell.posEntryModeLabel.text = [self getStringFromPOSEntryMode:summary.posEntryMode];
    cell.cardTypeLabel.text = [self getStringFromCardType:summary.cardType];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    IMSTransactionHistorySummary *summary;
    if(_isInvoiceBased){
        summary = [((IMSInvoiceHistorySummary*)[_historyList objectAtIndex:indexPath.section]).transactions objectAtIndex:indexPath.row];
    }
    else{
        summary = [_historyList objectAtIndex:indexPath.row];
    }
    [self showProgressMessage:@"Getting transaction detail" andIsTransactionStoppable:NO];
    [[[Ingenico sharedInstance] User]
     getTransactionDetailsWithTransactionID:summary.transactionId
     andOnDone:^(IMSTransactionHistoryDetail * _Nullable transaction, NSError * _Nullable error) {
         [self dismissProgress];
         if(error != nil){
             [self showProgressMessage:[[NSString alloc]
                                        initWithFormat:@"Get Transaction Details failed with error code : %ld",
                                        (long)error.code] andIsSuccess:false];
         }
         else{
             [self setLastTransactionID:summary.transactionId];
             [self setLastTransactionType:summary.transactionType];
             TransactionDetailViewController *controller = (TransactionDetailViewController *)[self.storyboard instantiateViewControllerWithIdentifier:@"transactionDetailVC"] ;
             controller.transactionDetail = transaction;
             [self.navigationController pushViewController:controller animated:NO];
         }
     }];
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}


@end
