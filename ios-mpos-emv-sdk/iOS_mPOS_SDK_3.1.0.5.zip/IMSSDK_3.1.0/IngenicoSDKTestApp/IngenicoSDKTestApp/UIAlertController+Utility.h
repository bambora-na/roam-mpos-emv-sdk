//
//  UIAlertController+Utility.h
//  IngenicoSDKTestApp
//
//  Created by Abhiram Dinesh on 2/14/18.
//  Copyright © 2018 RoamData. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIAlertController (Utility) <UITextFieldDelegate>

-(void) addCheckBoxWithTitle: (NSString*_Nullable) title andConfigurationHandler:(void (^ __nullable)(UIButton * _Nonnull checkBox))configurationHandler;

@end
