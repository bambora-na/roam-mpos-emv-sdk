//
//  IMSBaseViewController.swift
//  EMVSDKSwiftTestApp
//
//  Created by Mallikarjun Patil on 9/8/16.
//  Copyright © 2016 Ingenico. All rights reserved.
//

import UIKit
import MessageUI
import CoreLocation

class IMSBaseViewController: UIViewController, DeviceStatusAndEMVConfigurationHandler, DeviceManagementDelegate, CLLocationManagerDelegate, MFMailComposeViewControllerDelegate {

    
    
    static var isDeviceConnected :Bool = false
    static var currentVC:IMSBaseViewController!
    static var isLoggedIn:Bool = false
    static var lastTransactionType:IMSTransactionType?
    static var lastTransactionID:String?
    static var lastTokenId:String?
    static var lastClientTransactionId:String?
    static var isConfigModeSet :Bool = false
    
    var versionLabel : UILabel?
    
    static var progressView: MRProgressOverlayView?
    
    var connectingDevice : RUADevice?
    var deviceStatusBarButton:UIBarButtonItem?
    
    var locm:CLLocationManager?
    var location:CLLocation?
    
    @IBOutlet var logView: UIView!
    @IBOutlet weak var logTextView: UITextView!
    var isLogViewDisplayed:Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if CLLocationManager.authorizationStatus() == .denied || CLLocationManager.authorizationStatus() == .restricted {
            return
        }

        if locm == nil {
            locm = CLLocationManager()
            locm?.delegate = self
        }
        locm?.requestWhenInUseAuthorization();
        locm?.startUpdatingLocation()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        IMSBaseViewController.currentVC=self;
        IMSBaseViewController.currentVC.deviceStatusBarButton?.customView = getDeviceStatusImage()
        DeviceManagementHelper.shared.delegate = self
        self.tabBarController?.navigationItem.title = "mPOS EMV SDK"
    }

    func checkFirmwareUpdate(){
        if getIsLoggedIn() && getIsDeviceConnected() {
            Ingenico.sharedInstance()?.paymentDevice.checkFirmwareUpdate({ (error, updateAction, firmwareInfo) in
                self.dismissProgress()
                if (error != nil) {
                    self.showError("Check firmware update failed")
                }
                else if(updateAction == .FirmwareUpdateActionRequired || updateAction == .FirmwareUpdateActionOptional) {
                    
                    let alert = UIAlertController(title: "Firmware Update", message: "Firmware update is \(updateAction == .FirmwareUpdateActionRequired ? "required":"optional")", preferredStyle: .alert)
                    let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: { (action) in
                        if (updateAction == .FirmwareUpdateActionOptional) {
                            self.checkDeviceSetup()
                        }
                    })
                    let update = UIAlertAction(title: "Update", style: .default, handler: { (action) in
                        self.updateFirmware()
                    })
                    alert.addAction(update)
                    alert.addAction(cancel)
                    self.present(alert, animated: true, completion: nil)
                }
                else {
                    self.checkDeviceSetup()
                }
            })
        }
    }
    
    func updateFirmware() {
        self.showProgressMessage("Downloading firmware...")
        Ingenico.sharedInstance()?.paymentDevice.updateFirmware(downloadProgress: { (downloaded, total) in
            self.showProgressPercent(Float(downloaded)/Float(total), message: "Downloading firmware...") {
                Ingenico.sharedInstance()?.paymentDevice.cancelFirmwareUpdate()
            }
        }, andFirmwareUpdateProgress: { (current, total) in
            self.showProgressPercent(Float(current)/Float(total), message: "Updating firmware...") {
                Ingenico.sharedInstance()?.paymentDevice.cancelFirmwareUpdate()
            }
        }, andOnDone: { (error) in
            if error == nil {
                self.showProgressMessage( "Firmware update succeeded")
            }
            else {
                self.showError("Firmware update failed")
            }
        })
    }
    
    func promptForDeviceSetup(_ required:Bool) {
        var alert = UIAlertController(title: "Device Setup", message: "Device setup is required", preferredStyle: .alert)
        if(!required){
            alert = UIAlertController(title: "Device Setup", message: "Device setup is recommended", preferredStyle: .alert)
        }
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler:nil)
        let update = UIAlertAction(title: "Setup", style: .default, handler: { (action) in
            self.showProgressMessage("Setting up device...")
            Ingenico.sharedInstance()?.paymentDevice.setup(progressHandler: { (current, total) in
                let progress = Float(current)/Float(total)
                self.showProgressPercent(progress, message: "Setting up device...")
            }, andOnDone: { (error) in
                self.dismissProgress()
                if error == nil {
                    self.showSucess( "Device setup succeeded")
                }
                else {
                    self.showError("Device setup failed")
                }
            })
        })
        alert.addAction(update)
        alert.addAction(cancel)
        self.present(alert, animated: true, completion: nil)
    }
    
    func checkDeviceSetup() {
        self.dismissProgress()
        Ingenico.sharedInstance()?.paymentDevice.checkSetup({ (error, isSetupRequired) in
            if error != nil {
                self.showError("Check device setup failed")
            }
            else if isSetupRequired {
                self.promptForDeviceSetup(true)
            }else if !isSetupRequired && !(Ingenico.sharedInstance()?.getCurrentCapabilities().isEMVConfigUptoDate ?? true){
                self.promptForDeviceSetup(false)
            }
        })
    }
 
    func setLoggedIn(_ loggedIn:Bool){
        IMSBaseViewController.isLoggedIn=loggedIn
    }
    
    func setDeviceConneced(_ deviceConnected:Bool){
        IMSBaseViewController.isDeviceConnected=deviceConnected
    }
    
    func getIsLoggedIn() -> Bool{
        return IMSBaseViewController.isLoggedIn
    }
    
    func getIsDeviceConnected() -> Bool{
        return IMSBaseViewController.isDeviceConnected
    }
    
    func setIsConfigModeSet(_ configModeSet:Bool){
        IMSBaseViewController.isConfigModeSet=configModeSet
    }
    
    func getIsConfigModeSet() -> Bool{
        return IMSBaseViewController.isConfigModeSet
    }
    
    func getLastTransactionType() -> IMSTransactionType?{
        return IMSBaseViewController.lastTransactionType
    }
    
    func setLastTransactionType(_ type:IMSTransactionType){
        IMSBaseViewController.lastTransactionType = type
    }
    func setLastTransactionID(_ id:String)  {
        IMSBaseViewController.lastTransactionID = id
    }
    func getLastTransactionID() -> String? {
        return IMSBaseViewController.lastTransactionID
    }
    func setLastTokenID(_ id:String)  {
        IMSBaseViewController.lastTokenId = id
    }
    func getLastTokenID() -> String? {
        return IMSBaseViewController.lastTokenId
    }
    func setLastClientTransactionID(_ id:String)  {
        IMSBaseViewController.lastClientTransactionId = id
    }
    func getLastClientTransactionID() -> String? {
        return IMSBaseViewController.lastClientTransactionId
    }
    func getResponseCodeString(_ code:Int) -> String {
        let responseCode:IMSResponseCode = IMSResponseCode(rawValue: UInt(code))!
        switch (responseCode) {
        case .Success:
            return "Success";
        case .PaymentDeviceNotAvailable:
            return "Payment Device Not Available";
        case .PaymentDeviceError:
            return "Payment Device Not Error";
        case .PaymentDeviceTimeout:
            return "Payment Device Timeouts";
        case .NotSupportedByPaymentDevice:
            return "Not Supported by Payment Device";
        case .CardBlocked:
            return "Card Blocked";
        case .ApplicationBlocked:
            return "Application Blocked";
        case .InvalidCard:
            return "Invalid Card";
        case .InvalidApplication:
            return "Invalid Card Application";
        case .TransactionCancelled:
            return "Transaction Cancelled";
        case .CardReaderGeneralError:
            return "Card Reader General Error";
        case .CardInterfaceGeneralError:
            return "Card Not Accepted";
        case .BatteryTooLowError:
            return "Battery Too Low";
        case .BadCardSwipe:
            return "Bad Card Swipe";
        case .TransactionDeclined:
            return "Transaction Declined";
        case .TransactionReversalCardRemovedFailed:
            return "Transaction Reversal Card Removed Failed";
        case .TransactionReversalCardRemovedSuccess:
            return "Transaction Reversal Card Removed Success";
        case .TransactionReversalChipDeclineFailed:
            return "Transaction Reversal Chip Decline  Failed";
        case .TransactionReversalChipDeclineSuccess:
            return "Transaction Reversal Chip Decline Success";
        case .TransactionReversalNetworkTimeoutFailed:
            return "Transaction Reversal Network Timeout Failed";
        case .TransactionReversalNetworkTimeoutSuccess:
            return "Transaction Reversal Network Timeout Success";
        case .UserNameValidationError:
            return "UserName Validation Error";
        case .NetworkError:
            return "Network Error";
        default:
            return String(format: "response Code:\(responseCode.rawValue)")
        }
    }
    
    func getStringFromCommunication(_ type: RUACommunicationInterface) -> String {
        switch type {
        case RUACommunicationInterfaceAudioJack:
            return "CommunicationInterfaceAudioJack"
        case RUACommunicationInterfaceBluetooth:
            return "RUACommunicationInterfaceBluetooth"
        case RUACommunicationInterfaceUSB:
            return "RUACommunicationInterfaceUSB"
        default:
            return "RUACommunicationInterfaceUnknown"
        }
    }
    
    func getValidLocaleForTransactionRequest(_ text: String?) -> Locale? {
        if let text = text{
            if(text == "en_US" || text == "en_CA" || text == "fr_CA"){
                return Locale(identifier: text);
            }
        }
        return nil;
    }
    
    //MARK: - DeviceStatusAndEMVConfigurationHandler Implementation
    func onConnected() {
        self.showSucess( "Device connected")
        NSLog("Devices Connected")
        setDeviceConneced(true)
        IMSBaseViewController.currentVC.deviceStatusBarButton?.customView = getDeviceStatusImage()
        DeviceManagementHelper.shared.stopScan()
        if(!self.getIsConfigModeSet()){
            Ingenico.sharedInstance()?.paymentDevice.getBatteryLevel({ (batteryLevel, error) in
                self.checkFirmwareUpdate()
            })
        }
        if(connectingDevice != nil && connectingDevice?.communicationInterface == RUACommunicationInterfaceBluetooth) {
            DeviceManagementHelper.shared.saveDevice(device: connectingDevice!, ofType: (Ingenico.sharedInstance()?.paymentDevice.getType())!)
        }
        
    }
    
    func onDisconnected() {
        self.showError("Device disconnected")
        setDeviceConneced(false)
        NSLog("Devices Disconnected")
        IMSBaseViewController.currentVC.deviceStatusBarButton?.customView = getDeviceStatusImage()
        connectingDevice = nil
        DeviceManagementHelper.shared.startScan()
    }
    
    func onError(_ message:String) {
        self.showError( "Error:\(message)")
        NSLog("An error occured \(message)")
        IMSBaseViewController.currentVC.deviceStatusBarButton?.customView = getDeviceStatusImage()
        connectingDevice = nil
        DeviceManagementHelper.shared.startScan()
    }
    
    func performSetup(_ handler: UserActionHandler!) {
        dismissProgress()
        let alert:UIAlertController = UIAlertController.init(title: "Perform setup?", message: "", preferredStyle: .actionSheet)
        let yesAction = UIAlertAction(title: "Yes", style: .default, handler: { (action) in
            self.showProgressMessage("Performing set up...")
            alert.dismiss(animated: true, completion: nil)
            handler(true)
        })
        let noAction = UIAlertAction(title: "No", style: .default, handler: { (action) in
            alert.dismiss(animated: true, completion: nil)
            handler(false)
        })
        alert.addAction(yesAction)
        alert.addAction(noAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    func performFirmwareUpdate(_ action: IMSFirmwareUpdateAction, andUserActionHandler handler: UserActionHandler!) {
        dismissProgress()
        let alert:UIAlertController = UIAlertController.init(title: "Perform firmware update?", message: "FW update option is \(self.getStringFromFirmwareUpdateOption(action))", preferredStyle: .actionSheet)
        let yesAction = UIAlertAction(title: "Yes", style: .default, handler: { (action) in
            self.showProgressMessage("Performing firmware update...")
            alert.dismiss(animated: true, completion: nil)
            handler(true)
        })
        let noAction = UIAlertAction(title: "No", style: .default, handler: { (action) in
            alert.dismiss(animated: true, completion: nil)
            handler(false)
        })
        alert.addAction(yesAction)
        alert.addAction(noAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    func onConfigured(_ error: Error!, andCapabilities capabilities: IMSCapabilities!) {
        if let error = error{
            self.showError("Configured: EMV capable: \(capabilities.emvCapable) \nResponse code: \(self.getResponseCodeString((error as NSError).code)) \nFW update action: \(self.getStringFromFirmwareUpdateOption(capabilities.firmwareUpdateAction)) \nstoredTransactionsAmountLimit : \(capabilities.storedTransactionsAmountLimit)");
        }else{
            if(capabilities.emvCapable && !capabilities.isEMVConfigUptoDate){
                self.dismissProgress();
                self.promptForDeviceSetup(false)
            }else{
                self.showSucess("Configured: EMV capable: \(capabilities.emvCapable) \nResponse code: Success \nFW update action: \(self.getStringFromFirmwareUpdateOption(capabilities.firmwareUpdateAction)) \nstoredTransactionsAmountLimit : \(capabilities.storedTransactionsAmountLimit)")
            }
        }
    }
    
    func onProgress(_ message: IMSProgressMessage, andAdditionalMessage additionalMessage: String?) {
        if(message == IMSProgressMessage.CheckingFirmwareUpdate || message == IMSProgressMessage.CheckingDeviceSetup){
            self.showProgressMessage(getProgressStrFromMessage(message))
        }else{
            let current = (additionalMessage?.components(separatedBy: "/")[0] as! NSString).floatValue
            let total = (additionalMessage?.components(separatedBy: "/")[1] as! NSString).floatValue
            if(message == IMSProgressMessage.UpdatingFirmware){
                self.showProgressPercent(current/total, message: getProgressStrFromMessage(message)) {
                    Ingenico.sharedInstance()?.paymentDevice.cancelFirmwareUpdate()
                }
            }else{
                self.showProgressPercent(current/total, message: getProgressStrFromMessage(message))
            }
        }
    }
  
    func keepTheReaderActive(){
        Ingenico.sharedInstance()?.paymentDevice.getBatteryLevel({ (batteryLevel, error) in
            self.dismissProgress()
            if error == nil{
                NSLog("Get Battery Level: %@ \(batteryLevel)")
            }
        })
    }
    
    func getDeviceStatusImage() -> UIImageView{
        let imageName = (getIsDeviceConnected() == true) ? "Bluetooth Connected-30" : "Bluetooth Disconnected-30"
        return UIImageView.init(image: UIImage.init(named: imageName))
        
    }
    
    func connectPairedDevice(device: RUADevice, ofType deviceType: RUADeviceType) {
        if (!getIsDeviceConnected()) {
            Ingenico.sharedInstance()?.paymentDevice.setDeviceType(deviceType)
            Ingenico.sharedInstance()?.paymentDevice.select(device)
            Ingenico.sharedInstance()?.paymentDevice.initialize(self)
            
        }
    }
    
    
    @objc func doLogoff() {
        
        if self.tabBarController?.navigationItem.rightBarButtonItem?.title == "Clear Log"{
            logTextView.text = ""
            (self.tabBarController as! TabBarViewController).logString = ""
        } else {
            self.showProgressMessage("Logging off")
            Ingenico.sharedInstance()?.user.logoff { (error) in
                self.setLoggedIn(false)
                if error == nil {
                    self.showSucess( "Logoff Succeeded")
                } else{
                    self.showError("Logoff Failed")
                }
                _ = self.navigationController?.popViewController(animated: true)
            }
        }
    }
    
    func consoleLog (_ data:String){
        let formatter:DateFormatter = DateFormatter.init()
        formatter.dateFormat = "HH:mm:ss"
        let dateStr:String = formatter.string(from: Date())
        (self.tabBarController as! TabBarViewController).logString.append("[\(dateStr)]:\(data)\n")
        NSLog(data)
    }
    
    @objc func showLog(){
        if self.tabBarController?.navigationItem.leftBarButtonItem?.title == "Hide Log"{
            UIView.transition(with: self.view,
                              duration: 0.5,
                              options: .transitionFlipFromLeft,
                              animations: {
                                self.isLogViewDisplayed = false
                                self.logView.removeFromSuperview()
                                self.tabBarController?.navigationItem.rightBarButtonItem?.title = "Logout"
                                self.tabBarController?.navigationItem.leftBarButtonItem?.title = "Show Log"
            }, completion: nil)
        }else {
            //when Show Log button is pressed
            UIView.transition(with: self.view,
                              duration: 0.5,
                              options: .transitionFlipFromLeft,
                              animations: {
                                self.isLogViewDisplayed = true
                                self.logView.frame = CGRect(x: 0, y: 0 , width: (self.tabBarController?.view.bounds.width)!, height: (self.tabBarController?.view.bounds.height)!)
                                self.tabBarController?.view.addSubview(self.logView)
                                self.logTextView.text = (self.tabBarController as! TabBarViewController).logString as String
                                self.tabBarController?.navigationItem.rightBarButtonItem?.title = "Clear Log"
                                self.tabBarController?.navigationItem.leftBarButtonItem?.title = "Hide Log"
                                
            }, completion: nil)
        }
    }
    
    func getSampleProducts()->[IMSProduct]{
        
        let image = UIImage.init(named: "product_image.png")
        return [IMSProduct(name: "name1", andPrice: 50, andNote: "description1", andImage:IMSUtil.encodedImage(toBase64String: image, with: .ImageFormatPNG), andQuantity: 1),
                IMSProduct(name: "name2", andPrice: 50, andNote: "description2", andImage: nil, andQuantity: 1)]
    }
    
    func getSampleCardholderInfo()->IMSCardholderInfo{
        return IMSCardholderInfo(firstName: "john", andLastName: "appleseed", andMiddleName: "", andEmail: "john.appleseed@example.com", andPhone: "1234567890", andAddress1: "101 federal st", andAddress2: "suite 700", andCity: "boston", andState: "ma", andPostalCode: "02110")
    }
    
    func getProgressStrFromMessage(_ message:IMSProgressMessage) -> String{
        switch message {
        case .PleaseInsertCard:
            let allowedPOS = Ingenico.sharedInstance()?.paymentDevice.allowedPOSEntryModes()
            if let allowedPOS = allowedPOS as? [Int] {
                if (allowedPOS.contains(where: {$0 == IMSPOSEntryMode.POSEntryModeContactlessMSR.rawValue}) || allowedPOS.contains(where: {$0 == IMSPOSEntryMode.POSEntryModeContactlessEMV.rawValue})) {
                    if allowedPOS.contains(where: {$0 == IMSPOSEntryMode.POSEntryModeContactEMV.rawValue}) {
                        return "Please insert/tap/swipe card"
                    } else {
                        return "Please tap or swipe card"
                    }
                } else {
                    return "Please insert or swipe card";
                }
            }
            return "Please swipe card"
        case .CardInserted:
            return "Card inserted";
        case .ICCErrorSwipeCard:
            return "ICCError swipe card please";
        case .ApplicationSelectionStarted:
            return "Application selection started";
        case .ApplicationSelectionCompleted:
            return "Application selection completed";
        case .FirstPinEntryPrompt:
            return "First Pin prompt";
        case .LastPinEntryPrompt:
            return "Last Pin prompt";
        case .PinEntryFailed:
            return "Pin entry failed";
        case .PinEntryInProgress:
            return "Pin entry in progress";
        case .PinEntrySuccessful:
            return "Pin entry in progress";
        case .RetrytPinEntryPrompt:
            return "Retry Pin entry prompt";
        case .WaitingforCardSwipe:
            return "Waiting for card swipe";
        case .PleaseSeePhone:
            return "Please see phone";
        case .SwipeDetected:
            return "Swipe detected";
        case .SwipeErrorReswipeMagStripe:
            return "Reswipe please";
        case .TapDetected:
            return "Tap detected";
        case .UseContactInterfaceInsteadOfContactless:
            return "Use contact interface instead of contactless";
        case .ErrorReadingContactlessCard:
            return "Error reading contactless card";
        case .DeviceBusy:
            return "Device busy";
        case .CardHolderPressedCancelKey:
            return "Cancel key pressed";
        case .RecordingTransaction:
            return "Recording transaction";
        case .UpdatingTransaction:
            return "Updating transaction";
        case .PleaseRemoveCard:
            return "Please remove card";
        case .RestartingContactlessInterface:
            return "Restarting contactless interface";
        case .GettingOnlineAuthorization:
            return "Getting Online Authorization";
        case .TryContactInterface:
            return "Try contact interface";
        case .ReinsertCard:
            return "Reinsert Card properly";
        case .RestartingTransactionDueToIncorrectPin:
            return "Restarting Transaction Due To Incorrect Pin";
        case .Unknown:
            return "Uknown"
        case .PresentCardAgain:
            return "PresentCardAgain"
        case .CardRemoved:
            return "CardRemoved"
        case .ChipCardSwipFailed:
            return "ChipCardSwipFailed"
        case .ContactlessInterfaceFailedTryContact:
            return "ContactlessInterfaceFailedTryContact"
        case .CardWasBlocked:
            return "CardWasBlocked"
        case .NotAuthorized:
            return "NotAuthorized"
        case .TransactionCompleteRemoveCard:
            return "TransactionCompleteRemoveCard"
        case .RemoveCard:
            return "RemoveCard"
        case .InsertOrSwipeCard:
            return "InsertOrSwipeCard"
        case .TransactionVoid:
            return "TransactionVoid"
        case .CardReadOkRemoveCard:
            return "CardReadOkRemoveCard"
        case .ProcessingTransaction:
            return "ProcessingTransaction"
        case .CardHolderBypassedPIN:
            return "CardHolderBypassedPIN"
        case .NotAccepted:
            return "NotAccepted"
        case .ProcessingDoNotRemoveCard:
            return "ProcessingDoNotRemoveCard"
        case .Authorizing:
            return "Authorizing"
        case .NotAcceptedRemoveCard:
            return "NotAcceptedRemoveCard"
        case .CardError:
            return "CardError"
        case .CardErrorRemoveCard:
            return "CardErrorRemoveCard"
        case .Cancelled:
            return "Cancelled"
        case .CancelledRemoveCard:
            return "CancelledRemoveCard"
        case .TransactionVoidRemoveCard:
            return "TransactionVoidRemoveCard"
        case .UnknownAID:
            return "UnknownAID"
        case .MultipleContactlessCardsDetected:
            return "MultipleContactlessCardsDetected"
        case .SendingReversal:
            return "SendingReversal"
        case .GettingCardVerification:
            return "GettingCardVerification"
        case .FetchingSecureCardEntryContent:
            return "FetchingSecureCardEntryContent"
        case .LoadingSecureCardEntryContent:
            return "LoadingSecureCardEntryContent"
        case .RetrievingDeviceLog:
            return "RetrievingDeviceLog"
        case .WaitingforChipCard:
            return "Waiting for Chip Card";
        case .WaitingforSwipeCard:
            return "Waiting for Swipe Card";
        case .WaitingforChipAndSwipe:
            return "Waiting for Chip And Swipe";
        case .WaitingforTapCard:
            return "Waiting for Tap Card";
        case .WaitingforChipAndTap:
            return "Waiting for Chip And Tap";
        case .WaitingforSwipeAndTap:
            return "Waiting for Swipe And Tap";
        case .WaitingforChipSwipeTap:
            return "Waiting for Chip Swipe Tap";
        case .WaitingforFallbackSwipe:
            return "Waiting for Fallback Swipe";
        case .WaitingforFallbackChip:
            return "Waiting for Fallback Chip";
        case .UpdatingFirmware:
            return "Updating firmware";
        case .SettingUpDevice:
            return "Setting up device";
        case .DownloadingFirmware:
            return "Downloading firmware";
        case .CheckingFirmwareUpdate:
            return "Checking for Firmware Update";
        case .CheckingDeviceSetup:
            return "Checking for Device Setup"
        default:
            return ""
        }
    }
    
    func getStrFromPOSEntryMode(_ entryMode: IMSPOSEntryMode)-> String{
        switch (entryMode) {
        case .POSEntryModeKeyed:
            return "Keyed";
        case .POSEntryModeContactEMV:
            return "ContactEMV";
        case .POSEntryModeContactlessEMV:
            return "ContactlessEMV";
        case .POSEntryModeContactlessMSR:
            return "ContactlessMSR";
        case .POSEntryModeMagStripe:
            return "MagStripe";
        case .POSEntryModeMagStripeEMVFail:
            return "MagStripeEMVFail";
        case .POSEntryModeVirtualTerminal:
            return "VirtualTerminal";
        case .POSEntryModeToken:
            return "Token";
        case .POSEntryModeKeyedSwipeFail:
            return "KeyedSwipeFail";
        default:
            return "Unknown";
        }
    }
    
    func getStrFromCVM(_ cvm:IMSCardVerificationMethod) -> String{
        switch (cvm) {
        case .CardVerificationMethodPin:
            return "Pin";
        case .CardVerificationMethodSignature:
            return "Signature";
        case .CardVerificationMethodPinAndSignature:
            return "PinAndSignature";
        default:
            return "None";
        }
        
    }
    
    
    func getStringFromResponse(_ resp: IMSTransactionResponse?) ->String {
        guard  let response = resp else {
            return "Response is empty"
        }
        return response.description
    }
    
    func getStringFromFirmwareUpdateOption(_ action: IMSFirmwareUpdateAction?) ->String {
        switch (action) {
        case .FirmwareUpdateActionNo:
            return "FirmwareUpdateActionNo";
        case .FirmwareUpdateActionRequired:
            return "FirmwareUpdateActionRequired";
        case .FirmwareUpdateActionOptional:
            return "FirmwareUpdateActionOptional";
        case .FirmwareUpdateActionUnknown:
            return "FirmwareUpdateActionUnknown";
        default:
            return "FirmwareUpdateActionUnknown";
        }
    }
    
    //MARK: - MFMailComposeViewControllerDelegate Methods
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        switch result {
        case .sent:
            let alert:UIAlertController = UIAlertController.init(title: "Email", message: "Email sent Successfully", preferredStyle: .alert)
            self.present(alert, animated: true, completion: nil)
        case .saved:
            let alert:UIAlertController = UIAlertController.init(title: "Email", message: "You saved a draft of this email", preferredStyle: .alert)
            self.present(alert, animated: true, completion: nil)
        case .cancelled:
            break
        case .failed:
            let alert:UIAlertController = UIAlertController.init(title: "Email", message: "Mail failed:  An error occurred when trying to compose this email", preferredStyle: .alert)
            self.present(alert, animated: true, completion: nil)
        default:
            break
        }
        
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func sendLogButtonPressed(_ sender: AnyObject) {
        
        if MFMailComposeViewController.canSendMail() {
            let mailController:MFMailComposeViewController = MFMailComposeViewController.init()
            mailController.mailComposeDelegate = self
            mailController.setSubject("Ingenico mPOS SDK - Console Logs")
            mailController.setMessageBody(self.logTextView.text, isHTML: true)
            if let logFilePath = UserDefaults.standard.object(forKey: "log_file_path") {
                if let logFile = try? Data(contentsOf: URL(fileURLWithPath: logFilePath as! String)) {
                    mailController.addAttachmentData(logFile, mimeType: "text/txt", fileName: "mpos_sdk_logs.log")
                }
            }
            
            self.present(mailController, animated: true, completion: nil)
        }else {
            let alert:UIAlertController = UIAlertController.init(title: "cannot send email", message: "This device cannot send email", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(ok)
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    // MARK: CLLocationManager delegate
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        NSLog("Failed to get current location:\(String(format: "%@", error.localizedDescription))")
        location = nil
        manager.delegate = nil
        manager.stopUpdatingHeading()
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .denied || status == .restricted {
            NSLog("Location services was denied")
            location = nil
            manager.delegate = nil
            manager.stopUpdatingLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didFinishDeferredUpdatesWithError error: Error?) {
        NSLog("Deferred updates failed with error: \(error?.localizedDescription ?? "")")
        location = nil
        manager.delegate = nil
        manager.stopUpdatingLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let lastUpdateInterval:TimeInterval  = Date().timeIntervalSince((manager.location?.timestamp)!)
        if lastUpdateInterval > 60 {
            return
        }
        location = manager.location
        manager.delegate = nil
        manager.stopUpdatingLocation()
    }
    
    func getLongitude()->String?{
        return String(format: "%f", self.location?.coordinate.longitude ?? 0)
    }
    
    func getLatitude()->String?{
        return String(format: "%f", self.location?.coordinate.latitude ?? 0)
    }
    
    //MARK: Progress Utils
    
    func dismissProgress() {
        MRProgressOverlayView.dismissAllOverlays(for: IMSBaseViewController.currentVC.view.window, animated: false)
    }
    
    func showProgressMessage(_ message:String, stopBlock: (() -> Void)? = nil) {
        dismissProgress()
        IMSBaseViewController.progressView = MRProgressOverlayView()
        IMSBaseViewController.progressView?.titleLabelText = message
        if (stopBlock != nil) {
            IMSBaseViewController.progressView?.stopBlock = { (view) in
                stopBlock!()
                self.dismissProgress()
            }
        }
        IMSBaseViewController.currentVC.view.window?.addSubview(IMSBaseViewController.progressView!)
        IMSBaseViewController.progressView?.show(true)
    }
    
    func showSucess(_ message:String) {
        showResult(message, isSucess: true)
    }
    
    func showError(_ message: String) {
        showResult(message, isSucess: false)
    }
    
    func showResult(_ message: String, isSucess:Bool) {
        dismissProgress()
        IMSBaseViewController.progressView = MRProgressOverlayView()
        IMSBaseViewController.progressView?.titleLabelText = message
        if (isSucess) {
            IMSBaseViewController.progressView?.mode = .checkmark
        }
        else {
            IMSBaseViewController.progressView?.mode = .cross
        }
        IMSBaseViewController.currentVC.view.window?.addSubview(IMSBaseViewController.progressView!)
        IMSBaseViewController.progressView?.show(true)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            self.dismissProgress()
        }
    }
    
    func showProgressPercent(_ progress: Float, message: String, stopBlock: (() -> Void)? = nil) {
        dismissProgress()
        IMSBaseViewController.progressView = MRProgressOverlayView()
        IMSBaseViewController.currentVC.view.window?.addSubview(IMSBaseViewController.progressView!)
        IMSBaseViewController.progressView?.show(false)
        IMSBaseViewController.progressView?.titleLabelText = message
        IMSBaseViewController.progressView?.mode = .determinateCircular
        IMSBaseViewController.progressView?.progress = progress
        if (stopBlock != nil) {
            IMSBaseViewController.progressView?.stopBlock = { (view) in
                stopBlock!()
                self.dismissProgress()
            }
        }
    }
    
    func showProcessingMessage() {
        showProgressMessage("Processing...") {
            Ingenico.sharedInstance()?.payment.abortTransaction()
        }
    }
    
}
