//
//  LoginViewController.swift
//  EMVSDKSwiftTestApp
//
//  Created by Mallikarjun Patil on 9/8/16.
//  Copyright © 2016 Ingenico. All rights reserved.
//

import UIKit
import LocalAuthentication

class LoginViewController: IMSBaseViewController, UITextFieldDelegate, RUAPairingListener {
    
    @IBOutlet weak var userNameTextField: UITextField!
    
    @IBOutlet weak var passWordTextField: UITextField!
    
    @IBOutlet weak var credentialLabel: UILabel!
    @IBOutlet weak var loginUseTouchIDButton: UIButton!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var checkDeviceSetupSwitch: UISwitch!
    
    private var isLoaded:Bool=false
    var ledSequence:[Any] = []
    var confirmationCallback: RUALedPairingConfirmationCallback?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        userNameTextField.tag = 0
        passWordTextField.tag = 1
        loginButton.layer.cornerRadius = 3
        loginButton.layer.masksToBounds = true
        deviceStatusBarButton = UIBarButtonItem.init(customView: getDeviceStatusImage())
        
        let tapper:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(handleSingleTap))
        tapper.cancelsTouchesInView = false
        self.view.addGestureRecognizer(tapper)
        versionLabel = UILabel()
        versionLabel?.textAlignment = .center
        versionLabel?.font = UIFont(name: "HelveticaNeue", size: 10)
        self.view.addSubview(versionLabel!)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationItem.leftBarButtonItem = UIBarButtonItem.init(title: "Back", style: .plain, target: self, action: #selector(goBack))
        self.navigationItem.rightBarButtonItem = deviceStatusBarButton
        let version = Ingenico.sharedInstance()?.getVersion() ?? ""
          if (!version.isEmpty) {
              versionLabel?.text = "mPOS EMV SDK v\(version)"
          }
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.navigationItem.rightBarButtonItem?.isEnabled = self.getIsLoggedIn()
        //deviceStatusLabel.isHidden = true
        if UserDefaults.standard.object(forKey: "lastLoggedInUN") != nil {
            userNameTextField.text = UserDefaults.standard.object(forKey: "lastLoggedInUN") as? String
        }
        if UserDefaults.standard.object(forKey: "lastLoggedInPW") != nil {
            passWordTextField.text = UserDefaults.standard.object(forKey: "lastLoggedInPW") as? String
        }
    }
    
    override func viewWillLayoutSubviews() {
        if !isLoaded {
            isLoaded = true
        }
        versionLabel?.frame = CGRect(x: 0, y: self.view.frame.height-40, width: self.view.frame.width, height: 40)
    }
    
    @objc func goBack() {
        Ingenico.sharedInstance()?.reset()
        _ = self.navigationController?.popViewController(animated: true)
        DeviceManagementHelper.shared.stopScan()
    }

    @IBAction func doLogin(_ sender: AnyObject) {
        loginWithUserName(userNameTextField.text!, andPW: passWordTextField.text!)
    }
    
    @IBAction func offlineLogin(_ sender: Any) {
        loginOfflineWithUserName(userNameTextField.text!, andPW: passWordTextField.text!)
    }
    
    
    @IBAction func ping(_ sender: Any) {
        Ingenico.sharedInstance()?.ping({ (error) in
            if (error == nil) {
                self.showSucess( "ping success")
            }
            else {
                self.showError("ping failed:\((error! as NSError).code)")
            }
        })
    }
    
    
    @IBAction func LoginUseTouchIDAction(_ sender: AnyObject) {
        loginUseTouchID()
    }
    
    func loginUseTouchID(){
        self.view.endEditing(true)
        let context:LAContext = LAContext()
        var error:NSError?
        
        // Check if the device can evaluate the policy.
        if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) {
            if UserDefaults.standard.object(forKey: "lastLoggedInUN") != nil && UserDefaults.standard.object(forKey: "lastLoggedInPW") != nil  {
                context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: "Login using TouchID", reply: { (success, evalPolicyError) in
                    DispatchQueue.main.async(execute: {
                        if (evalPolicyError != nil) {
                            self.showError("There was a problem verifying your identity")
                        }else if success {
                            self.loginWithUserName(UserDefaults.standard.object(forKey: "lastLoggedInUN") as! String, andPW: UserDefaults.standard.object(forKey: "lastLoggedInPW") as! String)
                        }else{
                            self.showError("You are not the device owner")
                        }
                    })
                })
            }
        }else {
            loginUseTouchIDButton.isEnabled = false
        }
    }
    
    @objc func handleSingleTap(_ sender:UITapGestureRecognizer){
        self.view.endEditing(true)
    }
    
    func loginWithUserName( _ uname : String, andPW pw : String){
        
        self.view.endEditing(true)
        self.showProgressMessage("Logging in...")
        Ingenico.sharedInstance()?.user.loginwithUsername(uname, andPassword: pw) { (user, error) in
            self.dismissProgress()
            if (error == nil) {
                self.navigationItem.rightBarButtonItem?.isEnabled = true
                self.setLoggedIn(true)
                if(!self.getIsConfigModeSet()){
                    self.checkFirmwareUpdate()
                }
                UserDefaults.standard.set(uname, forKey: "lastLoggedInUN")
                UserDefaults.standard.set(pw, forKey: "lastLoggedInPW")
                UserDefaults.standard.synchronize()
                let controller = self.storyboard!.instantiateViewController(withIdentifier: "tabBarController")
                self.navigationController?.pushViewController(controller, animated: true);
                let formatter:DateFormatter = DateFormatter.init()
                    formatter.dateFormat = "HH:mm:ss"
                let dateStr:String = formatter.string(from: Date())
                (controller as! TabBarViewController).logString.append("[\(dateStr)]:\(user?.description ?? "")\n")
            }else{
                self.navigationItem.rightBarButtonItem?.isEnabled = false
                let nserror = error as NSError?
                let alertController:UIAlertController  = UIAlertController.init(title: "Failed", message: "Login failed, please try again later \(self.getResponseCodeString((nserror?.code)!))", preferredStyle: .alert)
                let okAction:UIAlertAction = UIAlertAction.init(title: "OK", style: .default, handler: nil)
                alertController.addAction(okAction)
                self.present(alertController, animated: true, completion: nil)
            }
        }
    }
    
    func loginOfflineWithUserName( _ uname : String, andPW pw : String){
        
        self.view.endEditing(true)
        self.showProgressMessage("Logging in offline...")
        Ingenico.sharedInstance()?.storeAndForward.loginOffline(uname, andPassword: pw) { (error) in
            if (error == nil) {
                self.showSucess("Offline Login success")
                self.navigationItem.rightBarButtonItem?.isEnabled = true
                self.setLoggedIn(true)
                self.performSegue(withIdentifier:"loginsuccess" , sender: nil)
                UserDefaults.standard.set(uname, forKey: "lastLoggedInUN")
                UserDefaults.standard.set(pw, forKey: "lastLoggedInPW")
                UserDefaults.standard.synchronize()
            }else{
                self.dismissProgress()
                self.navigationItem.rightBarButtonItem?.isEnabled = false
                let nserror = error as NSError?
                let alertController:UIAlertController  = UIAlertController.init(title: "Failed", message: "Offline Login failed, please try again later \(self.getResponseCodeString((nserror?.code)!))", preferredStyle: .alert)
                let okAction:UIAlertAction = UIAlertAction.init(title: "OK", style: .default, handler: nil)
                alertController.addAction(okAction)
                self.present(alertController, animated: true, completion: nil)
            }
        }
    }
    
    @IBAction func forgotPassword(_ sender: Any) {
        let alertController = UIAlertController(title: "Forgot Password", message: "Enter username", preferredStyle: .alert)
        alertController.addTextField { (textField) in
            textField.placeholder = "Username"
        }
        let submitAction = UIAlertAction(title: "Submit", style: .default) { (action) in
            self.view.endEditing(true)
            self.showProgressMessage("Sending email....")
            let username = alertController.textFields?.first?.text
            Ingenico.sharedInstance()?.user.forgotPassword(username ?? "", andOnDone: { (error) in
                if (error != nil) {
                    self.showError(error?.localizedDescription ?? "")
                }
                else {
                    self.showSucess( "Email sent")
                }
            })
        }
        alertController.addAction(submitAction)
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    
    //MARK: - UITextFieldDelegate Implementation
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField.tag == 0 {
            passWordTextField.becomeFirstResponder()
            return false
        }else {
            self.view.endEditing(false)
            return true
        }
    }
    
    //Mark:- RUAPairing Listener Implementation
    func onPairSucceeded() {
        self.showSucess( "Pairing success")
    }
    
    func onPairCancelled() {
        self.showProgressMessage( "Pairing cancelled")
    }
    
    func onPairNotSupported() {
        self.showError("Pairing not supported")
    }
    
    func onPairFailed() {
        self.showError("Pairing failed")
    }
    
    func onLedPairSequenceConfirmation(_ ledSequence: [Any]!, confirmationCallback: RUALedPairingConfirmationCallback!) {
        self.ledSequence = ledSequence
        self.confirmationCallback = confirmationCallback
        self.performSegue(withIdentifier: "led_pair_segue", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "led_pair_segue") {
            let vc:LedPairingViewController = segue.destination as! LedPairingViewController
            vc.ledSequence = self.ledSequence
            vc.confirmationCallback = self.confirmationCallback
        }
    }
}
