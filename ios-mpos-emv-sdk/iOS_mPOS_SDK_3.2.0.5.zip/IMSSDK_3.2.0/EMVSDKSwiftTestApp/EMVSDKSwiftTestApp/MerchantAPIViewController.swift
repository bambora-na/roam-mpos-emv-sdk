//
//  MerchantAPIViewController.swift
//  EMVSDKSwiftTestApp
//
//  Created by Mallikarjun Patil on 9/12/16.
//  Copyright © 2016 Ingenico. All rights reserved.
//

import UIKit

class MerchantAPIViewController: IMSBaseViewController,UITableViewDelegate, UITableViewDataSource {
    

    var ingenico:Ingenico?
    var clerkIdTextField:UITextField!
    var invoiceIdTextField:UITextField!
    var staticDataArray = [[String: [String]]] ()
    
    @IBOutlet weak var merchantAPITableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ingenico = Ingenico.sharedInstance()
        merchantAPITableView.dataSource = self
        merchantAPITableView.delegate = self
        merchantAPITableView.tableFooterView = UIView()
        
        let staticDictionary1:[String: [String]] = ["Email APIs": ["Send Email Receipt", "Set User Email"]]
        staticDataArray.append(staticDictionary1)
        let staticDictionary2:[String: [String]] = ["Security Questions APIs": ["Get Security Questions", "Set Security Questions"]]
        staticDataArray.append(staticDictionary2)
        let staticDictionary3:[String: [String]] = ["Merchant Information APIs": ["Get Receipt Information", "Set Receipt Information", "Get processor info"]]
        staticDataArray.append(staticDictionary3)
        let staticDictionary4:[String: [String]] = ["Password APIs": ["Change Password", "Forgot Password"]]
        staticDataArray.append(staticDictionary4)
        let staticDictionary5:[String: [String]] = ["Transaction APIs": ["Filter Transaction History", "Filter Invoice History","Get Transaction Details","Get Transaction History"]]
        staticDataArray.append(staticDictionary5)
        let staticDictionary6:[String: [String]] = ["Update API": ["Update Transaction", "Upload Signature"]]
        staticDataArray.append(staticDictionary6)
        let staticDictionary7:[String: [String]] = ["Other API": ["Refresh user session", "Accept terms and conditions"]]
        staticDataArray.append(staticDictionary7)
        
        deviceStatusBarButton = UIBarButtonItem.init(customView: getDeviceStatusImage())
        
        tabBarController?.navigationItem.hidesBackButton = true

    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if isLogViewDisplayed == true {
            self.tabBarController?.navigationItem.leftBarButtonItem = nil
            self.tabBarController?.navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Hide Log", style: UIBarButtonItem.Style.plain, target: self, action: #selector(showLog))
            self.tabBarController?.navigationItem.rightBarButtonItems = nil
            self.tabBarController?.navigationItem.rightBarButtonItems = [UIBarButtonItem(title: "Clear Log", style: UIBarButtonItem.Style.plain, target: self, action:#selector(doLogoff)),
                                                                         deviceStatusBarButton!]
            
        }else {
            self.tabBarController?.navigationItem.leftBarButtonItem = nil
            self.tabBarController?.navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Show Log", style: UIBarButtonItem.Style.plain, target: self, action: #selector(showLog))
            self.tabBarController?.navigationItem.rightBarButtonItems = nil
            self.tabBarController?.navigationItem.rightBarButtonItems = [UIBarButtonItem(title: "Logout", style: UIBarButtonItem.Style.plain, target: self, action:#selector(doLogoff)),
                                                                         deviceStatusBarButton!]
        }
    }

    func forgotPassword(){
        self.showProgressMessage("Sending forgot password request:")
        ingenico?.user.forgotPassword(UserDefaults.standard.string(forKey: "lastLoggedInUN") ?? "", andOnDone: { (error) in
            self.dismissProgress()
            if error == nil {
                self.showSucess( "Forgot password succeeded")
                self.consoleLog("Forgot password succeeded")
            } else {
                self.showError("Forgot password failed")
                let nserror = error as NSError?
                self.consoleLog(String.init(format: "Forgot password  failed with error code %d", nserror!.code))
            }
        })
    }
    
    func setEmail(){
        var emailTF : UITextField?
        let alert = UIAlertController(title: "Set Email", message: "Enter email address", preferredStyle: .alert)
        alert.addTextField { (textfield) in
            textfield.placeholder = "email"
            emailTF = textfield
        }
        let okAction = UIAlertAction(title: "OK", style: .default) { (action) in
            self.showProgressMessage("Sending Set User Email request:")
            Ingenico.sharedInstance()?.user.setUserEmail(emailTF!.text ?? "", andOnDone: { (error) in
                self.dismissProgress()
                if error == nil {
                    self.showSucess( "Set Email succeeded")
                    self.consoleLog("Set Email succeeded")
                } else {
                    self.showError("Set Email failed")
                    let nserror = error as NSError?
                    self.consoleLog(String.init(format: "Set Email failed with error code %d", nserror!.code))
                }
            })
        }
        alert.addAction(okAction)
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alert.addAction(cancelAction)
        present(alert, animated: false, completion: nil)
        
    }
    
    func changePW(){
        var oldPwdTF : UITextField?
        var newPwdTF : UITextField?
        let alert = UIAlertController(title: "Set Email", message: "Enter email address", preferredStyle: .alert)
        alert.addTextField { (textfield) in
            textfield.placeholder = "old password"
            textfield.isSecureTextEntry = true
            oldPwdTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.placeholder = "new password"
            textfield.isSecureTextEntry = true
            newPwdTF = textfield
        }
        let okAction = UIAlertAction(title: "OK", style: .default) { (action) in
            self.showProgressMessage("Sending Change Password request:")
            Ingenico.sharedInstance()?.user.changePassword(withOldPassword: oldPwdTF!.text ?? "", andNewPassword: newPwdTF!.text ?? "", andOnDone: { (error) in
                self.dismissProgress()
                if error == nil {
                    self.showSucess( "Change Password succeeded")
                    self.consoleLog("Change Password succeeded")
                } else {
                    self.showError("Change Password failed")
                    let nserror = error as NSError?
                    self.consoleLog(String.init(format: "Change Password failed with error code %d", nserror!.code))
                }
            })
        }
        alert.addAction(okAction)
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alert.addAction(cancelAction)
        present(alert, animated: false, completion: nil)
        
    }
    
    func updateTransaction(){
        
        var origTxnIdTF:UITextField?
        var firstnameTF:UITextField?
        var lastnameTF:UITextField?
        var middlenameTF:UITextField?
        var emailTF:UITextField?
        var phoneTF:UITextField?
        var address1TF:UITextField?
        var address2TF:UITextField?
        var cityTF:UITextField?
        var stateTF:UITextField?
        var postalCodeTF:UITextField?
        var noteTF:UITextField?
        var isCompleteCB:UIButton?
        var showNotesCB:UIButton?
        
        let alert = UIAlertController(title: "Update Transaction", message: "Enter the following:", preferredStyle: .alert)
        alert.addTextField { (textfield) in
            textfield.placeholder = "Original Transaction Id"
            textfield.text = self.getLastTransactionID()
            origTxnIdTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.placeholder = "First Name"
            firstnameTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.placeholder = "Last Name"
            lastnameTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.placeholder = "Middle Name"
            middlenameTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.placeholder = "Email"
            emailTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.placeholder = "Phone"
            phoneTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.placeholder = "Address 1"
            address1TF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.placeholder = "Address 2"
            address2TF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.placeholder = "City"
            cityTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.placeholder = "State"
            stateTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.placeholder = "Postal Code"
            postalCodeTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.placeholder = "Transaction Note"
            noteTF = textfield
        }
        alert.addCheckBoxWithTitle("Display Notes And Invoice") { (checkbox) in
            showNotesCB = checkbox
        }
        alert.addCheckBoxWithTitle("Is Complete") { (checkbox) in
            isCompleteCB = checkbox
        }
        let ok = UIAlertAction(title: "Ok", style: .default) { (action) in
            self.showProgressMessage("Processing Transaction")
            let carholderInfo = IMSCardholderInfo(firstName: firstnameTF!.text, andLastName: lastnameTF!.text, andMiddleName: middlenameTF!.text, andEmail: emailTF!.text, andPhone: phoneTF!.text, andAddress1: address1TF!.text, andAddress2: address2TF!.text, andCity: cityTF!.text, andState: stateTF!.text, andPostalCode: postalCodeTF!.text)
            
            self.showProgressMessage("Sending update transaction request")
            Ingenico.sharedInstance()?.user.updateTransaction(withTransactionID: origTxnIdTF!.text!,
                                             andCardholderInfo: carholderInfo,
                                             andTransactionNote: noteTF!.text,
                                             andIsCompleted: isCompleteCB!.isSelected,
                                             andDisplayNotesAndInvoice: showNotesCB!.isSelected,
                                             andOnDone: { (error) in
                                                
                                                self.dismissProgress()
                                                if error == nil {
                                                    self.showSucess( "Update Transaction succeeded")
                                                    self.consoleLog("Update Transaction succeeded")
                                                } else {
                                                    self.showError("Update Transaction failed")
                                                    let nserror = error as NSError?
                                                    self.consoleLog(String.init(format: "Update Transaction failed with error code %d", nserror!.code))
                                                    
                                                }
            })
        }
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alert.addAction(ok)
        alert.addAction(cancel)
        
        if ((getLastTransactionID()) != nil)  {
            self.present(alert, animated: true, completion: nil)
            
        } else {
            showErrorMessage("Please perform a Transaction first", andErrorTitle: "Error")
        }
        
    }
    
    func getEmailReceiptInfo(){
        self.showProgressMessage("Getting Email Receipt Info")
        ingenico?.user.getEmailReceiptInfo({ (emailReceiptInfo, error) in
            self.dismissProgress()
            if error == nil {
                self.showSucess( "Get Email Receipt Info Succeeded")
                self.consoleLog("getEmailReceiptInfo:\(emailReceiptInfo?.description ?? "")")
            } else {
                self.showError("Get Email Receipt Info failed")
                let nserror = error as NSError?
                self.consoleLog(String.init(format: "Get Email failed with error code %d", nserror!.code))
            }
            
        })
        
    }
    func setEmailReceiptInfo(){
        var phoneTF : UITextField?
        let alert = UIAlertController(title: "Set Email Receipt Info", message: "Enter cardholder phone number", preferredStyle: .alert)
        alert.addTextField { (textfield) in
            textfield.placeholder = "phone number"
            phoneTF = textfield
        }
        let okAction = UIAlertAction(title: "OK", style: .default) { (action) in
            self.showProgressMessage("Setting Email Receipt Info")
            let receiptInfo:IMSEmailReceiptInfo = IMSEmailReceiptInfo.init(logoBase64: IMSUtil.encodedImage(toBase64String: UIImage.init(named: "merchant_receipt_info.png"), with: .ImageFormatPNG),
                                                                           andMerchantMessage: "Ingenico Mobile Solutions",
                                                                           andEmail: "ims@ims.com",
                                                                           andPhoneNumber: phoneTF!.text ?? "",
                                                                           andWebsiteURL: "www.ingenico.com",
                                                                           andFacebookURL: "facebookurltest",
                                                                           andTwitterURL: "twitterurl",
                                                                           andInstagramURL:"InstagramURLTEST",
                                                                           andBusinessName: "TheBakery",
                                                                           andAddress1: "123 Boston Ave",
                                                                           andAddress2: "Suite 007",
                                                                           andCity: "Boston",
                                                                           andState: "MA",
                                                                           andCountry: "US",
                                                                           andPostalCode: "01234")
            
            Ingenico.sharedInstance()?.user.setEmailReceiptInfo(receiptInfo, andOnDone: { (error) in
                self.dismissProgress()
                if error == nil {
                    self.showSucess( "Set Email receipt info succeeded")
                    self.consoleLog("Set Email receipt info  succeeded")
                } else {
                    self.showError("Set Email receipt info  failed")
                    let nserror = error as NSError?
                    self.consoleLog(String.init(format: "Set Email failed with error code %d", nserror!.code))
                }
            })
        }
        alert.addAction(okAction)
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alert.addAction(cancelAction)
        present(alert, animated: false, completion: nil)
    }
    
    func getProcessorInfo() {
        self.showProgressMessage("Getting processor info...")
        Ingenico.sharedInstance()?.user.getProcessorInfo({ (processorInfo, error) in
             self.dismissProgress()
            if error == nil {
                self.showSucess( "getProcessorInfo succeeded")
                self.consoleLog("getProcessorInfo:\(processorInfo?.description ?? "")")
            } else {
                self.showError("getProcessorInfo failed")
                let nserror = error as NSError?
                self.consoleLog(String.init(format: "getProcessorInfo failed with error code %d", nserror!.code))
            }
        })
    }
    
    func getSecurityQuestions(){
        self.showProgressMessage("Getting Security Questions")
        ingenico?.user.getSecurityQuestions({ (questions, error) in
            self.dismissProgress()
            if error == nil {
                self.showSucess( "Get Security Questions succeeded")
                self.consoleLog(self.getStringFromSecurityQuestionsArray(questions: questions as! [IMSSecurityQuestion]))
            } else {
                self.showError("Get Security Questions failed")
                let nserror = error as NSError?
                self.consoleLog(String.init(format: "Get Security Questions failed with error code %d", nserror!.code))
            }
        })
    }
    
    func setSecurityQuestions(){
        self.performSegue(withIdentifier: "segue_to_security_questions", sender: self)
    }
    
    func sendEmailReceipt(){
        
        if let val = getLastTransactionID() {
            
            self.showProgressMessage("Sending Email Receipt Request:")
            ingenico?.user.sendEmailReceipt(val, andEmailAddress: "ims@ims.com", andOnDone: { (error) in
                self.dismissProgress()
                if error == nil {
                    self.showSucess( "Send Email Receipt succeeded")
                    self.consoleLog("Send Email Receipt succeeded")
                } else {
                    self.showError("Send Email Receipt failed")
                    let nserror = error as NSError?
                    self.consoleLog(String.init(format: "Send Email Receipt failed with error code %d", nserror!.code))
                }
            })
        }else {
            showErrorMessage("Please perform a transaction first", andErrorTitle: "Error")
        }
    }
    
    
    func getTransactionDetails()  {
        if let val = getLastTransactionID(){
            self.showProgressMessage("Getting Transaction Detail")
            ingenico?.user.getTransactionDetails(withTransactionID: val, andOnDone: { (transactionDetail, error) in
                self.dismissProgress()
                if error == nil {
                    self.showSucess( "Get Transaction Detail succeeded")
                    self.consoleLog("Get Transaction Detail succeeded: \(self.getStringFromTransactionDetails(transaction: transactionDetail!))")
                } else {
                    self.showError("Get Transaction Detail failed")
                    let nserror = error as NSError?
                    self.consoleLog(String.init(format: "Get Transaction Detail failed with error code %d", nserror!.code))
                }
            })
        }else {
            showErrorMessage("Please perform a transaction first", andErrorTitle: "Error")
        }
    }
    
    func getTransactionHistory(){
        
        self.showProgressMessage("Getting Transaction History")
        let builder:IMSHistoryQueryBuilder = IMSHistoryQueryBuilder.init()
        builder.pastDays = 5
        builder.pageSize = 20
        builder.pageNumber = 1
        builder.transactionTypes = [NSNumber.init(value: IMSTransactionType.TransactionTypeCreditSale.rawValue),
                                    NSNumber.init(value: IMSTransactionType.TransactionTypeCreditSaleVoid.rawValue),
                                    NSNumber.init(value: IMSTransactionType.TransactionTypeCreditRefund.rawValue),
                                    NSNumber.init(value: IMSTransactionType.TransactionTypeCashSale.rawValue),
                                    NSNumber.init(value: IMSTransactionType.TransactionTypeCashRefund.rawValue),
                                    NSNumber.init(value: IMSTransactionType.TransactionTypeCreditAuth.rawValue),
                                    NSNumber.init(value: IMSTransactionType.TransactionTypeCreditAuthVoid.rawValue),
                                    NSNumber.init(value: IMSTransactionType.TransactionTypeCreditAuthCompletion.rawValue),
                                    NSNumber.init(value: IMSTransactionType.TransactionTypeCreditAuthCompletionVoid.rawValue)]
        
        self.ingenico?.user.getTransactionHistory(with: builder.createQueryCriteria()) { (transactionList, totalMatches, error) in
            self.dismissProgress()
            if error == nil {
                self.showSucess( "Get Transaction History Succeeded")
                self.consoleLog(String.init(format: "Get Transaction History succeeded with totalMatches: %d",totalMatches))
            } else {
                self.showError("Get Transaction History failed")
                let nserror = error as NSError?
                self.consoleLog(String.init(format: "Get Transaction History failed with error code %d", nserror!.code))
            }
        }
        
    }
    
    func filterInvoiceHistory(){
        let okAction:UIAlertAction = UIAlertAction.init(title: "OK", style: .default) { (action) in
            if (self.clerkIdTextField.text?.count)! > 4 {
                self.showErrorMessage("Error", andErrorTitle: "ClerkID is upto 4 alphanumerics")
            }else {
                self.view.endEditing(true)
                self.showProgressMessage("Getting Invoice History")
                let builder:IMSHistoryQueryBuilder = IMSHistoryQueryBuilder.init()
                builder.pastDays = 5
                builder.pageSize = 100
                builder.pageNumber = 1
                if (self.clerkIdTextField.text?.count)! > 0 {
                    builder.clerkId = self.clerkIdTextField.text
                }
                if (self.invoiceIdTextField.text?.count)! > 0 {
                    builder.invoiceId = self.invoiceIdTextField.text
                }
                builder.transactionTypes = [NSNumber.init(value: IMSTransactionType.TransactionTypeCreditSale.rawValue),
                                            NSNumber.init(value: IMSTransactionType.TransactionTypeCreditSaleVoid.rawValue),
                                            NSNumber.init(value: IMSTransactionType.TransactionTypeCreditRefund.rawValue),
                                            NSNumber.init(value: IMSTransactionType.TransactionTypeCashSale.rawValue),
                                            NSNumber.init(value: IMSTransactionType.TransactionTypeCashRefund.rawValue),
                                            NSNumber.init(value: IMSTransactionType.TransactionTypeCreditAuth.rawValue),
                                            NSNumber.init(value: IMSTransactionType.TransactionTypeCreditAuthVoid.rawValue),
                                            NSNumber.init(value: IMSTransactionType.TransactionTypeCreditAuthCompletion.rawValue),
                                            NSNumber.init(value: IMSTransactionType.TransactionTypeCreditAuthCompletionVoid.rawValue)]
                
                builder.transactionStatuses = [NSNumber.init(value: IMSTransactionStatus.TransactionStatusActive.rawValue),
                                               NSNumber.init(value: IMSTransactionStatus.TransactionStatusCompleted.rawValue),
                                               NSNumber.init(value: IMSTransactionStatus.TransactionStatusRefunded.rawValue),
                                               NSNumber.init(value: IMSTransactionStatus.TransactionStatusVoided.rawValue),
                                               NSNumber.init(value: IMSTransactionStatus.TransactionStatusExpired.rawValue),
                                               NSNumber.init(value: IMSTransactionStatus.TransactionStatusUnknown.rawValue)]
                
                self.ingenico?.user.getInvoiceHistory(with: builder.createQueryCriteria(), andOnDone: { (invoiceList, totalMatches, error) in
                    self.dismissProgress()
                    if error == nil {
                        self.showSucess( "Get Invoice History Succeeded")
                        self.consoleLog(String.init(format: "Get Invoice History succeeded with totalMatches: %d",totalMatches))
                    } else {
                        self.showError("Get Invoice History failed")
                        let nserror = error as NSError?
                        self.consoleLog(String.init(format: "Get Invoice History failed with error code %d", nserror!.code))
                    }
                    
                })
            }
        }
        
        showTransactionFilterAlertControllerWith(action: okAction)
    }
    
    func filterTransactionHistory(){
        
        let okAction:UIAlertAction = UIAlertAction.init(title: "OK", style: .default) { (action) in
            if (self.clerkIdTextField.text?.count)! > 4 {
                self.showErrorMessage("Error", andErrorTitle: "ClerkID is upto 4 alphanumerics")
            }else {
                self.view.endEditing(true)
                self.showProgressMessage("Getting Transaction History")
                let builder:IMSHistoryQueryBuilder = IMSHistoryQueryBuilder.init()
                builder.pastDays = 5
                builder.pageSize = 20
                builder.pageNumber = 1
                if (self.clerkIdTextField.text?.count)! > 0 {
                    builder.clerkId = self.clerkIdTextField.text
                }
                if (self.invoiceIdTextField.text?.count)! > 0 {
                    builder.invoiceId = self.invoiceIdTextField.text
                }
                builder.transactionTypes = [NSNumber.init(value: IMSTransactionType.TransactionTypeCreditSale.rawValue),
                                            NSNumber.init(value: IMSTransactionType.TransactionTypeCreditSaleVoid.rawValue),
                                            NSNumber.init(value: IMSTransactionType.TransactionTypeCreditRefund.rawValue),
                                            NSNumber.init(value: IMSTransactionType.TransactionTypeCashSale.rawValue),
                                            NSNumber.init(value: IMSTransactionType.TransactionTypeCashRefund.rawValue),
                                            NSNumber.init(value: IMSTransactionType.TransactionTypeCreditAuth.rawValue),
                                            NSNumber.init(value: IMSTransactionType.TransactionTypeCreditAuthVoid.rawValue),
                                            NSNumber.init(value: IMSTransactionType.TransactionTypeCreditAuthCompletion.rawValue),
                                            NSNumber.init(value: IMSTransactionType.TransactionTypeCreditAuthCompletionVoid.rawValue)]
                
                builder.transactionStatuses = [NSNumber.init(value: IMSTransactionStatus.TransactionStatusActive.rawValue),
                                               NSNumber.init(value: IMSTransactionStatus.TransactionStatusCompleted.rawValue),
                                               NSNumber.init(value: IMSTransactionStatus.TransactionStatusRefunded.rawValue),
                                               NSNumber.init(value: IMSTransactionStatus.TransactionStatusVoided.rawValue),
                                               NSNumber.init(value: IMSTransactionStatus.TransactionStatusExpired.rawValue),
                                               NSNumber.init(value: IMSTransactionStatus.TransactionStatusUnknown.rawValue)]
                
                self.ingenico?.user.getTransactionHistory(with: builder.createQueryCriteria(), andOnDone: { (transactionList, totalMatches, error) in
                    self.dismissProgress()
                    if error == nil {
                        self.showSucess( "Get Transaction History Succeeded")
                        self.consoleLog(String.init(format: "Get Transaction History succeeded with totalMatches: %d",totalMatches))
                    } else {
                        self.showError("Get Transaction History failed")
                        let nserror = error! as NSError
                        self.consoleLog(String.init(format: "Get Transaction History failed with error code %d", nserror.code))
                    }
                    
                })
            }
        }
        
        showTransactionFilterAlertControllerWith(action: okAction)
    }
    
    
    func showTransactionFilterAlertControllerWith(action:UIAlertAction){
        let alertController:UIAlertController = UIAlertController.init(title: "Filter By", message: nil, preferredStyle: .alert)
        alertController.addTextField { (textField) in
            textField.keyboardType = .default
            textField.placeholder = "Clerk ID (max 4 alphanumeric chars)";
            self.clerkIdTextField = textField
        }
        
        alertController.addTextField { (textField) in
            textField.keyboardType = .default
            textField.placeholder = "Invoice ID";
            self.invoiceIdTextField = textField
        }
        alertController.addAction(action)
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) {
            UIAlertAction in
            NSLog("Cancel Pressed")
        }
        alertController.addAction(cancelAction)
        self.present(alertController, animated: true, completion: nil)
        
    }
    
    
    
    func uploadSignature(){
        self.showProgressMessage("Uploading Signature...")
        let encodedString:String = (UIImage.init(named: "signature.png")!.pngData()?.base64EncodedString(options: .endLineWithLineFeed))!
        ingenico?.user.uploadSignatureForTransaction(withId: getLastTransactionID() ?? "", andSignature: encodedString, andOnDone: { (error) in
            self.dismissProgress()
            if error == nil {
                self.showSucess( "Uploading signature Succeeded")
                self.consoleLog("Uploading signature Succeeded")
            } else {
                self.showError("Uploading signature failed")
                self.consoleLog("Uploading signature failed")
            }
        })
    }
    
    func refreshUserSession() {
        self.showProgressMessage("Refreshing User Session...")
        Ingenico.sharedInstance()?.user.refreshUserSession({ (userprofile, error) in
            self.dismissProgress()
            if error == nil {
                self.showSucess( "refreshUserSession Succeeded")
                self.consoleLog("refreshUserSession Succeeded")
                self.consoleLog("userprofile : \(userprofile?.description ?? "")")
            } else {
                self.showError("refreshUserSession failed")
                self.consoleLog("refreshUserSession failed")
            }
        })
    }
    
    func acceptTerms() {
        self.showProgressMessage("accepting terms and conditions...")
        Ingenico.sharedInstance()?.user.acceptTermsAndConditions({ (error) in
            self.dismissProgress()
            if error == nil {
                self.showSucess( "acceptTermsAndConditions Succeeded")
                self.consoleLog("acceptTermsAndConditions Succeeded")
            } else {
                self.showError("acceptTermsAndConditions failed")
                self.consoleLog("acceptTermsAndConditions failed")
            }
        })
    }
    
    
    
    
    //MARK: - Helper methods
    func showErrorMessage (_ errorMessage:String, andErrorTitle errortitle:String){
        
        let controller:UIAlertController = UIAlertController.init(title: errortitle, message: errorMessage, preferredStyle: .alert)
        let action:UIAlertAction = UIAlertAction.init(title: "OK", style: .default, handler: nil)
        controller.addAction(action)
        self.present(controller, animated: true, completion: nil)
    }
    
    func getStringFromTransactionType(_ type:IMSTransactionType)->String{
        
        let typeString:String
        switch type {
        case .TransactionTypeCreditSale:
            typeString = "Credit Sale"
        case .TransactionTypeCreditRefund:
            typeString = "Credit Refund"
        case .TransactionTypeCreditSaleVoid:
            typeString = "Credit Sale Reversal"
        case .TransactionTypeCreditAuth:
            typeString = "Credit Auth"
        case .TransactionTypeCreditAuthVoid:
            typeString = "Credit Auth Void"
        case .TransactionTypeCashSale:
            typeString = "Cash Sale"
        case .TransactionTypeCashRefund:
            typeString = "Cash Refund"
        case .TransactionTypeCreditAuthCompletion:
            typeString = "Auth Completion"
        case .TransactionTypeCreditAuthCompletionVoid:
            typeString = "Auth Completion Void"
        case .TransactionTypeCreditRefundVoid:
            typeString = "Credit Refund Void"
        case .TransactionTypeDebitSale:
            typeString = "Debit Sale"
        case .TransactionTypeDebitRefund:
            typeString = "Debit Refund"
        case .TransactionTypeDebitSaleVoid:
            typeString = "Debit Void"
        case .TransactionTypeDebitRefundVoid:
            typeString = "Debit Refund Void"
        case .TransactionTypeCreditSaleAdjust:
            typeString = "Credit Sale Adjust"
        case .TransactionTypeUnknown:
            typeString = "Unknown"
        default:
            typeString = "Unknown"
        }
        return typeString
    }
    
    func getStringFromTransactionStatus(_ status :IMSTransactionStatus)-> String{
        
        let statusString:String
        switch status {
        case .TransactionStatusActive:
            statusString = "Active"
        case .TransactionStatusCompleted:
            statusString = "Completed"
        case .TransactionStatusRefunded:
            statusString = "Refunded"
        case .TransactionStatusVoided:
            statusString = "Voided"
        case .TransactionStatusExpired:
            statusString = "Expired"
        case .TransactionStatusAccepted:
            statusString = "Accepted"
        case .TransactionStatusDeclined:
            statusString = "Declined"
        case .TransactionStatusAdjusted:
            statusString = "Adjusted"
        default:
            statusString = "Unknown"
            
        }
        return statusString
    }
    
    func getStringFromPOSEntryMode(_ type:IMSPOSEntryMode)->String{
        
        var typeString:String = ""
        switch type {
        case .POSEntryModeKeyed:
            typeString = "Keyed"
        case .POSEntryModeKeyedSwipeFail:
            typeString = "KeyedSwipefail"
        case .POSEntryModeContactlessEMV:
            typeString = "ContactlessEMV"
        case .POSEntryModeContactlessMSR:
            typeString = "ContactlessMSR"
        case .POSEntryModeMagStripe:
            typeString = "MagStripe"
        case .POSEntryModeContactEMV:
            typeString = "ContactEMV"
        case .POSEntryModeUnKnown:
            typeString = "Unknown"
        default: break
        }
        return typeString
    }
    
    
    func getStringFromTransactionResponseCode(_ type:IMSTransactionResponseCode)->String{
        
        var typeString:String = ""
        switch type {
        case .TransactionResponseCodeApproved:
            typeString = "Approved"
            break
        case .TransactionResponseCodeDeclined:
            typeString = "Declined"
            break
        case .TransactionResponseCodeUnKnown:
            typeString = "Unknown"
            break
        case .TransactionResponseCodeReferral:
            typeString = "Referral"
            break
        case .TransactionResponseCodeVerifyError:
            typeString = "VerifyError"
            break
        case .TransactionResponseCodePassPhraseExpired:
            typeString = "PassPhraseExpired"
            break
        case .TransactionResponseCodeInvalidPassPhrase:
            typeString = "InvalidPassPhrase"
            break
        case .TransactionResponseCodeBinaryDataResponse:
            typeString = "BinaryDataResponse"
            break
        default:
            typeString = "Unknown"
        }
        return typeString
    }
    
    
    func getStringFromCustomerInfo(_ cardHolderInfo:IMSCardholderInfo)->String{
        let resultString:NSMutableString = NSMutableString()
        if let val = cardHolderInfo.firstName{
            resultString.append(String.init(format: "  firstName:  %@\n",val))
        }
        if let val = cardHolderInfo.lastName{
            resultString.append(String.init(format: "  lastName:  %@\n",val))
        }
        if let val = cardHolderInfo.middleName{
            resultString.append(String.init(format: "  middleName:  %@\n",val))
        }
        if let val = cardHolderInfo.email{
            resultString.append(String.init(format: "  email:  %@\n",val))
        }
        if let val = cardHolderInfo.phone{
            resultString.append(String.init(format: "  phone:  %@\n",val))
        }
        if let val = cardHolderInfo.address1{
            resultString.append(String.init(format: "  address1:  %@\n",val))
        }
        if let val = cardHolderInfo.address2{
            resultString.append(String.init(format: "  address2:  %@\n",val))
        }
        if let val = cardHolderInfo.city{
            resultString.append(String.init(format: "  city:  %@\n",val))
        }
        if let val = cardHolderInfo.state{
            resultString.append(String.init(format: "  state:  %@\n",val))
        }
        return resultString as String
    }
    
    func getStringFromAmount(_ amount:IMSAmount)->String{
        let resultString:NSMutableString = NSMutableString()
        if let val = amount.currency{
            resultString.append(String.init(format: "  currency:  %@\n",val))
        }
        resultString.append(String.init(format: "  total:  %d\n",amount.total))
        resultString.append(String.init(format: "  subtotal:  %d\n",amount.subTotal))
        resultString.append(String.init(format: "  tax:  %d\n",amount.tax))
        resultString.append(String.init(format: "  discount:  %d\n",amount.discount))
        resultString.append(String.init(format: "  tip:  %d\n",amount.tip))
        return resultString as String
    }
    
    
    
    func getStringFromProduct(_ products:[IMSProduct])->String{
        
        let resultString: NSMutableString = NSMutableString()
        for product in products {
            
            if let val = product.name {
                resultString.append(String.init(format: "  name:  %@\n",val))
            }
            resultString.append(String.init(format: "  price:  %d\n",product.price))
            resultString.append(String.init(format: "  quantity:  %d\n",product.quantity))
            if let val = product.note {
                resultString.append(String.init(format: "  note:  %@\n",val))
            }
            resultString.append("\n")
        }
        return resultString as String
    }
    
    func getStringFromTransactionDetails(transaction:IMSTransactionHistoryDetail)->String{
        let resultString:NSMutableString = NSMutableString()
        resultString.append(String.init(format: "  transactionType:  %@\n",getStringFromTransactionType(transaction.transactionType)))
        resultString.append(String.init(format: "  transactionStatus:  %@\n",getStringFromTransactionStatus(transaction.transactionStatus)))
        resultString.append(String.init(format: "  posEntryMode:  %@\n",getStringFromPOSEntryMode(transaction.posEntryMode)))
        resultString.append(String.init(format: "  transactionResponseCode:  %@\n",getStringFromTransactionResponseCode(transaction.transactionResponseCode)))
        if let val = transaction.processorResponseCode{
            resultString.append(String.init(format: "  processorResponseCode:  %@\n",val))
        }
        if let val = transaction.authCode{
            resultString.append(String.init(format: "  authCode:  %@\n",val))
        }
        if let val = transaction.transactionId{
            resultString.append(String.init(format: "  gatewayTransactionId:  %@\n",val))
        }
        if let val = transaction.invoiceId{
            resultString.append(String.init(format: "  invoiceId:  %@\n",val))
        }
        if let val = transaction.clientTransactionId{
            resultString.append(String.init(format: "  clientTransactionId:  %@\n",val))
        }
        if let val = transaction.originalTransactionId{
            resultString.append(String.init(format: "  originalGatewayTransactionId:  %@\n",val))
        }
        if let val = transaction.processorTimestamp{
            resultString.append(String.init(format: "  processorTimestamp:  %@\n",val))
        }
        if let val = transaction.processorTimezone{
            resultString.append(String.init(format: "  processorTimezone:  %@\n",val))
        }
        if let val = transaction.deviceTimestamp{
            resultString.append(String.init(format: "  deviceTimestamp:  %@\n",val))
        }
        if let val = transaction.deviceTimezone{
            resultString.append(String.init(format: "  deviceTimezone:  %@\n",val))
        }
        if let val = transaction.paymentServiceTimestamp{
            resultString.append(String.init(format: "  paymentServiceTimestamp:  %@\n",val))
        }
        if let val = transaction.paymentServiceTimezone{
            resultString.append(String.init(format: "  paymentServiceTimezone:  %@\n",val))
        }
        if let val = transaction.cardHolderName{
            resultString.append(String.init(format: "  cardHolderName:  %@\n",val))
        }
        resultString.append(String.init(format: "  approvedAmount:  %d\n",transaction.approvedAmount))
        
        resultString.append(String.init(format: "  cardLastDigits:  %@\n",getStringFromCardType(type: transaction.cardType)))
        if let val = transaction.redactedCardNumber{
            resultString.append(String.init(format: "  redactedCardNumber:  %@\n",val))
        }
        resultString.append(String.init(format: "  refundableAmount:  %d\n",transaction.refundableAmount))
        if let val = transaction.clerkDisplay{
            resultString.append(String.init(format: "  clerkDisplay:  %@\n",val))
        }
        if let val = transaction.merchantInvoiceId{
            resultString.append(String.init(format: "  merchantInvoiceId:  %@\n",val))
        }
        if let val = transaction.transactionNote{
            resultString.append(String.init(format: "  transactionNote:  %@\n",val))
        }
        if let val = transaction.customData{
            resultString.append(String.init(format: "  customData:  %@\n",val))
        }
        if (transaction.cardholderInfo != nil) && (getStringFromCustomerInfo(transaction.cardholderInfo).count > 0) {
            resultString.append(String.init(format: "\n  cardholderInfo:  \n%@",getStringFromCustomerInfo(transaction.cardholderInfo)))
        }
        if (transaction.amount != nil) && getStringFromAmount(transaction.amount).count > 0 {
            resultString.append(String.init(format: "\n  amount:  \n%@",getStringFromAmount(transaction.amount)))
        }
        if let val:[IMSProduct] = transaction.products as! [IMSProduct]? {
            resultString.append(String.init(format: "\n  productList:  \n%@",getStringFromProduct(val)))
        }
        return resultString as String
    }
    
    
    
    
    func getStringFromSecurityQuestionsArray(questions:[IMSSecurityQuestion])->String{
        let resultVal:NSMutableString = NSMutableString()
        resultVal.append("Get Security Questions Succeeded\n")
        for question in questions {
            resultVal.append(String(format: " Id : %d\n",question.questionId))
            resultVal.append(String(format: " Question : %@\n",question.question))
        }
        return resultVal as String
    }
    
    func getStringFromCardType(type:IMSCardType)->String{
        
        let typeString :String
        switch type {
        case .CardTypeAMEX:
            typeString = "AMEX"
        case .CardTypeDiners:
            typeString = "Diners"
        case .CardTypeDiscover:
            typeString = "Discover"
        case .CardTypeJCB:
            typeString = "JCB"
        case .CardTypeMasterCard:
            typeString = "MasterCard"
        case .CardTypeVISA:
            typeString = "VISA"
        case .CardTypeMaestro:
            typeString = "Maestro"
        default:
            typeString = "Unknown"
        }
        return typeString as String
    }
    
    
    
    //MARK: - UI Tableview delegate
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let sectionTitle = (staticDataArray[section] as NSDictionary).allKeys[0] as! String
        return staticDataArray[section][sectionTitle]!.count
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.section {
        case 0:
            switch indexPath.row {
            case 0:
                sendEmailReceipt()
            case 1:
                setEmail()
            default:
                break
            }
        case 1:
            switch indexPath.row {
            case 0:
                getSecurityQuestions()
            case 1:
                setSecurityQuestions()
            default:
                break
            }
        case 2:
            switch indexPath.row {
            case 0:
                getEmailReceiptInfo()
            case 1:
                setEmailReceiptInfo()
            case 2:
                getProcessorInfo()
            default:
                break
            }
        case 3:
            switch indexPath.row {
            case 0:
                changePW()
            case 1:
                forgotPassword()
            default:
                break
            }
        case 4:
            switch indexPath.row {
            case 0:
                filterTransactionHistory()
            case 1:
                filterInvoiceHistory()
            case 2:
                getTransactionDetails()
            case 3:
                getTransactionHistory()
            default:
                break
            }
        case 5:
            switch indexPath.row {
            case 0:
                updateTransaction()
            case 1:
                uploadSignature()
            default:
                break
            }
        case 6:
            switch indexPath.row {
            case 0:
                refreshUserSession()
            case 1:
                acceptTerms()
            default:
                break
            }
        default:
            break
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.merchantAPITableView.dequeueReusableCell(withIdentifier: "Cell")! as UITableViewCell
        let sectionTitle = (staticDataArray[indexPath.section] as NSDictionary).allKeys[0] as! String
        cell.textLabel?.text = staticDataArray[indexPath.section][sectionTitle]?[indexPath.row]
        cell.textLabel?.textAlignment = .center
        cell.selectionStyle = .none;
        return cell
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return staticDataArray.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        let sectionTitle = (staticDataArray[section] as NSDictionary).allKeys[0] as! String
        return sectionTitle
    }
  
    
}
