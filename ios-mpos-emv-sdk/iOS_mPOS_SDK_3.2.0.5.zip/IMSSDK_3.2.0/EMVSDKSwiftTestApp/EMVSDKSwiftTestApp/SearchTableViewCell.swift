//
//  SearchTableViewCell.swift
//  EMVSDKSwiftTestApp
//
//  Created by Mallikarjun Patil on 9/9/16.
//  Copyright © 2016 Ingenico. All rights reserved.
//

import UIKit

class SearchTableViewCell: UITableViewCell {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var communicationLabel: UILabel!
    @IBOutlet weak var identifierLabel: UILabel!
}
