//
//  UIAlertControllerUtility.swift
//  EMVSDKSwiftTestApp
//
//  Created by Abhiram Dinesh on 5/5/20.
//  Copyright © 2020 Ingenico. All rights reserved.
//

import UIKit

extension UIAlertController : UITextFieldDelegate {
    
    func addCheckBoxWithTitle(_ title: String, configurationHandler: ((UIButton) -> Void)) {
        let checkbox = UIButton(type: UIButton.ButtonType.custom)
        checkbox.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        checkbox.addTarget(self, action: #selector(buttonPressed), for: .touchUpInside)
        checkbox.contentMode = .scaleAspectFit
        checkbox.reversesTitleShadowWhenHighlighted = true
        checkbox.setTitle("🔲", for: .normal)
        checkbox.setTitle("☑️", for: .selected)
        checkbox.setTitle("☑️", for: .highlighted)
        checkbox .adjustsImageWhenHighlighted = true
        self .addTextField { (textField) in
            textField.delegate = self
            textField.text = title
            textField.rightViewMode = .always
            textField.rightView = checkbox
        }
        configurationHandler(checkbox)
    }
    
    @objc func buttonPressed(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
    }
     
    public func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        return false
    }
    
}
