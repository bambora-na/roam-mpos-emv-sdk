/*
 //////////////////////////////////////////////////////////////////////////////
 //
 // Copyright (c) 2015 - 2018. All Rights Reserved, Ingenico Inc.
 //
 //////////////////////////////////////////////////////////////////////////////
 */


#import "RUAPairingListener.h"

#ifndef RUAAudioJackPairingListener_h
#define RUAAudioJackPairingListener_h


@protocol RUAAudioJackPairingListener <RUAPairingListener>
@end


#endif /* RUAAudioJackPairingListener_h */
