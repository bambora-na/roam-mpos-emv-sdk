/*
 //////////////////////////////////////////////////////////////////////////////
 //
 // Copyright (c) 2015 - 2019. All Rights Reserved, Ingenico Inc.
 //
 //////////////////////////////////////////////////////////////////////////////
 */

#import <UIKit/UIKit.h>

@interface RUALedPairingView : UIView

- (instancetype)initWithFrame:(CGRect)frame;
-(void) showSequences : (NSArray *) sequences;

@end

