/*
* //////////////////////////////////////////////////////////////////////////////
* //
* // Copyright © 2015-2021 Worldline SMB US Inc. All Rights Reserved.
* //
* //////////////////////////////////////////////////////////////////////////////
*/

#import <Foundation/Foundation.h>
#import "IMSEnum.h"
/**
* This immutable class contains information about the current SDK capabilities.
*/
@interface IMSCapabilities : NSObject
/*!
 * Returns if the SDK is store and forward capable for the current user.
 * @return true  - if capable
 *         false - otherwise
 */
@property (readonly) bool storeAndForwardCapable;

/*!
 * Returns if the SDK is EMV capable
 * @return true  - if capable
 *         false - otherwise
 */
@property (readonly) bool EMVCapable;

/*!
 * Returns the firmware update action
 * @return IMSFirmwareUpdateAction
 */
@property (readonly) IMSFirmwareUpdateAction firmwareUpdateAction;

/*!
 * Indicates if the EMV configuration of the connected payment device is up to date with the latest configuration on the Worldline ROAM backend.
 * Unlike checkDeviceSetup() where the response (isSetupRequired = true) will revert the device to MSR only thus mandating a device setup,
 * this flag can be considered as a soft error which indicates that device setup is recommended without affecting the EMV capability of the reader.
 * It is recommended to check this flag after login/refreshUserSession and do a device setup if this method returns false.
 * @return true  - up to date
 *         false - out of date
 */
@property (readonly) bool isEMVConfigUptoDate;

/*!
 * Returns the remaining amount balance in cents that the SDK is capable of storing before it reaches the limit set for this merchant (see IMSConfiguration.storeAndForwardDollarLimit). Please note that cash and void stored transactions are excluded from this limit calculation. <br>
 * @return
 * -2 - Not Applicable (if Store and forward is not enabled or there is no limit and the merchant can store any number of transactions) <br>
 * -1 - some error has occured during computation <br>
 * 0 - stored transactions amount is equal or exceeded the limit (in case of migration with stored transactions exceeding the limit), hence SDK blocks from storing further transactions <br>
 * positive value - SDK allows storing transactions if the amount is less than or equal to this retuned value <br>
 */
@property (readonly) int storedTransactionsAmountLimit;

- (id)  initWithStoreAndForwardCapable:(bool)storeAndForwardCapable EMVCapable:(bool)EMVCapable FirmwareUpdateOption:(IMSFirmwareUpdateAction)firmwareUpdateAction AndisEMVConfigUptoDate:(bool)deviceSetupRecommended andStoredTransactionsAmountLimit:(int)storedTransactionsAmountLimit;

@end

