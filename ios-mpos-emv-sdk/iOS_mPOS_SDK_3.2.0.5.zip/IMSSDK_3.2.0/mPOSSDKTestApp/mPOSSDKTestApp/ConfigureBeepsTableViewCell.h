//
//  ConfigureBeepsTableViewCell.h
//  mPOSSDKTestApp
//
//  Created by Bin Lang on 9/25/17.
//  Copyright © 2017 RoamData. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ConfigureBeepsTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *categoryLabel;
@property (weak, nonatomic) IBOutlet UISwitch *toggle;
@end
