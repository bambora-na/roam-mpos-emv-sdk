//
//  ConfigureBeepsTableViewCell.m
//  mPOSSDKTestApp
//
//  Created by Bin Lang on 9/25/17.
//  Copyright © 2017 RoamData. All rights reserved.
//

#import "ConfigureBeepsTableViewCell.h"

@implementation ConfigureBeepsTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
