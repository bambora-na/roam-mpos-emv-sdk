//
//  Constants.h
//  mPOSSDKTestApp
//
//  Copyright © 2019 RoamData. All rights reserved.
//

#import <Foundation/Foundation.h>

#ifndef Constants_h
#define Constants_h

static NSString *CLIENT_VERSION = @"4.2.3";

static NSString * API_KEY = @"Set your API key here";

static NSString * BASE_URL = @"https://uatmcm.roamdata.com";

#endif /* Constants_h */
