/*
* //////////////////////////////////////////////////////////////////////////////
* //
* // Copyright © Ingenico Retail Enterprise US Inc., All Rights Reserved.
* //
* //////////////////////////////////////////////////////////////////////////////
*/

#import <UIKit/UIKit.h>

@class DropDownMenu;

@protocol DropDownMenuDelegate
- (void) delegateMethod: (DropDownMenu *) sender;
@end

@interface DropDownMenu : UIView <UITableViewDelegate, UITableViewDataSource> {
    NSString *animationDirection;
}

@property (nonatomic, retain) id <DropDownMenuDelegate> delegate;
@property (nonatomic, retain) NSString *animationDirection;

- (void) hideDropDown:(UITextField *)textfield;
- (void) addItem:(NSString *)item;
- (id)showDropDown:(UITextField *)textfield withHeight:(CGFloat *)height withArray:(NSArray *)arr along:(NSString *)direction;
@end
