//
//  PaymentDeviceViewController.h
//  mPOSSDKTestApp
//
//  Copyright © 2016 RoamData. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IMSBaseViewController.h"

@interface HistoryFilterViewController : IMSBaseViewController

@property (weak, nonatomic) IBOutlet UITableView *pickTableView;
@property (strong ,nonatomic) void (^callback)(IMSHistoryQueryBuilder *builder);

@end
