//
//  PaymentDeviceViewController.h
//  mPOSSDKTestApp
//
//  Copyright © 2016 RoamData. All rights reserved.
//

#import "HistoryFilterViewController.h"
#import "InputFieldsTableViewCell.h"

#define TransactionType 1
#define CardType 2
#define TransactionStatus 3
#define OptionalFields 4
#define PaymentSource 5
#define Other 6

@interface HistoryFilterViewController ()<UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource>{
    NSArray *inputFields;
    NSArray *inputPlaceHolders;
    NSArray *inputAccessibilityLabels;
    NSArray *transactionTypes;
    NSArray *cardTypes;
    NSArray *transactionStatus;
    NSArray *posEntrySources;
    NSArray *optionalFields;
    NSArray *others;
    NSDateFormatter *dateFormatter;
    UIDatePicker *datePicker;
    NSMutableDictionary *selectedItems;
    NSArray *dataSource;
    NSArray *headerTitle;
    IMSHistoryQueryBuilder *builder;
    NSMutableArray *textFieldData;
}

@end

@implementation HistoryFilterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    builder = [[IMSHistoryQueryBuilder alloc] init];
    _pickTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    _pickTableView.tableHeaderView = [[UIView alloc] initWithFrame:CGRectZero];
    dateFormatter = [[NSDateFormatter alloc] init];
    
    selectedItems = [[NSMutableDictionary alloc] initWithObjectsAndKeys:
                     [[NSMutableArray alloc] init],[NSNumber numberWithInt:TransactionType],
                     [[NSMutableArray alloc] init],[NSNumber numberWithInt:CardType],
                     [[NSMutableArray alloc] init],[NSNumber numberWithInt:TransactionStatus],
                     [[NSMutableArray alloc] init],[NSNumber numberWithInt:OptionalFields],
                     [[NSMutableArray alloc] init],[NSNumber numberWithInt:PaymentSource],
                     [[NSMutableArray alloc] init],[NSNumber numberWithInt:Other],nil];
    
    inputAccessibilityLabels = [[NSMutableArray alloc] initWithObjects:
                   @"vc_historyfilter_start_date",
                   @"vc_historyfilter_end_date",
                   @"vc_historyfilter_past_days",
                   @"vc_historyfilter_page_size",
                   @"vc_historyfilter_page_number",
                   @"vc_historyfilter_clerk_id",
                   @"vc_historyfilter_invoice_id",
                   @"vc_historyfilter_transaction_id",
                   @"vc_historyfilter_transaction_guid",
                   @"vc_historyfilter_customer_name",
                   @"vc_historyfilter_customer_email",
                   @"vc_historyfilter_cardHolder_name",
                   @"vc_historyfilter_auth_amount",
                   @"vc_historyfilter_last_four",
                   @"vc_historyfilter_invoice_amount",
                   @"vc_historyfilter_transaction_note",
                   @"vc_historyfilter_merchant_invoice_id",
                   @"vc_historyfilter_transacted_by",
                   @"vc_historyfilter_auth_code",
                   @"vc_historyfilter_batch_number",
                   @"vc_historyfilter_order_number",
                   nil];
    
    inputPlaceHolders = [[NSMutableArray alloc] initWithObjects:
                         @"MM/dd/YYYY (Optional)",
                         @"MM/dd/YYYY (Optional)",
                         @"Numeric (Optional)",
                         @"Numeric",
                         @"Numeric",
                         @"Optional",
                         @"Optional",
                         @"Optional",
                         @"Optional",
                         @"Optional",
                         @"Optional",
                         @"Optional",
                         @"Numeric (Optional)",
                         @"Optional",
                         @"Numeric (Optional)",
                         @"Optional",
                         @"Optional",
                         @"Optional",
                         @"Optional",
                         @"Numeric (Optional)",
                         @"Numeric (Optional)",
                         nil];
    
    inputFields = [[NSMutableArray alloc] initWithObjects:
                                @"StartDate",
                                @"EndDate",
                                @"PastDays",
                                @"PageSize",
                                @"PageNumber",
                                @"ClerkID",
                                @"InvoiceID",
                                @"TransactionID",
                                @"TransactionGuid",
                                @"CustomerName",
                                @"CustomerEmail",
                                @"CardHolderName",
                                @"AuthAmountInCents",
                                @"LastFourDigitsOfCard",
                                @"InvoiceAmountInCents",
                                @"TransactionNote",
                                @"MerchantInvoiceID",
                                @"TransactedBy",
                                @"AuthCode",
                                @"BatchNumber",
                                @"OrderNumber",
                                nil];
    
    transactionTypes = [[NSMutableArray alloc] initWithObjects:
                        @"All",
                        @"CreditSale",
                        @"CashSale",
                        @"CreditRefund",
                        @"CashRefund",
                        @"CreditSaleVoid",
                        @"CreditAuth",
                        @"CreditAuthVoid",
                        @"CreditAuthCompletion",
                        @"CreditAuthCompletionVoid",
                        @"DebitSale",
                        @"DebitSaleVoid",
                        @"DebitRefund",
                        @"CreditRefundVoid",
                        @"DebitRefundVoid",
                        @"CreditForceSale",
                        @"CreditForceSaleVoid",
                        @"CreditBalanceInquiry",
                        @"TokenEnrollment",
                        @"CreditAuthAdjust",
                        @"CreditAuthAdjustVoid",
                        @"CreditSaleAdjust",
                        @"CreditSaleAdjustVoid",
                        @"DebitBalanceInquiry",
                        @"AVSOnly",
                        @"CreditAuthPartialVoid",
                        @"CreditAuthAdjustPartialVoid",
                        @"Unknown",
                        nil];
    
    cardTypes = [[NSMutableArray alloc] initWithObjects:
                 @"All",
                 @"Visa",
                 @"MasterCard",
                 @"Maestro",
                 @"Diners",
                 @"Discover",
                 @"AMEX",
                 @"JCB",
                 nil];
    
    transactionStatus = [[NSMutableArray alloc] initWithObjects:
                         @"All",
                         @"Active",
                         @"Completed",
                         @"Refunded",
                         @"Voided",
                         @"Expired",
                         @"Accepted",
                         @"Adjusted",
                         @"Unknown",
                         nil];
    
    optionalFields = [[NSMutableArray alloc] initWithObjects:
                      @"All",
                      @"TokenData", nil];
    
    posEntrySources = [[NSMutableArray alloc] initWithObjects:
                      @"All",
                      @"Mobile",
                      @"Secure",
                      @"Device",
                      @"Direct",
                      @"Unknown",
                      nil];
                      
    others = [[NSMutableArray alloc] initWithObjects:
                      @"Include Submerchant Transactions",
                      nil];
    
    dataSource = [[NSArray alloc] initWithObjects:
                  inputFields,
                  transactionTypes,
                  cardTypes,
                  transactionStatus,
                  optionalFields,
                  posEntrySources,
                  others, nil];
    
    headerTitle = [[NSArray alloc] initWithObjects:
                   @"Inputs",
                   @"TransactionTypes",
                   @"CardTypes",
                   @"TransactionStatus",
                   @"OptionalFields",
                   @"PaymentSources",
                   @"Other", nil];
    textFieldData = [[NSMutableArray alloc] initWithCapacity:inputFields.count];
    
    for(int i = 0; i < inputFields.count; i++) {
        textFieldData[i] = @"";
    }
    
    // Set defaults for required fields
    textFieldData[2] = @"5";
    builder.pastDays = 5;
    textFieldData[3] = @"20";
    builder.pageSize = 20;
    textFieldData[4] = @"0";
    builder.pageNumber = 0;
    
    dateFormatter.dateFormat = @"MM/dd/YYYY";
    datePicker = [[UIDatePicker alloc] init];
    datePicker.datePickerMode = UIDatePickerModeDate;
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Search" style:UIBarButtonItemStylePlain target:self action:@selector(searchHistory)];
    self.navigationItem.rightBarButtonItem.accessibilityLabel = @"vc_historyfilter_search";
    [self.navigationItem.rightBarButtonItem setTitleTextAttributes:@{
                                                                     NSFontAttributeName: [UIFont fontWithName:@"TrebuchetMS-Bold" size:16.0],
                                                                     NSForegroundColorAttributeName: [UIColor darkGrayColor]
                                                                     } forState:UIControlStateNormal];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"Goback"] style:UIBarButtonItemStylePlain target:self action:@selector(goBack)];
    [self.navigationItem.leftBarButtonItem setAccessibilityLabel:@"back_btn"];
    self.navigationItem.leftBarButtonItem.tintColor = [UIColor darkGrayColor];
}

- (void)viewDidLayoutSubviews{
    [super viewDidLayoutSubviews];
    _pickTableView.frame = CGRectMake(0, 0, _pickTableView.frame.size.width, _pickTableView.frame.size.height+[UIApplication sharedApplication].statusBarFrame.size.height+self.navigationController.navigationBar.frame.size.height);
}

#pragma UITextFieldDelegate Implementation
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self.view endEditing:NO];
    return YES;
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    textFieldData[textField.tag] = textField.text;
    if(textField.tag == 2){
        builder.pastDays = textField.text?[textField.text intValue]:0;
        textFieldData[0] = @"";
        textFieldData[1] = @"";
        builder.startDate = nil;
        builder.endDate = nil;
    }
    else if(textField.tag == 3){
        builder.pageSize = textField.text?[textField.text intValue]:0;
    }
    else if(textField.tag == 4){
        builder.pageNumber = textField.text?[textField.text intValue]:0;
    }
    else if(textField.tag == 5){
        builder.clerkId = textField.text;
    }
    else if(textField.tag == 6){
        builder.invoiceId = textField.text;
    }
    else if(textField.tag == 7){
        builder.transactionID = textField.text;
    }
    else if(textField.tag == 8){
        builder.transactionGuid = textField.text;
    }
    else if(textField.tag == 9){
        builder.customerName = textField.text;
    }
    else if(textField.tag == 10){
        builder.customerEmail = textField.text;
    }
    else if(textField.tag == 11){
        builder.cardHolderName = textField.text;
    }
    else if(textField.tag == 12){
        builder.authAmountInCents = textField.text?[textField.text intValue]:0;
    }
    else if(textField.tag == 13){
        builder.lastFourDigitsOfCard = textField.text;
    }
    else if(textField.tag == 14){
        builder.invoiceAmountInCents = textField.text?[textField.text intValue]:0;
    }
    else if(textField.tag == 15){
        builder.transactionNote = textField.text;
    }
    else if(textField.tag == 16){
        builder.merchantInvoiceID = textField.text;
    }
    else if(textField.tag == 17){
        builder.transactedBy = textField.text;
    }
    else if(textField.tag == 18){
        builder.authCode = textField.text;
    }
    else if(textField.tag == 19){
        builder.batchNumber = textField.text;
    }
    else if(textField.tag == 20){
        builder.orderNumber = textField.text;
    }
    [_pickTableView reloadData];
    return YES;
}

#pragma UITableViewDelegate,UITableViewDataSource Implementation

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.bounds.size.width, 35)];
    UILabel *sectionLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 0, tableView.bounds.size.width-20, 35)];
    sectionLabel.text = [headerTitle objectAtIndex:section];
    sectionLabel.font = [UIFont fontWithName:@"Palatino-Italic" size:16];
    [headerView setBackgroundColor:[UIColor lightGrayColor]];
    [headerView addSubview:sectionLabel];
    return headerView;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return dataSource.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[dataSource objectAtIndex:section] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if(indexPath.section == 0){
        UIBarButtonItem *space=[[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
        InputFieldsTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"inputFieldCell"];
        cell.titleLabel.text = [[dataSource objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
        cell.titleLabel.textColor = [UIColor darkGrayColor];
        cell.titleLabel.font = [UIFont fontWithName:@"Palatino" size:14];
        cell.inputTextField.tag = indexPath.row;
        NSString *text = [textFieldData objectAtIndex:indexPath.row];
        cell.inputTextField.text = text;
        if (text.length == 0) {
            cell.inputTextField.placeholder = [inputPlaceHolders objectAtIndex:indexPath.row];
        }
        cell.inputTextField.accessibilityLabel = [ inputAccessibilityLabels objectAtIndex:indexPath.row];
        if(indexPath.row == 0){
            UIToolbar *startDateToolBar=[[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 44)];
            [startDateToolBar setTintColor:[UIColor grayColor]];
            [startDateToolBar setItems:[NSArray arrayWithObjects:space,[[UIBarButtonItem alloc]initWithTitle:@"Done" style:UIBarButtonItemStylePlain target:self action:@selector(confirmStartDate)], nil]];
            cell.inputTextField.inputView = datePicker;
            cell.inputTextField.inputAccessoryView = startDateToolBar;
        }
        else if(indexPath.row == 1){
            UIToolbar *endDateToolBar=[[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 44)];
            [endDateToolBar setTintColor:[UIColor grayColor]];
            [endDateToolBar setItems:[NSArray arrayWithObjects:space,[[UIBarButtonItem alloc]initWithTitle:@"Done" style:UIBarButtonItemStylePlain target:self action:@selector(confirmEndDate)], nil]];
            cell.inputTextField.inputView = datePicker;
            cell.inputTextField.inputAccessoryView = endDateToolBar;
        }
        else if(indexPath.row == 2||
                indexPath.row == 3||
                indexPath.row == 4||
                indexPath.row == 12||
                indexPath.row == 14||
                indexPath.row == 19||
                indexPath.row == 20){
            cell.inputTextField.inputView = nil;
            cell.inputTextField.inputAccessoryView = nil;
            cell.inputTextField.delegate = self;
            cell.inputTextField.keyboardType = UIKeyboardTypeNumberPad;
        }
        else{
            cell.inputTextField.inputView = nil;
            cell.inputTextField.inputAccessoryView = nil;
            cell.inputTextField.delegate = self;
            cell.inputTextField.keyboardType = UIKeyboardTypeASCIICapable;
        }
        return cell;
    }
    else{
        static NSString *CellIdentifier = @"HistoryFilterAPICell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        }
        cell.textLabel.text = [[dataSource objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
        cell.accessibilityLabel = [[dataSource objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
        cell.textLabel.textColor = [UIColor darkGrayColor];
        cell.textLabel.font = [UIFont fontWithName:@"Palatino" size:14];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        if ([[selectedItems objectForKey:[NSNumber numberWithInteger:indexPath.section]] indexOfObject:[NSNumber numberWithInteger:indexPath.row]] != NSNotFound) {
            [cell setAccessoryType:UITableViewCellAccessoryCheckmark];
        } else {
            [cell setAccessoryType:UITableViewCellAccessoryNone];
        }
        return cell;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSUInteger index = [[selectedItems objectForKey:[NSNumber numberWithInteger:indexPath.section]] indexOfObject:[NSNumber numberWithInteger:indexPath.row]];
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    if (index != NSNotFound) {
        [[selectedItems objectForKey:[NSNumber numberWithInteger:indexPath.section]] removeObjectAtIndex:index];
        [cell setAccessoryType:UITableViewCellAccessoryNone];
    } else {
        if(indexPath.row == 0){
            [[selectedItems objectForKey:[NSNumber numberWithInteger:indexPath.section]] removeAllObjects];
        }
        else{
            index = [[selectedItems objectForKey:[NSNumber numberWithInteger:indexPath.section]] indexOfObject:[NSNumber numberWithInteger:0]];
            if(index != NSNotFound){
                [[selectedItems objectForKey:[NSNumber numberWithInteger:indexPath.section]] removeObjectAtIndex:index];
            }
        }
        [[selectedItems objectForKey:[NSNumber numberWithInteger:indexPath.section]] addObject:[NSNumber numberWithInteger:indexPath.row]];
        [_pickTableView reloadData];
    }
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}

#pragma Helper Methods
- (void)confirmStartDate{
    [self.view endEditing:YES];
    textFieldData[0] = [dateFormatter stringFromDate:datePicker.date];
    builder.startDate = [dateFormatter stringFromDate:datePicker.date];
    textFieldData[2] = @"";
    builder.pastDays = 0;
    [self.pickTableView reloadData];
}

- (void)confirmEndDate{
    [self.view endEditing:YES];
    textFieldData[1] = [dateFormatter stringFromDate:datePicker.date];
    builder.endDate = [dateFormatter stringFromDate:datePicker.date];
    textFieldData[2] = @"";
    builder.pastDays = 0;
    [self.pickTableView reloadData];
}

- (void)goBack{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)searchHistory{
    [self.view endEditing:YES];
    if([selectedItems objectForKey:[NSNumber numberWithInt:TransactionType]]){
        NSArray *type = [selectedItems objectForKey:[NSNumber numberWithInt:TransactionType]];
        if(![type containsObject:[NSNumber numberWithInt:0]]){
            NSMutableArray *types = [[NSMutableArray alloc] init];
            if([type containsObject:[NSNumber numberWithInt:1]]){
                [types addObject:[[NSNumber alloc] initWithInt:TransactionTypeCreditSale]];
            }
            if([type containsObject:[NSNumber numberWithInt:2]]){
                [types addObject:[[NSNumber alloc] initWithInt:TransactionTypeCashSale]];
            }
            if([type containsObject:[NSNumber numberWithInt:3]]){
                [types addObject:[[NSNumber alloc] initWithInt:TransactionTypeCreditRefund]];
            }
            if([type containsObject:[NSNumber numberWithInt:4]]){
                [types addObject:[[NSNumber alloc] initWithInt:TransactionTypeCashRefund]];
            }
            if([type containsObject:[NSNumber numberWithInt:5]]){
                [types addObject:[[NSNumber alloc] initWithInt:TransactionTypeCreditSaleVoid]];
            }
            if([type containsObject:[NSNumber numberWithInt:6]]){
                [types addObject:[[NSNumber alloc] initWithInt:TransactionTypeCreditAuth]];
            }
            if([type containsObject:[NSNumber numberWithInt:7]]){
                [types addObject:[[NSNumber alloc] initWithInt:TransactionTypeCreditAuthVoid]];
            }
            if([type containsObject:[NSNumber numberWithInt:8]]){
                [types addObject:[[NSNumber alloc] initWithInt:TransactionTypeCreditAuthCompletion]];
            }
            if([type containsObject:[NSNumber numberWithInt:9]]){
                [types addObject:[[NSNumber alloc] initWithInt:TransactionTypeCreditAuthCompletionVoid]];
            }
            if([type containsObject:[NSNumber numberWithInt:10]]){
                [types addObject:[[NSNumber alloc] initWithInt:TransactionTypeDebitSale]];
            }
            if([type containsObject:[NSNumber numberWithInt:11]]){
                [types addObject:[[NSNumber alloc] initWithInt:TransactionTypeDebitSaleVoid]];
            }
            if([type containsObject:[NSNumber numberWithInt:12]]){
                [types addObject:[[NSNumber alloc] initWithInt:TransactionTypeDebitRefund]];
            }
            if([type containsObject:[NSNumber numberWithInt:13]]){
                [types addObject:[[NSNumber alloc] initWithInt:TransactionTypeCreditRefundVoid]];
            }
            if([type containsObject:[NSNumber numberWithInt:14]]){
                [types addObject:[[NSNumber alloc] initWithInt:TransactionTypeDebitRefundVoid]];
            }
            if([type containsObject:[NSNumber numberWithInt:15]]){
                [types addObject:[[NSNumber alloc] initWithInt:TransactionTypeCreditForceSale]];
            }
            if([type containsObject:[NSNumber numberWithInt:16]]){
                [types addObject:[[NSNumber alloc] initWithInt:TransactionTypeCreditForceSaleVoid]];
            }
            if([type containsObject:[NSNumber numberWithInt:17]]){
                [types addObject:[[NSNumber alloc] initWithInt:TransactionTypeCreditBalanceInquiry]];
            }
            if([type containsObject:[NSNumber numberWithInt:18]]){
                [types addObject:[[NSNumber alloc] initWithInt:TransactionTypeTokenEnrollment]];
            }
            if([type containsObject:[NSNumber numberWithInt:19]]){
                [types addObject:[[NSNumber alloc] initWithInt:TransactionTypeCreditAuthAdjust]];
            }
            if([type containsObject:[NSNumber numberWithInt:20]]){
                [types addObject:[[NSNumber alloc] initWithInt:TransactionTypeCreditAuthAdjustVoid]];
            }
            if([type containsObject:[NSNumber numberWithInt:21]]){
                [types addObject:[[NSNumber alloc] initWithInt:TransactionTypeCreditSaleAdjust]];
            }
            if([type containsObject:[NSNumber numberWithInt:22]]){
                [types addObject:[[NSNumber alloc] initWithInt:TransactionTypeCreditSaleAdjustVoid]];
            }
            if([type containsObject:[NSNumber numberWithInt:23]]){
                [types addObject:[[NSNumber alloc] initWithInt:TransactionTypeDebitBalanceInquiry]];
            }
            if([type containsObject:[NSNumber numberWithInt:24]]){
                [types addObject:[[NSNumber alloc] initWithInt:TransactionTypeAVSOnly]];
            }
            if([type containsObject:[NSNumber numberWithInt:25]]){
                [types addObject:[[NSNumber alloc] initWithInt:TransactionTypeCreditAuthPartialVoid]];
            }
            if([type containsObject:[NSNumber numberWithInt:26]]){
                [types addObject:[[NSNumber alloc] initWithInt:TransactionTypeCreditAuthAdjustPartialVoid]];
            }
            if([type containsObject:[NSNumber numberWithInt:27]]){
                [types addObject:[[NSNumber alloc] initWithInt:TransactionTypeUnknown]];
            }
            builder.transactionTypes = types;
        }
    }
    if([selectedItems objectForKey:[NSNumber numberWithInt:CardType]]){
        NSArray *type = [selectedItems objectForKey:[NSNumber numberWithInt:CardType]];
        if(![type containsObject:[NSNumber numberWithInt:0]]){
            NSMutableArray *types = [[NSMutableArray alloc] init];
            if([type containsObject:[NSNumber numberWithInt:1]]){
                [types addObject:[[NSNumber alloc] initWithInt:CardTypeVISA]];
            }
            if([type containsObject:[NSNumber numberWithInt:2]]){
                [types addObject:[[NSNumber alloc] initWithInt:CardTypeMasterCard]];
            }
            if([type containsObject:[NSNumber numberWithInt:3]]){
                [types addObject:[[NSNumber alloc] initWithInt:CardTypeMaestro]];
            }
            if([type containsObject:[NSNumber numberWithInt:4]]){
                [types addObject:[[NSNumber alloc] initWithInt:CardTypeDiners]];
            }
            if([type containsObject:[NSNumber numberWithInt:5]]){
                [types addObject:[[NSNumber alloc] initWithInt:CardTypeDiscover]];
            }
            if([type containsObject:[NSNumber numberWithInt:6]]){
                [types addObject:[[NSNumber alloc] initWithInt:CardTypeAMEX]];
            }
            if([type containsObject:[NSNumber numberWithInt:7]]){
                [types addObject:[[NSNumber alloc] initWithInt:CardTypeJCB]];
            }
            builder.cardTypes = types;
        }
    }
    if([selectedItems objectForKey:[NSNumber numberWithInt:TransactionStatus]]){
        NSArray *stauts = [selectedItems objectForKey:[NSNumber numberWithInt:TransactionStatus]];
        if([stauts containsObject:[NSNumber numberWithInt:0]]){
            builder.transactionStatuses = [[NSArray alloc] initWithObjects:
                                           [[NSNumber alloc] initWithInt:TransactionStatusActive],
                                           [[NSNumber alloc] initWithInt:TransactionStatusCompleted],
                                           [[NSNumber alloc] initWithInt:TransactionStatusRefunded],
                                           [[NSNumber alloc] initWithInt:TransactionStatusVoided],
                                           [[NSNumber alloc] initWithInt:TransactionStatusExpired],
                                           [[NSNumber alloc] initWithInt:TransactionStatusAccepted],
                                           [[NSNumber alloc] initWithInt:TransactionStatusAdjusted],nil];
        }
        else{
            NSMutableArray *statuses = [[NSMutableArray alloc] init];
            if([stauts containsObject:[NSNumber numberWithInt:1]]){
                [statuses addObject:[[NSNumber alloc] initWithInt:TransactionStatusActive]];
            }
            if([stauts containsObject:[NSNumber numberWithInt:2]]){
                [statuses addObject:[[NSNumber alloc] initWithInt:TransactionStatusCompleted]];
            }
            if([stauts containsObject:[NSNumber numberWithInt:3]]){
                [statuses addObject:[[NSNumber alloc] initWithInt:TransactionStatusRefunded]];
            }
            if([stauts containsObject:[NSNumber numberWithInt:4]]){
                [statuses addObject:[[NSNumber alloc] initWithInt:TransactionStatusVoided]];
            }
            if([stauts containsObject:[NSNumber numberWithInt:5]]){
                [statuses addObject:[[NSNumber alloc] initWithInt:TransactionStatusExpired]];
            }
            if([stauts containsObject:[NSNumber numberWithInt:6]]){
                [statuses addObject:[[NSNumber alloc] initWithInt:TransactionStatusAccepted]];
            }
            if([stauts containsObject:[NSNumber numberWithInt:7]]){
                [statuses addObject:[[NSNumber alloc] initWithInt:TransactionStatusAdjusted]];
            }
            if([stauts containsObject:[NSNumber numberWithInt:8]]){
                [statuses addObject:[[NSNumber alloc] initWithInt:TransactionStatusUnknown]];
            }
            builder.transactionStatuses = statuses;
        }
    }
    if([selectedItems objectForKey:[NSNumber numberWithInt:PaymentSource]]){
        NSArray *selectedSources = [selectedItems objectForKey:[NSNumber numberWithInt:PaymentSource]];
        if([selectedSources containsObject:[NSNumber numberWithInt:0]]){
            builder.posEntrySources = [[NSArray alloc] initWithObjects:
                                      [[NSNumber alloc] initWithInt:POSEntrySourceMobile],
                                      [[NSNumber alloc] initWithInt:POSEntrySourceSecure],
                                      [[NSNumber alloc] initWithInt:POSEntrySourceDevice],
                                      [[NSNumber alloc] initWithInt:POSEntrySourceDirect],nil];
        }
        else{
            NSMutableArray *sources = [[NSMutableArray alloc] init];
            if([selectedSources containsObject:[NSNumber numberWithInt:1]]){
                [sources addObject:[[NSNumber alloc] initWithInt:POSEntrySourceMobile]];
            }
            if([selectedSources containsObject:[NSNumber numberWithInt:2]]){
                [sources addObject:[[NSNumber alloc] initWithInt:POSEntrySourceSecure]];
            }
            if([selectedSources containsObject:[NSNumber numberWithInt:3]]){
                [sources addObject:[[NSNumber alloc] initWithInt:POSEntrySourceDevice]];
            }
            if([selectedSources containsObject:[NSNumber numberWithInt:4]]){
                [sources addObject:[[NSNumber alloc] initWithInt:POSEntrySourceDirect]];
            }
            if([selectedSources containsObject:[NSNumber numberWithInt:5]]){
                [sources addObject:[[NSNumber alloc] initWithInt:POSEntrySourceUnknown]];
            }
            builder.posEntrySources = sources;
        }
    }
    if([selectedItems objectForKey:[NSNumber numberWithInt:Other]]){
        NSMutableArray *array = [selectedItems objectForKey:[NSNumber numberWithInt:Other]];
        if([array containsObject:[NSNumber numberWithInt:0]]){
            builder.includeSubmerchantTransactions = true;
        }
    }
    if([selectedItems objectForKey:[NSNumber numberWithInt:OptionalFields]] && [[selectedItems objectForKey:[NSNumber numberWithInt:OptionalFields]] count]>0){
        builder.optionalFields = [[NSArray alloc] initWithObjects:[[NSNumber alloc] initWithInt:OptionalFieldTokenData], nil];
    }
    if(_callback){
        _callback(builder);
    }
}

@end

