//
//  IMSBaseViewController.h
//  mPOSSDKTestApp

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <iOS_mPOS_SDK/Ingenico.h>
#import "LogHelper.h"


@interface IMSBaseViewController : UIViewController<DeviceStatusAndEMVConfigurationHandler>

@property (strong, nonatomic) UILabel *sessionLabel;

- (void)checkDeviceStatus;

- (void)setLoggedIn:(bool)loggedin;

- (bool)isLoggedIn;

- (void)setCurrentUserProfile:(IMSUserProfile *)profile;

- (IMSUserProfile *)getCurrentUserProfile;

- (void)setDeviceConnected:(BOOL)deviceConnected;

- (BOOL)isDeviceConnected;

- (void)setReleasingState:(BOOL)releasingState;

- (BOOL)isReleasingState;

- (void)setConfigModeSet:(BOOL)configModeSet;

- (BOOL)isConfigModeSet;

- (void)setLastTransactionType:(IMSTransactionType)type;

- (IMSTransactionType)getLastTransactionType;

- (void)setLastTransactionID:(NSString *)txnID;

- (NSString *)getLastTransactionID;

- (NSString *)getResponseCodeString:(IMSResponseCode)responseCode;

- (void)setConnectingDeviceType:(RUADeviceType)deviceType;

- (RUADeviceType)getConnectingDeviceType;

- (UIImage *)getDeviceStatusIcon;

- (void)setConnectingDevice:(RUADevice *)device;

- (void)setConnectingState:(BOOL)connectingState;

-(void) setIsInitializationInProgress:(BOOL)initializationState;

- (void)dismissProgress;

- (void)showProgressMessage:(NSString *)progressMessage andIsTransactionStoppable:(BOOL)isstoppable;

- (void)showProgressMessage:(NSString *)progressMessage withStopBlock:(void(^)())block;

- (void)showProgressMessage:(NSString *)progressMessage andIsSuccess:(BOOL)issuccess;

- (void)showProgressPercent:(float) progress andMessage:(NSString *)message andIsFirmwareUpdate:(BOOL)isFirmwareUpdate;

- (void)setLastClientTransactionID:(NSString *)txnID;

- (NSString *)getLastClientTransactionID;

- (void)setLastTokenId:(NSString *)tokenId;

- (NSString *)getLastTokenId;

- (void)doLogoff;

- (NSString *)getStringFromTransactionType:(IMSTransactionType)type;

- (NSString *)getStringFromTransactionStatus:(IMSTransactionStatus)stauts;

- (NSString *)getStringFromPOSEntryMode:(IMSPOSEntryMode)type;

- (NSString *)getStringFromCardType:(IMSCardType)type;

- (NSString *)getStringFromCurrency:(NSString *)currency;

- (NSString *)getStringFromTokenResponseCode:(IMSTokenResponseCode)code;

- (NSString *) getStringFromTransactionResponseCode:(IMSTransactionResponseCode) type;

- (NSString *) getStringFromCardVerificationMethod:(IMSCardVerificationMethod) cvm;

- (NSString *) getStringFromCardPresentment:(IMSCardPresentment)cardPresentment;

- (NSString *)getProgressStrFromMessage:(IMSProgressMessage)message;

- (NSString *)getStringFromFirmwareUpdateOption:(IMSFirmwareUpdateAction)action;
@end
