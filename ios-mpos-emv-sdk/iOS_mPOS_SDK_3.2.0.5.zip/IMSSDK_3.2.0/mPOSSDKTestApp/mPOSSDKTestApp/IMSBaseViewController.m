//
//  IMSBaseViewController.m
//  mPOSSDKTestApp

#import "IMSBaseViewController.h"
#import "MRProgress.h"
#import "MRProgressOverlayView.h"
#import "DeviceManagementHelper.h"
#import "PaymentAPIViewController.h"
#import "PaymentDeviceViewController.h"
#import "HistoryFilterViewController.h"
#import "MerchantAPIViewController.h"
#import "TabBarViewController.h"
#import "TransactionHistoryListViewController.h"
#import "TransactionDetailViewController.h"
#import "ConfigureBeepsFilterViewController.h"

static bool isDeviceConnected;
static IMSBaseViewController *currentVC;
static bool isLoggedIn;
static bool isConnectingState;
static bool isReleasingState;
static bool isConfigModeSet;
static bool isCheckingDeviceSetupOnLoginOrReaderConnection;
static IMSTransactionType _lastTransactionType;
static NSString *_lastTransactionID;
static RUADeviceType _connectingDeviceType;
static RUADevice *_connectingDevice;
static NSString* _lastClientTransactionID;
static NSString* _lastTokenId;
static MRProgressOverlayView *_progressView;
static bool isInitializationInProgress;
static IMSUserProfile *_currentUserProfile;

@interface IMSBaseViewController ()<DeviceManagementDelegate>

@property (strong, nonatomic) UILabel *versionLabel;

@property (strong, nonatomic) UILabel *navigationLabel;

@end

@implementation IMSBaseViewController

@synthesize versionLabel = _versionLabel;
@synthesize navigationLabel = _navigationLabel;

- (void)viewDidLoad {
    [super viewDidLoad];
    _sessionLabel = [[UILabel alloc] init];
    _sessionLabel.textAlignment = NSTextAlignmentCenter;
    _sessionLabel.font = [UIFont fontWithName:@"HelveticaNeue" size:10];
    
    //height 30 for the height and 10 padding
    _versionLabel = [[UILabel alloc] init];
    _versionLabel.textAlignment = NSTextAlignmentCenter;
    _versionLabel.font = [UIFont fontWithName:@"HelveticaNeue" size:10];

    _navigationLabel = [[UILabel alloc] initWithFrame: CGRectMake(0, 0,200, 40)];
    _navigationLabel.textAlignment = NSTextAlignmentCenter;
    _navigationLabel.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    _navigationLabel.tintColor = [UIColor blackColor];
    self.navigationItem.titleView = _navigationLabel;
    if(![self isKindOfClass:[TransactionHistoryListViewController class]] &&
       ![self isKindOfClass:[TransactionDetailViewController class]] &&
       ![self isKindOfClass:[HistoryFilterViewController class]] &&
       ![self isKindOfClass:[ConfigureBeepsFilterViewController class]]){
        [self.view addSubview:_versionLabel];
        [self.view addSubview:_sessionLabel];
    }
    self.navigationController.navigationBar.userInteractionEnabled = YES;
}


- (void)viewWillLayoutSubviews{
    CGRect frame = self.view.frame;
    _sessionLabel.frame = CGRectMake(0, frame.size.height-40, frame.size.width, 20);
    _versionLabel.frame = CGRectMake(0, frame.size.height-20, frame.size.width, 20);
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    currentVC = self;
    if(!isConnectingState){
        [[DeviceManagementHelper sharedInstance] setDelegate:self];
    }
    [self updateNavigationBar];
    NSString *version = [[Ingenico sharedInstance] getVersion];
    if (version) {
        currentVC.versionLabel.text = [[NSString alloc] initWithFormat:@"mPOS EMV SDK v%@", version];
    }
    if (isInitializationInProgress) {
        [self showProgressMessage:@"Connecting to the device" andIsTransactionStoppable:NO];
    }
}

- (void)updateNavigationBar{
    if([currentVC isKindOfClass:[PaymentAPIViewController class]] ||
       [currentVC isKindOfClass:[PaymentDeviceViewController class]] ||
       [currentVC isKindOfClass:[MerchantAPIViewController class]]){
        [(TabBarViewController *)currentVC.parentViewController deviceStatusUpdated];
    }
    NSTextAttachment *_deviceStatusIcon = [[NSTextAttachment alloc] init];
    _deviceStatusIcon.image = [self getDeviceStatusIcon];
    _deviceStatusIcon.bounds = CGRectMake(10, -6.5, 25, 25);
    NSAttributedString *_imageStr = [NSAttributedString attributedStringWithAttachment:_deviceStatusIcon];
    NSMutableAttributedString * mutableAttriStr = [[NSMutableAttributedString alloc] initWithString:@"mPOS EMV SDK"];
    [mutableAttriStr addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"HelveticaNeue" size:16] range:NSMakeRange(0, mutableAttriStr.length)];
    [mutableAttriStr appendAttributedString:_imageStr];
    currentVC.navigationLabel.attributedText = mutableAttriStr;
}

- (void)deviceSetup{
    [[[Ingenico sharedInstance] PaymentDevice] checkDeviceSetup:^(NSError *error,bool isSetupRequired) {
        if(error){
            [self showProgressMessage:@"Check device setup failed" andIsSuccess:NO];
        }
        else{
            if(isSetupRequired){
                [self promptForDeviceSetup:true];//device set up is requird or device will be capable of MSR only
            }else if((!isSetupRequired && ![[Ingenico sharedInstance] getCurrentCapabilities].isEMVConfigUptoDate)){
                [self promptForDeviceSetup:false];//device set up is recommended but device will still be capable of EMV
            }
        }
    }];
}

- (void)promptForDeviceSetup:(BOOL)isDeviceSetupRequired{
    UIAlertController *view;
    if(isDeviceSetupRequired){
        view = [UIAlertController
                alertControllerWithTitle:@"Device setup"
                message:[[NSString alloc] initWithFormat:@"Device setup is required"]
                preferredStyle:UIAlertControllerStyleAlert];
    }else{
        view = [UIAlertController
                alertControllerWithTitle:@"Device setup recommended"
                message:[[NSString alloc] initWithFormat:@"Device setup is recommended"]
                preferredStyle:UIAlertControllerStyleAlert];
    }
    UIAlertAction *cancel = [UIAlertAction
                             actionWithTitle:@"Cancel"
                             style:UIAlertActionStyleCancel
                             handler:nil];
    UIAlertAction *setup = [UIAlertAction
                            actionWithTitle:@"Setup"
                            style:UIAlertActionStyleDefault
                            handler:^(UIAlertAction *action) {
                                [self showProgressMessage:@"Setting up device!" andIsTransactionStoppable:NO];
                                [[Ingenico sharedInstance].PaymentDevice setupWithProgressHandler:^(NSInteger current, NSInteger total) {
                                    float progress = (float)current/total;
                                    [self showProgressPercent:progress andMessage:@"Setting up device..." andIsFirmwareUpdate:false];
                                } andOnDone:^(NSError *error) {
                                    [self dismissProgress];
                                    if(!error){
                                        [self showProgressMessage:@"Setup completed" andIsSuccess:YES];
                                    }
                                    else{
                                        NSLog(@"Setup failed with error %@", error);
                                        [self showProgressMessage:@"Setup failed" andIsSuccess:NO];
                                    }
                                }];
                            }];
    [view addAction:setup];
    [view addAction:cancel];
    if(self.presentedViewController !=nil){
        [self.presentedViewController dismissViewControllerAnimated:NO completion:^{
            [self presentViewController:view animated:YES completion:nil];
        }];
    }
    else{
        [self presentViewController:view animated:YES completion:nil];
    }
}

- (void)checkDeviceStatus{
    if(isLoggedIn && isDeviceConnected){
        [[[Ingenico sharedInstance] PaymentDevice] checkFirmwareUpdate:^(NSError *error, IMSFirmwareUpdateAction updateAction, IMSFirmwareInfo *firmwareInfo) {
            [self dismissProgress];
            if(error!=nil){
                [self showProgressMessage:@"Check firmware update failed" andIsSuccess:NO];
            }
            else{
                UIAlertController *view = [UIAlertController
                                           alertControllerWithTitle:@"Firmware update"
                                           message:[[NSString alloc] initWithFormat:@"Firmware update is %@",[self getStringFromFirmwareUpdateAction:updateAction]]
                                           preferredStyle:UIAlertControllerStyleAlert];
                UIAlertAction *cancel = [UIAlertAction
                                         actionWithTitle:@"Cancel"
                                         style:UIAlertActionStyleCancel
                                         handler:^(UIAlertAction *action) {
                                             if(updateAction != FirmwareUpdateActionRequired){
                                                 [self deviceSetup];
                                             }
                                         }];
                UIAlertAction *update = [UIAlertAction
                                         actionWithTitle:@"Update"
                                         style:UIAlertActionStyleDefault
                                         handler:^(UIAlertAction *action) {
                                             if ([[[Ingenico sharedInstance] PaymentDevice] getActiveCommunicationType] == RUACommunicationInterfaceAudioJack) {
                                                 [self showProgressMessage:@"Firmware update is not supported via Audiojack" andIsSuccess:NO];
                                                 [self deviceSetup];
                                             }
                                             else {
                                                 [self showProgressMessage:@"Updating device firmware" andIsTransactionStoppable:NO];
                                                 [[[Ingenico sharedInstance] PaymentDevice] updateFirmwareWithDownloadProgress:^(long downloadedSize, long totalFileSize) {
                                                     [self showProgressPercent:downloadedSize/(float)totalFileSize andMessage:@"Downloading firmware..." andIsFirmwareUpdate:false];
                                                 } andFirmwareUpdateProgress:^(NSInteger current, NSInteger total) {
                                                     [self showProgressPercent:current/(float)total andMessage:@"Updating firmware..." andIsFirmwareUpdate:true];
                                                 } andOnDone:^(NSError *error) {
                                                     [self dismissProgress];
                                                     if(!error){
                                                         [self showProgressMessage:@"Update device firmware succeeded" andIsSuccess:YES];
                                                     }
                                                     else{
                                                         [self showProgressMessage:@"Update device firmware failed" andIsSuccess:NO];
                                                     }
                                                 }];
                                             }
                                         }];
                if(updateAction == FirmwareUpdateActionRequired || updateAction == FirmwareUpdateActionOptional){
                    [view addAction:update];
                    [view addAction:cancel];
                    if(self.presentedViewController !=nil){
                        [self.presentedViewController dismissViewControllerAnimated:NO completion:^{
                            [self presentViewController:view animated:YES completion:nil];
                        }];
                    }
                    else{
                        [self presentViewController:view animated:YES completion:nil];
                    }
                }
                else{
                    [self deviceSetup];
                }

            }
        }];
    }
}

- (void)setLoggedIn:(bool)loggedin{
    isLoggedIn = loggedin;
    if (!loggedin) {
        _sessionLabel.text = @"";
    }
}

- (bool)isLoggedIn{
    return isLoggedIn;
}

- (void)setCurrentUserProfile:(IMSUserProfile *)profile{
    _currentUserProfile = profile;
}

- (IMSUserProfile *)getCurrentUserProfile{
    return _currentUserProfile;
}

- (void)setDeviceConnected:(BOOL)deviceConnected{
    isDeviceConnected = deviceConnected;
}

- (BOOL)isDeviceConnected{
    return isDeviceConnected;
}

- (void)setLastTransactionType:(IMSTransactionType)type{
    _lastTransactionType = type;
}

- (IMSTransactionType)getLastTransactionType{
    return _lastTransactionType;
}

- (void)setLastTransactionID:(NSString *)txnID{
    _lastTransactionID = txnID;
}

- (NSString *)getLastTransactionID{
    return _lastTransactionID;
}

- (void)setLastClientTransactionID:(NSString *)txnID{
    _lastClientTransactionID = txnID;
}

- (NSString *)getLastClientTransactionID{
    return _lastClientTransactionID;
}

- (void)setLastTokenId:(NSString *)tokenId{
    _lastTokenId = tokenId;
}

- (NSString *)getLastTokenId{
    return _lastTokenId;
}

- (void)setConfigModeSet:(BOOL)configModeSet{
    isConfigModeSet = configModeSet;
}

- (BOOL)isConfigModeSet{
    return isConfigModeSet;
}

- (NSString *)getStringFromFirmwareUpdateAction:(IMSFirmwareUpdateAction)action{
    switch(action){
        case FirmwareUpdateActionNo:
            return @"not required";
        case FirmwareUpdateActionUnknown:
            return @"unknown";
        case FirmwareUpdateActionOptional:
            return @"optional";
        case FirmwareUpdateActionRequired:
            return @"required";
    }
}

- (NSString *)getResponseCodeString:(IMSResponseCode)responseCode {
    switch (responseCode) {
        case Success:
            return @"Success";
        case PaymentDeviceNotAvailable:
            return @"Payment Device Not Available";
        case PaymentDeviceError:
            return @"Payment Device Not Error";
        case PaymentDeviceTimeout:
            return @"Payment Device Timeouts";
        case NotSupportedByPaymentDevice:
            return @"Not Supported by Payment Device";
        case CardBlocked:
            return @"Card Blocked";
        case ApplicationBlocked:
            return @"Application Blocked";
        case InvalidCard:
            return @"Invalid Card";
        case InvalidApplication:
            return @"Invalid Card Application";
        case TransactionCancelled:
            return @"Transaction Cancelled";
        case CardReaderGeneralError:
            return @"Card Reader General Error";
        case CardInterfaceGeneralError:
            return @"Card Not Accepted";
        case BatteryTooLowError:
            return @"Battery Too Low";
        case BadCardSwipe:
            return @"Bad Card Swipe";
        case TransactionDeclined:
            return @"Transaction Declined";
        case TransactionReversalCardRemovedFailed:
            return @"Transaction Reversal Card Removed Failed";
        case TransactionReversalCardRemovedSuccess:
            return @"Transaction Reversal Card Removed Success";
        case TransactionReversalChipDeclineFailed:
            return @"Transaction Reversal Chip Decline  Failed";
        case TransactionReversalChipDeclineSuccess:
            return @"Transaction Reversal Chip Decline Success";
        case TransactionReversalNetworkTimeoutFailed:
            return @"Transaction Reversal Network Timeout Failed";
        case TransactionReversalNetworkTimeoutSuccess:
            return @"Transaction Reversal Network Timeout Success";
        case TransactionCancelFailed:
            return @"Transaction Cancel Failed";
        case CardNotPresentOrNotFullyInserted:
            return @"Card Not Present Or Not Fully Inserted";
        default:
            return[[NSString alloc] initWithFormat:@"Response Code:%lu",(unsigned long)responseCode];
    }
}

- (NSString *)getDeviceNameFromType:(RUADeviceType)deviceType{
    switch (deviceType) {
        case RUADeviceTypeRP450c:
            return @"RP450C";
        case RUADeviceTypeRP45BT:
            return @"RP45BT";
        case RUADeviceTypeRP750x:
            return @"RP750";
        case RUADeviceTypeMOBY3000:
            return @"Moby3000";
        case RUADeviceTypeMOBY8500:
            return @"Moby8500";
        case RUADeviceTypeMOBY5500:
            return @"Moby5500";
        default:
            return @"RP450C";
    }
}

- (UIImage *)colorImage:(UIImage *)image color:(UIColor *)color
{
    UIGraphicsBeginImageContextWithOptions(image.size, NO, [UIScreen mainScreen].scale);
    CGContextRef context = UIGraphicsGetCurrentContext();

    CGContextTranslateCTM(context, 0, image.size.height);
    CGContextScaleCTM(context, 1.0, -1.0);
    CGRect rect = CGRectMake(0, 0, image.size.width, image.size.height);

    CGContextSetBlendMode(context, kCGBlendModeNormal);
    CGContextDrawImage(context, rect, image.CGImage);
    CGContextSetBlendMode(context, kCGBlendModeSourceIn);
    [color setFill];
    CGContextFillRect(context, rect);


    UIImage *coloredImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();

    return coloredImage;
}

- (void)setConnectingDeviceType:(RUADeviceType)deviceType{
    _connectingDeviceType = deviceType;
}

- (UIImage *)getDeviceStatusIcon{
    if(isDeviceConnected){
        return [self colorImage:[UIImage imageNamed:[[NSString alloc] initWithFormat:@"%@-Connected",[self getDeviceNameFromType:_connectingDeviceType]]] color:[UIColor blackColor]];
    }
    else{
        return [self colorImage:[UIImage imageNamed:[[NSString alloc] initWithFormat:@"%@-Disconnected",[self getDeviceNameFromType:_connectingDeviceType]]] color:[UIColor blackColor]];
    }
}

- (RUADeviceType)getConnectingDeviceType{
    return _connectingDeviceType;
}

- (void)setConnectingDevice:(RUADevice *)device{
    _connectingDevice = device;
}

- (void)setConnectingState:(BOOL)connectingState{
    isConnectingState = connectingState;
}

- (void)setReleasingState:(BOOL)releasingState{
    isReleasingState = releasingState;
}

- (BOOL)isReleasingState{
    return isReleasingState;
}

-(void) setIsInitializationInProgress:(BOOL)initializationState{
    isInitializationInProgress = initializationState;
}
#pragma RUADeviceStatus Implementation
- (void)onConnected {
    [LogHelper.sharedInstance consoleLog:@"Device Connected"];
    isDeviceConnected = YES;
    _connectingDeviceType = [[Ingenico sharedInstance].PaymentDevice getType];
    [self displayInitializationResult:@"Device Connected"];
    [self updateNavigationBar];
    [[DeviceManagementHelper sharedInstance] stopScan];
    if(![self isConfigModeSet]){
        [[[Ingenico sharedInstance] PaymentDevice] getDeviceBatteryLevel:^(NSInteger batteryLevel, NSError * _Nullable error) {
            [self checkDeviceStatus];
        }];
    }
    if(_connectingDevice &&
       [_connectingDevice communicationInterface] == RUACommunicationInterfaceBluetooth){
           [[DeviceManagementHelper sharedInstance] saveDevice:_connectingDeviceType deviceName:_connectingDevice];
       }
}

- (void)onDisconnected {
    isDeviceConnected = NO;
    [self displayInitializationResult:@"Device Disconnected"];
    [LogHelper.sharedInstance consoleLog:@"Device Disconnected"];
    [self updateNavigationBar];
    _connectingDevice = nil;
    if(!isConnectingState){
        [[DeviceManagementHelper sharedInstance] initiateScan];
    }
}

- (void)onError:(NSString *)message {
    isDeviceConnected = NO;
    [self displayInitializationResult:[[NSString alloc] initWithFormat:@"Device OnError:%@",message]];
    [self updateNavigationBar];
    [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Device OnError:%@",message]];
    NSLog(@"An error occured %@", message);
    _connectingDevice = nil;
    if(!isConnectingState){
        [[DeviceManagementHelper sharedInstance] initiateScan];
    }
}

- (void)performSetup:(UserActionHandler) handler{
    [self dismissProgress];
    UIAlertController *alertView = [UIAlertController
                                    alertControllerWithTitle:@"Perform set up?"
                                    message:@""
                                    preferredStyle:UIAlertControllerStyleActionSheet];
    UIAlertAction *yesAction = [UIAlertAction
                                actionWithTitle:@"Yes"
                                style:UIAlertActionStyleDefault
                                handler:^(UIAlertAction *action) {
        [self showProgressMessage:@"Performing set up..." andIsTransactionStoppable:NO];
        [alertView dismissViewControllerAnimated:YES completion:nil];
        handler(true);
    }];
    [alertView addAction:yesAction];
    UIAlertAction *noAction = [UIAlertAction
                               actionWithTitle:@"No"
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction *action) {
        [alertView dismissViewControllerAnimated:YES completion:nil];
        handler(false);
    }];
    [alertView addAction:noAction];
    [self presentViewController:alertView animated:true completion:nil];
}

- (void)performFirmwareUpdate:(IMSFirmwareUpdateAction)action andUserActionHandler:(UserActionHandler) handler{
    [self dismissProgress];
    UIAlertController *alertView = [UIAlertController
                                    alertControllerWithTitle:@"Perform firmware update?"
                                    message:[[NSString alloc] initWithFormat:@"FW update option is %@", [self getStringFromFirmwareUpdateOption:action]]
                                    preferredStyle:UIAlertControllerStyleActionSheet];
    UIAlertAction *yesAction = [UIAlertAction
                                actionWithTitle:@"Yes"
                                style:UIAlertActionStyleDefault
                                handler:^(UIAlertAction *action) {
        [self showProgressMessage:@"Performing firmware update..." andIsTransactionStoppable:NO];
        [alertView dismissViewControllerAnimated:YES completion:nil];
        handler(true);
    }];
    [alertView addAction:yesAction];
    UIAlertAction *noAction = [UIAlertAction
                               actionWithTitle:@"No"
                               style:UIAlertActionStyleDefault
                               handler:^(UIAlertAction *action) {
        [alertView dismissViewControllerAnimated:YES completion:nil];
        handler(false);
    }];
    [alertView addAction:noAction];
    [self presentViewController:alertView animated:true completion:nil];
}

- (void)onConfigured:(NSError *)error andCapabilities:(IMSCapabilities*)capabilities{
    NSString* responseCodeStr = [self getResponseCodeString:error.code];
    BOOL EMVCapable = capabilities.EMVCapable;
    if(error == nil) {
        if(EMVCapable && ![[Ingenico sharedInstance] getCurrentCapabilities].isEMVConfigUptoDate){
            [self dismissProgress];
            [self promptForDeviceSetup:false];//device set up is recommended but device will still be capable of EMV
        }else{
            [self showProgressMessage:[[NSString alloc] initWithFormat:@"Configured\nEMV Capable: %@\nResponse code: %@\nFW update action: %@" , EMVCapable ? @"YES" : @"NO", responseCodeStr, [self getStringFromFirmwareUpdateOption: capabilities.firmwareUpdateAction]] andIsSuccess:YES];
        }
    }else{
        [self showProgressMessage:[[NSString alloc] initWithFormat:@"Configured\nEMV Capable: %@\nResponse code: %@\nFW update action: %@", EMVCapable ? @"YES" : @"NO", responseCodeStr, [self getStringFromFirmwareUpdateOption: capabilities.firmwareUpdateAction]] andIsSuccess:NO];
    }
    [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Configured\nEMV Capable: %@\nResponse code: %@\nFW update action: %@" , EMVCapable ? @"YES" : @"NO", responseCodeStr, [self getStringFromFirmwareUpdateOption: capabilities.firmwareUpdateAction]]];
}

- (void)onProgress:(IMSProgressMessage)message andAdditionalMessage:(NSString * _Nullable)additionalMessage{
    NSString *progressMessage = [self getProgressStrFromMessage:message];
    if(message == UpdatingFirmware){
        NSString *currentStep = [additionalMessage componentsSeparatedByString:@"/"][0];
        NSString *totalStep = [additionalMessage componentsSeparatedByString:@"/"][1];
        [self showProgressPercent:currentStep.floatValue/totalStep.floatValue andMessage:progressMessage andIsFirmwareUpdate:YES];
    }else if(message == CheckingFirmwareUpdate || message == CheckingDeviceSetup){
        [self showProgressMessage:progressMessage andIsTransactionStoppable:NO];
    }else {
        NSString *currentStep = [additionalMessage componentsSeparatedByString:@"/"][0];
        NSString *totalStep = [additionalMessage componentsSeparatedByString:@"/"][1];
        [self showProgressPercent:currentStep.floatValue/totalStep.floatValue andMessage:progressMessage andIsFirmwareUpdate:NO];
    }
}

-(void)displayInitializationResult:(NSString*) initiilizationResult{
    [self setIsInitializationInProgress:NO];
    [self dismissProgress];
    if (isDeviceConnected) {
        [self showProgressMessage:initiilizationResult andIsSuccess:YES];
    }else{
        [self showProgressMessage:initiilizationResult andIsSuccess:NO];
    }
    
}
- (void)onPlugged{
    NSLog(@"Devices plugged");
    [[DeviceManagementHelper sharedInstance] stopScan];
}

- (void)connectPairedDevice:(RUADevice*)device deviceType:(RUADeviceType)deviceType
{
    if(!isDeviceConnected){
        [[Ingenico sharedInstance].PaymentDevice setDeviceType:deviceType];
        [[Ingenico sharedInstance].PaymentDevice select:device];
        [[Ingenico sharedInstance].PaymentDevice initialize:self];
        isInitializationInProgress = YES;
    }
}

- (void)dismissProgress{
    [MRProgressOverlayView dismissAllOverlaysForView:currentVC.view.window animated:false];
    NSLog(@"Dismiss all progress view called");
}

- (void)showProgressMessage:(NSString *)progressMessage andIsTransactionStoppable:(BOOL)isstoppable{
    [self dismissProgress];
    _progressView = [[MRProgressOverlayView alloc] init];
    _progressView.titleLabelText = progressMessage;
    if(isstoppable){
        _progressView.stopBlock = ^(MRProgressOverlayView *view){
            [[Ingenico sharedInstance].Payment abortTransaction];
            [MRProgressOverlayView dismissAllOverlaysForView:currentVC.view.window animated:false];
        };
    }
    [currentVC.view.window addSubview:_progressView];
    NSLog(@"Show progress view %p", _progressView);
    [_progressView show:YES];
}

- (void)showProgressMessage:(NSString *)progressMessage withStopBlock:(void(^)())stopBlock {
    [self dismissProgress];
    _progressView = [[MRProgressOverlayView alloc] init];
    _progressView.titleLabelText = progressMessage;
    _progressView.stopBlock = stopBlock;
    [MRProgressOverlayView dismissAllOverlaysForView:currentVC.view.window animated:false];
    [currentVC.view.window addSubview:_progressView];
    NSLog(@"Show progress view %p", _progressView);
    [_progressView show:YES];
}

- (void)performBlock:(void(^)())block afterDelay:(NSTimeInterval)delay {
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), block);
}

- (void)showProgressMessage:(NSString *)progressMessage andIsSuccess:(BOOL)issuccess{
    [self dismissProgress];
    _progressView = [[MRProgressOverlayView alloc] init];
    _progressView.titleLabelText = progressMessage;
    if(issuccess){
        _progressView.mode = MRProgressOverlayViewModeCheckmark;
    }
    else{
        _progressView.mode = MRProgressOverlayViewModeCross;
    }
    [currentVC.view.window addSubview:_progressView];
    dispatch_async(dispatch_get_main_queue(), ^{
        NSLog(@"Show progress view %p", _progressView);
        [_progressView show:YES];
        [self performBlock:^{
            NSLog(@"Dismiss progress view %p", _progressView);
            [_progressView dismiss:NO];
        } afterDelay:1.0];
    });
}

- (void)showProgressPercent:(float)progress andMessage:(NSString *)message andIsFirmwareUpdate:(BOOL)isFirmwareUpdate{
    [self dismissProgress];
    _progressView = [[MRProgressOverlayView alloc] init];
    [currentVC.view.window addSubview:_progressView];
    [_progressView show:false];
    if(isFirmwareUpdate){
        _progressView.stopBlock = ^(MRProgressOverlayView *view){
                [[Ingenico sharedInstance].PaymentDevice cancelFirmwareUpdate];
                [MRProgressOverlayView dismissAllOverlaysForView:currentVC.view.window animated:false];
                [self dismissProgress];
        };
    }
    _progressView.mode = MRProgressOverlayViewModeDeterminateCircular;
    _progressView.titleLabelText = message;
    [_progressView setProgress:progress];
    NSLog(@"Show progress view with percent %p", _progressView);
}

- (void)doLogoff{
    [self.view endEditing:YES];
    [self showProgressMessage:@"Logging off" andIsTransactionStoppable:NO];
    [[[Ingenico sharedInstance] User] logoff:^(NSError *error) {
        [self setLoggedIn:false];
        if (error == nil) {
            [self showProgressMessage:@"Logoff succeeded" andIsSuccess:YES];
        } else {
            [self showProgressMessage:@"Logoff failed" andIsSuccess:NO];
        }
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self dismissProgress];
            [self.navigationController popViewControllerAnimated:YES];
        });
    }];
}

#pragma Helper method

- (NSString *)getStringFromTokenResponse:(IMSTokenResponseParameters *) tokenResp {
    NSMutableString *string = [[NSMutableString alloc] init];
    if (tokenResp.tokenIdentifier) {
        [string
         appendString:[[NSString alloc] initWithFormat:@"  Token Identifier:  %@\n",
                       tokenResp.tokenIdentifier]];
        [string
         appendString:[[NSString alloc] initWithFormat:@"  Token Fee:  %ld\n",
                       (long)tokenResp.tokenFeeInCents]];
    }
    if (tokenResp.responseCode != IMSTokenResponseCodeUnknown) {
        [string
         appendString:[[NSString alloc] initWithFormat:@"  Token Response Code:  %@\n",
                       [self getStringFromTokenResponseCode:tokenResp.responseCode]]];
    }
    if (tokenResp.tokenSource) {
        [string
         appendString:[[NSString alloc] initWithFormat:@"  Token Source:  %@\n",
                       tokenResp.tokenSource]];
    }
    if (tokenResp.tokenSourceData) {
        [string
         appendString:[[NSString alloc] initWithFormat:@"  Token Source Data:  %@\n",
                       tokenResp.tokenSourceData]];
    }
    return string;
}

- (NSString *)getStringFromTokenResponseCode:(IMSTokenResponseCode) code {
    NSString *typeStr;
    switch (code) {
        case IMSTokenResponseCodeApproved:
            typeStr = @"Approved";
            break;
        case IMSTokenResponseCodeDeclined:
            typeStr = @"Declined";
            break;
        case IMSTokenResponseCodeError:
            typeStr = @"Error";
            break;
        case IMSTokenResponseCodeUnknown:
        default:
            typeStr = @"Unknown";
            break;
    }
    return typeStr;
}

- (NSString *)getStringFromAmount:(IMSAmount *) amount {
    NSMutableString *string = [[NSMutableString alloc] init];
    if (amount.currency) {
        [string
         appendString:[[NSString alloc] initWithFormat:@"  currency:  %@\n",
                       amount.currency]];
    }
    if (amount.total) {
        [string
         appendString:[[NSString alloc] initWithFormat:@"  total:  %ld\n",
                       (long)amount.total]];
    }
    if (amount.subTotal) {
        [string
         appendString:[[NSString alloc] initWithFormat:@"  subtotal:  %ld\n",
                       (long)amount.subTotal]];
    }
    if (amount.tax) {
        [string
         appendString:[[NSString alloc] initWithFormat:@"  tax:  %ld\n",
                       (long)amount.tax]];
    }
    if (amount.discount) {
        [string
         appendString:[[NSString alloc] initWithFormat:@"  discount:  %ld\n",
                       (long)amount.discount]];
    }
    if (amount.tip) {
        [string
         appendString:[[NSString alloc] initWithFormat:@"  tip:  %ld\n",
                       (long)amount.tip]];
    }
    if (amount.surcharge) {
        [string
         appendString:[[NSString alloc] initWithFormat:@"  surcharge:  %ld\n",
                       (long)amount.surcharge]];
    }
    return string;
}

- (NSString *)getStringFromCustomerInfo:(IMSCardholderInfo *)cardholderInfo {
    NSMutableString *string = [[NSMutableString alloc] init];
    if (cardholderInfo.firstName) {
        [string
         appendString:[[NSString alloc] initWithFormat:@"  firstName:  %@\n",
                       cardholderInfo.firstName]];
    }
    if (cardholderInfo.lastName) {
        [string
         appendString:[[NSString alloc] initWithFormat:@"  lastName:  %@\n",
                       cardholderInfo.lastName]];
    }
    if (cardholderInfo.middleName) {
        [string
         appendString:[[NSString alloc] initWithFormat:@"  middleName:  %@\n",
                       cardholderInfo.middleName]];
    }
    if (cardholderInfo.email) {
        [string
         appendString:[[NSString alloc] initWithFormat:@"  email:  %@\n",
                       cardholderInfo.email]];
    }
    if (cardholderInfo.phone) {
        [string
         appendString:[[NSString alloc] initWithFormat:@"  phone:  %@\n",
                       cardholderInfo.phone]];
    }
    if (cardholderInfo.address1) {
        [string
         appendString:[[NSString alloc] initWithFormat:@"  address1:  %@\n",
                       cardholderInfo.address1]];
    }
    if (cardholderInfo.address2) {
        [string
         appendString:[[NSString alloc] initWithFormat:@"  address2:  %@\n",
                       cardholderInfo.address2]];
    }
    if (cardholderInfo.city) {
        [string
         appendString:[[NSString alloc] initWithFormat:@"  city:  %@\n",
                       cardholderInfo.city]];
    }
    if (cardholderInfo.state) {
        [string
         appendString:[[NSString alloc] initWithFormat:@"  state:  %@\n",
                       cardholderInfo.state]];
    }
    return string;
}

- (NSString *) getStringFromTransactionType:(IMSTransactionType)type {
    NSString *typeStr;
    switch (type) {
        case TransactionTypeCreditSale:
            typeStr = @"Credit Sale";
            break;
        case TransactionTypeCreditRefund:
            typeStr = @"Credit Refund";
            break;
        case TransactionTypeCreditSaleVoid:
            typeStr = @"Credit Sale Reversal";
            break;
        case TransactionTypeCreditAuth:
            typeStr = @"Credit Auth";
            break;
        case TransactionTypeCreditAuthVoid:
            typeStr = @"Credit Auth Void";
            break;
        case TransactionTypeCashSale:
            typeStr = @"CashSale";
            break;
        case TransactionTypeCashRefund:
            typeStr = @"CashRefund";
            break;
        case TransactionTypeCreditAuthCompletion:
            typeStr = @"Auth Completed";
            break;
        case TransactionTypeCreditAuthCompletionVoid:
            typeStr = @"Auth Completion Void";
            break;
        case TransactionTypeCreditRefundVoid:
            typeStr = @"Credit Refund Void";
            break;
        case TransactionTypeDebitSale:
            typeStr = @"Debit Sale";
            break;
        case TransactionTypeDebitRefund:
            typeStr = @"Debit Refund";
            break;
        case TransactionTypeDebitSaleVoid:
            typeStr = @"Debit Void";
            break;
        case TransactionTypeDebitRefundVoid:
            typeStr = @"Debit Refund Void";
            break;
        case TransactionTypeCreditForceSale:
            typeStr = @"Credit Force Sale";
            break;
        case TransactionTypeCreditForceSaleVoid:
            typeStr = @"Credit Force Void";
            break;
        case TransactionTypeCreditBalanceInquiry:
            typeStr = @"Credit Balance Inquiry";
            break;
        case TransactionTypeTokenEnrollment:
            typeStr = @"Token Enrollment";
            break;
        case TransactionTypeCreditSaleAdjust:
            typeStr = @"Credit Sale Adjust";
            break;
        case TransactionTypeCreditAuthAdjust:
            typeStr = @"Credit Auth Adjust";
            break;
        case TransactionTypeCreditAuthAdjustVoid:
            typeStr = @"Credit Auth Adjust Void";
            break;
        case TransactionTypeCreditSaleAdjustVoid:
            typeStr = @"Credit Sale Adjust Void";
            break;
        case TransactionTypeDebitBalanceInquiry:
            typeStr = @"Debit Balance Inquiry";
            break;
        case TransactionTypeCreditAuthPartialVoid:
            typeStr = @"Credit Auth Partial Void";
            break;
        case TransactionTypeAVSOnly:
            typeStr = @"AVS Only";
            break;
        case TransactionTypeSale:
            typeStr = @"Sale";
            break;
        case TransactionTypeRefund:
            typeStr = @"Refund";
            break;
        case TransactionTypeBalanceInquiry:
            typeStr = @"Balance Inquiry";
            break;
        case TransactionTypeCreditAuthAdjustPartialVoid:
            typeStr = @"Credit Auth Adjust Partial Void";
            break;
        case TransactionTypeUnknown:
            typeStr = @"UnknownTransaction";
            break;
    }
    return typeStr;
}

- (NSString *) getStringFromTransactionStatus:(IMSTransactionStatus)stauts {
    NSString *statusStr;
    switch (stauts) {
        case TransactionStatusActive:
            statusStr = @"Active";
            break;
        case TransactionStatusCompleted:
            statusStr = @"Completed";
            break;
        case TransactionStatusRefunded:
            statusStr = @"Refunded";
            break;
        case TransactionStatusVoided:
            statusStr = @"Voided";
            break;
        case TransactionStatusExpired:
            statusStr = @"Expired";
            break;
        case TransactionStatusAccepted:
            statusStr = @"Accepted";
            break;
        case TransactionStatusDeclined:
            statusStr = @"Declined";
            break;
        case TransactionStatusAdjusted:
            statusStr = @"Adjusted";
            break;
        default:
            statusStr = @"UnknownStatus";
            break;
    }
    return statusStr;
}

- (NSString *) getStringFromTenderType:(IMSTenderType)type {
    NSString *str;
    switch (type) {
        case TenderTypeCash:
            str = @"Cash";
            break;
        case TenderTypeCredit:
            str = @"Credit";
            break;
        case TenderTypeUnknown:
        default:
            str = @"UnknownTender";
            break;
    }
    return str;
}

- (NSString *) getStringFromPOSEntryMode:(IMSPOSEntryMode) type{
    NSString *typeStr;
    switch (type) {
        case POSEntryModeKeyed:
            typeStr = @"Keyed";
            break;
        case POSEntryModeContactlessEMV:
            typeStr = @"ContactlessEMV";
            break;
        case POSEntryModeContactlessMSR:
            typeStr = @"ContactlessMSR";
            break;
        case  POSEntryModeMagStripe:
            typeStr = @"MagStripe";
            break;
        case POSEntryModeContactEMV:
            typeStr = @"ContactEMV";
            break;
        case POSEntryModeKeyedSwipeFail:
            typeStr = @"KeyedSwipeFail";
            break;
        case POSEntryModeToken:
            typeStr = @"Token";
            break;
        case POSEntryModeVirtualTerminal:
            typeStr = @"VirtualTerminal";
            break;
        case POSEntryModeMagStripeEMVFail:
            typeStr = @"MagStripeEMVFail";
            break;
        case POSEntryModeUnKnown:
        default:
            typeStr = @"UnknownPOSEntryMode";
            break;
    }
    return typeStr;
}

- (NSString *) getStringFromCardPresentment:(IMSCardPresentment)cardPresentment {
    NSString *str;
    switch (cardPresentment) {
        case CardPresentmentOriginal:
            str = @"Original";
            break;
        case CardPresentmentStoreAndForward:
            str = @"StoreAndForward";
            break;
        case CardPresentmentRecurring:
            str = @"Recurring";
            break;
        case CardPresentmentInstallment:
            str = @"Installment";
            break;
        case CardPresentmentBillpay:
            str = @"Billpay";
            break;
        default:
            str = @"Unknown";
            break;
    }
    return str;
}

- (NSString *) getStringFromTransactionResponseCode:(IMSTransactionResponseCode) type{
    NSString *typeStr;
    switch (type) {
        case TransactionResponseCodeApproved:
            typeStr = @"Approved";
            break;
        case TransactionResponseCodeDeclined:
            typeStr = @"Declined";
            break;
        case TransactionResponseCodeReferral:
            typeStr = @"Referral";
            break;
        case TransactionResponseCodeVerifyError:
            typeStr = @"VerifyError";
            break;
        case TransactionResponseCodePassPhraseExpired:
            typeStr = @"PassPhraseExpired";
            break;
        case TransactionResponseCodeInvalidPassPhrase:
            typeStr = @"InvalidPassPhrase";
            break;
        case TransactionResponseCodeBinaryDataResponse:
            typeStr = @"BinaryDataResponse";
            break;
        case TransactionResponseCodeUnKnown:
        default:
            typeStr = @"Unknown";
            break;
    }
    return typeStr;
}

- (NSString *) getStringFromCardVerificationMethod:(IMSCardVerificationMethod) cvm{
    NSString *typeStr;
    switch (cvm) {
        case CardVerificationMethodPin:
            typeStr = @"Pin";
            break;
        case CardVerificationMethodSignature:
            typeStr = @"Signature";
            break;
        case CardVerificationMethodPinAndSignature:
            typeStr = @"PinAndSignature";
            break;
        case CardVerificationMethodNone:
        default:
            typeStr = @"None";
            break;
    }
    return typeStr;
}

- (NSString *) getStringFromProduct: (IMSProduct*) product {
    NSMutableString *string = [[NSMutableString alloc] init];
    if(product.name){
        [string
         appendString:[[NSString alloc] initWithFormat:@"  name: %@\n",
                       product.name]];
    }
    if(product.price){
        [string
         appendString:[[NSString alloc] initWithFormat:@"  price: %ld\n",
                       (long)product.price]];
    }
    if(product.quantity){
        [string
         appendString:[[NSString alloc] initWithFormat:@"  quantity: %ld\n",
                       (long)product.quantity]];
    }
    if(product.note){
        [string
         appendString:[[NSString alloc] initWithFormat:@"  note: %@\n",
                       product.note]];
    }
    return string;
}

- (NSString *) getStringFromCardType:(IMSCardType) type{
    NSString *typeStr;
    switch (type) {
        case CardTypeAMEX:
            typeStr = @"AMEX";
            break;
        case CardTypeDiners:
            typeStr = @"Diners";
            break;
        case CardTypeDiscover:
            typeStr = @"Discover";
            break;
        case CardTypeJCB:
            typeStr = @"JCB";
            break;
        case CardTypeMasterCard:
            typeStr = @"MasterCard";
            break;
        case CardTypeVISA:
            typeStr = @"VISA";
            break;
        case CardTypeMaestro:
            typeStr = @"Maestro";
            break;
        case CardTypeUnknown:
        default:
            typeStr = @"UnknownCard";
            break;
    }
    return typeStr;
}

- (NSString *)getStringFromCurrency:(NSString *)currency{
    return @"$";
}

- (NSString *)getProgressStrFromMessage:(IMSProgressMessage)message{
    switch (message) {
        case PleaseInsertCard:{
            NSArray *allowedPOS = [[Ingenico sharedInstance].PaymentDevice allowedPOSEntryModes];
            if([allowedPOS containsObject:[NSNumber numberWithInteger:POSEntryModeContactlessMSR]] ||
               [allowedPOS containsObject:[NSNumber numberWithInteger:POSEntryModeContactlessEMV]]){
                if([allowedPOS containsObject:[NSNumber numberWithInteger:POSEntryModeContactEMV]]){
                    return @"Please insert/tap/swipe card";
                } else{
                    return @"Please tap or swipe card";
                }
            }
            else{
                return @"Please insert or swipe card";
            }
        }
        case ChipCardSwipFailed:
            return @"Cannot swipe chip card. Please insert card instead";
        case CardInserted:
            return @"Card inserted";
        case ICCErrorSwipeCard:
            return @"ICCError swipe card please";
        case ApplicationSelectionStarted:
            return @"Application selection started";
        case ApplicationSelectionCompleted:
            return @"Application selection completed";
        case FirstPinEntryPrompt:
            return @"First Pin prompt";
        case LastPinEntryPrompt:
            return @"Last Pin prompt";
        case PinEntryFailed:
            return @"Pin entry failed";
        case PinEntryInProgress:
            return @"Pin entry in progress";
        case PinEntrySuccessful:
            return @"Pin entry in progress";
        case RetrytPinEntryPrompt:
            return @"Retry Pin entry prompt";
        case WaitingforCardSwipe:
            return @"Waiting for card swipe";
        case PleaseSeePhone:
            return @"Please see phone";
        case SwipeDetected:
            return @"Swipe detected";
        case SwipeErrorReswipeMagStripe:
            return @"Reswipe please";
        case TapDetected:
            return @"Tap detected";
        case UseContactInterfaceInsteadOfContactless:
            return @"Use contact interface instead of contactless";
        case ErrorReadingContactlessCard:
            return @"Error reading contactless card";
        case DeviceBusy:
            return @"Device busy";
        case CardHolderPressedCancelKey:
            return @"Cancel key pressed";
        case RecordingTransaction:
            return @"Recording transaction";
        case UpdatingTransaction:
            return @"Updating transaction";
        case PleaseRemoveCard:
            return @"Please remove card";
        case RestartingContactlessInterface:
            return @"Restarting contactless interface";
        case GettingOnlineAuthorization:
            return @"Getting Online Authorization";
        case TryContactInterface:
            return @"Try contact interface";
        case MultipleContactlessCardsDetected:
            return @"Please present one card only";
        case PresentCardAgain:
            return @"Please present card again";
        case CardRemoved:
            return @"Card Removed";
        case SendingReversal:
            return @"Sending reversal";
        case FetchingSecureCardEntryContent:
            return @"Fetching Secure Card Entry content";
        case LoadingSecureCardEntryContent:
            return @"Loading Secure Card Entry content";
        case ReinsertCard:
            return @"Reinsert Card properly";
        case RestartingTransactionDueToIncorrectPin:
            return @"Restarting Transaction Due To Incorrect Pin";
        case ContactlessInterfaceFailedTryContact:
            return @"Contactless Failed, Try Contact";
        case WaitingforChipCard:
            return @"Waiting for Chip Card";
        case WaitingforSwipeCard:
            return @"Waiting for Swipe Card";
        case WaitingforChipAndSwipe:
            return @"Waiting for Chip And Swipe";
        case WaitingforTapCard:
            return @"Waiting for Tap Card";
        case WaitingforChipAndTap:
            return @"Waiting for Chip And Tap";
        case WaitingforSwipeAndTap:
            return @"Waiting for Swipe And Tap";
        case WaitingforChipSwipeTap:
            return @"Waiting for Chip Swipe Tap";
        case WaitingforFallbackSwipe:
            return @"Waiting for Fallback Swipe";
        case WaitingforFallbackChip:
            return @"Waiting for Fallback Chip";
        case RetrievingDeviceLog:
            return @"Retrieving Device Log";
        case UpdatingFirmware:
            return @"Updating firmware";
        case SettingUpDevice:
            return @"Setting up device";
        case DownloadingFirmware:
            return @"Downloading firmware";
        case CheckingFirmwareUpdate:
            return @"Checking for firmware update";
        case CheckingDeviceSetup:
            return @"Checking for device set up";
        case Unknown:
        default:
            return nil;
    }
}

- (NSString *)getStringFromFirmwareUpdateOption:(IMSFirmwareUpdateAction)action{
    switch (action) {
        case FirmwareUpdateActionRequired:
            return @"FirmwareUpdateActionRequired";
        case FirmwareUpdateActionOptional:
            return @"FirmwareUpdateActionOptional";
        case FirmwareUpdateActionNo:
            return @"FirmwareUpdateActionNo";
        case FirmwareUpdateActionUnknown:
            return @"FirmwareUpdateActionUnknown";
        default:
            return @"FirmwareUpdateActionUnknown";
    }
}
@end
