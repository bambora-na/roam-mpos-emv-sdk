//
//  DeviceManagementHelper.h
//  mPOSSDKTestApp
//
//  Copyright © 2016 RoamData. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IMSNavigationViewController : UINavigationController

@end
