//
//  LedPairingViewController.m
//  mPOSSDKTestApp
//
//  Created by Abhiram Dinesh on 9/16/19.
//  Copyright © 2019 RoamData. All rights reserved.
//

#import "LedPairingViewController.h"

@interface LedPairingViewController ()

@property (weak, nonatomic) IBOutlet UIImageView *ledPairingViewContainer;

@end

@implementation LedPairingViewController

RUALedPairingView *pairingView;

- (void)viewDidLoad {
    [super viewDidLoad];
    pairingView = [[RUALedPairingView alloc] initWithFrame:CGRectMake(
                                                                      _ledPairingViewContainer.frame.size.width/3,
                                                                      _ledPairingViewContainer.frame.size.width/9,
                                                                      _ledPairingViewContainer.frame.size.width/3,
                                                                      _ledPairingViewContainer.frame.size.width/12
                                                                      )
                   ];
    [_ledPairingViewContainer addSubview:pairingView];
}

- (void)viewDidAppear:(BOOL)animated {
    [pairingView showSequences:_ledSequence];
}

- (IBAction)cancel:(id)sender {
    [_confirmationCallback cancel];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)restart:(id)sender {
    [self dismissViewControllerAnimated:YES completion:^{
        [_confirmationCallback restartLedPairingSequence];
    }];
    
}

- (IBAction)confirm:(id)sender {
    [_confirmationCallback confirm];
    [self dismissViewControllerAnimated:YES completion:nil];
}


@end
