//
//  LogViewController.m
//  mPOSSDKTestApp
//
//  Created by Abhiram Dinesh on 3/3/21.
//  Copyright © 2021 RoamData. All rights reserved.
//

#import "LogViewController.h"
#import <MessageUI/MessageUI.h>
#import "LogHelper.h"

@interface LogViewController ()<MFMailComposeViewControllerDelegate>
@property (weak, nonatomic) IBOutlet UITextView *logTextView;

@end

@implementation LogViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Hide Log" style:UIBarButtonItemStylePlain target:self action:@selector(hideLog)];
    self.navigationItem.leftBarButtonItem.tintColor = [UIColor darkGrayColor];
    [_logTextView setText:[LogHelper.sharedInstance getLogString]];
}

- (IBAction)clearLog:(id)sender {
    [LogHelper.sharedInstance clearLog];
    [_logTextView setText:@""];
}


- (IBAction)emailLog:(id)sender {
    if ([MFMailComposeViewController canSendMail])
    {
        MFMailComposeViewController *mail = [[MFMailComposeViewController alloc] init];
        mail.mailComposeDelegate = self;
        [mail setSubject:@"Ingenico mPOS SDK - Console Logs"];
        [mail setMessageBody:[_logTextView text] isHTML:YES];
        NSString *logFilePath = [[NSUserDefaults standardUserDefaults] objectForKey:@"log_file_path"];
        if (logFilePath.length > 0) {
            NSData *logFile = [NSData dataWithContentsOfFile:logFilePath];
            [mail addAttachmentData:logFile mimeType:@"text/txt" fileName:@"mpos_sdk_logs.log"];
        }
        [self presentViewController:mail animated:YES completion:NULL];
    }
    else {
        [self showAlertWithTitle:@"cannot send email" andMessage:@"This device cannot send email" andHanlder:nil];
    }
}

- (void)showAlertWithTitle:(NSString *)title andMessage:(NSString *)message andHanlder:(void (^)(UIAlertAction *action))handler{
    UIAlertController *controller = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:handler];
    [controller addAction:action];
    [self presentViewController:controller animated:YES completion:nil];
}

-(void) hideLog {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - MFMailComposeViewControllerDelegate Methods

- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    NSString *message;
    switch (result) {
        case MFMailComposeResultSent:
        {
            message = @"Email Sent Successfully";
            break;
        }
        case MFMailComposeResultSaved:
        {
            message = @"You saved a draft of this email";
            break;
        }
        case MFMailComposeResultCancelled:
        case MFMailComposeResultFailed:
        default:
        {
            message = @"An error occurred when trying to compose this email";
            break;
        }

    }
    [self dismissViewControllerAnimated:YES completion:^{
        [self showAlertWithTitle:@"Email" andMessage:message andHanlder:nil];
    }];
}



@end
