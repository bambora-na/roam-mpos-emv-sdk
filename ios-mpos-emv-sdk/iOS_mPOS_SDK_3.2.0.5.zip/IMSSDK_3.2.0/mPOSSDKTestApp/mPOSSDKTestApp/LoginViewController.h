//
//  LoginViewController.h
//  mPOSSDKTestApp
//
//  Copyright © 2016 RoamData. All rights reserved.
//

#import "IMSBaseViewController.h"
#import "TabBarViewController.h"
#import <UIKit/UIKit.h>

@interface LoginViewController : IMSBaseViewController <RUAReleaseHandler, RUAPairingListener>
@property (weak, nonatomic) IBOutlet UITextField *userNameTextField;
@property (weak, nonatomic) IBOutlet UITextField *passWordTextField;
@property (weak, nonatomic) IBOutlet UILabel *passWordLabel;
@property (weak, nonatomic) IBOutlet UILabel *userNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *credentialLabel;
@property (weak, nonatomic) IBOutlet UIButton *loginUseTouchIDButton;
- (IBAction)doOfflineLogin:(id)sender;
- (IBAction)doPing:(id)sender;
- (IBAction)doLogin:(id)sender;
- (IBAction)LoginUseTouchIDAction:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *loginButton;
@property (weak, nonatomic) IBOutlet UIButton *offlineLoginButton;

@end
