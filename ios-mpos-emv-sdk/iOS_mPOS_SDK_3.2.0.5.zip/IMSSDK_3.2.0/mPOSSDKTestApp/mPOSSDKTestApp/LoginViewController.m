//
//  PaymentAPIViewController.m
//  mPOSSDKTestApp
//
//  Copyright © 2016 RoamData. All rights reserved.
//

#import "LoginViewController.h"
#import "MerchantAPIViewController.h"
#import "PaymentAPIViewController.h"
#import "PaymentDeviceViewController.h"
#import "DeviceManagementHelper.h"
#import <LocalAuthentication/LocalAuthentication.h>
#import "LedPairingViewController.h"
@import Security;

@interface LoginViewController ()<UITextFieldDelegate>{
    BOOL isLoaded;
    id<RUALedPairingConfirmationCallback> _pairingConfirmationCallback;
    NSArray *_ledSequence;
}

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"Goback"] style:UIBarButtonItemStylePlain target:self action:@selector(goBack:)];
    self.navigationItem.leftBarButtonItem.tintColor = [UIColor darkGrayColor];
    [self.navigationItem.leftBarButtonItem setAccessibilityLabel:@"back_btn"];
    _userNameTextField.tag = 0;
    _passWordTextField.tag = 1;
    [_userNameTextField setIsAccessibilityElement:YES];
    [_userNameTextField setAccessibilityLabel:@"vc_login_et_username"];
    [_passWordTextField setAccessibilityLabel:@"vc_login_et_password"];
    [_loginButton setAccessibilityLabel:@"vc_login_btn_login"];
    [_offlineLoginButton setAccessibilityLabel:@"vc_login_btn_offlinelogin"];
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    self.sessionLabel.text = @"";
    if([[NSUserDefaults standardUserDefaults] objectForKey:@"lastLoggedInUN"] != nil){
        _userNameTextField.text = [[NSUserDefaults standardUserDefaults] objectForKey:@"lastLoggedInUN"];
    }
}

- (void)viewWillLayoutSubviews{
    [super viewWillLayoutSubviews];
    
    if(!isLoaded){
        isLoaded = YES;
    }
    else{
        CALayer *border = [CALayer layer];
        CGFloat borderWidth = 1;
        border.borderColor = [UIColor darkGrayColor].CGColor;
        border.frame = CGRectMake(0, _userNameTextField.frame.size.height - borderWidth, _userNameTextField.frame.size.width, borderWidth);
        border.borderWidth = borderWidth;
        _userNameTextField.borderStyle = UITextBorderStyleNone;
        [_userNameTextField.layer addSublayer:border];
        _userNameTextField.layer.masksToBounds = YES;

        CALayer *borderPW = [CALayer layer];
        borderPW.borderColor = [UIColor darkGrayColor].CGColor;
        borderPW.frame = CGRectMake(0, _passWordTextField.frame.size.height - borderWidth, _passWordTextField.frame.size.width, borderWidth);
        borderPW.borderWidth = borderWidth;
        _passWordTextField.borderStyle = UITextBorderStyleNone;
        [_passWordTextField.layer addSublayer:borderPW];
        _passWordTextField.layer.masksToBounds = YES;
    }
}

- (IBAction)goBack:(id)sender{
    [self setReleasingState:YES];
    [[Ingenico sharedInstance].PaymentDevice releaseDevice:(self)];
    [self.navigationController popViewControllerAnimated:YES];
    [[DeviceManagementHelper sharedInstance] stopScan];
}

- (IBAction)doLogin:(id)sender {
    [self loginWithUserName:_userNameTextField.text andPW:_passWordTextField.text];
}

- (IBAction)LoginUseTouchIDAction:(id)sender {
    [self loginUseTouchID];
}

- (void)loginUseTouchID{
    LAContext *context = [[LAContext alloc] init];
    NSError *error = nil;
    if ([context canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:&error]) {
        if([[NSUserDefaults standardUserDefaults] objectForKey:@"lastLoggedInUN"] != nil){
            
            NSDictionary *query = @{
                                    (id)kSecClass: (id)kSecClassGenericPassword,
                                    (id)kSecAttrService: @"mPOSService",
                                    (id)kSecReturnData: @YES,
                                    (id)kSecUseOperationPrompt: @"Authenticate to login",
                                    };
            CFTypeRef dataTypeRef = NULL;
            OSStatus status = SecItemCopyMatching((__bridge CFDictionaryRef)(query), &dataTypeRef);
            if (status == errSecSuccess) {
                NSData *resultData = (__bridge_transfer NSData *)dataTypeRef;
                NSString *password = [[NSString alloc] initWithData:resultData encoding:NSUTF8StringEncoding];
                dispatch_async(dispatch_get_main_queue(),^{
                    [self loginWithUserName:[[NSUserDefaults standardUserDefaults] objectForKey:@"lastLoggedInUN"] andPW:password];
                });
            }
            else {
                [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"biometricLoginEnabled"];
            }
        }
    }
}

-(bool)savePasswordToKeychain:(NSString *)password {
    if (!password) return false;
    CFErrorRef error = NULL;
    SecAccessControlRef sacObject = SecAccessControlCreateWithFlags(kCFAllocatorDefault,
                                                                    kSecAttrAccessibleWhenPasscodeSetThisDeviceOnly,
                                                                    kSecAccessControlTouchIDCurrentSet, &error);
    if (sacObject == NULL || error != NULL) {
        return false;
    }
    NSData *secretPasswordTextData = [password dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *attributes = @{
                                 (id)kSecClass: (id)kSecClassGenericPassword,
                                 (id)kSecAttrService: @"mPOSService",
                                 (id)kSecValueData: secretPasswordTextData,
                                 (id)kSecUseAuthenticationUI: (id)kSecUseAuthenticationUIAllow,
                                 (id)kSecAttrAccessControl: (__bridge_transfer id)sacObject
                                 };
    int result = SecItemAdd((__bridge CFDictionaryRef)attributes, nil);
    return result == 0;
}

-(bool) deletePasswordfromKeychain {
    NSDictionary *query = @{
                            (id)kSecClass: (id)kSecClassGenericPassword,
                            (id)kSecAttrService: @"mPOSService"
                            };
    int result = SecItemDelete((__bridge CFDictionaryRef)query);
    if (result == errSecItemNotFound){
        return true;
    }
    return result == 0;
}

- (void)loginWithUserName:(NSString *)uname andPW:(NSString *)pw{
    [self.view endEditing:YES];
        [self showProgressMessage:@"Logging in" andIsTransactionStoppable:NO];
        [[[Ingenico sharedInstance] User] loginwithUsername:uname andPassword:pw onResponse:^(IMSUserProfile *user, NSError *error) {
            [self dismissProgress];
            if(!error){
                [LogHelper.sharedInstance consoleLog:@"Login success"];
                [self setLoggedIn:true];
                [self setCurrentUserProfile:user];
                //Clear saved password and disable biometric login if different user logs in
                NSString * lastLoggedInUser = [[NSUserDefaults standardUserDefaults] objectForKey:@"lastLoggedInUN"];
                if (![lastLoggedInUser isEqualToString:uname] && [self deletePasswordfromKeychain]) {
                    [[NSUserDefaults standardUserDefaults] setObject:uname forKey:@"lastLoggedInUN"];
                    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"biometricLoginEnabled"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                }
                BOOL biometricLoginEnabled = [[NSUserDefaults standardUserDefaults] boolForKey:@"biometricLoginEnabled"];
                BOOL biometricLoginSupported = [[[LAContext alloc] init] canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:nil];
                if([self isConfigModeSet]){
                    [self goToMainMenu:user];
                }else{
                    if (!biometricLoginEnabled && biometricLoginSupported) {
                        UIAlertController *alertController = [UIAlertController
                                                             alertControllerWithTitle:@"TouchID/FaceID Login"
                                                             message:@"Enable TouchID/FaceID Login"
                                                             preferredStyle:UIAlertControllerStyleAlert];
                        UIAlertAction *cancelAction = [UIAlertAction
                                                       actionWithTitle:@"Cancel"
                                                       style:UIAlertActionStyleDefault
                                                       handler:^(UIAlertAction * _Nonnull action) {
                                                           [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"biometricLoginEnabled"];
                                                           [self goToMainMenu:user];
                                                       }];
                        [alertController addAction:cancelAction];
                        UIAlertAction *okAction = [UIAlertAction
                                                   actionWithTitle:@"Enable"
                                                   style:UIAlertActionStyleDefault
                                                   handler:^(UIAlertAction * _Nonnull action) {
                                                       if ([self savePasswordToKeychain:pw]) {
                                                           [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"biometricLoginEnabled"];
                                                       }
                                                       [self goToMainMenu:user];
                                                   }];
                        [alertController addAction:okAction];
                        [self presentViewController:alertController animated:YES completion:nil];
                    }
                    else {
                        [self goToMainMenu:user];
                    }
                }
            } else{
                if (error.code == InvalidCredentials && [self deletePasswordfromKeychain]) {
                    [[NSUserDefaults standardUserDefaults] setObject:nil forKey:@"lastLoggedInUN"];
                    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"biometricLoginEnabled"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                }
                UIAlertController *alertontroller = [UIAlertController
                                                     alertControllerWithTitle:@"Login Failed"
                                                     message:[self getResponseCodeString:error.code]
                                                     preferredStyle:UIAlertControllerStyleAlert];
                UIAlertAction *okAction = [UIAlertAction
                                           actionWithTitle:@"OK"
                                           style:UIAlertActionStyleDefault
                                           handler:nil];
                [alertontroller addAction:okAction];
                
                [self presentViewController:alertontroller animated:YES completion:nil];
                [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"login failed with error code %ld.",(long)error.code]];
            }
        }];
}

- (void) goToMainMenu:(IMSUserProfile*) user {
    UITabBarController *tbc = [self.storyboard instantiateViewControllerWithIdentifier:@"tabBarController"];
    tbc.selectedIndex= 0;
    [self showViewController:tbc sender:self];
    [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Login Success\n%@",user.description]];
    self.sessionLabel.text = [NSString stringWithFormat:@"Session Token: %@", user.session.sessionToken];
    if(![self isConfigModeSet]){
        [self checkDeviceStatus];
    }
}

- (void)offlineLoginWithUserName:(NSString *)uname andPW:(NSString *)pw{
    [self.view endEditing:YES];
    [self showProgressMessage:@"Offline logging in" andIsTransactionStoppable:NO];
    [[[Ingenico sharedInstance] StoreAndForward] loginOffline:uname andPassword:pw onResponse:^(NSError *error) {
        [self dismissProgress];
        if (error == nil) {
            [LogHelper.sharedInstance consoleLog:@"Offline login success"];
            [self setLoggedIn:true];
            UITabBarController *tbc = [self.storyboard instantiateViewControllerWithIdentifier:@"tabBarController"];
            tbc.selectedIndex= 0;
            [self showViewController:tbc sender:self];
        }else{
            UIAlertController *alertontroller = [UIAlertController
                                                 alertControllerWithTitle:@"Offline Login Failed"
                                                 message:[self getResponseCodeString:error.code]
                                                 preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *okAction = [UIAlertAction
                                       actionWithTitle:@"OK"
                                       style:UIAlertActionStyleDefault
                                       handler:nil];
            [alertontroller addAction:okAction];
            [self presentViewController:alertontroller animated:YES completion:nil];
            [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Offline login failed with error code %ld.",(long)error.code]];
        }
    }];
}

- (IBAction)doOfflineLogin:(id)sender {
    [self offlineLoginWithUserName:_userNameTextField.text andPW:_passWordTextField.text];
}

- (IBAction)doPing:(id)sender {
    [[Ingenico sharedInstance] ping:^(NSError *error) {
        NSString *title;
        NSString *message;
        if(error){
            title = @"Failure";
            message = [[NSString alloc] initWithFormat:@"Ping failed with error code %ld.",(long)error.code];
        }
        else{
            title = @"Success";
            message = @"Ping succeeded.";
        }
        UIAlertController *alertontroller = [UIAlertController
                                             alertControllerWithTitle:title
                                             message:message
                                             preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *okAction = [UIAlertAction
                                   actionWithTitle:@"OK"
                                   style:UIAlertActionStyleDefault
                                   handler:nil];
        [alertontroller addAction:okAction];
        [LogHelper.sharedInstance consoleLog:message];
        if(self.presentedViewController !=nil){
            [self.presentedViewController dismissViewControllerAnimated:NO completion:^{
                [self presentViewController:alertontroller animated:YES completion:nil];
            }];
        }
        else{
            [self presentViewController:alertontroller animated:YES completion:nil];
        }
    }];
}

- (IBAction)forgotPassword:(id)sender {
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Forgot Password" message:@"Enter Username" preferredStyle:UIAlertControllerStyleAlert];
    
    [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        [textField setPlaceholder:@"Username"];
    }];
    UIAlertAction *submitAction = [UIAlertAction actionWithTitle:@"Submit" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self.view endEditing:YES];
        [self showProgressMessage:@"Sending email...." andIsTransactionStoppable:NO];
        NSString *username = [alertController textFields].firstObject.text;
        [[[Ingenico sharedInstance] User] forgotPassword:username andOnDone:^(NSError * _Nullable error) {
            [self dismissProgress];
            if (error) {
                [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"forgotPassword failed with error code %ld.",(long)error.code]];
            }
            else {
                [LogHelper.sharedInstance consoleLog:@"forgotPassword email sent"];
            }
        }];
    }];
    [alertController addAction:submitAction];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
    [alertController addAction:cancelAction];
    [self presentViewController:alertController animated:YES completion:nil];
}




#pragma mark - UITextFieldDelegate Implementation
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if(textField.tag == 0){
        [_passWordTextField becomeFirstResponder];
        return NO;
    }
    else{
        [self.view endEditing:YES];
        return YES;
    }
}

#pragma mark - RUAReleaseHandler Implementation
-(void)done {
    [self setReleasingState:NO];
}


#pragma mark - RUAPairingListener Implementation

- (void)onPairFailed {
    [self showProgressMessage:@"pairing failed" andIsSuccess:NO];
}

- (void)onPairNotSupported {
    [self showProgressMessage:@"pairing not supported" andIsSuccess:NO];
}

- (void)onPairSucceeded {
    [self showProgressMessage:@"pairing success" andIsSuccess:YES];
}

-(void)onPairCancelled {
    [self showProgressMessage:@"pairing cancelled" andIsSuccess:NO];
}

-(void) onLedPairSequenceConfirmation:(NSArray *)ledSequence confirmationCallback:(id<RUALedPairingConfirmationCallback>)confirmationCallback {
    _pairingConfirmationCallback = confirmationCallback;
    _ledSequence = ledSequence;
    [self performSegueWithIdentifier:@"segue_to_led_pairing" sender:self];
}

#pragma mark - RUAPairingListener Implementation

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"segue_to_led_pairing"]) {
        LedPairingViewController *vc = segue.destinationViewController;
        vc.confirmationCallback = _pairingConfirmationCallback;
        vc .ledSequence = _ledSequence;
    }
}

@end
