//
//  PaymentAPIViewController.h
//  mPOSSDKTestApp
//
//  Copyright © 2016 RoamData. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IMSBaseViewController.h"

@interface PaymentAPIViewController : IMSBaseViewController

@property (weak, nonatomic) IBOutlet UITableView *paymentTableView;
@property (assign) BOOL ignoreReversalBeforeTxn;

@end
