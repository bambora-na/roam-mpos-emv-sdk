//
//  PaymentAPIViewController.m
//  mPOSSDKTestApp
//
//  Copyright © 2016 RoamData. All rights reserved.
//

#import "PaymentAPIViewController.h"
#import "IMSNavigationViewController.h"
#import "TabBarViewController.h"
#import "UIAlertController+Utility.h"

@interface PaymentAPIViewController ()<UITableViewDelegate, UITableViewDataSource>{
    NSArray *cashTransactionArrray;
    NSArray *transactionWithoutCardReaderArray;
    NSArray *transactionWithCardReaderArray;
    NSArray *pendingTransactionArray;
    NSArray *secureCardEntryArray;
    NSArray *loadTestingArray;
    NSArray *paymentAPIArray;
    NSArray *sectionTitleArray;
    NSArray *otherArray;
    __block UITextField *totalTF;
    __block UITextField *subtotalTF;
    __block UITextField *discountTF;
    __block UITextField *taxTF;
    __block UITextField *tipTF;
    __block UITextField *surchargeTF;
    __block UITextField *clerkIDTF;
    __block UITextField *authCodeTF;
    __block UITextField *stanTF;
    __block UITextField *invocieIDTF;
    __block UITextField *transactionNoteTF;
    __block UITextField *tokenFeeTF;
    __block UITextField *customRefTF;
    __block UITextField *tokenIDTF;
    __block UITextField *avsZipCodeTF;
    __block UITextField *avsAddressTF;
    __block UITextField *orderNumberTF;
    __block UITextField *localeTF;
    __block UITextField *currencyCodeTF;
    __block UIButton *cvvCheckBox;
    __block UIButton *avsCheckBox;
    __block UIButton *tokenEnrollCheckBox;
    __block UIButton *tokenUpdateCheckBox;
    __block UIButton *cardPresentCheckBox;
    __block UIButton *showNoteAndInvoiceOnReceiptCheckBox;
    IMSTransactionType transactionType;
    IMSTransactionResponse *_response;
    TransactionOnDone doneCallback;
    TransactionOnDone partialDoneCallback;
    UpdateProgress progressCallback;
    ApplicationSelectionHandler applicationSelectionCallback;
    IMSTransactionTypeSelectionHandler transactionTypeSelectionCallback;
    NSString * alertMessageTitle;
    NSArray *_pendingTransactions;
    NSIndexPath *_tableViewCellPath;
    IMSSecureCardEntryViewController *sceViewController;
    UITapGestureRecognizer *tapGesture;
    UIViewController *sceContainerVC;
    bool isViewController;
    bool isPartialAuth;
    bool isPerformingPartialAuth;
    bool withCardReader;
    bool canEnrollToken;
    bool canUpdateToken;
    bool isManualKeyed;
    bool isTokenTransaction;
    bool isResale;
    bool isReauth;
    bool isSCETransaction;
    bool checkIfCardPresent;
    NSInteger initialSubmittedAmount;
    NSInteger partialAuthAmount;
    NSMutableArray *partialTransactionIds;
    NSString * transactionGroupId;
}

@end

@implementation PaymentAPIViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    cashTransactionArrray = [[NSArray alloc] initWithObjects:
                             @"* Cash Sale",
                             @"* Cash Refund", nil];
    transactionWithoutCardReaderArray = [[NSArray alloc] initWithObjects:
                                         @"* Keyed sale",
                                         @"* Keyed auth",
                                         @"* Keyed force sale",
                                         @"* Keyed token enrollment",
                                         @"* Keyed token update",
                                         @"* Auth complete",
                                         @"* Credit refund against transaction",
                                         @"* Void transaction",
                                         @"* Token sale",
                                         @"* Credit sale adjust",
                                         @"* Partial Auth",
                                         @"* Credit Re-Sale",
                                         @"* Credit Re-Auth",
                                         @"* Credit auth adjust",
                                         @"* Partial Void",
                                         @"* Token Auth",
                                         nil];
    transactionWithCardReaderArray = [[NSArray alloc] initWithObjects:
                                      @"* Credit sale",
                                      @"* Credit auth",
                                      @"* Credit force sale",
                                      @"* Credit balance inquiry",
                                      @"* Debit sale",
                                      @"* Debit refund",
                                      @"* Credit refund",
                                      @"* Keyed Credit Sale",
                                      @"* Token enrollment",
                                      @"* Token update",
                                      @"* Debit balance inquiry",
                                      @"* AVS Only",
                                      @"* Sale",
                                      @"* Refund",
                                      @"* Balance Inquiry",
                                      @"* Keyed Credit Auth",
                                      @"* Keyed Credit Refund",
                                      @"* Keyed Token Enrollment",
                                      @"* Keyed Token Update",
                                      @"* VAS Only",
                                      @"* Void Transaction",
                                      nil];
    pendingTransactionArray = [[NSArray alloc] initWithObjects:
                               @"* Get pending transactions",
                               @"* Ignore pending transactions",
                               @"* Reverse pending transactions",
                               @"* Ignore Reversal Before Transaction",
                               @"* Reverse Single Transaction", nil];
    secureCardEntryArray = [[NSArray alloc] initWithObjects:
                            @"* Model view - Credit Sale",
                            @"* View controller - Credit Sale",
                            @"* Model view - Credit Auth",
                            @"* View controller - Credit Auth",
                            @"* Model view - Credit Refund",
                            @"* View controller - Credit Refund",nil];
    loadTestingArray = [[NSArray alloc] initWithObjects:@"* Transaction load testing", @"*Store and Forward Cash Transaction load testing", @"*Store and Forward Credit Sale Transaction load testing", @"*Store and Forward Credit Auth Transaction load testing", nil];
    otherArray = [[NSArray alloc] initWithObjects:@"* Get current capabilities", @"* Update Preference", nil];
    paymentAPIArray = [[NSArray alloc] initWithObjects:
                       cashTransactionArrray,
                       transactionWithoutCardReaderArray,
                       transactionWithCardReaderArray,
                       pendingTransactionArray,
                       secureCardEntryArray,
                       loadTestingArray,
                       otherArray,
					   nil];
    sectionTitleArray = [[NSArray alloc] initWithObjects:
                         @"Cash Transaction",
                         @"Transaction without card reader",
                         @"Transaction with card reader",
                         @"Manage pending transactions",
                         @"Secure card entry",
                         @"Load testing",
                         @"Others",nil];

    _paymentTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    _paymentTableView.tableHeaderView = [[UIView alloc] initWithFrame:CGRectZero];
    [_paymentTableView setAccessibilityLabel:@"vc_paymentapi_tableview"];
    [self setupCallbacks];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [(TabBarViewController *)self.parentViewController setCurrentVisibleChildViewController:self];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
     _paymentTableView.frame = CGRectMake(0, _paymentTableView.frame.origin.y-([UIApplication sharedApplication].statusBarFrame.size.height+self.parentViewController.navigationController.navigationBar.frame.size.height), _paymentTableView.frame.size.width, _paymentTableView.frame.size.height+[UIApplication sharedApplication].statusBarFrame.size.height+self.parentViewController.navigationController.navigationBar.frame.size.height);
}

#pragma mark TableViewDelegate Implementation

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.bounds.size.width, 35)];
    UILabel *sectionLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 0, tableView.bounds.size.width-20, 35)];
    sectionLabel.text = [sectionTitleArray objectAtIndex:section];
    sectionLabel.font = [UIFont fontWithName:@"Palatino-Italic" size:16];
    [headerView setBackgroundColor:[UIColor lightGrayColor]];
    [headerView addSubview:sectionLabel];
    return headerView;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return paymentAPIArray.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [[paymentAPIArray objectAtIndex:section] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *CellIdentifier = @"PaymentAPICell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    cell.textLabel.text = [[paymentAPIArray objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    cell.textLabel.textColor = [UIColor darkGrayColor];
    cell.textLabel.font = [UIFont fontWithName:@"Palatino" size:14];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    [cell setAccessibilityLabel:[NSString stringWithFormat:@"vc_paymentapi_section_%d_row_%d", (int)indexPath.section, (int)indexPath.row]];
    return cell;
}

- (void) resetTransactionProperties {
    transactionType = TransactionTypeUnknown;
    withCardReader = NO;
    canEnrollToken = NO;
    canUpdateToken = NO;
    isManualKeyed = NO;
    isTokenTransaction = NO;
    isResale = NO;
    isReauth = NO;
    isSCETransaction = NO;
    isPartialAuth = NO;
    checkIfCardPresent = NO;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    _tableViewCellPath = indexPath;
    [self resetTransactionProperties];
    if(indexPath.section == 0){
        // Cash transactions section
        if(indexPath.row == 0){
            alertMessageTitle = @"Cash Sale";
            transactionType = TransactionTypeCashSale;
        }
        else if(indexPath.row == 1){
            alertMessageTitle = @"Cash Refund";
            transactionType = TransactionTypeCashRefund;
            if([self getLastTransactionType] != TransactionTypeCashSale || [self getLastTransactionID] == nil){
                [self showErrorMessage:@"Please do a cash sale first" andErrorTitle:@"Error"];
                return;
            }
        }
    }
    else if(indexPath.section == 1){
        // Transactions without card reader section
        if(indexPath.row == 0){
            alertMessageTitle = @"Keyed Credit Sale";
            transactionType = TransactionTypeCreditSale;
            canEnrollToken = YES;
            canUpdateToken = YES;
            checkIfCardPresent = YES;
        }
        else if(indexPath.row == 1){
            alertMessageTitle = @"Keyed Credit Auth";
            transactionType = TransactionTypeCreditAuth;
            canEnrollToken = YES;
            canUpdateToken = YES;
            checkIfCardPresent = YES;
        }
        else if(indexPath.row == 2){
            alertMessageTitle = @"Keyed Credit Force";
            transactionType = TransactionTypeCreditForceSale;
            checkIfCardPresent = YES;
        }
        else if(indexPath.row == 3){
            alertMessageTitle = @"Keyed Token Enrollment";
            transactionType = TransactionTypeTokenEnrollment;
            canEnrollToken = YES;
        }
        else if(indexPath.row == 4){
            alertMessageTitle = @"Keyed Token Update";
            transactionType = TransactionTypeTokenEnrollment;
            canUpdateToken = YES;
        }
        else if(indexPath.row == 5){
            alertMessageTitle = @"Credit Auth Completion";
            transactionType = TransactionTypeCreditAuthCompletion;
            if([self getLastTransactionID] == nil){
                [self showErrorMessage:@"Please do a credit auth first" andErrorTitle:@"Error"];
                return;
            }
        }
        else if(indexPath.row == 6){
            alertMessageTitle = @"Closed Credit Refund";
            transactionType = TransactionTypeCreditRefund;
            if(([self getLastTransactionType] != TransactionTypeCreditSale &&
                [self getLastTransactionType] != TransactionTypeCreditSaleAdjust &&
                [self getLastTransactionType] != TransactionTypeCreditForceSale &&
                [self getLastTransactionType] != TransactionTypeCreditAuthCompletion) || [self getLastTransactionID] == nil){
                [self showErrorMessage:@"Please do a credit sale/credit force sale first" andErrorTitle:@"Error"];
                return;
            }
        }
        else if(indexPath.row == 7){
            alertMessageTitle = @"Void";
            [self doVoidTransaction:false];
            return;
        }
        else if(indexPath.row == 8){
            alertMessageTitle = @"Token Sale";
            transactionType = TransactionTypeCreditSale;
            isTokenTransaction = YES;
            if([self getLastTokenId] == nil){
                [self showErrorMessage:@"Enroll a token before trying to do a sale" andErrorTitle:@"Error"];
                return;
            }
        }
        else if(indexPath.row == 9){
            alertMessageTitle = @"Credit Sale Adjust";
            transactionType = TransactionTypeCreditSaleAdjust;
            if ([self getLastTransactionID] == nil) {
                [self showErrorMessage:@"Please do a cash/credit sale first" andErrorTitle:@"Error"];
                return;
            }
        }
        else if(indexPath.row == 10){
            alertMessageTitle = @"Partial Auth";
            transactionType = TransactionTypeCreditSale;
            isPartialAuth = YES;
            checkIfCardPresent = YES;
        }
        else if(indexPath.row == 11) {
            alertMessageTitle = @"Credit Resale";
            transactionType = TransactionTypeCreditSale;
            isResale = YES;
            canEnrollToken = YES;
            canUpdateToken = YES;
            if([self getLastTransactionID] == nil){
                [self showErrorMessage:@"Please do a credit sale first" andErrorTitle:@"Error"];
                return;
            }
        }
        else if(indexPath.row == 12) {
            alertMessageTitle = @"Credit Reauth";
            transactionType = TransactionTypeCreditAuth;
            isReauth = YES;
            canEnrollToken = YES;
            canUpdateToken = YES;
            if([self getLastTransactionID] == nil){
                [self showErrorMessage:@"Please do a credit auth first" andErrorTitle:@"Error"];
                return;
            }
        }
        else if(indexPath.row == 13){
            alertMessageTitle = @"Credit Auth Adjust";
            transactionType = TransactionTypeCreditAuthAdjust;
            if ([self getLastTransactionID] == nil) {
                [self showErrorMessage:@"Please do a credit auth first" andErrorTitle:@"Error"];
                return;
            }
        }
        else if(indexPath.row == 14){
            alertMessageTitle = @"Partial Void";
            [self doPartialVoidTransaction];
            return;
        }
        else if(indexPath.row == 15){
            alertMessageTitle = @"Token Auth";
            transactionType = TransactionTypeCreditAuth;
            isTokenTransaction = YES;
            if([self getLastTokenId] == nil){
                [self showErrorMessage:@"Enroll a token before trying to do a token auth" andErrorTitle:@"Error"];
                return;
            }
        }
    }
    else if(indexPath.section == 2){
        // Transactions with Card Reader Section
        withCardReader = YES;
        if(indexPath.row == 0){
            alertMessageTitle = @"Credit Sale";
            transactionType = TransactionTypeCreditSale;
            canEnrollToken = YES;
            canUpdateToken = YES;
        }
        else if(indexPath.row == 1){
            alertMessageTitle = @"Credit Auth";
            transactionType = TransactionTypeCreditAuth;
            canEnrollToken = YES;
            canUpdateToken = YES;
        }
        else if(indexPath.row == 2){
            alertMessageTitle = @"Credit Force";
            transactionType = TransactionTypeCreditForceSale;
        }
        else if(indexPath.row == 3){
            alertMessageTitle = @"Credit Balance Inquiry";
            transactionType = TransactionTypeCreditBalanceInquiry;
        }
        else if(indexPath.row == 4){
            alertMessageTitle = @"Debit Sale";
            transactionType = TransactionTypeDebitSale;
        }
        else if(indexPath.row == 5){
            alertMessageTitle = @"Debit Refund";
            transactionType = TransactionTypeDebitRefund;
        }
        else if(indexPath.row == 6){
            alertMessageTitle = @"Open Credit Refund";
            transactionType = TransactionTypeCreditRefund;
            canEnrollToken = YES;
            canUpdateToken = YES;
        }
        else if(indexPath.row == 7){
            alertMessageTitle = @"Keyed Credit Sale With Card Reader";
            transactionType = TransactionTypeCreditSale;
            isManualKeyed = YES;
            canEnrollToken = YES;
            canUpdateToken = YES;
            checkIfCardPresent = YES;
        }
        else if(indexPath.row == 8){
            alertMessageTitle = @"Token Enrollment";
            transactionType = TransactionTypeTokenEnrollment;
            canEnrollToken = YES;
        }
        else if(indexPath.row == 9){
            alertMessageTitle = @"Token Update";
            transactionType = TransactionTypeTokenEnrollment;
            canUpdateToken = YES;
        }
        else if(indexPath.row == 10){
            alertMessageTitle = @"Debit Balance Inquiry";
            transactionType = TransactionTypeDebitBalanceInquiry;
        }
        
        else if(indexPath.row == 11){
            alertMessageTitle = @"AVS Only";
            transactionType = TransactionTypeAVSOnly;
        }
        else if(indexPath.row == 12){
            alertMessageTitle = @"Sale";
            transactionType = TransactionTypeSale;
        }
        else if(indexPath.row == 13){
            alertMessageTitle = @"Refund";
            transactionType = TransactionTypeRefund;
        }
        else if(indexPath.row == 14){
            alertMessageTitle = @"Balnce Inquiry";
            transactionType = TransactionTypeBalanceInquiry;
        }
        else if(indexPath.row == 15){
            alertMessageTitle = @"Keyed Credit Auth With Card Reader";
            transactionType = TransactionTypeCreditAuth;
            isManualKeyed = YES;
            canEnrollToken = YES;
            canUpdateToken = YES;
            checkIfCardPresent = YES;
        }
        else if(indexPath.row == 16){
            alertMessageTitle = @"Keyed Credit Refund With Card Reader";
            transactionType = TransactionTypeCreditRefund;
            isManualKeyed = YES;
            canEnrollToken = YES;
            canUpdateToken = YES;
            checkIfCardPresent = YES;
        }
        else if(indexPath.row == 17){
            alertMessageTitle = @"Keyed Token Enrollment With Card Reader";
            transactionType = TransactionTypeTokenEnrollment;
            isManualKeyed = YES;
            canEnrollToken = YES;
            checkIfCardPresent = YES;
        }
        else if(indexPath.row == 18){
            alertMessageTitle = @"Keyed Token Update With Card Reader";
            transactionType = TransactionTypeTokenEnrollment;
            isManualKeyed = YES;
            canUpdateToken = YES;;
            checkIfCardPresent = YES;
        }
        else if(indexPath.row == 19){
            alertMessageTitle = @"VAS Only Transaction";
            [self showProgressMessage:@"Processing VAS Transaction" andIsTransactionStoppable:YES];
            [self processVasOnlyTransaction];
            [tableView deselectRowAtIndexPath:indexPath animated:NO];
            return;
        }
        else if(indexPath.row == 20){
            alertMessageTitle = @"Void Transaction With Card Reader";
            [self doVoidTransaction:true];
            [tableView deselectRowAtIndexPath:indexPath animated:NO];
            return;
        }
    }
    else if(indexPath.section == 3){
        // Pending Transactions Section
        if(indexPath.row == 0){
            // Get pending transactions
            [self getPendingTransactions];
        }
        else if(indexPath.row == 1){
            // Ignore pending transactions
            [self ignorePendingTransaction];
        }
        else if(indexPath.row == 2){
            // Reverse pending transactions
            [self reverseTransaction];
        } else if(indexPath.row == 3){
            // Ignore Reversal Before Transaction
            [self ignoreReversalBeforeTransaction];
        }
        else if(indexPath.row == 4){
            // Reverse Single Transaction
            [self reverseSingleTransaction];
        }
        return;
    }
    else if(indexPath.section == 4){
        // Secure card entry Section
        isSCETransaction = YES;
        isManualKeyed = YES;
        canEnrollToken = YES;
        canUpdateToken = YES;
        if(indexPath.row == 0){
            // Model view - Credit Sale
            alertMessageTitle = @"Secure Card Entry Credit Sale";
            isViewController = false;
            transactionType = TransactionTypeCreditSale;
            checkIfCardPresent = YES;
        }
        else if(indexPath.row == 1){
            // View controller - Credit Sale
            alertMessageTitle = @"Secure Card Entry Credit Sale";
            isViewController = true;
            transactionType = TransactionTypeCreditSale;
            checkIfCardPresent = YES;
        }
        else if(indexPath.row == 2){
            // Model view - Credit Auth
            alertMessageTitle = @"Secure Card Entry Credit Auth";
            isViewController = false;
            transactionType = TransactionTypeCreditAuth;
            checkIfCardPresent = YES;
        }
        else if(indexPath.row == 3){
            // View controller - Credit Auth
            alertMessageTitle = @"Secure Card Entry Credit Auth";
            isViewController = true;
            transactionType = TransactionTypeCreditAuth;
            checkIfCardPresent = YES;
        }
        else if(indexPath.row == 4){
            // Model view - Credit Refund
            alertMessageTitle = @"Secure Card Entry Credit Refund";
            isViewController = false;
            transactionType = TransactionTypeCreditRefund;
            checkIfCardPresent = YES;
        }
        else if(indexPath.row == 5){
            // View controller - Credit Refund
            alertMessageTitle = @"Secure Card Entry Credit Refund";
            isViewController = true;
            transactionType = TransactionTypeCreditRefund;
            checkIfCardPresent = YES;
        }
    }
    else if(indexPath.section == 5){
        // Stress test section
        __block UITextField *loadTestTransactionCountTF;
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
            if(indexPath.row == 0){
                [self doTransactionLoadTestingWithCounter:0 andTotal:(int)[loadTestTransactionCountTF.text integerValue]];
            }else if(indexPath.row == 1){
                [self doStoreAndForwardCashTransactionLoadTestingWithCounter:0 andTotal:(int)[loadTestTransactionCountTF.text integerValue]];
            }else if(indexPath.row == 2){
                [self doStoreAndForwardTransactionLoadTestingWithTransactionType:TransactionTypeCreditSale andCounter:0 andTotal:(int)[loadTestTransactionCountTF.text integerValue]];
            } else{
                [self doStoreAndForwardTransactionLoadTestingWithTransactionType:TransactionTypeCreditAuth andCounter:0 andTotal:(int)[loadTestTransactionCountTF.text integerValue]];
            }
        }];
        UIAlertController *alertontroller = [UIAlertController
                                             alertControllerWithTitle:@"Load testing"
                                             message:@"Please enter number of transactions to be done"
                                             preferredStyle:UIAlertControllerStyleAlert];
        [alertontroller addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeNumberPad;
            loadTestTransactionCountTF = textField;
        }];
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
        [alertontroller addAction:cancelAction];
        [alertontroller addAction:okAction];
        [self presentViewController:alertontroller animated:YES completion:nil];
        return;
    }
    else if(indexPath.section == 6){
        if(indexPath.row == 0){
            IMSCapabilities* capabilities = [[Ingenico sharedInstance] getCurrentCapabilities];
            [LogHelper.sharedInstance consoleLog:capabilities.description];
            return;
        }else{
            IMSPreference* pref = [[IMSPreference alloc] init];
            void (^setConfigMode)(IMSConfigMode mode) = ^void(IMSConfigMode mode) {
                [pref setConfigMode:mode];
                void (^setRetryCount)(NSUInteger retryCount) = ^void(NSUInteger retryCount) {
                    [pref setRetryCount:retryCount];
                    void (^setLocale)(NSLocale *locale) = ^void(NSLocale *locale) {
                    [pref setMerchantLocale:locale];
                    [self setConfigModeSet:YES];
                    [Ingenico.sharedInstance updatePreference:pref];
                    [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Update Preference: \nConfig Mode: %lu\nRetry Count: %lu" , (unsigned long)pref.configMode, (unsigned long)pref.retryCount]];
                    };
                    UIAlertController *localeAlert = [UIAlertController alertControllerWithTitle:nil message:@"Select Locale:" preferredStyle:UIAlertControllerStyleActionSheet];
                    UIAlertAction *enUS = [UIAlertAction actionWithTitle:@"en_US" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                        setLocale([[NSLocale alloc] initWithLocaleIdentifier:@"en_US"]);
                    }];
                    UIAlertAction *enCA = [UIAlertAction actionWithTitle:@"en_CA" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                        setLocale([[NSLocale alloc] initWithLocaleIdentifier:@"en_CA"]);
                    }];
                    UIAlertAction *frCA = [UIAlertAction actionWithTitle:@"fr_CA" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                        setLocale([[NSLocale alloc] initWithLocaleIdentifier:@"fr_CA"]);
                    }];
                    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
                    [localeAlert addAction:enUS];
                    [localeAlert addAction:enCA];
                    [localeAlert addAction:frCA];
                    [localeAlert addAction:cancel];
                    [self presentViewController:localeAlert animated:YES completion:nil];
                };
                UIAlertController *retryCountAlert = [UIAlertController alertControllerWithTitle:nil message:@"Select Retry Count:" preferredStyle:UIAlertControllerStyleActionSheet];
                UIAlertAction *zero = [UIAlertAction actionWithTitle:@"0" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                        setRetryCount(0);
                }];
                UIAlertAction *one = [UIAlertAction actionWithTitle:@"1" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                        setRetryCount(1);
                }];
                UIAlertAction *two = [UIAlertAction actionWithTitle:@"2" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                        setRetryCount(2);
                }];
                UIAlertAction *three = [UIAlertAction actionWithTitle:@"3" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                        setRetryCount(3);
                }];
                UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
                [retryCountAlert addAction:zero];
                [retryCountAlert addAction:one];
                [retryCountAlert addAction:two];
                [retryCountAlert addAction:three];
                [retryCountAlert addAction:cancel];
                [self presentViewController:retryCountAlert animated:YES completion:nil];
            };
            UIAlertController *configModeAlert = [UIAlertController alertControllerWithTitle:nil message:@"Select Config Mode:" preferredStyle:UIAlertControllerStyleActionSheet];
            UIAlertAction *Manual = [UIAlertAction actionWithTitle:@"Manual" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                setConfigMode(IMSConfigModeManual);
            }];
            UIAlertAction *Optimal = [UIAlertAction actionWithTitle:@"Optimal" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                setConfigMode(IMSConfigModeOptimal);
            }];
            UIAlertAction *Auto = [UIAlertAction actionWithTitle:@"Auto" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                setConfigMode(IMSConfigModeAuto);
            }];
            UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
            [configModeAlert addAction:Manual];
            [configModeAlert addAction:Optimal];
            [configModeAlert addAction:Auto];
            [configModeAlert addAction:cancel];
            [self presentViewController:configModeAlert animated:YES completion:nil];
        }
    }
    [self promptForAmount];
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}

#pragma Helper Methods

- (BOOL)shouldReversePendingTransactions{
    if (!_ignoreReversalBeforeTxn &&
        [[Ingenico sharedInstance].Payment hasPendingTransactions]) {
        [self showErrorMessage:@"Found pending transactions. Reverse them to proceed." andErrorTitle:@"Error"];
        return true;
    }
    return false;
}

-(void)promptForAmount{
    [self promptForAmountWithTransactionType:transactionType
                           andWithCardReader:withCardReader
                            andIsManualKeyed:isManualKeyed
                           andCanEnrollToken:canEnrollToken
                              andIsTokenSale:isTokenTransaction
                            andIsPartialAuth:isPartialAuth
                            andIsTokenUpdate:canUpdateToken
                                 andIsResale:isResale
                                 andIsReauth:isReauth
                         andIsSCETransaction:isSCETransaction
                       andCheckIfCardPresent:checkIfCardPresent];
}

- (void)promptForAmountWithTransactionType:(IMSTransactionType)transactionType
                         andWithCardReader:(BOOL)isWithReader
                          andIsManualKeyed:(BOOL)isManualKeyed
                         andCanEnrollToken:(BOOL)enrollToken
                            andIsTokenSale:(BOOL)isTokenSale
                          andIsPartialAuth:(BOOL)isPartialAuth
                          andIsTokenUpdate:(BOOL)isTokenUpdate
                               andIsResale:(BOOL)isResale
                               andIsReauth:(BOOL)isReauth
                       andIsSCETransaction:(BOOL)isSCETransaction
                     andCheckIfCardPresent:(BOOL)checkIfCardPresent{
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        if((totalTF.text.intValue < 0) &&
           (transactionType != TransactionTypeTokenEnrollment &&
            transactionType != TransactionTypeCreditBalanceInquiry &&
            transactionType != TransactionTypeDebitBalanceInquiry &&
            transactionType != TransactionTypeBalanceInquiry &&
            transactionType != TransactionTypeAVSOnly)){
            [self showErrorMessage:@"Please provide valid total amount" andErrorTitle:@"Wrong Amount"];
        }
        else{
            [self.view endEditing:YES];
            [self showProgressMessage:@"Processing Transaction" andIsTransactionStoppable:YES];
            IMSBaseTransactionRequest *TransactionRequest = [self  getSampleTransactionRequestwithTotalAmount:[totalTF.text integerValue]
                                                                    andSubtotalAmount:[subtotalTF.text integerValue]
                                                                    andDiscountAmount:[discountTF.text length]>0?[discountTF.text integerValue]:0
                                                                         andTaxAmount:[taxTF.text length]>0?[taxTF.text integerValue]:0
                                                                         andTipAmount:[tipTF.text length]>0?[tipTF.text integerValue]:0
                                                                           andClerkID:[clerkIDTF.text length]>0?clerkIDTF.text:nil
                                                                              andStan:[stanTF.text length]>0?[stanTF.text integerValue] :-1
                                                                              andType:transactionType
                                                                   andCustomReference:[customRefTF.text length]>0?customRefTF.text:nil
                                                                    andWithCardReader:isWithReader
                                                                     andIsManualKeyed:isManualKeyed
                                                                    andCanEnrollToken:enrollToken
                                                                       andIsTokenSale:isTokenSale
                                                                     andIsPartialAuth:isPartialAuth
                                                                     andIsTokenUpdate:isTokenUpdate
                                                                          andIsResale:isResale
                                                                          andIsReauth:isReauth
                                                                  andIsSCETransaction:isSCETransaction
                                                                   andSurchargeAmount:[surchargeTF.text length]>0?[surchargeTF.text integerValue]:0
                                                                      andCurrencyCode:[currencyCodeTF.text length]>0?currencyCodeTF.text:@"USD"];
            if ([localeTF.text isEqualToString:@"en_US"] ||
                [localeTF.text isEqualToString:@"en_CA"] ||
                [localeTF.text isEqualToString:@"fr_CA"]) {
                TransactionRequest.locale = [NSLocale localeWithLocaleIdentifier:localeTF.text];
            }
            if(TransactionRequest == nil){
                [self showErrorMessage:@"Total amount is less than 0, please provide valid subtotal/discount/tax/tip/surcharge amount" andErrorTitle:@"Error"];
                return;
            }
            totalTF = nil;
            subtotalTF = nil;
            discountTF = nil;
            taxTF = nil;
            tipTF = nil;
            surchargeTF = nil;
            clerkIDTF = nil;
            avsCheckBox = nil;
            cvvCheckBox = nil;
            tokenEnrollCheckBox = nil;
            tokenUpdateCheckBox = nil;
            cardPresentCheckBox = nil;
            avsAddressTF = nil;
            avsZipCodeTF = nil;
            currencyCodeTF = nil;
            showNoteAndInvoiceOnReceiptCheckBox = nil;
            [self setLastTransactionType:transactionType];
            [self setLastTransactionID:nil];
            switch (transactionType) {
                case TransactionTypeCashSale:
                    [[Ingenico sharedInstance].Payment processCashTransaction:TransactionRequest andOnDone:doneCallback];
                    break;
                case TransactionTypeCreditSale:
                {
                    if(isTokenSale) {
                        [[Ingenico sharedInstance].Payment processTokenSaleTransaction:TransactionRequest
                                                                     andUpdateProgress:progressCallback
                                                                             andOnDone:doneCallback];
                    }
                    else if(isPartialAuth) {
                        [[Ingenico sharedInstance].Payment processKeyedTransaction:TransactionRequest andOnDone:doneCallback];
                    }
                    else if(isResale) {
                        [[Ingenico sharedInstance].Payment processCreditResaleTransaction:TransactionRequest
                                                                        andUpdateProgress:progressCallback
                                                                                andOnDone:doneCallback];
                    }
                    else if(!isWithReader && !isManualKeyed){
                        [[Ingenico sharedInstance].Payment processKeyedTransaction:TransactionRequest andOnDone:doneCallback];
                    }
                    else if(isManualKeyed && isWithReader){
                        [[Ingenico sharedInstance].Payment processKeyedTransactionWithCardReader:TransactionRequest
                                                                               andUpdateProgress:progressCallback
                                                                                       andOnDone:doneCallback];
                    }
                    else if(!isManualKeyed && isWithReader){
                        [[Ingenico sharedInstance].Payment processCreditSaleTransactionWithCardReader:TransactionRequest
                                                                                    andUpdateProgress:progressCallback
                                                                                 andSelectApplication:applicationSelectionCallback
                                                                                            andOnDone:doneCallback];
                    }
                    else if(isSCETransaction){
                        [self dismissProgress];
                        if(isViewController){
                            IMSNavigationViewController *navigationController =
                            [[IMSNavigationViewController alloc] initWithRootViewController:
                             [[IMSSecureCardEntryViewController alloc] initWithCreditSaleTransactionRequest:TransactionRequest
                                                                                andUpdateProgress:^(IMSProgressMessage progressMessage, NSString * _Nullable extraMessage) {
                                                                                    NSLog(@"SCE Progress message :%@",[self getProgressStrFromMessage:progressMessage]);
                                                                                    
                                                                                }
                                                                                        andOnDone:doneCallback]];
                            [self presentViewController:navigationController animated:YES completion:nil];
                        }
                        else{
                            [self setupAndDisplaySceModal:TransactionRequest andTransactionType:transactionType];
                        }

                    }
                    break;
                }
                case TransactionTypeCreditAuth:
                {
                    if(isTokenSale) {
                        [[Ingenico sharedInstance].Payment processTokenAuthTransaction:TransactionRequest
                                                                     andUpdateProgress:progressCallback
                                                                             andOnDone:doneCallback];
                    }
                    else if(isReauth) {
                        [[Ingenico sharedInstance].Payment processCreditReauthTransaction:TransactionRequest
                                                                        andUpdateProgress:progressCallback
                                                                                andOnDone:doneCallback];
                    }
                    else if(isWithReader && isManualKeyed){
                        [[Ingenico sharedInstance].Payment processKeyedCreditAuthTransactionWithCardReader:TransactionRequest
                                                                                         andUpdateProgress:progressCallback
                                                                                                 andOnDone:doneCallback];
                    }
                    else if(isWithReader){
                        [[Ingenico sharedInstance].Payment processCreditAuthTransactionWithCardReader:TransactionRequest
                                                                                    andUpdateProgress:progressCallback
                                                                                 andSelectApplication:applicationSelectionCallback
                                                                                            andOnDone:doneCallback];
                    }
                    else if(isSCETransaction){
                        [self dismissProgress];
                        if(isViewController){
                            IMSNavigationViewController *navigationController =
                            [[IMSNavigationViewController alloc] initWithRootViewController:
                             [[IMSSecureCardEntryViewController alloc] initWithCreditAuthTransactionRequest:TransactionRequest
                                                                                          andUpdateProgress:^(IMSProgressMessage progressMessage, NSString * _Nullable extraMessage) {
                                                                                              NSLog(@"SCE Progress message :%@",[self getProgressStrFromMessage:progressMessage]);
                                                                                          }
                                                                                                  andOnDone:doneCallback]];
                            [self presentViewController:navigationController animated:YES completion:nil];
                        }
                        else{
                            [self setupAndDisplaySceModal:TransactionRequest andTransactionType:transactionType];
                        }
                        
                    }
                    else{
                        [[Ingenico sharedInstance].Payment processKeyedCreditAuthTransaction:TransactionRequest andOnDone:doneCallback];
                    }
                    break;
                }
                case TransactionTypeDebitSale:
                    [[Ingenico sharedInstance].Payment processDebitSaleTransactionWithCardReader:TransactionRequest
                                                                               andUpdateProgress:progressCallback
                                                                            andSelectApplication:applicationSelectionCallback
                                                                                       andOnDone:doneCallback];
                    break;
                case TransactionTypeCashRefund:
                    [[Ingenico sharedInstance].Payment processCashRefundTransaction:TransactionRequest andOnDone:doneCallback];
                    break;
                case TransactionTypeCreditRefund:
                {
                    if(isSCETransaction){
                        [self dismissProgress];
                        if(isViewController){
                            IMSNavigationViewController *navigationController =
                            [[IMSNavigationViewController alloc] initWithRootViewController:
                             [[IMSSecureCardEntryViewController alloc] initWithCreditRefundTransactionRequest:TransactionRequest
                                                                                andUpdateProgress:^(IMSProgressMessage progressMessage, NSString * _Nullable extraMessage) {
                                                                                    [LogHelper.sharedInstance consoleLog:[NSString stringWithFormat:@"Progress Message:%@", [self getProgressStrFromMessage:progressMessage]]];
                                                                                }
                                                                                        andOnDone:doneCallback]];
                            [self presentViewController:navigationController animated:YES completion:nil];
                        }
                        else{
                            [self setupAndDisplaySceModal:TransactionRequest andTransactionType:transactionType];
                        }
                    }
                    else if(!isWithReader){
                        [[Ingenico sharedInstance].Payment processCreditRefundAgainstTransaction:TransactionRequest andOnDone:doneCallback];
                    }
                    else if(isWithReader && isManualKeyed){
                        [[Ingenico sharedInstance].Payment processKeyedCreditRefundTransactionWithCardReader:TransactionRequest
                                                                                           andUpdateProgress:progressCallback
                                                                                                   andOnDone:doneCallback];
                    }
                    else{
                        [[Ingenico sharedInstance].Payment processCreditRefundWithCardReader:TransactionRequest
                                                                           andUpdateProgress:progressCallback
                                                                        andSelectApplication:applicationSelectionCallback
                                                                                   andOnDone:doneCallback];
                    }
                    break;
                }
                case TransactionTypeDebitRefund:
                    [[Ingenico sharedInstance].Payment processDebitRefundWithCardReader:TransactionRequest
                                                                      andUpdateProgress:progressCallback
                                                                   andSelectApplication:applicationSelectionCallback
                                                                              andOnDone:doneCallback];
                    break;
                case TransactionTypeCreditAuthCompletion:
                    [[Ingenico sharedInstance].Payment processCreditAuthCompleteTransaction:TransactionRequest andOnDone:doneCallback];
                    break;
                case TransactionTypeCreditForceSale:
                    if(!isWithReader){
                        [[Ingenico sharedInstance].Payment processKeyedCreditForceSaleTransaction:TransactionRequest andOnDone:doneCallback];
                    }
                    else{
                        [[Ingenico sharedInstance].Payment processCreditForceSaleTransactionWithCardReader:TransactionRequest
                                                                                         andUpdateProgress:progressCallback
                                                                                      andSelectApplication:applicationSelectionCallback
                                                                                                 andOnDone:doneCallback];
                    }
                    break;
                case TransactionTypeTokenEnrollment:
                    if(isWithReader && isManualKeyed){
                        [[Ingenico sharedInstance].Payment processKeyedTokenEnrollmentTransactionWithCardReader:TransactionRequest andUpdateProgress:progressCallback andOnDone:doneCallback];
                    }
                    else if(isWithReader){
                        [[Ingenico sharedInstance].Payment processTokenEnrollmentWithCardReader:TransactionRequest
                                                                              andUpdateProgress:progressCallback
                                                                           andSelectApplication:applicationSelectionCallback
                                                                                      andOnDone:doneCallback];
                    }
                    else{
                        [[Ingenico sharedInstance].Payment processKeyedTokenEnrollment:TransactionRequest
                                                                         andOnDone:doneCallback];
                    }
                    break;
                case TransactionTypeCreditBalanceInquiry:
                    [[Ingenico sharedInstance].Payment processCreditBalanceInquiryWithCardReader:TransactionRequest
                                                                               andUpdateProgress:progressCallback
                                                                            andSelectApplication:applicationSelectionCallback
                                                                                       andOnDone:doneCallback];
                    break;
                case TransactionTypeDebitBalanceInquiry:
                    [[Ingenico sharedInstance].Payment processDebitBalanceInquiryWithCardReader:TransactionRequest
                                                                              andUpdateProgress:progressCallback
                                                                           andSelectApplication:applicationSelectionCallback
                                                                                      andOnDone:doneCallback];
                    break;
                case TransactionTypeBalanceInquiry:
                    [[Ingenico sharedInstance].Payment processBalanceInquiryWithCardReader:TransactionRequest
                                                                              andUpdateProgress:progressCallback
                                                                           andSelectApplication:applicationSelectionCallback
                                                               andTransactionTypeSelection:transactionTypeSelectionCallback
                                                                                      andOnDone:doneCallback];
                    break;
                case TransactionTypeCreditSaleAdjust:
                    [[Ingenico sharedInstance].Payment processCreditSaleAdjustTransaction:TransactionRequest
                                                                        andUpdateProgress:progressCallback
                                                                                andOnDone:doneCallback];
                    break;
                case TransactionTypeCreditAuthAdjust:
                    [[Ingenico sharedInstance].Payment processCreditAuthAdjustTransaction:TransactionRequest
                                                                        andUpdateProgress:progressCallback
                                                                                andOnDone:doneCallback];
                    break;
                case TransactionTypeAVSOnly:
                    [[Ingenico sharedInstance].Payment processAVSOnlyTransactionWithCardReader:TransactionRequest
                                                                             andUpdateProgress:progressCallback
                                                                          andSelectApplication:applicationSelectionCallback
                                                                                     andOnDone:doneCallback];
                    break;
                case TransactionTypeSale:
                    [[Ingenico sharedInstance].Payment processSaleTransactionWithCardReader:TransactionRequest andUpdateProgress:progressCallback andSelectApplication:applicationSelectionCallback andTransactionTypeSelection:transactionTypeSelectionCallback andOnDone:doneCallback];
                    break;
                case TransactionTypeRefund:
                    [[Ingenico sharedInstance].Payment processRefundTransactionWithCardReader:TransactionRequest andUpdateProgress:progressCallback andSelectApplication:applicationSelectionCallback andTransactionTypeSelection:transactionTypeSelectionCallback andOnDone:doneCallback];
                    break;
                default:
                    break;
            }
        }}];

    if (![self shouldReversePendingTransactions]) {
        [self showAmountAlertControllerWithAction:okAction andTransactionType:transactionType andWithCardReader:isWithReader andCanEnrollToken:enrollToken andIsTokenUpdate: isTokenUpdate andIsManualKeyed:isManualKeyed andIsSCETransaction:isSCETransaction andCheckIfCardPresent:checkIfCardPresent andIsTokenSale:isTokenSale];
    }

}

- (void)dismissModalView{
    if (sceContainerVC) {
        [sceContainerVC.view removeFromSuperview];
        [sceContainerVC removeFromParentViewController];
        sceContainerVC = nil;
    }
    if(sceViewController){
        [sceViewController.view removeFromSuperview];
        [sceViewController removeFromParentViewController];
        sceViewController = nil;
    }
    if(tapGesture){
        [self.view removeGestureRecognizer:tapGesture];
        tapGesture = nil;
    }
}

- (void)cancelSecureCardEntry{
    [self dismissViewControllerAnimated:NO completion:nil];
}

-(void)doPartialVoidTransaction{
    if ([self getLastTransactionID] == nil) {
        [self showErrorMessage:@"Please do a auth or authadjust transaction first" andErrorTitle:@"Error"];
    } else {
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
            [self.view endEditing:YES];
            [self showProgressMessage:@"Processing Transaction" andIsTransactionStoppable:YES];
            IMSAmount *amount = [[IMSAmount alloc] initWithTotal:[totalTF.text integerValue] andSubtotal:0  andTax:0 andDiscount:0 andDiscountDescription:nil  andTip:0 andCurrency:@"USD" andSurcharge:0];
            IMSPartialVoidTransactionRequest *transactionRequest = [[IMSPartialVoidTransactionRequest alloc] initWithAmount:amount andOriginalSaleTransactionID:[self getLastTransactionID] andClerkID:[clerkIDTF.text length]>0?clerkIDTF.text:nil andLongitude:[(TabBarViewController *)self.parentViewController getLongitude] andLatitude:[(TabBarViewController *)self.parentViewController getLatitude] andCustomReference:[customRefTF.text length]>0?customRefTF.text:nil andTransactionNotes:[transactionNoteTF.text length]>0?transactionNoteTF.text:nil andOrderNumber:[orderNumberTF.text length]>0?orderNumberTF.text:nil];
            [self setLastTransactionType:TransactionTypeUnknown];
            clerkIDTF = nil;
            [[Ingenico sharedInstance].Payment processPartialVoidTransaction:transactionRequest andOnDone:doneCallback];
        }];
        UIAlertController *alertController = [UIAlertController
                                             alertControllerWithTitle:@"Enter ClerkID"
                                             message:@"Please provide clerkID"
                                             preferredStyle:UIAlertControllerStyleAlert];
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeNumberPad;
            textField.placeholder = @"Total Amount";
            textField.accessibilityLabel = @"vc_paymentapi_total_amount";
            totalTF = textField;
        }];
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeDefault;
            textField.placeholder = @"ClerkID(Optional)";
            textField.accessibilityLabel = @"vc_paymentapi_clerk_id";
            clerkIDTF = textField;
        }];
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeDefault;
            textField.placeholder = @"Transaction Note(optional)";
            textField.accessibilityLabel = @"vc_paymentapi_transaction_note";
            transactionNoteTF = textField;
        }];
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeDefault;
            textField.placeholder = @"Custom Reference(Optional)";
            textField.accessibilityLabel = @"vc_paymentapi_custom_ref";
            customRefTF = textField;
        }];
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeNumberPad;
            textField.placeholder = @"Order Number(Optional)";
            textField.accessibilityLabel = @"vc_paymentapi_order_number";
            orderNumberTF = textField;
        }];
        [alertController addAction:okAction];
        [self presentViewController:alertController animated:YES completion:nil];
    }
}

- (void)doVoidTransaction:(BOOL)isWithCardReader {
    if(([self getLastTransactionType] != TransactionTypeCreditSale &&
        [self getLastTransactionType] != TransactionTypeDebitSale &&
        [self getLastTransactionType] != TransactionTypeCreditAuth &&
        [self getLastTransactionType] != TransactionTypeCreditAuthCompletion &&
        [self getLastTransactionType] != TransactionTypeCreditForceSale &&
        [self getLastTransactionType] != TransactionTypeCreditRefund &&
        [self getLastTransactionType] != TransactionTypeDebitRefund &&
        [self getLastTransactionType] != TransactionTypeCreditSaleAdjust &&
        [self getLastTransactionType] != TransactionTypeCreditAuthAdjust &&
        [self getLastTransactionType] != TransactionTypeSale &&
        [self getLastTransactionType] != TransactionTypeRefund) || [self getLastTransactionID] == nil){
        [self showErrorMessage:@"Please do a credit/debit/auth/authcomplete/creditforce/creditrefund/debitrefund/adjust transaction first" andErrorTitle:@"Error"];
    }
    else{
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
            [self.view endEditing:YES];
            IMSVoidTransactionRequest *TransactionRequest = [[IMSVoidTransactionRequest alloc] initWithOriginalSaleTransactionID:[self getLastTransactionID] andClerkID:[clerkIDTF.text length]>0?clerkIDTF.text:nil andLongitude:[(TabBarViewController *)self.parentViewController getLongitude] andLatitude:[(TabBarViewController *)self.parentViewController getLatitude] andCustomReference:[customRefTF.text length]>0?customRefTF.text:nil andTransactionNotes:[transactionNoteTF.text length]>0?transactionNoteTF.text:nil andOrderNumber:[orderNumberTF.text length]>0?orderNumberTF.text:nil andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected];
            [self setLastTransactionType:TransactionTypeUnknown];
            clerkIDTF = nil;
            if(isWithCardReader){
                [[Ingenico sharedInstance].Payment processVoidTransactionWithCardReader:TransactionRequest andUpdateProgress:progressCallback andSelectApplication:applicationSelectionCallback andOnDone:doneCallback];
            }else{
                [self showProgressMessage:@"Processing Transaction" andIsTransactionStoppable:YES];
                [[Ingenico sharedInstance].Payment processVoidTransaction:TransactionRequest andOnDone:doneCallback];
            }
        }];
        UIAlertController *alertController = [UIAlertController
                                             alertControllerWithTitle:@"Enter ClerkID"
                                             message:@"Please provide clerkID"
                                             preferredStyle:UIAlertControllerStyleAlert];
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeDefault;
            textField.placeholder = @"ClerkID(Optional)";
            textField.accessibilityLabel = @"vc_paymentapi_clerk_id";
            clerkIDTF = textField;
        }];
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeDefault;
            textField.placeholder = @"Transaction Note(optional)";
            textField.accessibilityLabel = @"vc_paymentapi_transaction_note";
            transactionNoteTF = textField;
        }];
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeDefault;
            textField.placeholder = @"Custom Reference(Optional)";
            textField.accessibilityLabel = @"vc_paymentapi_custom_ref";
            customRefTF = textField;
        }];
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeNumberPad;
            textField.placeholder = @"Order Number(Optional)";
            textField.accessibilityLabel = @"vc_paymentapi_order_number";
            orderNumberTF = textField;
        }];
        [alertController addCheckBoxWithTitle:@"ShowNoteAndInvoiceOnReceipt" andConfigurationHandler:^(UIButton * _Nonnull checkBox) {
            checkBox.accessibilityLabel = @"vc_paymentapi_show_note_cb";
            showNoteAndInvoiceOnReceiptCheckBox = checkBox;
        }];
        [alertController addAction:okAction];
        [self presentViewController:alertController animated:YES completion:nil];
    }
}

- (void) voidLastPartialTransaction {
    if (partialTransactionIds.count != 0) {
        NSString * transactionId = partialTransactionIds.lastObject;
        [partialTransactionIds removeLastObject];
        IMSVoidTransactionRequest *TransactionRequest = [[IMSVoidTransactionRequest alloc] initWithOriginalSaleTransactionID:transactionId andClerkID:[clerkIDTF.text length]>0?clerkIDTF.text:nil andLongitude:[(TabBarViewController *)self.parentViewController getLongitude] andLatitude:[(TabBarViewController *)self.parentViewController getLatitude] andCustomReference:[customRefTF.text length]>0?customRefTF.text:nil];
        [[Ingenico sharedInstance].Payment processVoidTransaction:TransactionRequest andOnDone:partialDoneCallback];
    }
}

- (void)showErrorMessage:(NSString *)errorMessage andErrorTitle:(NSString *)errorTitle{
    [self dismissProgress];
    UIAlertController *controller = [UIAlertController alertControllerWithTitle:errorTitle message:errorMessage preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
    [controller addAction:action];
    [self presentViewController:controller animated:YES completion:nil];
}

- (void)showAlertWithTitle:(NSString *)title andMessage:(NSString *)message andHanlder:(void (^)(UIAlertAction *action))handler{
    UIAlertController *controller = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [controller.message setAccessibilityLabel:@"vc_paymentapi_alert_message"];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:handler];
    [controller addAction:action];
    [self presentViewController:controller animated:YES completion:nil];
}

- (void)doStoreAndForwardTransactionLoadTestingWithTransactionType:(IMSTransactionType)type andCounter:(int)counter andTotal:(int)total{
    __weak typeof(self) weakSelf = self;
    [self.view endEditing:YES];
    [self showProgressMessage:[NSString stringWithFormat:@"Processing Transaction #%d", counter] andIsTransactionStoppable:YES];
    UpdateProgress updateProgress = ^void(IMSProgressMessage message, NSString *extraMessage){
        NSString *strMessage = [weakSelf getProgressStrFromMessage:message];
        if(strMessage){
            [weakSelf showProgressMessage:strMessage andIsTransactionStoppable:YES];
        }
    };
    ApplicationSelectionHandler applicationSelectionCallback = ^void(NSArray *applicationList, NSError *error, ApplicationSelectedResponse reponse){
        [weakSelf dismissProgress];
        UIAlertController *alertView = [UIAlertController
                                        alertControllerWithTitle:@"Select application for your card"
                                        message:@""
                                        preferredStyle:UIAlertControllerStyleActionSheet];
        for (RUAApplicationIdentifier *appID in applicationList) {
            UIAlertAction *ok = [UIAlertAction
                                 actionWithTitle:appID.applicationLabel ? appID.applicationLabel : @""
                                 style:UIAlertActionStyleDefault
                                 handler:^(UIAlertAction *action) {
                                     [weakSelf showProgressMessage:@"Processing card transaction" andIsTransactionStoppable:YES];
                                     [alertView dismissViewControllerAnimated:YES completion:nil];
                                     reponse(appID);
                                 }];
            [alertView addAction:ok];
        }
        UIAlertAction *cancel = [UIAlertAction
                                 actionWithTitle:@"Cancel"
                                 style:UIAlertActionStyleCancel
                                 handler:^(UIAlertAction *action) {
                                     reponse(nil);
                                 }];
        [alertView addAction:cancel];
        [weakSelf presentViewController:alertView animated:YES completion:nil];
    };
    TransactionOnDone onDone = ^void(IMSTransactionResponse *response, NSError *error){
        [weakSelf dismissProgress];
        [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:
                                              @"Store and Forward Transaction number %d Response:\n%@",
                                              counter, response.description]];
        [LogHelper.sharedInstance consoleLog:[[Ingenico sharedInstance] getCurrentCapabilities].description];
        if(error.code == TransactionCancelled){
            return;
        }
        if(counter < total - 1){
            int newNumber = counter +1;
            [NSThread sleepForTimeInterval:0.5f];
            [weakSelf doStoreAndForwardTransactionLoadTestingWithTransactionType:type andCounter:newNumber andTotal:total];
        }
    };
    if(type == TransactionTypeCreditSale){
        IMSStoreAndForwardCreditSaleTransactionRequest *request = (IMSStoreAndForwardCreditSaleTransactionRequest *)[self getSampleTransactionRequestwithTotalAmount:100
                                                                                                                                               andSubtotalAmount:0
                                                                                                                                               andDiscountAmount:0
                                                                                                                                                    andTaxAmount:0
                                                                                                                                                    andTipAmount:0
                                                                                                                                                      andClerkID:nil
                                                                                                                                                         andStan:0
                                                                                                                                                         andType:TransactionTypeCreditSale
                                                                                                                                              andCustomReference:nil
                                                                                                                                               andWithCardReader:YES
                                                                                                                                                andIsManualKeyed:NO
                                                                                                                                               andCanEnrollToken:NO
                                                                                                                                                  andIsTokenSale:NO
                                                                                                                                                andIsPartialAuth:NO
                                                                                                                                                andIsTokenUpdate:NO
                                                                                                                                                     andIsResale:NO
                                                                                                                                                     andIsReauth:NO
                                                                                                                                             andIsSCETransaction:NO
                                                                                                                                              andSurchargeAmount:0
                                                                                                                                                     andCurrencyCode:[[NSUserDefaults standardUserDefaults] valueForKey:@"CurrencyCode"]];
        [[Ingenico sharedInstance].StoreAndForward processEmvStoreAndForwardCreditSaleTransactionWithCardReader:request andUpdateProgress:updateProgress andSelectApplication: applicationSelectionCallback andOnDone:onDone];
    }else{
        IMSStoreAndForwardCreditAuthTransactionRequest *request = (IMSStoreAndForwardCreditAuthTransactionRequest *)[self getSampleTransactionRequestwithTotalAmount:100
                                                                                                                                               andSubtotalAmount:0
                                                                                                                                               andDiscountAmount:0
                                                                                                                                                    andTaxAmount:0
                                                                                                                                                    andTipAmount:0
                                                                                                                                                      andClerkID:nil
                                                                                                                                                         andStan:0
                                                                                                                                                         andType:TransactionTypeCreditAuth
                                                                                                                                              andCustomReference:nil
                                                                                                                                               andWithCardReader:YES
                                                                                                                                                andIsManualKeyed:NO
                                                                                                                                               andCanEnrollToken:NO
                                                                                                                                                  andIsTokenSale:NO
                                                                                                                                                andIsPartialAuth:NO
                                                                                                                                                andIsTokenUpdate:NO
                                                                                                                                                     andIsResale:NO
                                                                                                                                                     andIsReauth:NO
                                                                                                                                             andIsSCETransaction:NO
                                                                                                                                              andSurchargeAmount:0
                                                                                                                                                     andCurrencyCode:[[NSUserDefaults standardUserDefaults] valueForKey:@"CurrencyCode"]];
        [[Ingenico sharedInstance].StoreAndForward processEmvStoreAndForwardCreditAuthTransactionWithCardReader:request andUpdateProgress:updateProgress andSelectApplication: applicationSelectionCallback andOnDone:onDone];
    }
}

- (void)doStoreAndForwardCashTransactionLoadTestingWithCounter:(int)counter andTotal:(int)total{
    [self.view endEditing:YES];
    [self showProgressMessage:[NSString stringWithFormat:@"Processing Transaction #%d", counter] andIsTransactionStoppable:YES];
    IMSStoreAndForwardCashSaleTransactionRequest *request = (IMSStoreAndForwardCashSaleTransactionRequest *)[self getSampleTransactionRequestwithTotalAmount:100
                                                                                                                                           andSubtotalAmount:0
                                                                                                                                           andDiscountAmount:0
                                                                                                                                                andTaxAmount:0
                                                                                                                                                andTipAmount:0
                                                                                                                                                  andClerkID:nil
                                                                                                                                                     andStan:0
                                                                                                                                                     andType:TransactionTypeCashSale
                                                                                                                                          andCustomReference:nil
                                                                                                                                           andWithCardReader:YES
                                                                                                                                            andIsManualKeyed:NO
                                                                                                                                           andCanEnrollToken:NO
                                                                                                                                              andIsTokenSale:NO
                                                                                                                                            andIsPartialAuth:NO
                                                                                                                                            andIsTokenUpdate:NO
                                                                                                                                                 andIsResale:NO
                                                                                                                                                 andIsReauth:NO
                                                                                                                                         andIsSCETransaction:NO
                                                                                                                                          andSurchargeAmount:0
                                                                                                                                             andCurrencyCode:[[NSUserDefaults standardUserDefaults] valueForKey:@"CurrencyCode"]];
    [[Ingenico sharedInstance].StoreAndForward processStoreAndForwardCashTransaction:request andOnDone:^(IMSTransactionResponse * _Nullable response, NSError * _Nullable error) {
        [self dismissProgress];
        [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:
                                              @"Store and Forward Cash Transaction number %d Response:\n%@",
                                              counter, response.description]];
        [LogHelper.sharedInstance consoleLog:[[Ingenico sharedInstance] getCurrentCapabilities].description];
        if(error.code == TransactionCancelled){
            return;
        }
        if(counter < total - 1){
            int newNumber = counter +1;
            [NSThread sleepForTimeInterval:0.5f];
            [self doStoreAndForwardCashTransactionLoadTestingWithCounter:newNumber andTotal:total];
        }
    }];
}

- (void)doTransactionLoadTestingWithCounter:(int)counter andTotal:(int) total{
    [self.view endEditing:YES];
    [self showProgressMessage:[NSString stringWithFormat:@"Processing Transaction #%d", counter] andIsTransactionStoppable:YES];
    IMSCreditSaleTransactionRequest *request= (IMSCreditSaleTransactionRequest *)[self getSampleTransactionRequestwithTotalAmount:100
                                                                                                                andSubtotalAmount:0
                                                                                                                andDiscountAmount:0
                                                                                                                     andTaxAmount:0
                                                                                                                     andTipAmount:0
                                                                                                                       andClerkID:nil
                                                                                                                          andStan:0
                                                                                                                          andType:TransactionTypeCreditSale
                                                                                                               andCustomReference:nil
                                                                                                                andWithCardReader:YES
                                                                                                                 andIsManualKeyed:NO
                                                                                                                andCanEnrollToken:NO
                                                                                                                   andIsTokenSale:NO
                                                                                                                 andIsPartialAuth:NO
                                                                                                                 andIsTokenUpdate:NO
                                                                                                                      andIsResale:NO
                                                                                                                      andIsReauth:NO
                                                                                                              andIsSCETransaction:NO
                                                                                                               andSurchargeAmount:0
                                                                                                                  andCurrencyCode:[[NSUserDefaults standardUserDefaults] valueForKey:@"CurrencyCode"]];
    [[Ingenico sharedInstance].Payment processCreditSaleTransactionWithCardReader:request
                                                                andUpdateProgress:progressCallback
                                                             andSelectApplication:^(NSArray *applicationList, NSError *error,
                                                                                    ApplicationSelectedResponse appReponse) {
                                                                 appReponse((RUAApplicationIdentifier *)[applicationList objectAtIndex:0]);
                                                             }
                                                                        andOnDone:^(IMSTransactionResponse *response, NSError *error) {
                                                                            [self dismissProgress];
                                                                            [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:
                                                                                                                                           @"Card Transaction  number %d Response:\n%@",
                                                                                                                                           counter, response.description]];
                                                                            if (response.transactionID == nil) {
                                                                                [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Card Transaction failed with error code %ld", (long)error.code]];
                                                                            }
                                                                            if(error.code == TransactionCancelled){
                                                                                return;
                                                                            }
                                                                            if(counter < total - 1){
                                                                                int newNumber = counter +1;
                                                                                [NSThread sleepForTimeInterval:0.5f];
                                                                                [self doTransactionLoadTestingWithCounter:newNumber andTotal:total];
                                                                            }
                                                                        }];
}

- (void)reverseTransaction{
    [self showProgressMessage:@"Reversing Transactions..." andIsTransactionStoppable:NO];
    [[Ingenico sharedInstance].Payment reverseAllPendingTransactionsWithRetryCounter:10 andOnDone:^(NSError *error) {
        [self dismissProgress];
        if(error == nil) {
            [LogHelper.sharedInstance consoleLog:@"Transaction Reversal Succeeded"];
        }else{
            [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Transaction reversal failed with %@", [self getResponseCodeString:error.code]]];
        }
    }];
}

- (void)reverseSingleTransaction{
    [[Ingenico sharedInstance].Payment getPendingTransactions:^(NSArray *transactions, NSError *error) {
        [self dismissProgress];
        if (error == nil) {
            _pendingTransactions = transactions;
            UIAlertController *alertView = [UIAlertController
                                            alertControllerWithTitle:@"Select Pending Transaction"
                                            message:@""
                                            preferredStyle:UIAlertControllerStyleActionSheet];
            for (IMSPendingTransaction *txnId in _pendingTransactions) {
                UIAlertAction *ok = [UIAlertAction
                                     actionWithTitle:txnId.clientTransactionId
                                     style:UIAlertActionStyleDefault
                                     handler:^(UIAlertAction *action) {
                                        [self showProgressMessage:@"Reversing transaction" andIsTransactionStoppable:NO];
                                        [[Ingenico sharedInstance].Payment reversePendingTransaction:txnId.clientTransactionId andOnDone:^(NSError *error) {
                                            [self dismissProgress];
                                            [self showProgressMessage:[self getResponseCodeString:error.code] andIsSuccess:YES];
                                                [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Transaction reversal done with %@", [self getResponseCodeString:error.code]]];
                                        }];
                                     }];
                [alertView addAction:ok];
            }
            UIAlertAction *cancel = [UIAlertAction
                                     actionWithTitle:@"Cancel"
                                     style:UIAlertActionStyleCancel
                                     handler:^(UIAlertAction *action) {
                                         
                                     }];
            [alertView addAction:cancel];
            if([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPhone){
                [self presentViewController:alertView animated:YES completion:nil];
            }
            else{
                [alertView setModalPresentationStyle:UIModalPresentationPopover];
                UIPopoverController *controller = [[UIPopoverController alloc] initWithContentViewController:alertView];
                [controller presentPopoverFromRect:[self.paymentTableView convertRect: [self.paymentTableView rectForRowAtIndexPath:_tableViewCellPath] toView: self.paymentTableView.superview] inView:[self.paymentTableView superview] permittedArrowDirections:UIPopoverArrowDirectionUp animated:YES];
            }
        }else{
            [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Get pending transactions failed with %@", [self getResponseCodeString:error.code]]];
        }
    }];
}

- (void)getPendingTransactions{
    [self showProgressMessage:@"Getting pending Transactions..." andIsTransactionStoppable:NO];
    [[Ingenico sharedInstance].Payment getPendingTransactions:^(NSArray *transactions, NSError *error) {
        [self dismissProgress];
        if (error == nil) {
            _pendingTransactions = transactions;
            [LogHelper.sharedInstance consoleLog:@"getPendingTransactions success"];
        }else{
            [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Get pending transactions failed with %@", [self getResponseCodeString:error.code]]];
        }
    }];
}

- (void)ignorePendingTransaction{
    if ([_pendingTransactions count] == 0) {
        UIAlertController *controller = [UIAlertController alertControllerWithTitle:@"Error" message:@"Get pending transactions first" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *dismissaction = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:nil];
        [controller addAction:dismissaction];
        [self presentViewController:controller animated:YES completion:nil];
    } else {
        for (IMSPendingTransaction *txn in _pendingTransactions) {
            [[Ingenico sharedInstance].Payment ignorePendingTransaction:txn.clientTransactionId];
        }
        [self showProgressMessage:@"Success" andIsSuccess:YES];
    }
}

- (void)ignoreReversalBeforeTransaction{
    _ignoreReversalBeforeTxn = true;
    [[Ingenico sharedInstance].Payment ignorePendingReversalsBeforeNextTransaction];
    [self showProgressMessage:@"Success" andIsSuccess:YES];
}

- (void) doPartialAuthorization {
    if (!isPerformingPartialAuth) {
        //First transaction
        initialSubmittedAmount = _response.submittedAmount.total;
        if (_response.authorizedAmount < initialSubmittedAmount) {
            isPerformingPartialAuth = YES;
            partialTransactionIds = [[NSMutableArray alloc] init];
        } else {
            [self updateTranasctionWithTransactionID:_response.transactionID];
        }
    }
    if (isPerformingPartialAuth) {
        //Subsequent transactions
        partialAuthAmount += _response.authorizedAmount;
        if (partialAuthAmount < initialSubmittedAmount) {
            if (_response.transactionResponseCode == TransactionResponseCodeApproved) {
                transactionGroupId = _response.transactionGroupID;
                [partialTransactionIds addObject:(_response.transactionGUID)];
            }
            [self promptForAmount];
        } else {
            [self updateTranasctionWithTransactionID:partialTransactionIds.firstObject];
            [self resetPartialAuthState];
        }
    }
}

- (void) resetPartialAuthState {
    isPartialAuth = NO;
    isPerformingPartialAuth = NO;
    initialSubmittedAmount = 0;
    partialAuthAmount = 0;
    partialTransactionIds = nil;
    transactionGroupId = nil;
}

- (void)uploadSignature {
    [self showProgressMessage:@"Uploading signature..." andIsTransactionStoppable:NO];
    NSString *encodedSignature = [UIImagePNGRepresentation([UIImage imageNamed:@"signature.png"])
                               base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
    [[Ingenico sharedInstance].User uploadSignatureForTransactionWithId:_response.transactionID andSignature:encodedSignature andOnDone:^(NSError *error) {
        [self dismissProgress];
        if (isPartialAuth) {
            [self doPartialAuthorization];
        }
        else {
            [self updateTranasctionWithTransactionID:_response.transactionID];
        }
        if(error){
            [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"upload signature failed with %@", [self getResponseCodeString:error.code]]];
        }
        else{
            [LogHelper.sharedInstance consoleLog:@"upload signature succeeded"];
        }
    }];
}

-(void) setupAndDisplaySceModal: (id) TransactionRequest andTransactionType: (IMSTransactionType) transactionType {
    sceContainerVC = [[UIViewController alloc]init];
    sceContainerVC.view.frame = CGRectMake(0, 0, (self.view.bounds.size.width*80)/100, (self.view.bounds.size.height*80)/100);
    [sceContainerVC.view setBackgroundColor:[UIColor whiteColor]];
    [sceContainerVC.view setCenter:CGPointMake(self.view.center.x, self.view.center.y)];
    sceContainerVC.view.layer.borderWidth = 1;
    sceContainerVC.view.layer.borderColor = [UIColor darkGrayColor].CGColor;
    [sceContainerVC.view setTag:1];
    UIButton *cancelButton = [UIButton buttonWithType:UIButtonTypeSystem];
    cancelButton.frame = CGRectMake(sceContainerVC.view.bounds.origin.x, sceContainerVC.view.bounds.origin.y, 40, 40);
    [cancelButton setImage:[UIImage imageNamed:@"Cancel"] forState:UIControlStateNormal];
    [cancelButton addTarget:self action:@selector(dismissModalView) forControlEvents:UIControlEventTouchUpInside];
    [sceContainerVC.view addSubview:cancelButton];
    switch (transactionType) {
        case TransactionTypeCreditRefund: {
            sceViewController = [[IMSSecureCardEntryViewController alloc] initWithCreditRefundTransactionRequest:TransactionRequest
                                                                                               andUpdateProgress:^(IMSProgressMessage progressMessage, NSString * _Nullable extraMessage) {
                                                                                                   [LogHelper.sharedInstance consoleLog:[NSString stringWithFormat:@"Progress Message:%@", [self getProgressStrFromMessage:progressMessage]]];
                                                                                                   
                                                                                               }
                                                                                               andOnDone:doneCallback];
            break;
        }
        case TransactionTypeCreditSale: {
            sceViewController = [[IMSSecureCardEntryViewController alloc] initWithCreditSaleTransactionRequest:TransactionRequest
                                                                                             andUpdateProgress:^(IMSProgressMessage progressMessage, NSString * _Nullable extraMessage) {
                                                                                                 [LogHelper.sharedInstance consoleLog:[NSString stringWithFormat:@"Progress Message:%@", [self getProgressStrFromMessage:progressMessage]]];
                                                                                             }
                                                                                             andOnDone:doneCallback];
            break;
        }
        case TransactionTypeCreditAuth: {
            sceViewController = [[IMSSecureCardEntryViewController alloc] initWithCreditAuthTransactionRequest:TransactionRequest
                                                                                             andUpdateProgress:^(IMSProgressMessage progressMessage, NSString * _Nullable extraMessage) {
                                                                                                 [LogHelper.sharedInstance consoleLog:[NSString stringWithFormat:@"Progress Message:%@", [self getProgressStrFromMessage:progressMessage]]];
                                                                                             }
                                                                                             andOnDone:doneCallback];
            break;
        }
    }
    
    tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissModalView)];
    tapGesture.numberOfTapsRequired = 1;
    [self.view addGestureRecognizer:tapGesture];
    sceViewController.view.frame = CGRectMake(sceContainerVC.view.bounds.origin.x, sceContainerVC.view.bounds.origin.y + 40, sceContainerVC.view.bounds.size.width, sceContainerVC.view.bounds.size.height - 40);
    [sceContainerVC addChildViewController:sceViewController];
    [sceContainerVC.view addSubview:sceViewController.view];
    
    [sceContainerVC setModalPresentationStyle:UIModalPresentationOverCurrentContext];
    [sceContainerVC setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
    [self addChildViewController:sceContainerVC];
    [self.view addSubview:sceContainerVC.view];
}

- (void)getSignatureOrUpdateTransaction:(IMSTransactionResponse *)response{
    if([self getLastTransactionType] == TransactionTypeCreditBalanceInquiry ||
       [self getLastTransactionType] == TransactionTypeDebitBalanceInquiry ||
       [self getLastTransactionType] == TransactionTypeBalanceInquiry ||
       [self getLastTransactionType] == TransactionTypeTokenEnrollment ||
       [self getLastTransactionType] == TransactionTypeAVSOnly) {
        [self updateTranasctionWithTransactionID:response.transactionID];
    }
    else if((response.cardVerificationMethod == CardVerificationMethodPinAndSignature ||
             response.cardVerificationMethod == CardVerificationMethodSignature) &&
            (response.posEntryMode == POSEntryModeContactEMV ||
             response.posEntryMode == POSEntryModeContactlessEMV ||
             response.posEntryMode == POSEntryModeMagStripeEMVFail
             ) && [response transactionID]){
                [self dismissProgress];
                UIAlertController *controller = [UIAlertController alertControllerWithTitle:@"Select action" message:[[NSString alloc] initWithFormat:@"Please select action for pending signature transaction: %@", [self getLastTransactionID]] preferredStyle:UIAlertControllerStyleAlert];
                UIAlertAction *uploadaction = [UIAlertAction actionWithTitle:@"UploadSignature" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                    [self uploadSignature];
                }];
                UIAlertAction *voidaction = [UIAlertAction actionWithTitle:@"Void" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                    [self doVoidTransaction:false];
                }];
                UIAlertAction *dismissaction =
                    [UIAlertAction actionWithTitle:@"Dismiss" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                        if (isPartialAuth) {
                            [self doPartialAuthorization];
                        }
                        else {
                            [self updateTranasctionWithTransactionID:_response.transactionID];
                        }
                    }];
                [controller addAction:voidaction];
                [controller addAction:uploadaction];
                [controller addAction:dismissaction];
                [self presentViewController:controller animated:YES completion:nil];
                
            }
    else if(response.cardVerificationMethod == CardVerificationMethodSignature){
        [self uploadSignature];
    }
    else {
        [self updateTranasctionWithTransactionID:response.transactionID];
    }
}

- (NSString *)getStrFromTransactionCode:(NSInteger)code{
    switch (code) {
        case 0:
            return @"Transaction approved";
        default:
            return @"Transaction declined";
    }
}

- (NSString *)getProgressStrFromMessage:(IMSProgressMessage)message{
    switch (message) {
        case PleaseInsertCard:{
            NSArray *allowedPOS = [[Ingenico sharedInstance].PaymentDevice allowedPOSEntryModes];
            if([allowedPOS containsObject:[NSNumber numberWithInteger:POSEntryModeContactlessMSR]] ||
               [allowedPOS containsObject:[NSNumber numberWithInteger:POSEntryModeContactlessEMV]]){
                if([allowedPOS containsObject:[NSNumber numberWithInteger:POSEntryModeContactEMV]]){
                    return @"Please insert/tap/swipe card";
                } else{
                    return @"Please tap or swipe card";
                }
            }
            else{
                return @"Please insert or swipe card";
            }
        }
        case ChipCardSwipFailed:
            return @"Cannot swipe chip card. Please insert card instead";
        case CardInserted:
            return @"Card inserted";
        case ICCErrorSwipeCard:
            return @"ICCError swipe card please";
        case ApplicationSelectionStarted:
            return @"Application selection started";
        case ApplicationSelectionCompleted:
            return @"Application selection completed";
        case FirstPinEntryPrompt:
            return @"First Pin prompt";
        case LastPinEntryPrompt:
            return @"Last Pin prompt";
        case PinEntryFailed:
            return @"Pin entry failed";
        case PinEntryInProgress:
            return @"Pin entry in progress";
        case PinEntrySuccessful:
            return @"Pin entry in progress";
        case RetrytPinEntryPrompt:
            return @"Retry Pin entry prompt";
        case WaitingforCardSwipe:
            return @"Waiting for card swipe";
        case PleaseSeePhone:
            return @"Please see phone";
        case SwipeDetected:
            return @"Swipe detected";
        case SwipeErrorReswipeMagStripe:
            return @"Reswipe please";
        case TapDetected:
            return @"Tap detected";
        case UseContactInterfaceInsteadOfContactless:
            return @"Use contact interface instead of contactless";
        case ErrorReadingContactlessCard:
            return @"Error reading contactless card";
        case DeviceBusy:
            return @"Device busy";
        case CardHolderPressedCancelKey:
            return @"Cancel key pressed";
        case RecordingTransaction:
            return @"Recording transaction";
        case UpdatingTransaction:
            return @"Updating transaction";
        case PleaseRemoveCard:
            return @"Please remove card";
        case RestartingContactlessInterface:
            return @"Restarting contactless interface";
        case GettingOnlineAuthorization:
            return @"Getting Online Authorization";
        case TryContactInterface:
            return @"Try contact interface";
        case MultipleContactlessCardsDetected:
            return @"Please present one card only";
        case PresentCardAgain:
            return @"Please present card again";
        case CardRemoved:
            return @"Card Removed";
        case SendingReversal:
            return @"Sending reversal";
        case FetchingSecureCardEntryContent:
            return @"Fetching Secure Card Entry content";
        case LoadingSecureCardEntryContent:
            return @"Loading Secure Card Entry content";
		case ReinsertCard:
			return @"Reinsert Card properly";
		case RestartingTransactionDueToIncorrectPin:
			return @"Restarting Transaction Due To Incorrect Pin";
        case ContactlessInterfaceFailedTryContact:
            return @"Contactless Failed, Try Contact";
        case WaitingforChipCard:
            return @"Waiting for Chip Card";
        case WaitingforSwipeCard:
            return @"Waiting for Swipe Card";
        case WaitingforChipAndSwipe:
            return @"Waiting for Chip And Swipe";
        case WaitingforTapCard:
            return @"Waiting for Tap Card";
        case WaitingforChipAndTap:
            return @"Waiting for Chip And Tap";
        case WaitingforSwipeAndTap:
            return @"Waiting for Swipe And Tap";
        case WaitingforChipSwipeTap:
            return @"Waiting for Chip Swipe Tap";
        case WaitingforFallbackSwipe:
            return @"Waiting for Fallback Swipe";
        case WaitingforFallbackChip:
            return @"Waiting for Fallback Chip";
        case UpdatingFirmware:
            return @"Updating firmware";
        case SettingUpDevice:
            return @"Setting up device";
        case DownloadingFirmware:
            return @"Downloading firmware";
        case CheckingFirmwareUpdate:
            return @"Checking for firmware update";
        case CheckingDeviceSetup:
            return @"Checking for device set up";
        case Unknown:
        default:
            return nil;
    }
}

- (NSString *)getStrFromPOSEntryMode:(IMSPOSEntryMode)entryMode{
    switch (entryMode) {
        case POSEntryModeKeyed:
            return @"Keyed";
        case POSEntryModeContactEMV:
            return @"ContactEMV";
        case POSEntryModeContactlessEMV:
            return @"ContactlessEMV";
        case POSEntryModeContactlessMSR:
            return @"ContactlessMSR";
        case POSEntryModeMagStripe:
            return @"MagStripe";
        case POSEntryModeMagStripeEMVFail:
            return @"MagStripeEMVFail";
        case POSEntryModeVirtualTerminal:
            return @"VirtualTerminal";
        case POSEntryModeToken:
            return @"Token";
        case POSEntryModeKeyedSwipeFail:
            return @"KeyedSwipeFail";
        case POSEntryModeUnKnown:
        default:
            return @"Unknown";
    }
}

- (NSString *)getStrFromCVM:(IMSCardVerificationMethod)cvm{
    switch (cvm) {
        case CardVerificationMethodPin:
            return @"Pin";
        case CardVerificationMethodSignature:
            return @"Signature";
        case CardVerificationMethodPinAndSignature:
            return @"PinAndSignature";
        case CardVerificationMethodNone:
        default:
            return @"None";
    }
}

- (NSString *)getStrFromTokenResponseCode:(IMSTokenResponseCode)code{
    switch (code) {
        case IMSTokenResponseCodeApproved:
            return @"Approved";
        case IMSTokenResponseCodeDeclined:
            return @"Token not requested because the transaction authorization was declined";
        case IMSTokenResponseCodeError:
            return @"Service provider error. See TokenSourceData for details.";
        case IMSTokenResponseCodeCommunicationError:
            return @"Error connecting to the tokenization service provider.";
        default:
            return @"Unknown";
    }
}

- (id)getSampleTransactionRequestwithTotalAmount:(NSInteger)total
                                  andSubtotalAmount:(NSInteger)subtotal
                                  andDiscountAmount:(NSInteger)discount
                                       andTaxAmount:(NSInteger)tax
                                       andTipAmount:(NSInteger)tip
                                         andClerkID:(NSString *)clerkID
                                            andStan:(NSInteger)stan
                                            andType:(IMSTransactionType)type
                                 andCustomReference:(NSString *)customRef
                                  andWithCardReader:(BOOL)isWithReader
                                   andIsManualKeyed:(BOOL)isManualKeyed
                                  andCanEnrollToken:(BOOL)enrollToken
                                     andIsTokenSale:(BOOL)isTokenSale
                                   andIsPartialAuth:(BOOL)isPartialAuth
                                   andIsTokenUpdate:(BOOL)isTokenUpdate
                                        andIsResale:(BOOL)isResale
                                        andIsReauth:(BOOL)isReauth 
                                andIsSCETransaction:(BOOL)isSCETransaction
                                 andSurchargeAmount:(NSInteger)surcharge
                                    andCurrencyCode:(NSString *)currencyCode{
    [[NSUserDefaults standardUserDefaults] setObject:currencyCode forKey:@"CurrencyCode"];
    IMSAmount *amount = [[IMSAmount alloc] initWithTotal:total andSubtotal:subtotal  andTax:tax andDiscount:discount andDiscountDescription:@"RoamDiscount"  andTip:tip andCurrency:currencyCode andSurcharge:surcharge];
    IMSAmount *reverseAmount = [[IMSAmount alloc] initWithTotal:total andSubtotal:subtotal  andTax:tax andDiscount:discount
             andDiscountDescription:nil  andTip:-1 andCurrency:currencyCode andSurcharge:surcharge];
    IMSCard *card = [[IMSCard alloc] initWithNumber:@"5424180000005550"
                                  andExpirationDate:@"0123"
                                             andCVV:@"123"
                                             andAVS:@"82560" andPOSEntryMode:POSEntryModeKeyed];
    IMSTokenRequestParametersBuilder *builder = [[IMSTokenRequestParametersBuilder alloc] init];
    builder.tokenReferenceNumber = @"test-123";
    builder.tokenFeeInCents = [tokenFeeTF.text integerValue];
    builder.cardholderLastName = @"Data";
    builder.cardholderFirstName = @"Roam";
    builder.billToEmail = @"roam@roamdata.com";
    builder.billToAddress1 = @"1 Federal St";
    builder.billToAddress2 = @"Suite 1";
    builder.billToCity = @"Boston";
    builder.billToState = @"MA";
    builder.billToCountry = @"USA";
    builder.billToZip = @"02110";
    builder.ignoreAVSResult = true;
    IMSTokenRequestParameters *tokenRequest = nil;
    if ((!tokenEnrollCheckBox && enrollToken) || [tokenEnrollCheckBox isSelected] ) {
        tokenRequest = builder.createTokenEnrollmentRequestParameters;
    }
    else if ((!tokenUpdateCheckBox && isTokenUpdate) || [tokenUpdateCheckBox isSelected]) {
        builder.tokenIdentifier = tokenIDTF.text;
        tokenRequest = builder.createTokenUpdateRequestParameters;
    }

    NSArray *products = [self getSampleProducts:total];
    switch (type) {
        case TransactionTypeCashSale:
            return [[IMSCashSaleTransactionRequest alloc] initWithAmount:amount
                                                             andProducts:products
                                                              andClerkID:clerkID
                                                            andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                             andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                   andTransactionGroupID:nil
                                                     andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                    andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
                                                          andIsCompleted:false
                                                      andCustomReference:customRef];
        case TransactionTypeCreditSale:
        {
            if (isTokenSale) {
                return [[IMSTokenSaleTransactionRequest alloc] initWithTokenReferenceNumber:@"test-123"
                                                                         andTokenIdentifier:tokenIDTF.text
                                                                                  andAmount:amount
                                                                                andProducts:products
                                                                                 andClerkID:clerkID
                                                                               andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                                andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                                      andTransactionGroupID:nil
                                                                        andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                                       andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil
                                                            andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
                                                                         andCustomReference:customRef
                                                                             andIsCompleted:false
                                                                             andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
            }
            if (isPartialAuth) {
                return [[IMSKeyedCardSaleTransactionRequest alloc]  initWithCard:card
                                                                       andAmount:amount
                                                                     andProducts:products
                                                                      andClerkID:clerkID
                                                                    andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                     andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                           andTransactionGroupID:transactionGroupId
                                                             andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                            andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil
                                                 andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
                                                       andTokenRequestParameters:tokenRequest
                                                              andCustomReference:customRef
                                                                  andIsCompleted:false
                                                                    andUCIFormat:UCIFormatIngenico
                                                                andIsCardPresent:cardPresentCheckBox.isSelected
                                                                andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
            }
            if (isResale) {
                return [[IMSCreditResaleTransactionRequest alloc] initWithOriginalSaleTransactionID:[self getLastTransactionID]
                                                                                          andAmount:amount
                                                                                        andProducts:products
                                                                                         andClerkID:clerkID
                                                                                       andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                                        andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                                              andTransactionGroupID:transactionGroupId
                                                                                andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                                               andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil
                                                                    andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
                                                                                 andCustomReference:customRef
                                                                                     andIsCompleted:false
                                                                          andTokenRequestParameters:tokenRequest
                                                                          andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
            }
            if(!isWithReader && isManualKeyed){
                return [[IMSSCECreditSaleTransactionRequest alloc] initWithAmount:amount
                                                            andProducts:products
                                                             andClerkID:clerkID
                                                           andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                            andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                              andLocale: [NSLocale currentLocale]
                                                  andTransactionGroupID:nil
                                                    andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                   andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil
                                        andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
                                              andTokenRequestParameters:tokenRequest
                                                     andCustomReference:customRef
                                                         andIsCompleted:false
                                                           andUCIFormat:UCIFormatIngenico
                                                       andIsCardPresent:cardPresentCheckBox.isSelected
                                                       andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
            }
            else if(!isWithReader){
                return [[IMSKeyedCardSaleTransactionRequest alloc]  initWithCard:card
                                                                       andAmount:amount
                                                                     andProducts:products
                                                                      andClerkID:clerkID
                                                                    andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                     andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                           andTransactionGroupID:nil
                                                             andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                            andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil
                                                 andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
                                                       andTokenRequestParameters:tokenRequest
                                                              andCustomReference:customRef
                                                                  andIsCompleted:false
                                                                    andUCIFormat:UCIFormatIngenico
                                                                andIsCardPresent:cardPresentCheckBox.isSelected
                                                                andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
            }
            else if(isManualKeyed){
                return [[IMSKeyedCardSaleTransactionWithCardReaderRequest alloc] initWithAmount:amount
                                                                                    andProducts:products
                                                                                     andClerkID:clerkID
                                                                                   andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                                    andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                                          andTransactionGroupID:nil
                                                                            andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                                           andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil
                                                                andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
                                                                      andTokenRequestParameters:tokenRequest
                                                                             andCustomReference:customRef
                                                                                 andIsCompleted:false
                                                                          andIsCardAVSRequested:avsCheckBox.isSelected
                                                                          andIsCardCVVRequested:cvvCheckBox.isSelected
                                                                                   andUCIFormat:UCIFormatIngenico
                                                                               andIsCardPresent:cardPresentCheckBox.isSelected
                                                                               andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
            }
            else{
                return [[IMSCreditSaleTransactionRequest alloc] initWithAmount:amount
                                                                   andProducts:products
                                                                    andClerkID:clerkID
                                                                  andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                   andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                         andTransactionGroupID:nil
                                                           andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                          andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil
                                               andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
                                                     andTokenRequestParameters:tokenRequest
                                                            andCustomReference:customRef
                                                                andIsCompleted:false
                                                                  andUCIFormat:UCIFormatIngenico
                                                                  andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];

            }
        }
        case TransactionTypeDebitSale:
            return [[IMSDebitSaleTransactionRequest alloc] initWithAmount:amount
                                                              andProducts:products
                                                               andClerkID:clerkID
                                                             andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                              andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                    andTransactionGroupID:nil
                                                      andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                     andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil
                                          andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
                                                       andCustomReference:customRef
                                                           andIsCompleted:false
                                                             andUCIFormat:UCIFormatIngenico
                                                             andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
        case TransactionTypeCreditAuth:
        {
            if (isTokenSale) {
                return [[IMSTokenAuthTransactionRequest alloc] initWithTokenReferenceNumber:@"test-123"
                                                                         andTokenIdentifier:tokenIDTF.text
                                                                                  andAmount:amount
                                                                                andProducts:products
                                                                                 andClerkID:clerkID
                                                                               andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                                andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                                      andTransactionGroupID:nil
                                                                        andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                                       andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil
                                                            andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
                                                                         andCustomReference:customRef
                                                                             andIsCompleted:false
                                                                             andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
            } else if (isReauth) {
                return [[IMSCreditReauthTransactionRequest alloc] initWithOriginalSaleTransactionID:[self getLastTransactionID]
                                                                                          andAmount:amount
                                                                                        andProducts:products
                                                                                         andClerkID:clerkID
                                                                                       andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                                        andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                                              andTransactionGroupID:transactionGroupId
                                                                                andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                                               andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil
                                                                    andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
                                                                                 andCustomReference:customRef
                                                                                     andIsCompleted:false
                                                                          andTokenRequestParameters:tokenRequest
                                                                          andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
            }
            else if(isManualKeyed && isWithReader){
                return [[IMSKeyedCreditAuthTransactionWithCardReaderRequest alloc] initWithAmount:amount
                                                                                    andProducts:products
                                                                                     andClerkID:clerkID
                                                                                   andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                                    andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                                          andTransactionGroupID:nil
                                                                            andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                                           andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil
                                                                andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
                                                                      andTokenRequestParameters:tokenRequest
                                                                             andCustomReference:customRef
                                                                                 andIsCompleted:false
                                                                          andIsCardAVSRequested:avsCheckBox.isSelected
                                                                          andIsCardCVVRequested:cvvCheckBox.isSelected
                                                                                   andUCIFormat:UCIFormatIngenico
                                                                               andIsCardPresent:cardPresentCheckBox.isSelected
                                                                               andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
            }
            else if(isWithReader){
                return [[IMSCreditAuthTransactionRequest alloc] initWithAmount:amount
                                                                   andProducts:products
                                                                    andClerkID:clerkID
                                                                  andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                   andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                         andTransactionGroupID:nil
                                                           andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                          andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil
                                               andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
                                                     andTokenRequestParameters:tokenRequest
                                                            andCustomReference:customRef
                                                                andIsCompleted:false
                                                                  andUCIFormat:UCIFormatIngenico
                                                                  andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
            }
            else if (isSCETransaction) {
                return [[IMSSCECreditAuthTransactionRequest alloc] initWithAmount:amount
                                                                      andProducts:products
                                                                       andClerkID:clerkID
                                                                     andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                      andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                                        andLocale: [NSLocale currentLocale]
                                                            andTransactionGroupID:nil
                                                              andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                             andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil
                                                  andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
                                                        andTokenRequestParameters:tokenRequest
                                                               andCustomReference:customRef
                                                                   andIsCompleted:false
                                                                     andUCIFormat:UCIFormatIngenico
                                                                 andIsCardPresent:cardPresentCheckBox.isSelected
                                                                 andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
            }
            else{
                return [[IMSKeyedCreditAuthTransactionRequest alloc] initWithCard:card
                                                                        andAmount:amount
                                                                      andProducts:products
                                                                       andClerkID:clerkID
                                                                     andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                      andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                            andTransactionGroupID:nil
                                                              andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                             andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil
                                                  andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
                                                        andTokenRequestParameters:tokenRequest
                                                               andCustomReference:customRef
                                                                   andIsCompleted:false
                                                                     andUCIFormat:UCIFormatIngenico
                                                                 andIsCardPresent:cardPresentCheckBox.isSelected
                                                                 andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
            }
        }
        case TransactionTypeCreditAuthCompletion:
            return [[IMSCreditAuthCompleteTransactionRequest alloc] initWithOriginalSaleTransactionID:[self getLastTransactionID]
                                                                                            andAmount:amount
                                                                                          andProducts:products
                                                                                           andClerkID:clerkID
                                                                                         andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                                          andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                                                andTransactionGroupID:nil
                                                                                   andCustomReference:customRef andIsCompleted:false andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                                                   andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
        case TransactionTypeCashRefund:
            return [[IMSCashRefundTransactionRequest alloc] initWithOriginalSaleTransactionID:[self getLastTransactionID]
                                                                                    andAmount:reverseAmount
                                                                                   andClerkID:clerkID
                                                                                 andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                                  andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                                           andCustomReference:customRef andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                    andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected];
        case TransactionTypeCreditRefund:
        {
            if(isSCETransaction){
                return [[IMSSCECreditRefundTransactionRequest alloc] initWithAmount:amount
                                                                      andClerkID:clerkID
                                                                    andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                     andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                             andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                            andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil
                                                 andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
                                                              andCustomReference:customRef
                                                       andTokenRequestParameters:tokenRequest
                                                                    andUCIFormat:UCIFormatIngenico
                                                                andIsCardPresent:cardPresentCheckBox.isSelected
                                                                andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
            }
            else if(!isWithReader){
                return [[IMSCreditRefundTransactionRequest alloc] initWithOriginalSaleTransactionID:[self getLastTransactionID]
                                                                                          andAmount:reverseAmount
                                                                                         andClerkID:clerkID
                                                                                       andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                                        andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                                                 andCustomReference:customRef andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                                                 andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil
                        andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected];
            }
            else if(isWithReader && isManualKeyed) {
                return [[IMSKeyedCreditRefundTransactionWithCardReaderRequest alloc] initWithAmount:reverseAmount
                                                                                         andClerkID:clerkID
                                                                                       andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                                        andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                                                andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                                               andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil
                                                                    andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
                                                                          andTokenRequestParameters:tokenRequest andCustomReference:customRef
                                                                                       andUCIFormat:UCIFormatIngenico
                                                                                   andIsCardPresent:cardPresentCheckBox.isSelected
                                                                                     andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
            }
            else {
                return [[IMSCreditCardRefundTransactionRequest alloc] initWithAmount:reverseAmount
                                                                          andClerkID:clerkID
                                                                        andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                         andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                                 andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                                andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil
                                                     andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
                                                                  andCustomReference:customRef
                                                           andTokenRequestParameters:tokenRequest
                                                                        andUCIFormat:UCIFormatIngenico
                                                                        andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
            }
        }
        case TransactionTypeDebitRefund:
        {
            return [[IMSDebitCardRefundTransactionRequest alloc] initWithAmount:reverseAmount
                                                                     andClerkID:clerkID
                                                                   andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                    andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                            andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                           andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil
                                                andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
                                                             andCustomReference:customRef
                                                                   andUCIFormat:UCIFormatIngenico
                                                                   andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
        }
        case TransactionTypeCreditForceSale:
        {
            if(!isWithReader){
                return [[IMSKeyedCreditForceSaleTransactionRequest alloc] initWithAmount:amount
                                                                             andProducts:products
                                                                                 andCard:card
                                                                              andClerkID:clerkID
                                                                            andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                             andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                                   andTransactionGroupID:nil
                                                                    andAuthorizationCode:authCodeTF.text
                                                               andSystemTraceAuditNumber:stan
                                                                     andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                                    andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil
                                                         andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
                                                                      andCustomReference:customRef
                                                                          andIsCompleted:false
                                                                            andUCIFormat:UCIFormatIngenico
                                                                        andIsCardPresent:cardPresentCheckBox.isSelected
                                                                        andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
            }
            else{
                return [[IMSCreditForceSaleTransactionRequest alloc] initWithAmount:amount
                                                                        andProducts:products
                                                                         andClerkID:clerkID
                                                                       andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                        andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                              andTransactionGroupID:nil
                                                               andAuthorizationCode:authCodeTF.text
                                                          andSystemTraceAuditNumber:stan
                                                                andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                               andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil
                                                    andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
                                                                 andCustomReference:customRef
                                                                     andIsCompleted:false
                                                                       andUCIFormat:UCIFormatIngenico
                                                                       andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
            }
        }
        case TransactionTypeCreditBalanceInquiry:
            return [[IMSCreditBalanceInquiryTransactionRequest alloc] initWithClerkID:clerkID
                                                                         andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                          andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                                   andCustomReference:customRef
                                                                         andUCIFormat:UCIFormatIngenico
                                                                         andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
        case TransactionTypeDebitBalanceInquiry:
            return [[IMSDebitBalanceInquiryTransactionRequest alloc] initWithClerkID:clerkID
                                                                        andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                         andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                                  andCustomReference:customRef
                                                                        andUCIFormat:UCIFormatIngenico
                                                                        andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
        case TransactionTypeBalanceInquiry:
            return [[IMSBalanceInquiryTransactionRequest alloc] initWithClerkID:clerkID
                                                                        andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                         andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                                  andCustomReference:customRef
                                                                        andUCIFormat:UCIFormatIngenico
                                                                        andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
        case TransactionTypeTokenEnrollment:
            if(isWithReader && isManualKeyed){
                return [[IMSKeyedTokenEnrollmentWithCardReaderTransactionRequest alloc] initWithTokenRequestParameters:tokenRequest
                                                                                                            andClerkID:clerkID
                                                                                                          andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                                                           andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                                                                          andUCIFormat:UCIFormatIngenico
                                                                                                        andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil
                                                                                                 andIsCardCVVRequested:cvvCheckBox.isSelected
                                                                                                 andIsCardAVSRequested:avsCheckBox.isSelected
                                                                                                      andIsCardPresent:cardPresentCheckBox.isSelected];
            }
            else if(isWithReader){
                return [[IMSTokenEnrollmentTransactionRequest alloc] initWithTokenRequestParameters:tokenRequest
                                                                                         andClerkID:clerkID
                                                                                       andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                                        andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                                                       andUCIFormat:UCIFormatIngenico
                                                                                       andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
            }
            else{
                return [[IMSKeyedTokenEnrollmentTransactionRequest alloc] initWithTokenRequestParameters:tokenRequest
                                                                                                 andCard:card
                                                                                              andClerkID:clerkID
                                                                                            andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                                             andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                                                            andUCIFormat:UCIFormatIngenico
                                                                                            andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
            }
        case TransactionTypeCreditSaleAdjust:
            return [[IMSCreditSaleAdjustTransactionRequest alloc] initWithOriginalSaleTransactionId:[self getLastTransactionID]
                                                                                          andAmount:amount
                                                                                        andProducts:products
                                                                                         andClerkID:clerkID
                                                                                       andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                                        andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                                              andTransactionGroupID:nil
                                                                                andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                                               andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil
                                                                    andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
                                                                                 andCustomReference:customRef
                                                                                     andIsCompleted:false
                                                                                     andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
            break;
        case TransactionTypeCreditAuthAdjust:
            return [[IMSCreditAuthAdjustTransactionRequest alloc] initWithOriginalSaleTransactionId:[self getLastTransactionID]
                                                                                          andAmount:amount
                                                                                        andProducts:products
                                                                                         andClerkID:clerkID
                                                                                       andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                                        andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                                              andTransactionGroupID:nil
                                                                                andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                                               andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil
                                                                    andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
                                                                                 andCustomReference:customRef
                                                                                     andIsCompleted:false
                                                                                     andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
            break;
        case TransactionTypeAVSOnly:
            return [[IMSAVSOnlyTransactionRequest alloc] initWithClerkID:clerkID
                                                            andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                             andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                      andCustomReference:customRef
                                                            andUCIFormat:UCIFormatIngenico
                                                           andAVSZipCode:avsZipCodeTF.text
                                                           andAVSAddress:avsAddressTF.text
                                                          andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
        case TransactionTypeSale:
            return [[IMSSaleTransactionRequest alloc] initWithAmount:amount
                                                               andProducts:products
                                                                andClerkID:clerkID
                                                              andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                               andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                     andTransactionGroupID:nil
                                                       andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                      andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil
                                           andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
                                                 andTokenRequestParameters:tokenRequest
                                                        andCustomReference:customRef
                                                            andIsCompleted:false
                                                              andUCIFormat:UCIFormatIngenico
                                                              andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
        case TransactionTypeRefund:
            return [[IMSRefundTransactionRequest alloc] initWithAmount:reverseAmount
                                                                      andClerkID:clerkID
                                                                    andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                     andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                             andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                            andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil
                                                 andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
                                                              andCustomReference:customRef
                                                       andTokenRequestParameters:tokenRequest
                                                                    andUCIFormat:UCIFormatIngenico
                                                                    andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil];
        default:
            return nil;
    }
}

- (NSArray *)getSampleProducts:(NSInteger)totalAmount {
    return [[NSArray alloc]
            initWithObjects:
            [[IMSProduct alloc]
             initWithName:@"product"
             andPrice:totalAmount
             andNote:@"test product"
             andImage:[IMSUtil encodedImageToBase64String:[UIImage imageNamed:@"product_image.png"] withImageFormat:ImageFormatPNG]
             andQuantity:1],
            nil];
}

- (IMSCardholderInfo *)getSampleCardholderInfo:(NSString *)transactionID {
    return [[IMSCardholderInfo alloc] initWithFirstName:[NSString stringWithFormat:@"First_%@", transactionID]
                                            andLastName:[NSString stringWithFormat:@"Last_%@", transactionID]
                                          andMiddleName:nil
                                               andEmail:[NSString stringWithFormat:@"Email_%@@gmail.com", transactionID]
                                               andPhone:nil
                                            andAddress1:nil
                                            andAddress2:nil
                                                andCity:nil
                                               andState:nil
                                          andPostalCode:nil];
}

- (void)showAmountAlertControllerWithAction:(UIAlertAction *)action
                         andTransactionType:(IMSTransactionType)transactionType
                          andWithCardReader:(BOOL)isWithReader
                          andCanEnrollToken:(BOOL)enrollToken
                           andIsTokenUpdate:(BOOL)isTokenUpdate
                           andIsManualKeyed:(BOOL)isManualKeyed
						   andIsSCETransaction:(BOOL)isSCETransaction
                      andCheckIfCardPresent:(BOOL)checkIfCardPresent
                             andIsTokenSale: (BOOL) isTokenSale{
    UIAlertController *alertController = [UIAlertController
                                         alertControllerWithTitle:@"Information"
                                         message:@"Provide transaction info"
                                         preferredStyle:UIAlertControllerStyleAlert];
    if(transactionType != TransactionTypeCreditBalanceInquiry
       && transactionType != TransactionTypeDebitBalanceInquiry
       && transactionType != TransactionTypeBalanceInquiry
       && transactionType != TransactionTypeTokenEnrollment
       && transactionType != TransactionTypeAVSOnly){
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeNumberPad;
            textField.placeholder = @"Total Amount";
            textField.accessibilityLabel = @"vc_paymentapi_total_amount";
            if (isPerformingPartialAuth) {
                NSString * balanceAmount = [NSString stringWithFormat:@"%ld",(long)(initialSubmittedAmount - partialAuthAmount)];
                textField.text = balanceAmount;
            }
            totalTF = textField;
        }];
    }
    if(transactionType == TransactionTypeCreditForceSale){
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeDefault;
            textField.placeholder = @"AuthCode";
            textField.accessibilityLabel = @"vc_paymentapi_authcode";
            authCodeTF = textField;
        }];
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeNumberPad;
            textField.placeholder = @"SystemTraceAuditNumber";
            textField.accessibilityLabel = @"vc_paymentapi_stan";
            stanTF = textField;
        }];
    }
    if(transactionType != TransactionTypeCreditBalanceInquiry &&
       transactionType != TransactionTypeDebitBalanceInquiry &&
       transactionType != TransactionTypeBalanceInquiry &&
       transactionType != TransactionTypeTokenEnrollment &&
       transactionType != TransactionTypeAVSOnly){
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeNumberPad;
            textField.placeholder = @"Normalized Subtotal";
            textField.accessibilityLabel = @"vc_paymentapi_subtotal";
            subtotalTF = textField;
        }];
        if(transactionType != TransactionTypeCreditRefund &&
           transactionType != TransactionTypeDebitRefund &&
           transactionType != TransactionTypeCashRefund){
            [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
                textField.keyboardType = UIKeyboardTypeNumberPad;
                textField.placeholder = @"Normalized Tip(optional)";
                textField.accessibilityLabel = @"vc_paymentapi_tip";
                tipTF = textField;
            }];
        }
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeNumberPad;
            textField.placeholder = @"Normalized Discount(optional)";
            textField.accessibilityLabel = @"vc_paymentapi_discount";
            discountTF = textField;
        }];
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeNumberPad;
            textField.placeholder = @"Normalized Tax(optional)";
            textField.accessibilityLabel = @"vc_paymentapi_tax";
            taxTF = textField;
        }];
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeNumberPad;
            textField.placeholder = @"Normalized Surcharge(optional)";
            textField.accessibilityLabel = @"vc_paymentapi_surcharge";
            surchargeTF = textField;
        }];
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeDefault;
            textField.placeholder = @"Currency Code";
            textField.accessibilityLabel = @"vc_paymentapi_currency_code";
            NSString * cachedCurrencyCode = [[NSUserDefaults standardUserDefaults] valueForKey:@"CurrencyCode"];
            if(cachedCurrencyCode){
                textField.text = cachedCurrencyCode;
            }else{
                textField.text = @"USD";
            }
            currencyCodeTF = textField;
        }];
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeDefault;
            textField.placeholder = @"Transaction Note(optional)";
            textField.accessibilityLabel = @"vc_paymentapi_transaction_note";
            transactionNoteTF = textField;
        }];
        if(transactionType != TransactionTypeCreditAuthCompletion) {
            if (transactionType != TransactionTypeCashRefund &&
                !(transactionType == TransactionTypeCreditRefund && !(isWithReader || isSCETransaction))) {
                [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
                    textField.keyboardType = UIKeyboardTypeDefault;
                    textField.placeholder = @"Merchant Invoice ID(optional)";
                    textField.accessibilityLabel = @"vc_paymentapi_invoice_id";
                    invocieIDTF = textField;
                }];
            }
            [alertController addCheckBoxWithTitle:@"ShowNoteAndInvoiceOnReceipt" andConfigurationHandler:^(UIButton * _Nonnull checkBox) {
                checkBox.accessibilityLabel = @"vc_paymentapi_show_note_cb";
                showNoteAndInvoiceOnReceiptCheckBox = checkBox;
            }];
        }
    }
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeDefault;
        textField.placeholder = @"ClerkID(Optional)";
        textField.accessibilityLabel = @"vc_paymentapi_clerk_id";
        clerkIDTF = textField;
    }];
    if (transactionType != TransactionTypeCashSale
        && transactionType != TransactionTypeCashRefund){
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeNumberPad;
            textField.placeholder = @"Order Number(Optional)";
            textField.accessibilityLabel = @"vc_paymentapi_order_number";
            orderNumberTF = textField;
        }];
    }
    if (enrollToken || isTokenUpdate) {
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeNumberPad;
            textField.placeholder = @"Normalized Token Fee(Optional)";
            textField.accessibilityLabel = @"vc_paymentapi_token_fee";
            tokenFeeTF = textField;
        }];
        if (transactionType != TransactionTypeTokenEnrollment) {
            [alertController addCheckBoxWithTitle:@"Token Enroll" andConfigurationHandler:^(UIButton * _Nonnull checkBox) {
                [checkBox setSelected:NO];
                checkBox.accessibilityLabel = @"vc_paymentapi_token_enroll_cb";
                tokenEnrollCheckBox = checkBox;
                [tokenEnrollCheckBox addTarget:self action:@selector(checkboxSelected:) forControlEvents:UIControlEventTouchUpInside];
            }];
        }
        if (isTokenUpdate) {
            if (transactionType != TransactionTypeTokenEnrollment) {
                [alertController addCheckBoxWithTitle:@"Token Update" andConfigurationHandler:^(UIButton * _Nonnull checkBox) {
                    [checkBox setSelected:NO];
                    checkBox.accessibilityLabel = @"vc_paymentapi_token_update_cb";
                    tokenUpdateCheckBox = checkBox;
                    [tokenUpdateCheckBox addTarget:self action:@selector(checkboxSelected:) forControlEvents:UIControlEventTouchUpInside];
                }];
            }
        }
    }
    if (isTokenUpdate || isTokenSale) {
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeDefault;
            textField.placeholder = @"Token Identifier";
            textField.accessibilityLabel = @"vc_paymentapi_token_id";
            if ([self getLastTokenId] != nil) {
                textField.text = [self getLastTokenId];
            }
            tokenIDTF = textField;
        }];
    }
    if(transactionType != TransactionTypeTokenEnrollment) {
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeDefault;
            textField.placeholder = @"Custom Reference(Optional)";
            textField.accessibilityLabel = @"vc_paymentapi_custom_ref";
            customRefTF = textField;
        }];
    }
    if (isManualKeyed && isWithReader && transactionType != TransactionTypeCreditRefund) {
        [alertController addCheckBoxWithTitle:@"Request CVV" andConfigurationHandler:^(UIButton * _Nonnull checkBox) {
            checkBox.accessibilityLabel = @"vc_paymentapi_cvv_cb";
            [checkBox setSelected:YES];
            cvvCheckBox = checkBox;
        }];
        [alertController addCheckBoxWithTitle:@"Request AVS" andConfigurationHandler:^(UIButton * _Nonnull checkBox) {
            checkBox.accessibilityLabel = @"vc_paymentapi_avs_cb";
            [checkBox setSelected:NO];
            avsCheckBox = checkBox;
        }];
    }
    if (checkIfCardPresent) {
        [alertController addCheckBoxWithTitle:@"Card Present" andConfigurationHandler:^(UIButton * _Nonnull checkBox) {
            checkBox.accessibilityLabel = @"vc_paymentapi_card_present_cb";
            [checkBox setSelected:NO];
            cardPresentCheckBox = checkBox;
        }];
    }
    if (transactionType == TransactionTypeAVSOnly) {
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.accessibilityLabel = @"vc_paymentapi_avs_zipcode";
            textField.keyboardType = UIKeyboardTypeDefault;
            textField.placeholder = @"AVS Zip Code";
            avsZipCodeTF = textField;
        }];
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeDefault;
            textField.placeholder = @"AVS Address";
            textField.accessibilityLabel = @"vc_paymentapi_avs_address";
            avsAddressTF = textField;
        }];
    }
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeDefault;
        NSLocale *merchantLocale = [[Ingenico sharedInstance] preference].merchantLocale;
        textField.text = merchantLocale != nil ? [merchantLocale localeIdentifier] : @"en_US";
        localeTF = textField;
    }];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        if(isPerformingPartialAuth) {
            [self voidLastPartialTransaction];
            [self showProgressMessage:@"Voiding Partial Transaction" andIsTransactionStoppable:YES];
        }
    }];
    [alertController addAction:cancelAction];
    [alertController addAction:action];
    [self presentViewController:alertController animated:YES completion:nil];
}

- (void)updateTranasctionWithTransactionID:(NSString *)transactionID{
    [[Ingenico sharedInstance].User updateTransactionWithTransactionID:transactionID
                                                     andCardholderInfo:[self getSampleCardholderInfo:transactionID]
                                    andTransactionNote:nil
                                        andIsCompleted:NO
                             andDisplayNotesAndInvoice:YES
                                             andOnDone:^(NSError *error) {
                                                 if (nil == error) {
                                                     [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Update transaction succeeded"]];
                                                 } else {
                                                     [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Update transaction failed with %@", [self getResponseCodeString:error.code]]];
                                                 }
                                                 [self sendReceipt:transactionID];
                                             }];
}

- (void)sendReceipt:(NSString *)transactionID{
    [[Ingenico sharedInstance].User sendEmailReceipt:transactionID andEmailAddress:nil andOnDone:^(NSError *error) {
        if (nil == error) {
            [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"send email receipt succeeded\n"]];
        } else {
            [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"send email receipt failed with %@", [self getResponseCodeString:error.code]]];
        }
    }];
}

- (void)nextAction:(IMSTransactionResponse *)response andError:(NSError *)error{
    NSString* alertTitle;
    NSString* alertMessage;
    [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Transaction Response:\n%@", response.description]];
    if (error == nil) {
        alertTitle = [NSString stringWithFormat:@"%@ Complete", alertMessageTitle];
    }
    else{
        alertTitle = [NSString stringWithFormat:@"%@ Failed", alertMessageTitle];
        [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Transaction failed with %@", [self getResponseCodeString:error.code]]];
    }
    alertMessage = [NSString stringWithFormat:@"Response Code : %@\nTransaction ID : %@\nTransaction GUID : %@\nClerk Display : %@\nPOS Entry Mode : %@\nAuthorized Amount : %ld\nInvoice ID : %@\nAvailable Balance:%ld\nRedactedCardNumber:%@\nToken Response Code:%@\nClient Transaction ID:%@\nTransaction Response Code:%@\nCard Type:%@\nCard Holder Name:%@\nExpiration Date:%@\n", [self getResponseCodeString:error.code], response.transactionID, response.transactionGUID, response.clerkDisplay, [self getStrFromPOSEntryMode:response.posEntryMode], (long)response.authorizedAmount, response.invoiceID, (long)response.availableBalance,response.redactedCardNumber, [self getStrFromTokenResponseCode:response.tokenResponseParameters.responseCode], response.clientTransactionID, [self getStringFromTransactionResponseCode:response.transactionResponseCode],[self getStringFromCardType:response.cardType], response.cardholderName, response.cardExpirationDate];
    [LogHelper.sharedInstance consoleLog:alertMessage];
    [self showAlertWithTitle:alertTitle andMessage:alertMessage andHanlder:^(UIAlertAction *action) {
        if (response.transactionID && error == nil) {
            [self getSignatureOrUpdateTransaction:response];
        }
        else if(response.transactionID){
            [self updateTranasctionWithTransactionID:response.transactionID];
            if (isPerformingPartialAuth) {
                [self doPartialAuthorization];
            }
            else {
                [self resetPartialAuthState];
            }
        }
    }];
}

- (void)setupCallbacks{
    __weak typeof(self) weakSelf = self;
    doneCallback = ^void(IMSTransactionResponse *response, NSError *error){
        [weakSelf dismissProgress];
        [weakSelf dismissModalView];
        _response = response;
        if (response.clientTransactionID) {
            [weakSelf setLastClientTransactionID:response.clientTransactionID];
        }
        if (response){
            [weakSelf setLastTransactionID:response.transactionID];
        }
        if (response &&
            response.tokenResponseParameters &&
            response.tokenResponseParameters.tokenIdentifier &&
            ![response.tokenResponseParameters.tokenIdentifier isEqualToString:@""]) {
            [weakSelf setLastTokenId:response.tokenResponseParameters.tokenIdentifier];
        }
        if (error == nil && response.posEntryMode == POSEntryModeContactEMV){
            [weakSelf showProgressMessage:@"Please remove card" andIsTransactionStoppable:NO];
            [[Ingenico sharedInstance].PaymentDevice waitForCardRemoval:50 andOnDone:^(NSError *error1) {
                [weakSelf dismissProgress];
                [weakSelf nextAction:response andError:error];
            }];
        } else {
            [weakSelf nextAction:response andError:error];
        }
    };

    progressCallback = ^void(IMSProgressMessage message, NSString *extraMessage){
        NSString *strMessage = [weakSelf getProgressStrFromMessage:message];
        if(strMessage){
            [weakSelf showProgressMessage:strMessage andIsTransactionStoppable:YES];
            [LogHelper.sharedInstance consoleLog:[NSString stringWithFormat:@"Progress message:%@",strMessage]];
        }
    };
    
    partialDoneCallback = ^void(IMSTransactionResponse *response, NSError *error){
        _response = response;
        [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Transaction Response:\n%@", response.description]];
        if(error == nil && partialTransactionIds.count != 0){
            [weakSelf voidLastPartialTransaction];
        } else {
            [weakSelf dismissProgress];
            [weakSelf dismissModalView];
            [weakSelf resetPartialAuthState];
            NSString* alertTitle;
            NSString* alertMessage;
            if (error == nil) {
                alertTitle = @"Success";
                alertMessage = @"Voided all partial transactions. See log for details";
            }
            else {
                alertTitle = @"Failure";
                alertMessage = @"Unable to void all partial transactions. See log for details";
            }
            UIAlertController * alertController = [UIAlertController alertControllerWithTitle: alertTitle message:alertMessage preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *okAction = [UIAlertAction
                                     actionWithTitle:@"Ok"
                                     style:UIAlertActionStyleDefault
                                     handler:nil];
            [alertController addAction:okAction];
            [weakSelf presentViewController:alertController animated:YES completion: nil];
        }
        
    };

    applicationSelectionCallback = ^void(NSArray *applicationList, NSError *error, ApplicationSelectedResponse reponse){
        [weakSelf dismissProgress];
        UIAlertController *alertView = [UIAlertController
                                        alertControllerWithTitle:@"Select application for your card"
                                        message:@""
                                        preferredStyle:UIAlertControllerStyleActionSheet];
        for (RUAApplicationIdentifier *appID in applicationList) {
            UIAlertAction *ok = [UIAlertAction
                                 actionWithTitle:appID.applicationLabel ? appID.applicationLabel : @""
                                 style:UIAlertActionStyleDefault
                                 handler:^(UIAlertAction *action) {
                                     [weakSelf showProgressMessage:@"Processing card transaction" andIsTransactionStoppable:YES];
                                     [alertView dismissViewControllerAnimated:YES completion:nil];
                                     reponse(appID);
                                 }];
            [alertView addAction:ok];
        }
        UIAlertAction *cancel = [UIAlertAction
                                 actionWithTitle:@"Cancel"
                                 style:UIAlertActionStyleCancel
                                 handler:^(UIAlertAction *action) {
                                     reponse(nil);
                                 }];
        [alertView addAction:cancel];
        if([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPhone){
            [weakSelf presentViewController:alertView animated:YES completion:nil];
        }
        else{
            [alertView setModalPresentationStyle:UIModalPresentationPopover];
            UIPopoverController *controller = [[UIPopoverController alloc] initWithContentViewController:alertView];
            [controller presentPopoverFromRect:[weakSelf.paymentTableView convertRect: [weakSelf.paymentTableView rectForRowAtIndexPath:_tableViewCellPath] toView: weakSelf.paymentTableView.superview] inView:[weakSelf.paymentTableView superview] permittedArrowDirections:UIPopoverArrowDirectionUp animated:YES];
        }
    };
    transactionTypeSelectionCallback = ^void(NSError* error, IMSTransactionTypeSelectionResponse reponse){
        [weakSelf dismissProgress];
        UIAlertController *alertView = [UIAlertController
                                        alertControllerWithTitle:@"Select transaction type for your transaction"
                                        message:@""
                                        preferredStyle:UIAlertControllerStyleActionSheet];
        UIAlertAction *creditAction = [UIAlertAction
                             actionWithTitle:@"Credit"
                             style:UIAlertActionStyleDefault
                             handler:^(UIAlertAction *action) {
                                 [weakSelf showProgressMessage:@"Processing card transaction" andIsTransactionStoppable:YES];
                                 [alertView dismissViewControllerAnimated:YES completion:nil];
                                 reponse(ApplicationTypeCredit);
                             }];
        UIAlertAction *debitAction = [UIAlertAction
                             actionWithTitle:@"Debit"
                             style:UIAlertActionStyleDefault
                             handler:^(UIAlertAction *action) {
                                 [weakSelf showProgressMessage:@"Processing card transaction" andIsTransactionStoppable:YES];
                                 [alertView dismissViewControllerAnimated:YES completion:nil];
                                 reponse(ApplicationTypeDebit);
                             }];
        [alertView addAction:creditAction];
        [alertView addAction:debitAction];
        UIAlertAction *cancel = [UIAlertAction
                                 actionWithTitle:@"Cancel"
                                 style:UIAlertActionStyleCancel
                                 handler:^(UIAlertAction *action) {
                                     reponse(ApplicationTypeUnknown);
                                 }];
        [alertView addAction:cancel];
        if([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPhone){
            [weakSelf presentViewController:alertView animated:YES completion:nil];
        }
        else{
            [alertView setModalPresentationStyle:UIModalPresentationPopover];
            UIPopoverController *controller = [[UIPopoverController alloc] initWithContentViewController:alertView];
            [controller presentPopoverFromRect:[weakSelf.paymentTableView convertRect: [weakSelf.paymentTableView rectForRowAtIndexPath:_tableViewCellPath] toView: weakSelf.paymentTableView.superview] inView:[weakSelf.paymentTableView superview] permittedArrowDirections:UIPopoverArrowDirectionUp animated:YES];
        }
    };
}

-(void)checkboxSelected:(UIButton*)sender {
    if(sender == tokenEnrollCheckBox){
        [tokenUpdateCheckBox setSelected:NO];
    }
    else if(sender == tokenUpdateCheckBox){
        [tokenEnrollCheckBox setSelected:NO];
    }
}

-(void) processVasOnlyTransaction {
    [[Ingenico sharedInstance].Payment processVasOnlyTransactionWithCardReader:progressCallback andOnDone:^(IMSTransactionResponse * _Nullable response, NSError * _Nullable error) {
        [self dismissProgress];
        [self nextAction:response andError:error];
    }];
}

@end
