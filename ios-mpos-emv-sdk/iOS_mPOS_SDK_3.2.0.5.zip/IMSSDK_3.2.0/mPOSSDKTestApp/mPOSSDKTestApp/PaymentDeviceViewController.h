//
//  PaymentDeviceViewController.h
//  mPOSSDKTestApp
//
//  Copyright © 2016 RoamData. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IMSBaseViewController.h"

@interface PaymentDeviceViewController : IMSBaseViewController

@property (weak, nonatomic) IBOutlet UITableView *paymentDeviceTableView;

@end
