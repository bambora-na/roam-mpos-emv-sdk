//
//  SearchTableViewCell.h
//  mPOSSDKTestApp
//
//  Copyright © 2015 Ingenico Mobile Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *communicationLabel;
@property (weak, nonatomic) IBOutlet UILabel *identifierLabel;

@end
