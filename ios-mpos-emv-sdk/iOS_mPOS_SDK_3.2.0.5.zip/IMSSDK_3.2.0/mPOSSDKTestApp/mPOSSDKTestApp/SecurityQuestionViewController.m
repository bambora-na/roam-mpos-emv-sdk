//
//  SecurityQuestionViewController.m
//  mPOSSDKTestApp
//
//  Created by Abhiram Dinesh on 10/19/21.
//  Copyright © 2021 RoamData. All rights reserved.
//

#import "SecurityQuestionViewController.h"

@interface SecurityQuestionViewController () <UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate> {
    
    NSArray *_questions;

}
@property (weak, nonatomic) IBOutlet UIPickerView *questionPicker1;
@property (weak, nonatomic) IBOutlet UIPickerView *questionPicker2;
@property (weak, nonatomic) IBOutlet UITextField *answerTextField1;
@property (weak, nonatomic) IBOutlet UITextField *answerTextField2;

@end

@implementation SecurityQuestionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Show Log" style:UIBarButtonItemStylePlain target:self action:@selector(showLog:)];
    [self.navigationItem.rightBarButtonItem setTitleTextAttributes:
        @{
            NSFontAttributeName: [UIFont fontWithName:@"TrebuchetMS-Bold" size:16.0],
            NSForegroundColorAttributeName: [UIColor darkGrayColor]
        } forState:UIControlStateNormal
    ];
    
    [self.questionPicker1 setDelegate:self];
    [self.questionPicker1 setDataSource:self];
    [self.questionPicker2 setDelegate:self];
    [self.questionPicker2 setDataSource:self];
    [self.answerTextField1 setDelegate:self];
    [self.answerTextField2 setDelegate:self];
    
    [self loadSecurityQuestions];
}

- (void)loadSecurityQuestions {
    [self showProgressMessage:@"Getting security questions" andIsTransactionStoppable:NO];
    [Ingenico.sharedInstance.User getSecurityQuestions:^(NSArray * _Nullable questions, NSError * _Nullable error) {
        [self dismissProgress];
        if (error) {
            [LogHelper.sharedInstance consoleLog:[[NSString alloc]
                              initWithFormat:@"Get Security Questions failed "
                              @"with error code : %ld\n",
                              (long)error.code]];
        }
        else {
            _questions = questions;
            [self.questionPicker1 reloadAllComponents];
            [self.questionPicker2 reloadAllComponents];
        }
    }];
}

- (IBAction)submitSecurityQuestions:(id)sender {
    [self showProgressMessage:@"Setting security questions" andIsTransactionStoppable:NO];
    IMSSecurityQuestion *question1 = _questions[[_questionPicker1 selectedRowInComponent:0]];
    IMSSecurityQuestion* question2 = _questions[[_questionPicker2 selectedRowInComponent:0]];
    IMSSecurityQuestion *answer1 = [[IMSSecurityQuestion alloc] initWithQuestionID:question1.questionId  andAnswer:self.answerTextField1.text];
    IMSSecurityQuestion *answer2 = [[IMSSecurityQuestion alloc] initWithQuestionID:question2.questionId andAnswer:self.answerTextField2.text];
    [Ingenico.sharedInstance.User setSecurityQuestions:@[answer1, answer2] andOnDone:^(NSError * _Nullable error) {
        [self dismissProgress];
        if (error) {
            [LogHelper.sharedInstance consoleLog:[[NSString alloc]
                              initWithFormat:@"Set Security Questions failed "
                              @"with error code : %ld\n",
                              (long)error.code]];
        }
        else {
            [LogHelper.sharedInstance consoleLog:@"Set Security Questions Success"];
        }
    }];
}

- (IBAction)showLog:(id)sender{
    [self performSegueWithIdentifier:@"show_log_sq" sender:self];
}

- (NSInteger)numberOfComponentsInPickerView:(nonnull UIPickerView *)pickerView {
    return 1;
}

- (NSInteger)pickerView:(nonnull UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    if (_questions) {
        return _questions.count;
    }
    return 0;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    if (_questions) {
        IMSSecurityQuestion *securityQuestion = _questions[row];
        return securityQuestion.question;
    }
    return nil;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self.view endEditing:YES];
    return YES;
}



@end
