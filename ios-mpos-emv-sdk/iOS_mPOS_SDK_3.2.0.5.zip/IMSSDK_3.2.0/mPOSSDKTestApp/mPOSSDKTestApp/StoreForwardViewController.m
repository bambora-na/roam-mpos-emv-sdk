//
//  StoreForwardViewController.m
//  mPOSSDKTestApp
//
//  Copyright © 2016 RoamData. All rights reserved.
//

#import "StoreForwardViewController.h"
#import "TabBarViewController.h"
#import "UIAlertController+Utility.h"

@interface StoreForwardViewController ()<UITableViewDelegate, UITableViewDataSource>{
    NSArray *storeAndForwardArray;
    NSString *alertMessageTitle;
    TransactionOnDone doneCallback;
    UpdateProgress progressCallback;
    ApplicationSelectionHandler applicationSelectionCallback;
    IMSTransactionResponse *_response;
    __block UITextField *totalTF;
    __block UITextField *subtotalTF;
    __block UITextField *discountTF;
    __block UITextField *taxTF;
    __block UITextField *tipTF;
    __block UITextField *surchargeTF;
    __block UITextField *clerkIDTF;
    __block UITextField *authCodeTF;
    __block UITextField *stanTF;
    __block UITextField *invocieIDTF;
    __block UITextField *transactionNoteTF;
    __block UITextField *tokenFeeTF;
    __block UITextField *tokenIdentifierTF;
    __block UITextField *customRefTF;
    __block UITextField *orderNumberTF;
    __block UITextField *localeTF;
    __block UITextField *userEmailTextField;
    __block UITextField *currencyCodeTF;
    __block UIButton *cvvCheckBox;
    __block UIButton *avsCheckBox;
    __block UIButton *cardPresentCheckBox;
    __block UIButton *showNoteAndInvoiceOnReceiptCheckBox;
    __block UIButton *tokenEnrollmentCheckbox;
    __block UIButton *tokenUpdateCheckbox;
    __block UIButton *validateExpirationDateCheckbox;
    __block UITextField *clientTransactionIdTF;
    NSInteger successfulUploadedCount;
    NSInteger declinedTransactionCount;
    bool isStoreForwardUpload;
    bool emvSnF;
    NSIndexPath *_tableViewCellPath;
}

@end

@implementation StoreForwardViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    storeAndForwardArray = [[NSArray alloc] initWithObjects:
                            @"* Credit sale (Swipe Only)",
                            @"* Credit auth (Swipe Only)",
                            @"* Keyed Credit Sale",
                            @"* Update stored transaction",
                            @"* Upload stored transaction",
                            @"* Store receipt for stored transaction",
                            @"* Void stored transaction",
                            @"* Get stored transaction",
                            @"* Get stored transactions",
                            @"* Get stored transactions in service group",
                            @"* Upload stored transactions",
                            @"* Upload stored transactions in service group",
                            @"* Delete stored transaction",
							@"* Cash Sale",
                            @"* Token Enrollment/Update (Swipe Only)",
                            @"* Keyed Token Enrollement/Update",
                            @"* Credit sale (EMV)",
                            @"* Credit auth (EMV)",
                            @"* Token Enrollment/Update (EMV)",
                            @"* Delete stored transaction with client txn id",
                            nil];
    _storeForwardTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    _storeForwardTableView.tableHeaderView = [[UIView alloc] initWithFrame:CGRectZero];
    [self setupCallbacks];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [(TabBarViewController *)self.parentViewController setCurrentVisibleChildViewController:self];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    _storeForwardTableView.frame = CGRectMake(0, _storeForwardTableView.frame.origin.y-([UIApplication sharedApplication].statusBarFrame.size.height+self.parentViewController.navigationController.navigationBar.frame.size.height), _storeForwardTableView.frame.size.width, _storeForwardTableView.frame.size.height+[UIApplication sharedApplication].statusBarFrame.size.height+self.parentViewController.navigationController.navigationBar.frame.size.height);
}

- (void)setupCallbacks{
    __weak typeof(self) weakSelf = self;
    doneCallback = ^void(IMSTransactionResponse *response, NSError *error){
        [weakSelf dismissProgress];
        _response = response;
        [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Transaction Response:\n%@",response.description]];
        if(error == nil && response.posEntryMode == POSEntryModeContactEMV){
            [[Ingenico sharedInstance].PaymentDevice waitForCardRemoval:50 andOnDone:^(NSError *error) {
                if(error){
                    [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"WaitForCardRemoval failed with %@", [weakSelf getResponseCodeString:error.code]]];
                }
                else{
                    [LogHelper.sharedInstance consoleLog:@"WaitForCardRemoval command succeeded"];
                }
            }];
        }
        NSString* alertTitle;
        NSString* alertMessage;
        if (response.clientTransactionID) {
            [weakSelf setLastClientTransactionID:response.clientTransactionID];
        }
        if (error == nil) {
            [weakSelf setLastTransactionID:response.transactionID];
            alertTitle = [NSString stringWithFormat:@"%@ Complete", alertMessageTitle];
        }
        else{
            alertTitle = [NSString stringWithFormat:@"%@ Failed", alertMessageTitle];
            [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Transaction failed with %@", [weakSelf getResponseCodeString:error.code]]];
        }
        
        alertMessage = [NSString stringWithFormat:@"Response Code : %@\nTransaction ID : %@\nTransaction GUID : %@\nClerk Display : %@\nPOS Entry Mode : %@\nAuthorized Amount : %ld\nInvoice ID : %@\nAvailable Balance:%ld\nRedactedCardNumber:%@\nToken Response Code:%@\nClient Transaction ID:%@\nTransaction Response Code:%@\nCard Type:%@\n", [self getResponseCodeString:error.code], response.transactionID, response.transactionGUID, response.clerkDisplay, [self getStrFromPOSEntryMode:response.posEntryMode], (long)response.authorizedAmount, response.invoiceID, (long)response.availableBalance,response.redactedCardNumber, [self getStrFromTokenResponseCode:response.tokenResponseParameters.responseCode], response.clientTransactionID, [self getStringFromTransactionResponseCode:response.transactionResponseCode],[self getStringFromCardType:response.cardType]];
        if([response.tokenResponseParameters.tokenIdentifier length] > 0) {
            [weakSelf setLastTokenId:response.tokenResponseParameters.tokenIdentifier];
        }
        [weakSelf showAlertWithTitle:alertTitle andMessage:alertMessage andHandler:nil];
    };
    
    progressCallback = ^void(IMSProgressMessage message, NSString *extraMessage){
        NSString *strMessage = [weakSelf getProgressStrFromMessage:message];
        if(strMessage){
            [weakSelf showProgressMessage:strMessage andIsTransactionStoppable:isStoreForwardUpload?NO:YES];
        }
    };
    applicationSelectionCallback = ^void(NSArray *applicationList, NSError *error, ApplicationSelectedResponse reponse){
        [weakSelf dismissProgress];
        UIAlertController *alertView = [UIAlertController
                                        alertControllerWithTitle:@"Select application for your card"
                                        message:@""
                                        preferredStyle:UIAlertControllerStyleActionSheet];
        for (RUAApplicationIdentifier *appID in applicationList) {
            UIAlertAction *ok = [UIAlertAction
                                 actionWithTitle:appID.applicationLabel ? appID.applicationLabel : @""
                                 style:UIAlertActionStyleDefault
                                 handler:^(UIAlertAction *action) {
                                     [weakSelf showProgressMessage:@"Processing card transaction" andIsTransactionStoppable:YES];
                                     [alertView dismissViewControllerAnimated:YES completion:nil];
                                     reponse(appID);
                                 }];
            [alertView addAction:ok];
        }
        UIAlertAction *cancel = [UIAlertAction
                                 actionWithTitle:@"Cancel"
                                 style:UIAlertActionStyleCancel
                                 handler:^(UIAlertAction *action) {
                                     reponse(nil);
                                 }];
        [alertView addAction:cancel];
        if([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPhone){
            [weakSelf presentViewController:alertView animated:YES completion:nil];
        }
        else{
            [alertView setModalPresentationStyle:UIModalPresentationPopover];
            UIPopoverController *controller = [[UIPopoverController alloc] initWithContentViewController:alertView];
            [controller presentPopoverFromRect:[weakSelf.storeForwardTableView convertRect: [weakSelf.storeForwardTableView rectForRowAtIndexPath:_tableViewCellPath] toView: weakSelf.storeForwardTableView.superview] inView:[weakSelf.storeForwardTableView superview] permittedArrowDirections:UIPopoverArrowDirectionUp animated:YES];
        }
    };
}

//MARK:: tableview delegate methods
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.bounds.size.width, 35)];
    UILabel *sectionLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 0, tableView.bounds.size.width-20, 35)];
    sectionLabel.text = @"Store and forward transactions";
    sectionLabel.font = [UIFont fontWithName:@"Palatino-Italic" size:16];
    [headerView setBackgroundColor:[UIColor lightGrayColor]];
    [headerView addSubview:sectionLabel];
    return headerView;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [storeAndForwardArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *CellIdentifier = @"StoreForwardAPICell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    cell.textLabel.text = [storeAndForwardArray objectAtIndex:indexPath.row];
    cell.textLabel.textColor = [UIColor darkGrayColor];
    cell.textLabel.font = [UIFont fontWithName:@"Palatino" size:14];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    [cell setAccessibilityLabel:[NSString stringWithFormat:@"vc_storeforwardapi_section_%d_row_%d", (int)indexPath.section, (int)indexPath.row]];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    _tableViewCellPath = indexPath;
    isStoreForwardUpload = NO;
    if(indexPath.row == 0){
        [self promptForAmountWithTransactionType:TransactionTypeCreditSale];
    }
    else if(indexPath.row == 1){
        [self promptForAmountWithTransactionType:TransactionTypeCreditAuth];
        
    }
    else if(indexPath.row == 2){
        [self promptForAmountWithTransactionType:TransactionTypeCreditSale andWithCardReader:YES andIsManualKeyed:YES];
        
    }
    else if(indexPath.row == 3){
        [self clientTransactionIDChecking:^{
            [self updateStoredTransaction];
        }];
    }
    else if(indexPath.row == 4){
        [self clientTransactionIDChecking:^{
            alertMessageTitle = @"Upload Stored Transaction";
            isStoreForwardUpload = YES;
            [self showProgressMessage:@"Processing Transaction" andIsTransactionStoppable:NO];
            [[Ingenico sharedInstance].StoreAndForward uploadStoredTransaction:[self getLastClientTransactionID] andUpdateProgress:progressCallback andOnDone:doneCallback];
        }];
    }
    else if(indexPath.row == 5){
        [self setEmailToStoreReceiptForStoredTransaction];
    }
    else if(indexPath.row == 6){
        [self clientTransactionIDChecking:^{
            alertMessageTitle = @"Void Stored Transaction";
            __block UIButton *displayNotesCB;
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:alertMessageTitle message:@"Enter the following:" preferredStyle:UIAlertControllerStyleAlert];
            [alert addCheckBoxWithTitle:@"Display Notes And Invoice" andConfigurationHandler:^(UIButton * _Nonnull checkBox) {
                checkBox.accessibilityLabel = @"vc_snfapi_show_note_cb";
                displayNotesCB = checkBox;
            }];
            UIAlertAction *ok = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            [self showProgressMessage:@"Processing Transaction" andIsTransactionStoppable:NO];
                [[Ingenico sharedInstance].StoreAndForward processVoidStoredTransaction:[[IMSStoreAndForwardVoidTransactionRequest alloc] initWithOriginalClientTransactionID:[self getLastClientTransactionID] andClerkID:@"1234" andLongitude:[(TabBarViewController *)self.parentViewController getLongitude] andLatitude:[(TabBarViewController *)self.parentViewController getLatitude] andCustomReference:@"testcustref" andOrderNumber:nil andShowNotesAndInvoiceOnReceipt:displayNotesCB.isSelected] andOnDone:doneCallback];
            }];
            [alert addAction:ok];
            [self presentViewController:alert animated:YES completion:nil];
        }];
    }
    else if(indexPath.row == 7){
        [self clientTransactionIDChecking:^{
            alertMessageTitle = @"Get Stored Transaction";
            [self showProgressMessage:@"Getting Transaction Info" andIsTransactionStoppable:NO];
            [[Ingenico sharedInstance].StoreAndForward getStoredTransactionWithClientTransactionID:[self getLastClientTransactionID] andOnDone:^(IMSStoredTransactionSummary * _Nullable storedTransactionSummary, NSError * _Nullable error) {
                [self dismissProgress];
                if (error == nil) {
                    NSMutableString* storedData = [NSMutableString string];
                    [storedData appendString:[NSString stringWithFormat:@"Response Code : %@\n", [self getResponseCodeString:error.code]]];
                    [LogHelper.sharedInstance consoleLog:storedTransactionSummary.description];
                    [storedData appendString:[NSString stringWithFormat:@"ClientTransactionID:%@ \n", storedTransactionSummary.clientTransactionID]];
                    [self setLastClientTransactionID:storedTransactionSummary.clientTransactionID];
                    [self showAlertWithTitle:alertMessageTitle andMessage:storedData andHandler:nil];
                    [LogHelper.sharedInstance consoleLog:storedData];
                }else{
                    [LogHelper.sharedInstance consoleLog:[NSString stringWithFormat:@"Get Stored Transaction failed:%ld", error.code]];
                }
            }];
        }];
    }else if(indexPath.row == 8){
        [self getAllStoredTransactions:NO];
    }else if(indexPath.row == 9){
        [self getAllStoredTransactions:YES];
    }else if(indexPath.row == 10){
        alertMessageTitle = @"Upload Stored Transactions";
        [self showProgressMessage:@"Processing Transaction" andIsTransactionStoppable:NO];
        [self uploadAllStoredTransactions:NO];
    }else if(indexPath.row == 11){
        alertMessageTitle = @"Upload Stored Transactions";
        [self showProgressMessage:@"Processing Transaction" andIsTransactionStoppable:NO];
        [self uploadAllStoredTransactions:YES];
    }else if(indexPath.row == 12){
        [self clientTransactionIDChecking:^{
            alertMessageTitle = @"Delete Stored Transaction";
            [self showProgressMessage:@"Deleting Stored Transaction" andIsTransactionStoppable:NO];
            [[Ingenico sharedInstance].StoreAndForward deleteStoredTransactionWithClientTransactionID:[self getLastClientTransactionID] andOnDone:^(NSError * _Nullable error) {
                [self dismissProgress];
                if (error == nil) {
                    [self setLastClientTransactionID:nil];
                    [LogHelper.sharedInstance consoleLog:[NSString stringWithFormat:@"Deletion success for client transactino ID: %@", [self getLastClientTransactionID]]];
                    [self showAlertWithTitle:alertMessageTitle andMessage:@"Deletion success" andHandler:nil];
                }else{
                    [LogHelper.sharedInstance consoleLog:[NSString stringWithFormat:@"Deletion failed for client transactino ID: %@ with error: %ld", [self getLastClientTransactionID], error.code]];
                }
            }];
        }];
    }else if(indexPath.row == 13){
		[self promptForAmountWithTransactionType:TransactionTypeCashSale];
    }else if(indexPath.row == 14) {
        alertMessageTitle = @"Token Enrollment/Update";
        [self doTokenEnrollment];
    }else if(indexPath.row == 15) {
        alertMessageTitle = @"Keyed Token Enrollment/Update";
        [self doKeyedTokenEnrollment];
    }
    else if (indexPath.row == 16) {
        emvSnF = YES;
        [self promptForAmountWithTransactionType:TransactionTypeCreditSale];
    }
    else if (indexPath.row == 17) {
        emvSnF = YES;
        [self promptForAmountWithTransactionType:TransactionTypeCreditAuth];
    }
    else if (indexPath.row == 18) {
        emvSnF = YES;
        alertMessageTitle = @"EMV Token Enrollment/Update";
        [self doTokenEnrollment];
    }else if (indexPath.row == 19) {
        [self promptForDeleteStoredTransactionWithClientTxnId];
    }
}

- (void)clientTransactionIDChecking:(void(^)())response{
    if([self getLastClientTransactionID]){
        response();
    }
    else{
        [self showErrorMessage:@"Please run a store and forward transaction first or call GetStoredTransactions" andErrorTitle:@"Error"];
        [LogHelper.sharedInstance consoleLog:@"No Stored Transactions"];
    }
}

- (void)promptForAmountWithTransactionType:(IMSTransactionType)transactionType{
    [self promptForAmountWithTransactionType:transactionType andWithCardReader:YES andIsManualKeyed:NO];
}

- (void)promptForAmountWithTransactionType:(IMSTransactionType)transactionType
                         andWithCardReader:(BOOL)isWithReader
                          andIsManualKeyed:(BOOL)isManualKeyed{
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        if(totalTF.text.intValue < 0){
            [self showErrorMessage:@"Please provide valid total amount" andErrorTitle:@"Wrong Amount"];
        }
        else{
            [self.view endEditing:YES];
            [self showProgressMessage:@"Processing Transaction" andIsTransactionStoppable:YES];
            IMSBaseTransactionRequest *TransactionRequest =
            [self getSampleTransactionRequestwithTotalAmount:[totalTF.text integerValue]
                                           andSubtotalAmount:[subtotalTF.text integerValue]
                                           andDiscountAmount:[discountTF.text length]>0?[discountTF.text integerValue]:0
                                                andTaxAmount:[taxTF.text length]>0?[taxTF.text integerValue]:0
                                                andTipAmount:[tipTF.text length]>0?[tipTF.text integerValue]:0
                                          andSurchargeAmount:[surchargeTF.text length]>0?[surchargeTF.text integerValue]:0
                                                  andClerkID:[clerkIDTF.text length]>0?clerkIDTF.text:nil
                                                     andStan:[stanTF.text length]>0?[stanTF.text integerValue]:0
                                                     andType:transactionType
                                          andCustomReference:[customRefTF.text length]>0?customRefTF.text:nil
                                           andWithCardReader:isWithReader
                                            andIsManualKeyed:isManualKeyed
                                             andCurrencyCode:[currencyCodeTF.text length]>0?currencyCodeTF.text:@"USD"];
            if ([localeTF.text isEqualToString:@"en_US"] ||
                [localeTF.text isEqualToString:@"en_CA"] ||
                [localeTF.text isEqualToString:@"fr_CA"]) {
                TransactionRequest.locale = [NSLocale localeWithLocaleIdentifier:localeTF.text];
            }
            if(TransactionRequest == nil){
                [self showErrorMessage:@"Total amount is less than 0, please provide valid subtotal/discount/tax/tip/surcharge amount" andErrorTitle:@"Error"];
                return;
            }
            totalTF = nil;
            subtotalTF = nil;
            discountTF = nil;
            taxTF = nil;
            tipTF = nil;
            surchargeTF=nil;
            clerkIDTF = nil;
            currencyCodeTF = nil;
            showNoteAndInvoiceOnReceiptCheckBox = nil;
            tokenEnrollmentCheckbox = nil;
            tokenUpdateCheckbox = nil;
            validateExpirationDateCheckbox = nil;
            [self setLastTransactionType:transactionType];
            [self setLastTransactionID:nil];
            switch (transactionType) {
                case TransactionTypeCreditSale:
                alertMessageTitle = @"Store And Forward Credit Sale";
                    if (emvSnF) {
                        emvSnF = NO;
                        [[Ingenico sharedInstance].StoreAndForward processEmvStoreAndForwardCreditSaleTransactionWithCardReader:TransactionRequest andUpdateProgress:progressCallback andSelectApplication:applicationSelectionCallback andOnDone:doneCallback];
                    }
                    else if (!isManualKeyed){
                        [[Ingenico sharedInstance].StoreAndForward processStoreAndForwardCreditSaleTransactionWithCardReader:TransactionRequest
                                                                                                           andUpdateProgress:progressCallback
                                                                                                                   andOnDone:doneCallback];
                    }
                    else{
                        alertMessageTitle = @"Keyed Store And Forward Credit Sale With Card Reader";
                          [[Ingenico sharedInstance].StoreAndForward processStoreAndForwardKeyedCardSaleTransactionWithCardReader:TransactionRequest
                                                                                                             andUpdateProgress:progressCallback
                                                                                                                     andOnDone:doneCallback];
                    }
                    break;
                case TransactionTypeCreditAuth:
                alertMessageTitle = @"Store And Forward Credit Auth";
                    if (emvSnF) {
                        emvSnF = NO;
                        [[Ingenico sharedInstance].StoreAndForward processEmvStoreAndForwardCreditAuthTransactionWithCardReader:TransactionRequest
                                                                                                           andUpdateProgress:progressCallback
                                                                                                        andSelectApplication:applicationSelectionCallback
                                                                                                                   andOnDone:doneCallback];
                    }
                    else {
                        [[Ingenico sharedInstance].StoreAndForward processStoreAndForwardCreditAuthTransactionWithCardReader:TransactionRequest
                                                                                                           andUpdateProgress:progressCallback
                                                                                                                   andOnDone:doneCallback];
                    }
                    break;
				case TransactionTypeCashSale:
					alertMessageTitle = @"Store And Forward Cash Sale";
					[[Ingenico sharedInstance].StoreAndForward processStoreAndForwardCashTransaction:TransactionRequest andOnDone:doneCallback];
					break;
                default:
                    break;
            }
        }
    }];
    [self showAmountAlertControllerWithAction:okAction andTransactionType:transactionType andIsManualKeyed:isManualKeyed];
}

- (void)showAmountAlertControllerWithAction:(UIAlertAction *)action
                         andTransactionType:(IMSTransactionType)transactionType
                           andIsManualKeyed:(BOOL)isManualKeyed{
    UIAlertController *alertController = [UIAlertController
                                         alertControllerWithTitle:@"Information"
                                         message:@"Provide transaction info"
                                         preferredStyle:UIAlertControllerStyleAlert];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeNumberPad;
        textField.placeholder = @"Total Amount";
        textField.accessibilityLabel = @"vc_snfapi_total_amount";
        totalTF = textField;
    }];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeNumberPad;
        textField.placeholder = @"Normalized Subtotal";
        textField.accessibilityLabel = @"vc_snfapi_normalized_subtotal";
        subtotalTF = textField;
    }];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeNumberPad;
        textField.placeholder = @"Normalized Discount(optional)";
        textField.accessibilityLabel = @"vc_snfapi_normalized_discount";
        discountTF = textField;
    }];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeNumberPad;
        textField.placeholder = @"Normalized Tax(optional)";
        textField.accessibilityLabel = @"vc_snfapi_normalized_tax";
        taxTF = textField;
    }];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeNumberPad;
        textField.placeholder = @"Normalized Tip(optional)";
        textField.accessibilityLabel = @"vc_snfapi_normalized_tip";
        tipTF = textField;
    }];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeNumberPad;
        textField.placeholder = @"Normalized Surcharge(optional)";
        textField.accessibilityLabel = @"vc_snfapi_normalized_surcharge";
        surchargeTF = textField;
    }];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeDefault;
        textField.placeholder = @"Currency Code";
        textField.accessibilityLabel = @"vc_snfapi_currency_code";
        NSString * cachedCurrencyCode = [[NSUserDefaults standardUserDefaults] valueForKey:@"CurrencyCode"];
        if(cachedCurrencyCode){
            textField.text = cachedCurrencyCode;
        }else{
            textField.text = @"USD";
        }
        currencyCodeTF = textField;
    }];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeDefault;
        textField.placeholder = @"Merchant Invoice ID(optional)";
        textField.accessibilityLabel = @"vc_snfapi_invoice_id";
        invocieIDTF = textField;
    }];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeDefault;
        textField.placeholder = @"Transaction Note(optional)";
        textField.accessibilityLabel = @"vc_snfapi_transaction_note";
        transactionNoteTF = textField;
    }];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeDefault;
        textField.placeholder = @"ClerkID(Optional)";
        textField.accessibilityLabel = @"vc_snfapi_clerk_id";
        clerkIDTF = textField;
    }];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeDefault;
        textField.placeholder = @"Custom Reference(Optional)";
        textField.accessibilityLabel = @"vc_snfapi_custom_reference";
        customRefTF = textField;
    }];
    [alertController addCheckBoxWithTitle:@"ShowNoteAndInvoiceOnReceipt" andConfigurationHandler:^(UIButton * _Nonnull checkBox) {
        checkBox.accessibilityLabel = @"vc_snfapi_show_note_cb";
        showNoteAndInvoiceOnReceiptCheckBox = checkBox;
    }];
    if (isManualKeyed) {
        [alertController addCheckBoxWithTitle:@"Request CVV" andConfigurationHandler:^(UIButton * _Nonnull checkBox) {
            [checkBox setSelected:YES];
            checkBox.accessibilityLabel = @"vc_snfapi_cvv_cb";
            cvvCheckBox = checkBox;
        }];
        [alertController addCheckBoxWithTitle:@"Request AVS" andConfigurationHandler:^(UIButton * _Nonnull checkBox) {
            [checkBox setSelected:NO];
            checkBox.accessibilityLabel = @"vc_snfapi_avs_cb";
            avsCheckBox = checkBox;
        }];
        [alertController addCheckBoxWithTitle:@"Card Present" andConfigurationHandler:^(UIButton * _Nonnull checkBox) {
            [checkBox setSelected:NO];
            checkBox.accessibilityLabel = @"vc_snfapi_card_present_cb";
            cardPresentCheckBox = checkBox;
        }];
    }
    if(transactionType != TransactionTypeCashSale) {
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeNumberPad;
            textField.placeholder = @"Normalized Token Fee(Optional)";
            textField.accessibilityLabel = @"vc_snfapi_token_fee";
            tokenFeeTF = textField;
        }];
        [alertController addCheckBoxWithTitle:@"Token Enrollment" andConfigurationHandler:^(UIButton * _Nonnull checkBox) {
            [checkBox setSelected:NO];
            tokenEnrollmentCheckbox = checkBox;
            checkBox.accessibilityLabel = @"vc_snfapi_token_enroll_cb";
            [tokenEnrollmentCheckbox addTarget:self action:@selector(checkboxSelected:) forControlEvents:UIControlEventTouchUpInside];
        }];
        [alertController addCheckBoxWithTitle:@"Token Update" andConfigurationHandler:^(UIButton * _Nonnull checkBox) {
            [checkBox setSelected:NO];
            tokenUpdateCheckbox = checkBox;
            checkBox.accessibilityLabel = @"vc_snfapi_token_update_cb";
            [tokenUpdateCheckbox addTarget:self action:@selector(checkboxSelected:) forControlEvents:UIControlEventTouchUpInside];
        }];
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeDefault;
            textField.placeholder = @"Token Identifier";
            textField.accessibilityLabel = @"vc_snfapi_token_identifier";
            tokenIdentifierTF = textField;
            tokenIdentifierTF.text = [self getLastTokenId];
        }];
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeNumberPad;
            textField.placeholder = @"Order Number(Optional)";
            textField.accessibilityLabel = @"vc_snfapi_order_number";
            orderNumberTF = textField;
        }];
        if (!isManualKeyed) {
            [alertController addCheckBoxWithTitle:@"Validate Expiry Date" andConfigurationHandler:^(UIButton * _Nonnull checkBox) {
                [checkBox setSelected:YES];
                checkBox.accessibilityLabel = @"vc_snfapi_validate_expiry_date_cb";
                validateExpirationDateCheckbox = checkBox;
            }];
        }
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeDefault;
            NSLocale *merchantLocale = [[Ingenico sharedInstance] preference].merchantLocale;
            textField.text = merchantLocale != nil ? [merchantLocale localeIdentifier] : @"en_US";
            localeTF = textField;
        }];
    }
    [alertController addAction:action];
    [self presentViewController:alertController animated:YES completion:nil];
}

- (void)setEmailToStoreReceiptForStoredTransaction {
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        if(userEmailTextField && userEmailTextField.text.length >0){
            [self clientTransactionIDChecking:^{
                alertMessageTitle = @"Store Receipt for Stored Transaction";
                isStoreForwardUpload = YES;
                [self showProgressMessage:@"Sending stored request" andIsTransactionStoppable:NO];
                [[Ingenico sharedInstance].StoreAndForward storeReceiptForStoredTransaction:
                 [self getLastClientTransactionID]
                 andEmail:userEmailTextField.text
                 andOnDone:^(NSError *error) {
                     [self dismissProgress];
                     if (error == nil) {
                         [LogHelper.sharedInstance consoleLog:@"Store receipt for stored transaction succeeded"];
                     } else {
                         [LogHelper.sharedInstance consoleLog:[[NSString alloc]
                                                                                    initWithFormat:
                                                                                    @"Store receipt for stored transaction failed with error code : %ld\n",
                                                                                    (long)error.code]];
                     }
                 }];
            }];
        }
        else{
            [self showErrorMessage:@"Please provide valid email address" andErrorTitle:@"Error"];
        }
    }];
    [self promptForEmailAddress:okAction isOptional:false];
}

- (void)promptForEmailAddress:(UIAlertAction *)action isOptional:(BOOL)isOpetional{
    UIAlertController *alertController = [UIAlertController
                                         alertControllerWithTitle:@"Email Address"
                                         message:nil
                                         preferredStyle:UIAlertControllerStyleAlert];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeEmailAddress;
        if(isOpetional){
            textField.placeholder = @"Email Address (optional)";
        }
        else{
            textField.placeholder = @"Email Address";
        }
        textField.accessibilityLabel = @"vc_snfapi_email_address";
        userEmailTextField = textField;
    }];
    [alertController addAction:action];
    [self presentViewController:alertController animated:YES completion:nil];
}


- (id)getSampleTransactionRequestwithTotalAmount:(NSInteger)total
                               andSubtotalAmount:(NSInteger)subtotal
                               andDiscountAmount:(NSInteger)discount
                                    andTaxAmount:(NSInteger)tax
                                    andTipAmount:(NSInteger)tip
                              andSurchargeAmount:(NSInteger)surcharge
                                      andClerkID:(NSString *)clerkID
                                         andStan:(NSInteger)stan
                                         andType:(IMSTransactionType)type
                              andCustomReference:(NSString *)customRef
                               andWithCardReader:(BOOL)isWithReader
                                andIsManualKeyed:(BOOL)isManualKeyed
                                 andCurrencyCode:(NSString *)currencyCode{
    [[NSUserDefaults standardUserDefaults] setObject:currencyCode forKey:@"CurrencyCode"];
    IMSAmount *amount = [[IMSAmount alloc] initWithTotal:total andSubtotal:subtotal  andTax:tax andDiscount:discount andDiscountDescription:@"RoamDiscount"  andTip:tip andCurrency:currencyCode andSurcharge:surcharge];
    
    NSArray *products = [self getSampleProducts:total];
    IMSTokenRequestParametersBuilder *tokenRequestParamBuilder = [self getTokenRequestParametersBuilder];
    IMSTokenRequestParameters *tokenRequestParams = nil;
    if(tokenEnrollmentCheckbox.isSelected){
        tokenRequestParams = tokenRequestParamBuilder.createTokenEnrollmentRequestParameters;
    }
    if(tokenUpdateCheckbox.isSelected){
        tokenRequestParamBuilder.tokenIdentifier = tokenIdentifierTF.text;
        tokenRequestParams = tokenRequestParamBuilder.createTokenUpdateRequestParameters;
    }
    
    switch (type) {
        case TransactionTypeCreditSale:
        {
            if(!isManualKeyed){
                IMSStoreAndForwardCreditSaleTransactionRequest* storedTransactionRequest = [[IMSStoreAndForwardCreditSaleTransactionRequest alloc]
                                                                                            initWithAmount:amount
                                                                                            andProducts:products
                                                                                            andClerkID:clerkID
                                                                                            andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                                            andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                                                            andTransactionGroupID:nil
                                                                                            andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                                                            andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil
                                                                                            andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
                                                                                            andCustomReference:customRef
                                                                                            andIsCompleted:false
                                                                                            andUCIFormat:UCIFormatIngenico
                                                                                            andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil
                                                                                            andTokenRequestParameters:tokenRequestParams
                                                                                            andValidateCardExpirationDate:validateExpirationDateCheckbox.isSelected];
                [storedTransactionRequest setCustomData:@"Custom data"];
                return storedTransactionRequest;
            }
            else{
                IMSStoreAndForwardKeyedCardSaleTransactionRequest* storedTransactionRequest = [[IMSStoreAndForwardKeyedCardSaleTransactionRequest alloc]
                                                                                            initWithAmount:amount
                                                                                            andProducts:products
                                                                                            andClerkID:clerkID
                                                                                            andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                                            andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                                                            andTransactionGroupID:nil
                                                                                            andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                                                            andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil
                                                                                            andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
                                                                                            andCustomReference:customRef
                                                                                            andIsCompleted:false
                                                                                            andIsCardAVSRequested:avsCheckBox.isSelected
                                                                                            andIsCardCVVRequested:cvvCheckBox.isSelected
                                                                                            andUCIFormat:UCIFormatIngenico
                                                                                            andIsCardPresent:cardPresentCheckBox.isSelected
                                                                                            andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil
                                                                                            andTokenRequestParameters:tokenRequestParams];
                [storedTransactionRequest setCustomData:@"Custom data"];
                return storedTransactionRequest;
            }
        }
        case TransactionTypeCreditAuth:
        {
                IMSStoreAndForwardCreditAuthTransactionRequest* storedCreditAuthTransactionRequest =  [[IMSStoreAndForwardCreditAuthTransactionRequest alloc]
                                                                                                       initWithAmount:amount
                                                                                                       andProducts:products
                                                                                                       andClerkID:clerkID
                                                                                                       andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
                                                                                                       andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
                                                                                                       andTransactionGroupID:nil
                                                                                                       andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
                                                                                                       andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil
                                                                                                       andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
                                                                                                       andCustomReference:customRef
                                                                                                       andIsCompleted:false
                                                                                                       andUCIformat:UCIFormatIngenico
                                                                                                       andOrderNumber:orderNumberTF.text?orderNumberTF.text:nil
                                                                                                       andTokenRequestParameters:tokenRequestParams
                                                                                                       andValidateCardExpirationDate:validateExpirationDateCheckbox.isSelected];
                [storedCreditAuthTransactionRequest setCustomData:@"Custom data"];
                return storedCreditAuthTransactionRequest;
        }
		case TransactionTypeCashSale:
		{
			IMSStoreAndForwardCashSaleTransactionRequest* storedCashSaleTransactionRequest =  [[IMSStoreAndForwardCashSaleTransactionRequest alloc]
																								   initWithAmount:amount
																								   andProducts:products
																								   andClerkID:clerkID
																								   andLongitude:[(TabBarViewController *)self.parentViewController getLongitude]
																								   andLatitude:[(TabBarViewController *)self.parentViewController getLatitude]
																								   andTransactionGroupID:nil
																								   andTransactionNotes:transactionNoteTF.text?transactionNoteTF.text:nil
																								   andMerchantInvoiceID:invocieIDTF.text?invocieIDTF.text:nil
																								   andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox.isSelected
																								   andCustomReference:customRef
																								   andIsCompleted:false];
			[storedCashSaleTransactionRequest setCustomData:@"Custom data"];
			return storedCashSaleTransactionRequest;
		}
        default:
            return nil;
    }
}


- (void)updateStoredTransaction{
    alertMessageTitle = @"Update Stored Transaction";
    
    __block UITextField *origTxnIdTF;
    __block UITextField *firstNameTF;
    __block UITextField *lastNameTF;
    __block UITextField *middleNameTF;
    __block UITextField *emailTF;
    __block UITextField *phoneTF;
    __block UITextField *address1TF;
    __block UITextField *address2TF;
    __block UITextField *cityTF;
    __block UITextField *stateTF;
    __block UITextField *postalCodeTF;
    __block UITextField *transactionNoteTF;
    __block UIButton *displayNotesCB;
    __block UIButton *signatureCB;
    __block UIButton *isCompleteCB;
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:alertMessageTitle message:@"Enter the following:" preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = @"Original Transaction Id";
        textField.text = [self getLastClientTransactionID];
        textField.accessibilityLabel = @"vc_snfapi_original_transaction_id";
        origTxnIdTF = textField;
    }];
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = @"First name";
        textField.accessibilityLabel = @"vc_snfapi_first_name";
        firstNameTF = textField;
    }];
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = @"Last name";
        textField.accessibilityLabel = @"vc_snfapi_last_name";
        lastNameTF = textField;
    }];
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = @"Middle name";
        textField.accessibilityLabel = @"vc_snfapi_middle_name";
        middleNameTF = textField;
    }];
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = @"Email";
        textField.accessibilityLabel = @"vc_snfapi_email";
        emailTF = textField;
    }];
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = @"Phone";
        textField.accessibilityLabel = @"vc_snfapi_phone";
        phoneTF = textField;
    }];
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = @"Address 1";
        textField.accessibilityLabel = @"vc_snfapi_address_1";
        address1TF = textField;
    }];
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = @"Address 2";
        textField.accessibilityLabel = @"vc_snfapi_address_2";
        address2TF = textField;
    }];
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = @"City";
        textField.accessibilityLabel = @"vc_snfapi_city";
        cityTF = textField;
    }];
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = @"State";
        textField.accessibilityLabel = @"vc_snfapi_state";
        stateTF = textField;
    }];
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = @"Postal code";
        textField.accessibilityLabel = @"vc_snfapi_postal_code";
        postalCodeTF = textField;
    }];
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = @"Transaction Note";
        textField.accessibilityLabel = @"vc_snfapi_transaction_note";
        transactionNoteTF = textField;
    }];
    [alert addCheckBoxWithTitle:@"Include signature" andConfigurationHandler:^(UIButton * _Nonnull checkBox) {
        checkBox.accessibilityLabel = @"vc_snfapi_signature_cb";
        signatureCB = checkBox;
    }];
    [alert addCheckBoxWithTitle:@"Display Notes And Invoice" andConfigurationHandler:^(UIButton * _Nonnull checkBox) {
        checkBox.accessibilityLabel = @"vc_snfapi_show_note_cb";
        displayNotesCB = checkBox;
    }];
    [alert addCheckBoxWithTitle:@"Is Complete" andConfigurationHandler:^(UIButton * _Nonnull checkBox) {
        checkBox.accessibilityLabel = @"vc_snfapi_is_complete_cb";
        isCompleteCB = checkBox;
    }];
    UIAlertAction *ok = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self showProgressMessage:@"Processing Transaction" andIsTransactionStoppable:NO];
        IMSCardholderInfo *cardholderInfo =  [[IMSCardholderInfo alloc] initWithFirstName:firstNameTF.text
                                                                              andLastName:lastNameTF.text
                                                                            andMiddleName:middleNameTF.text
                                                                                 andEmail:emailTF.text
                                                                                 andPhone:phoneTF.text
                                                                              andAddress1:address1TF.text
                                                                              andAddress2:address2TF.text
                                                                                  andCity:cityTF.text
                                                                                 andState:stateTF.text
                                                                            andPostalCode:postalCodeTF.text];
        UIImage *image = signatureCB.selected ? [UIImage imageNamed:@"signature.png"] : nil;
        [[Ingenico sharedInstance].StoreAndForward updateStoredTransactionWithClientTransactionID:origTxnIdTF.text andCardholderInfo:cardholderInfo andTransactionNote:transactionNoteTF.text andIsCompleted:isCompleteCB.selected andDisplayNotesAndInvoice:displayNotesCB.selected andSignatureImage:[IMSUtil encodedImageToBase64String:image withImageFormat:ImageFormatPNG] andOnDone:^(NSError * _Nullable error) {
            [self dismissProgress];
            if(error == nil){
                [LogHelper.sharedInstance consoleLog:@"Update Stored Transaction success"];
            }else{
                [LogHelper.sharedInstance consoleLog:[NSString stringWithFormat:@"Update Stored Transaction failed with error: %ld", (long)error.code]];
            }
        }];
    }];
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
    [alert addAction:ok];
    [alert addAction:cancel];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)getAllStoredTransactions:(BOOL)includeGroupTransactions{
    alertMessageTitle = @"Get All Stored Transaction";
    [[Ingenico sharedInstance].StoreAndForward getStoredTransactions:YES
                                         andIncludeGroupTransactions:includeGroupTransactions
                                                           andOnDone:^(NSArray* storedTransactionSummaryList, int totalMatches, NSError* error){
        [self dismissProgress];
        if (error == nil) {
            NSMutableString* storedData = [NSMutableString string];
            if (totalMatches == 0) {
                [storedData appendString:@"No Stored Transactions"];
            }else{
                [storedData appendString:[NSString stringWithFormat:@"Response Code : %@\n", [self getResponseCodeString:error.code]]];
                [storedData appendString:[NSString stringWithFormat:@"Total Matches : %d\n",totalMatches]];
                for (int i=0; i<[storedTransactionSummaryList count]; i++) {
                    IMSStoredTransactionSummary* storedTransactionSummary = storedTransactionSummaryList[i];
                    [LogHelper.sharedInstance consoleLog:[NSString stringWithFormat:@"Printing Stored transaction %d of %d\n", i+1, (int)[storedTransactionSummaryList count]]];
                    [LogHelper.sharedInstance consoleLog:storedTransactionSummary.description];
                    [storedData appendString:[NSString stringWithFormat:@"ClientTransactionID: %@%@ \n",
                                              storedTransactionSummary.hasStoredVoid ? @"(void) " : @"",
                                              storedTransactionSummary.clientTransactionID]];
                    [self setLastClientTransactionID:((IMSStoredTransactionSummary*)storedTransactionSummaryList[[storedTransactionSummaryList count] - 1]).clientTransactionID];
                }
            }
            [LogHelper.sharedInstance consoleLog:storedData];
            [self showAlertWithTitle:alertMessageTitle andMessage:storedData andHandler:nil];
            
        }else{
            [LogHelper.sharedInstance consoleLog:[NSString stringWithFormat:@"Get Stored transactions failed with error: %ld", (long)error.code]];
        }
    }];
}

-(void)uploadAllStoredTransactions:(BOOL)includeGroupTransactions{
    __weak typeof(self) weakSelf = self;
    [[[Ingenico sharedInstance] StoreAndForward] getStoredTransactions:YES
                                           andIncludeGroupTransactions:includeGroupTransactions
                                                             andOnDone:^(NSArray * _Nullable transactions, int totalMatches, NSError * _Nullable error) {
        if(error == nil){
            [self setLastClientTransactionID:nil];
            if(totalMatches == 0){
                [weakSelf dismissProgress];
                [weakSelf showAlertWithTitle:@"Upload All Stored Transactions" andMessage:@"No stored transactions" andHandler:nil];
                [LogHelper.sharedInstance consoleLog:@"No Stored Transactions"];
            }else{
                successfulUploadedCount = 0;
                declinedTransactionCount = 0;
                [weakSelf uploadStoredTransactionFromIndex:0 ofArray:transactions];
                [LogHelper.sharedInstance consoleLog:@"Uploading transactions"];
            }
        }else{
            [weakSelf dismissProgress];
            [weakSelf showAlertWithTitle:@"Upload All Stored Transactions" andMessage:[NSString stringWithFormat:@"Get Stored transactions API failed with error: %ld", (long)error.code] andHandler:nil];
            [LogHelper.sharedInstance consoleLog:[NSString stringWithFormat:@"Get Stored transactions API failed with error: %ld", (long)error.code]];
        }
    }];
}

-(void)uploadStoredTransactionFromIndex:(NSInteger)index ofArray:(NSArray*)storedTransactionsArray{
    __weak typeof(self) weakSelf = self;
    if(index == [storedTransactionsArray count] ){
        [weakSelf dismissProgress];
        NSMutableString *dialogMsg = [NSMutableString stringWithFormat:@"Uploaded transaction count = %ld", (long)successfulUploadedCount];
        if (declinedTransactionCount > 0) {
            [dialogMsg appendString:[NSString stringWithFormat:@"\n Declined transaction count = %ld", (long)declinedTransactionCount]];
        }
        [LogHelper.sharedInstance consoleLog:dialogMsg];
        [weakSelf showAlertWithTitle:@"Upload All Stored Transactions" andMessage:dialogMsg andHandler:nil];
    }else{
        [weakSelf showProgressMessage:[NSString stringWithFormat:@"Uploading %ld/%ld", (long)index+1, (unsigned long)[storedTransactionsArray count]] andIsTransactionStoppable:NO];
        [LogHelper.sharedInstance consoleLog:[NSString stringWithFormat:@"Uploading %ld/%ld", (long)index+1, (unsigned long)[storedTransactionsArray count]]];
        IMSStoredTransactionSummary* currentUploadRequest = storedTransactionsArray[index];
        [[[Ingenico sharedInstance] StoreAndForward] uploadStoredTransaction:[currentUploadRequest clientTransactionID] andUpdateProgress:^(IMSProgressMessage progressMessage, NSString * _Nullable extraMessage) {
            [LogHelper.sharedInstance consoleLog:[NSString stringWithFormat:@"Progress message: %@ extra message: %@",[self getProgressStrFromMessage:progressMessage], extraMessage]];
        } andOnDone:^(IMSTransactionResponse * _Nullable response, NSError * _Nullable error) {
            if(error == nil){
                [LogHelper.sharedInstance consoleLog:[NSString stringWithFormat:@"Successfully Uploaded transaction at index: %ld",(long)index]];
                successfulUploadedCount++;
                [weakSelf setLastTransactionID:response.transactionID];
                if([response.tokenResponseParameters.tokenIdentifier length] > 0) {
                    [weakSelf setLastTokenId:response.tokenResponseParameters.tokenIdentifier];
                }
            }else{
                [LogHelper.sharedInstance consoleLog:[NSString stringWithFormat:@"Uploaded transaction at index: %ld failed with error %ld",(long)index, (long)error.code]];
                declinedTransactionCount++;
            }
            [weakSelf uploadStoredTransactionFromIndex:index+1 ofArray:storedTransactionsArray];
        }];
    }
}

- (NSString *)getStrFromCVM:(IMSCardVerificationMethod)cvm{
    switch (cvm) {
        case CardVerificationMethodPin:
            return @"Pin";
        case CardVerificationMethodSignature:
            return @"Signature";
        case CardVerificationMethodPinAndSignature:
            return @"PinAndSignature";
        case CardVerificationMethodNone:
        default:
            return @"None";
    }
}

- (NSString *)getStrFromPOSEntryMode:(IMSPOSEntryMode)entryMode{
    switch (entryMode) {
        case POSEntryModeKeyed:
            return @"Keyed";
        case POSEntryModeContactEMV:
            return @"ContactEMV";
        case POSEntryModeContactlessEMV:
            return @"ContactlessEMV";
        case POSEntryModeContactlessMSR:
            return @"ContactlessMSR";
        case POSEntryModeMagStripe:
            return @"MagStripe";
        case POSEntryModeMagStripeEMVFail:
            return @"MagStripeEMVFail";
        case POSEntryModeVirtualTerminal:
            return @"VirtualTerminal";
        case POSEntryModeKeyedSwipeFail:
            return @"KeyedSwipeFail";
        case POSEntryModeUnKnown:
        default:
            return @"Unknown";
    }
}

- (NSString *)getStrFromTokenResponseCode:(IMSTokenResponseCode)code{
    switch (code) {
        case IMSTokenResponseCodeApproved:
            return @"Approved";
        case IMSTokenResponseCodeDeclined:
            return @"Token not requested because the transaction authorization was declined";
        case IMSTokenResponseCodeError:
            return @"Service provider error. See TokenSourceData for details.";
        case IMSTokenResponseCodeCommunicationError:
            return @"Error connecting to the tokenization service provider.";
        default:
            return @"Unknown";
    }
}


- (void)showErrorMessage:(NSString *)errorMessage andErrorTitle:(NSString *)errorTitle{
    [self dismissProgress];
    UIAlertController *controller = [UIAlertController alertControllerWithTitle:errorTitle message:errorMessage preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
    [controller addAction:action];
    [self presentViewController:controller animated:YES completion:nil];
}

- (void)showAlertWithTitle:(NSString *)title andMessage:(NSString *)message andHandler:(void (^)(UIAlertAction *action))handler{
    UIAlertController *controller = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:handler];
    [controller addAction:action];
    [self presentViewController:controller animated:YES completion:nil];
}

- (NSString *)getProgressStrFromMessage:(IMSProgressMessage)message{
    switch (message) {
        case PleaseInsertCard: {
            NSArray *allowedPOS = [[Ingenico sharedInstance].PaymentDevice allowedPOSEntryModes];
            if([allowedPOS containsObject:[NSNumber numberWithInteger:POSEntryModeContactlessMSR]] ||
               [allowedPOS containsObject:[NSNumber numberWithInteger:POSEntryModeContactlessEMV]]){
                if([allowedPOS containsObject:[NSNumber numberWithInteger:POSEntryModeContactEMV]]){
                    return @"Please insert/tap/swipe card";
                } else {
                    return @"Please tap or swipe card";
                }
            }
            else {
                return @"Please insert or swipe card";
            }
        }
        case CardInserted:
            return @"Card inserted";
        case ICCErrorSwipeCard:
            return @"ICCError swipe card please";
        case ApplicationSelectionStarted:
            return @"Application selection started";
        case ApplicationSelectionCompleted:
            return @"Application selection completed";
        case FirstPinEntryPrompt:
            return @"First Pin prompt";
        case LastPinEntryPrompt:
            return @"Last Pin prompt";
        case PinEntryFailed:
            return @"Pin entry failed";
        case PinEntryInProgress:
            return @"Pin entry in progress";
        case PinEntrySuccessful:
            return @"Pin entry in progress";
        case RetrytPinEntryPrompt:
            return @"Retry Pin entry prompt";
        case WaitingforCardSwipe:
            return @"Waiting for card swipe";
        case PleaseSeePhone:
            return @"Please see phone";
        case SwipeDetected:
            return @"Swipe detected";
        case SwipeErrorReswipeMagStripe:
            return @"Reswipe please";
        case TapDetected:
            return @"Tap detected";
        case UseContactInterfaceInsteadOfContactless:
            return @"Use contact interface instead of contactless";
        case ErrorReadingContactlessCard:
            return @"Error reading contactless card";
        case DeviceBusy:
            return @"Device busy";
        case CardHolderPressedCancelKey:
            return @"Cancel key pressed";
        case RecordingTransaction:
            return @"Recording transaction";
        case UpdatingTransaction:
            return @"Updating transaction";
        case PleaseRemoveCard:
            return @"Please remove card";
        case RestartingContactlessInterface:
            return @"Restarting contactless interface";
        case GettingOnlineAuthorization:
            return @"Getting Online Authorization";
        case TryContactInterface:
            return @"Try contact interface";
        case MultipleContactlessCardsDetected:
            return @"Please present one card only";
        case PresentCardAgain:
            return @"Please present card again";
        case CardRemoved:
            return @"Card Removed";
        case Unknown:
        default:
            return nil;
    }
}

- (NSArray *)getSampleProducts:(NSInteger)totalAmount {
    return [[NSArray alloc]
            initWithObjects:
            [[IMSProduct alloc]
             initWithName:@"product"
             andPrice:totalAmount
             andNote:@"test product"
             andImage:[IMSUtil encodedImageToBase64String:[UIImage imageNamed:@"product_image.png"] withImageFormat:ImageFormatPNG]
             andQuantity:1],
            nil];
}

- (void)doTokenEnrollment{
    [self showClerkAlertControllerWithIsManualKeyed:false];
}
     
- (void)doKeyedTokenEnrollment{
    [self showClerkAlertControllerWithIsManualKeyed:true];
}

- (void)showClerkAlertControllerWithIsManualKeyed:(Boolean) isManualKeyed{
    UIAlertController *alertController = [UIAlertController
                                         alertControllerWithTitle:@"Information"
                                         message:@"Provide transaction info"
                                         preferredStyle:UIAlertControllerStyleAlert];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeDefault;
        textField.placeholder = @"ClerkID(Optional)";
        textField.accessibilityLabel = @"vc_snfapi_clerk_id";
        clerkIDTF = textField;
    }];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeNumberPad;
        textField.placeholder = @"Order Number(Optional)";
        textField.accessibilityLabel = @"vc_snfapi_order_number";
        orderNumberTF = textField;
    }];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeNumberPad;
        textField.placeholder = @"Normalized Token Fee(Optional)";
        textField.accessibilityLabel = @"vc_snfapi_token_fee";
        tokenFeeTF = textField;
    }];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeDefault;
        textField.placeholder = @"Token Identifier(Optional)";
        textField.accessibilityLabel = @"vc_snfapi_token_id";
        tokenIdentifierTF = textField;
        tokenIdentifierTF.text = [self getLastTokenId];
    }];
    if (!isManualKeyed) {
        [alertController addCheckBoxWithTitle:@"Validate Expiry Date" andConfigurationHandler:^(UIButton * _Nonnull checkBox) {
            [checkBox setSelected:YES];
            checkBox.accessibilityLabel = @"vc_snfapi_validate_expiry_date_cb";
            validateExpirationDateCheckbox = checkBox;
        }];
    }
    if (isManualKeyed) {
        [alertController addCheckBoxWithTitle:@"Request CVV" andConfigurationHandler:^(UIButton * _Nonnull checkBox) {
            [checkBox setSelected:YES];
            cvvCheckBox = checkBox;
        }];
        [alertController addCheckBoxWithTitle:@"Request AVS" andConfigurationHandler:^(UIButton * _Nonnull checkBox) {
            [checkBox setSelected:NO];
            avsCheckBox = checkBox;
        }];
        [alertController addCheckBoxWithTitle:@"Card Present" andConfigurationHandler:^(UIButton * _Nonnull checkBox) {
            [checkBox setSelected:NO];
            cardPresentCheckBox = checkBox;
        }];
    }
    [alertController addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        IMSTokenRequestParametersBuilder *tokenRequestParamBuilder = [self getTokenRequestParametersBuilder];
        tokenRequestParamBuilder.tokenFeeInCents = [tokenFeeTF.text length]>0?[tokenFeeTF.text integerValue]:0;
        tokenRequestParamBuilder.tokenIdentifier = [tokenIdentifierTF.text length]>0?tokenIdentifierTF.text:nil;
        NSString *clerkId = [clerkIDTF.text length]>0?clerkIDTF.text:nil;
        NSString *orderNumber = [orderNumberTF.text length]>0?orderNumberTF.text:nil;
        IMSTokenRequestParameters *tokenRequestParams = [tokenIdentifierTF.text length] > 0 ?
                                                        tokenRequestParamBuilder.createTokenUpdateRequestParameters :
                                                        tokenRequestParamBuilder.createTokenEnrollmentRequestParameters;
        if(isManualKeyed) {
            IMSStoreAndForwardKeyedTokenEnrollmentTransactionRequest* keyedTokenEnrollmentRequest = [[IMSStoreAndForwardKeyedTokenEnrollmentTransactionRequest alloc] initWithTokenRequestParameters:tokenRequestParams andClerkID:clerkId andLongitude:nil andLatitude:nil andUCIFormat:UCIFormatUnknown andOrderNumber:orderNumber andIsCardAVSRequested:avsCheckBox.isSelected andIsCardCVVRequested:cvvCheckBox.isSelected andIsCardPresent:cardPresentCheckBox.isSelected];
            [[Ingenico sharedInstance].StoreAndForward processStoreAndForwardKeyedTokenEnrollmentWithCardReader:keyedTokenEnrollmentRequest andUpdateProgress:progressCallback andOnDone:doneCallback];
        }
        else {
            IMSStoreAndForwardTokenEnrollmentTransactionRequest* tokenEnrollmentRequest = [[IMSStoreAndForwardTokenEnrollmentTransactionRequest alloc] initWithTokenRequestParameters:tokenRequestParams andClerkID:clerkId andLongitude:nil andLatitude:nil andUCIFormat:UCIFormatUnknown andOrderNumber:orderNumber andValidateCardExpirationDate:validateExpirationDateCheckbox.isSelected];
            if (emvSnF) {
                emvSnF = NO;
                [[Ingenico sharedInstance].StoreAndForward processEmvStoreAndForwardTokenEnrollmentWithCardReader:tokenEnrollmentRequest andUpdateProgress:progressCallback andSelectApplication:applicationSelectionCallback andOnDone:doneCallback];
            }
            else {
               [[Ingenico sharedInstance].StoreAndForward processStoreAndForwardTokenEnrollmentWithCardReader:tokenEnrollmentRequest andUpdateProgress:progressCallback andOnDone:doneCallback];
            }
        }
        clerkIDTF = nil;
        orderNumberTF = nil;
        tokenFeeTF = nil;
        tokenIdentifierTF = nil;
        validateExpirationDateCheckbox = nil;
    }]];
    [self presentViewController:alertController animated:YES completion:nil];
}
     
- (IMSTokenRequestParametersBuilder *)getTokenRequestParametersBuilder{
    IMSTokenRequestParametersBuilder *builder = [[IMSTokenRequestParametersBuilder alloc] init];
        builder.tokenReferenceNumber = @"test-123";
        builder.cardholderLastName = @"Data";
        builder.cardholderFirstName = @"Roam";
        builder.billToEmail = @"roam@roamdata.com";
        builder.billToAddress1 = @"1 Federal St";
        builder.billToAddress2 = @"Suite 1";
        builder.billToCity = @"Boston";
        builder.billToState = @"MA";
        builder.billToCountry = @"USA";
        builder.billToZip = @"02110";
    return builder;
}

-(void)checkboxSelected:(UIButton*)sender {
    if(sender == tokenEnrollmentCheckbox){
        [tokenUpdateCheckbox setSelected:NO];
    }
    else if(sender == tokenUpdateCheckbox){
        [tokenEnrollmentCheckbox setSelected:NO];
    }
}

- (void)promptForDeleteStoredTransactionWithClientTxnId{
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        [[Ingenico sharedInstance].StoreAndForward deleteStoredTransactionWithClientTransactionID:clientTransactionIdTF.text andOnDone:^(NSError * _Nullable error) {
            [self dismissProgress];
            if (error == nil) {
                [LogHelper.sharedInstance consoleLog:[NSString stringWithFormat:@"Deletion success for client transactino ID: %@", clientTransactionIdTF.text]];
                [self showAlertWithTitle:alertMessageTitle andMessage:@"Deletion success" andHandler:nil];
            }else{
                [LogHelper.sharedInstance consoleLog:[NSString stringWithFormat:@"Deletion failed for client transactino ID: %@ with error: %ld", clientTransactionIdTF.text, error.code]];
            }
        }];
    }];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
    UIAlertController *alertController = [UIAlertController
                                         alertControllerWithTitle:@"Please provide the client transaction id"
                                         message:nil
                                         preferredStyle:UIAlertControllerStyleAlert];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeDefault;
        textField.placeholder = @"client transaction id";
        clientTransactionIdTF = textField;
    }];
    [alertController addAction:okAction];
    [alertController addAction:cancelAction];
    [self presentViewController:alertController animated:YES completion:nil];
}

@end
