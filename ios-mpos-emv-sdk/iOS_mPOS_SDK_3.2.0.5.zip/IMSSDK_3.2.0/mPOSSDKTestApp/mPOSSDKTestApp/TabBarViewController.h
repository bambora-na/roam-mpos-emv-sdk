//
//  PaymentDeviceViewController.h
//  mPOSSDKTestApp
//
//  Copyright © 2016 RoamData. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TabBarViewController : UITabBarController

- (void)deviceStatusUpdated;

- (NSString *)getLongitude;

- (NSString *)getLatitude;

-(void)setCurrentVisibleChildViewController:(IMSBaseViewController*)childViewController;
@end
