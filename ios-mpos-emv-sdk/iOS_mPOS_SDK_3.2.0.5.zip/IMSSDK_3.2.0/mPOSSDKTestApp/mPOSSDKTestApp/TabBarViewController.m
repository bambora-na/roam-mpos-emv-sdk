//
//  PaymentDeviceViewController.h
//  mPOSSDKTestApp
//
//  Copyright © 2016 RoamData. All rights reserved.
//

#import "PaymentAPIViewController.h"
#import "TabBarViewController.h"
#import <CoreLocation/CoreLocation.h>

@interface TabBarViewController ()<CLLocationManagerDelegate>{
    CLLocationManager *_locm;
    CLLocation *_location;
    IMSBaseViewController* currentVisibleChildViewController;
}

@property (strong, nonatomic) UILabel *navigationLabel;

@end

@implementation TabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _navigationLabel = [[UILabel alloc] initWithFrame: CGRectMake(0, 0,200, 40)];
    _navigationLabel.textAlignment = NSTextAlignmentCenter;
    _navigationLabel.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    _navigationLabel.tintColor = [UIColor blackColor];
    self.navigationItem.titleView = _navigationLabel;
    self.navigationItem.hidesBackButton = YES;
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Show Log" style:UIBarButtonItemStylePlain target:self action:@selector(goNext:)];
    [self.navigationItem.leftBarButtonItem setTitleTextAttributes:@{
                                                                     NSFontAttributeName: [UIFont fontWithName:@"TrebuchetMS-Bold" size:16.0],
                                                                     NSForegroundColorAttributeName: [UIColor darkGrayColor]
                                                                     } forState:UIControlStateNormal];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"logout"] style:UIBarButtonItemStylePlain target:self action:@selector(logout)];
    self.navigationItem.rightBarButtonItem.tintColor = [UIColor darkGrayColor];
    [self.navigationItem.rightBarButtonItem setAccessibilityLabel:@"logout_btn"];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self updateNavigationBar];
    if ([CLLocationManager authorizationStatus] == kCLAuthorizationStatusDenied ||
        [CLLocationManager authorizationStatus] == kCLAuthorizationStatusRestricted) {
        return;
    }

    if (_locm == nil) {
        _locm = [[CLLocationManager alloc] init];
        _locm.delegate = self;
    }

    if ([_locm respondsToSelector:@selector(pausesLocationUpdatesAutomatically)]) {
        _locm.pausesLocationUpdatesAutomatically = NO;
    }
    if([[[UIDevice currentDevice] systemVersion] intValue] >= 8){
        if ([_locm respondsToSelector:@selector(requestWhenInUseAuthorization)])
        {
            [_locm requestWhenInUseAuthorization];
        }
    }
    [_locm startUpdatingLocation];
}


-(void)logout{
    [currentVisibleChildViewController doLogoff];
}


- (IBAction)goNext:(id)sender{
    if([self.navigationItem.leftBarButtonItem.title isEqualToString:@"Show Log"]){
        [self performSegueWithIdentifier:@"show_log" sender:self];
    }
}

- (void)deviceStatusUpdated{
    [self updateNavigationBar];
}

- (void)updateNavigationBar{
    NSTextAttachment *_deviceStatusIcon = [[NSTextAttachment alloc] init];
    _deviceStatusIcon.image = [(PaymentAPIViewController *)[self.childViewControllers objectAtIndex:0] getDeviceStatusIcon];
    _deviceStatusIcon.bounds = CGRectMake(10, -6.5, 25, 25);
    NSAttributedString *_imageStr = [NSAttributedString attributedStringWithAttachment:_deviceStatusIcon];
    NSMutableAttributedString * mutableAttriStr = [[NSMutableAttributedString alloc] initWithString:@"mPOS EMV SDK"];
    [mutableAttriStr addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"HelveticaNeue" size:16] range:NSMakeRange(0, mutableAttriStr.length)];
    [mutableAttriStr appendAttributedString:_imageStr];
    self.navigationLabel.attributedText = mutableAttriStr;
}

- (NSString *)getLongitude{
    if(_location){
        return [[NSString alloc] initWithFormat:@"%f",_location.coordinate.longitude];
    }
    else{
        return nil;
    }
}

- (NSString *)getLatitude{
    if(_location){
        return [[NSString alloc] initWithFormat:@"%f",_location.coordinate.latitude];
    }
    else{
        return nil;
    }
}

#pragma mark - CLLocationManager Methods
- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
#ifdef DEBUG
    NSLog(@"Failed to get current location: %@", error);
#endif
    _location = nil;
    manager.delegate = nil;
    [manager stopUpdatingLocation];
}

- (void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status {
    if (status == kCLAuthorizationStatusDenied || status == kCLAuthorizationStatusRestricted) {
#ifdef DEBUG
        NSLog(@"Location services denied");
#endif
        _location = nil;
        manager.delegate = nil;
        [manager stopUpdatingLocation];
    }
}

- (void)locationManager:(CLLocationManager *)manager didFinishDeferredUpdatesWithError:(NSError *)error {
#ifdef DEBUG
    NSLog(@"Deferred updates failed with error %@", error);
#endif
    _location = nil;
    manager.delegate = nil;
    [manager stopUpdatingLocation];
}

- (void)locationManager:(CLLocationManager *)manager
    didUpdateToLocation:(CLLocation *)newLocation
           fromLocation:(CLLocation *)oldLocation {
    NSTimeInterval lastUpdateInterval = [[NSDate date] timeIntervalSinceDate:newLocation.timestamp];
    if (lastUpdateInterval > 60) {
        return;
    }
    _location = newLocation;
    manager.delegate = nil;
    [manager stopUpdatingLocation];
}

- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations {
    NSTimeInterval lastUpdateInterval = [[NSDate date] timeIntervalSinceDate:manager.location.timestamp];

    if (lastUpdateInterval > 60) {
        return;
    }
    _location = manager.location;
    manager.delegate = nil;
    [manager stopUpdatingLocation];
}
-(void)setCurrentVisibleChildViewController:(IMSBaseViewController*)childViewController{
    currentVisibleChildViewController = childViewController;
}

@end
