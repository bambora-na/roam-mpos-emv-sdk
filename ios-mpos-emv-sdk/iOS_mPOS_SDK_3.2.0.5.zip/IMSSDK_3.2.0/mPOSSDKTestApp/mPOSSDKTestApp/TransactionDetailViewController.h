//
//  TransactionDetailViewController.h
//  mPOSSDKTestApp
//
//  Created by Bin Lang on 8/9/17.
//  Copyright © 2017 RoamData. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IMSBaseViewController.h"

@interface TransactionDetailViewController : IMSBaseViewController

@property (weak, nonatomic) IBOutlet UITableView *transactionDetailTableView;
@property (nonatomic) IMSTransactionHistoryDetail *transactionDetail;
@end
