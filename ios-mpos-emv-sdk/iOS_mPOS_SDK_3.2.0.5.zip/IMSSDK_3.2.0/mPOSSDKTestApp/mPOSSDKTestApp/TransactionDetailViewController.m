//
//  TransactionDetailViewController.m
//  mPOSSDKTestApp
//
//  Created by Bin Lang on 8/9/17.
//  Copyright © 2017 RoamData. All rights reserved.
//

#import "TransactionDetailViewController.h"

@interface TransactionDetailViewController (){
    NSMutableArray *sectionTitle;
}

@end

@implementation TransactionDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    sectionTitle = [[NSMutableArray alloc] init];
    [sectionTitle addObject:@"TransactionInfo"];
    if(_transactionDetail.amount){
        [sectionTitle addObject:@"AmountInfo"];
    }
    if(_transactionDetail.cardholderInfo){
        [sectionTitle addObject:@"CardHolderInfo"];
    }
    if(_transactionDetail.tokenResponse){
        [sectionTitle addObject:@"TokenResponse"];
    }
    if(_transactionDetail.emvData){
        [sectionTitle addObject:@"EmvData"];
    }
    _transactionDetailTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"Goback"] style:UIBarButtonItemStylePlain target:self action:@selector(goBack:)];
    [self.navigationItem.leftBarButtonItem setAccessibilityLabel:@"back_btn"];
    self.navigationItem.leftBarButtonItem.tintColor = [UIColor darkGrayColor];
}

- (IBAction)goBack:(id)sender{
    [self.navigationController popViewControllerAnimated:NO];
}

#pragma UITableViewDelegate,UITableViewDataSource Implementation

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.bounds.size.width, 35)];
    UILabel *sectionLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 0, tableView.bounds.size.width-20, 35)];
    if(section<sectionTitle.count){
        sectionLabel.text = [sectionTitle objectAtIndex:section];
    }
    else{
        sectionLabel.text = [[NSString alloc] initWithFormat:@"Product(%lu)",section-sectionTitle.count+1];
    }
    sectionLabel.font = [UIFont fontWithName:@"Palatino-Italic" size:16];
    [headerView setBackgroundColor:[UIColor lightGrayColor]];
    [headerView addSubview:sectionLabel];
    return headerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 30;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return sectionTitle.count+_transactionDetail.products.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(section < sectionTitle.count){
        if([[sectionTitle objectAtIndex:section] isEqualToString:@"TransactionInfo"]){
            return 35;
        }
        else if([[sectionTitle objectAtIndex:section] isEqualToString:@"AmountInfo"]){
            return 8;
        }
        else if([[sectionTitle objectAtIndex:section] isEqualToString:@"CardHolderInfo"]){
            return 10;
        }
        else if([[sectionTitle objectAtIndex:section] isEqualToString:@"TokenResponse"]){
            return 5;
        }
        else if([[sectionTitle objectAtIndex:section] isEqualToString:@"EmvData"]){
            if(_transactionDetail.emvData.emvOfflineData){
                return 33;
            }
            else{
                return 5;
            }
        }
    }
    else {
        return 4;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"detailCell"];
    if(cell == nil){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"detailCell"];
    }
    cell.detailTextLabel.textColor = [UIColor grayColor];
    if(indexPath.section == 0){
        if(indexPath.row == 0){
            cell.textLabel.text = @"Type:";
            cell.detailTextLabel.text = [self getStringFromTransactionType:_transactionDetail.transactionType];
        }
        else if(indexPath.row == 1){
            cell.textLabel.text = @"POSEntryMode:";
            cell.detailTextLabel.text = [self getStringFromPOSEntryMode:_transactionDetail.posEntryMode];
        }
        else if(indexPath.row == 2){
            cell.textLabel.text = @"ResponseCode:";
            cell.detailTextLabel.text = [self getStringFromTransactionResponseCode:_transactionDetail.transactionResponseCode];
        }
        else if(indexPath.row == 3){
            cell.textLabel.text = @"Status:";
            cell.detailTextLabel.text = [self getStringFromTransactionStatus:_transactionDetail.transactionStatus];
        }
        else if(indexPath.row == 4){
            cell.textLabel.text = @"CardVerificationMethod:";
            cell.detailTextLabel.text = [self getStringFromCardVerificationMethod:_transactionDetail.cardverificationMethod];
        }
        else if(indexPath.row == 5){
            cell.textLabel.text = @"AuthCode:";
            cell.detailTextLabel.text = _transactionDetail.authCode;
        }
        else if(indexPath.row == 6){
            cell.textLabel.text = @"TransactionID:";
            cell.detailTextLabel.text = _transactionDetail.transactionId;
        }
        else if(indexPath.row == 7){
            cell.textLabel.text = @"TransactionGUID:";
            cell.detailTextLabel.text = _transactionDetail.transactionGUID;
        }
        else if(indexPath.row == 8){
            cell.textLabel.text = @"ClientTransactionID:";
            cell.detailTextLabel.text = _transactionDetail.clientTransactionId;
        }
        else if(indexPath.row == 9){
            cell.textLabel.text = @"originalTransactionID:";
            cell.detailTextLabel.text = _transactionDetail.originalTransactionId;
        }
        else if(indexPath.row == 10){
            cell.textLabel.text = @"ProcessorTimeStamp:";
            cell.detailTextLabel.text = _transactionDetail.processorTimestamp;
        }
        else if(indexPath.row == 11){
            cell.textLabel.text = @"ProcessorTimezone:";
            cell.detailTextLabel.text = _transactionDetail.processorTimezone;
        }
        else if(indexPath.row == 12){
            cell.textLabel.text = @"DeviceTimeStamp:";
            cell.detailTextLabel.text = _transactionDetail.deviceTimestamp;
        }
        else if(indexPath.row == 13){
            cell.textLabel.text = @"DeviceTimezone:";
            cell.detailTextLabel.text = _transactionDetail.deviceTimezone;
        }
        else if(indexPath.row == 14){
            cell.textLabel.text = @"PaymentServiceTimestamp:";
            cell.detailTextLabel.text = _transactionDetail.paymentServiceTimestamp;
        }
        else if(indexPath.row == 15){
            cell.textLabel.text = @"PaymentServiceTimezone:";
            cell.detailTextLabel.text = _transactionDetail.paymentServiceTimezone;
        }
        else if(indexPath.row == 16){
            cell.textLabel.text = @"ApprovedAmount:";
            cell.detailTextLabel.text = [[NSString alloc] initWithFormat:@"%ld",(long)_transactionDetail.approvedAmount];
        }
        else if(indexPath.row == 17){
            cell.textLabel.text = @"ClerkID:";
            cell.detailTextLabel.text = _transactionDetail.clerkId;
        }
        else if(indexPath.row == 18){
            cell.textLabel.text = @"CardType:";
            cell.detailTextLabel.text = [self getStringFromCardType:_transactionDetail.cardType];
        }
        else if(indexPath.row == 19){
            cell.textLabel.text = @"RedactedCardNumber:";
            cell.detailTextLabel.text = _transactionDetail.redactedCardNumber;
        }
        else if(indexPath.row == 20){
            cell.textLabel.text = @"CardExpirationDate:";
            cell.detailTextLabel.text = _transactionDetail.cardExpirationDate;
        }
        else if(indexPath.row == 21){
            cell.textLabel.text = @"RefundableAmount:";
            cell.detailTextLabel.text = [[NSString alloc] initWithFormat:@"%ld",(long)_transactionDetail.refundableAmount];
        }
        else if(indexPath.row == 22){
            cell.textLabel.text = @"ClerkDisplay:";
            cell.detailTextLabel.text = _transactionDetail.clerkDisplay;
        }
        else if(indexPath.row == 23){
            cell.textLabel.text = @"InvoiceID:";
            cell.detailTextLabel.text = _transactionDetail.invoiceId;
        }
        else if(indexPath.row == 24){
            cell.textLabel.text = @"TransactionNote:";
            cell.detailTextLabel.text = _transactionDetail.transactionNote;
        }
        else if(indexPath.row == 25){
            cell.textLabel.text = @"MerchantInvoiceID:";
            cell.detailTextLabel.text = _transactionDetail.merchantInvoiceId;
        }
        else if(indexPath.row == 26){
            cell.textLabel.text = @"CardHolderName:";
            cell.detailTextLabel.text = _transactionDetail.cardHolderName;
        }
        else if(indexPath.row == 27){
            cell.textLabel.text = @"AvailableBalance:";
            cell.detailTextLabel.text = [[NSString alloc] initWithFormat:@"%ld",(long)_transactionDetail.availableBalance];
        }
        else if(indexPath.row == 28){
            cell.textLabel.text = @"CustomData:";
            cell.detailTextLabel.text = _transactionDetail.customData;
        }
        else if(indexPath.row == 29){
            cell.textLabel.text = @"CardPresentment:";
            cell.detailTextLabel.text =  [self getStringFromCardPresentment:_transactionDetail.cardPresentment];
        }
        else if(indexPath.row == 30){
            cell.textLabel.text = @"CustomReference:";
            cell.detailTextLabel.text = _transactionDetail.customReference;
        }
        else if(indexPath.row == 31){
            cell.textLabel.text = @"ShowNoteAndInvoiceOnReceipt:";
            cell.detailTextLabel.text = _transactionDetail.showNotesAndInvoiceOnReceipt? @"Yes" : @"No";
        }
        else if(indexPath.row == 32){
            cell.textLabel.text = @"BatchNumber:";
            cell.detailTextLabel.text = _transactionDetail.batchNumber;
        }
        else if(indexPath.row == 33){
            cell.textLabel.text = @"OrderNumber:";
            cell.detailTextLabel.text = _transactionDetail.orderNumber;
        }
        else if(indexPath.row == 34){
            cell.textLabel.text = @"ProcessorResponseCode:";
            cell.detailTextLabel.text = _transactionDetail.processorResponseCode;
        }
    }
    else if(indexPath.section < sectionTitle.count){
        if([[sectionTitle objectAtIndex:indexPath.section] isEqualToString:@"AmountInfo"]){
            if(indexPath.row == 0){
                cell.textLabel.text = @"Total:";
                cell.detailTextLabel.text = [[NSString alloc] initWithFormat:@"%ld",(long)_transactionDetail.amount.total];
            }
            else if(indexPath.row == 1){
                cell.textLabel.text = @"Subtotal:";
                cell.detailTextLabel.text = [[NSString alloc] initWithFormat:@"%ld",(long)_transactionDetail.amount.subTotal];
            }
            else if(indexPath.row == 2){
                cell.textLabel.text = @"Tax:";
                cell.detailTextLabel.text = [[NSString alloc] initWithFormat:@"%ld",(long)_transactionDetail.amount.tax];
            }
            else if(indexPath.row == 3){
                cell.textLabel.text = @"Discount:";
                cell.detailTextLabel.text = [[NSString alloc] initWithFormat:@"%ld",(long)_transactionDetail.amount.discount];
            }
            else if(indexPath.row == 4){
                cell.textLabel.text = @"Tip:";
                cell.detailTextLabel.text = [[NSString alloc] initWithFormat:@"%ld",(long)_transactionDetail.amount.tip];
            }
            else if(indexPath.row == 5){
                cell.textLabel.text = @"Surcharge:";
                cell.detailTextLabel.text = [[NSString alloc] initWithFormat:@"%ld",(long)_transactionDetail.amount.surcharge];
            }
            else if(indexPath.row == 6){
                cell.textLabel.text = @"Currency:";
                cell.detailTextLabel.text = _transactionDetail.amount.currency;
            }
            else if(indexPath.row == 7){
                cell.textLabel.text = @"DiscountDescription:";
                cell.detailTextLabel.text = _transactionDetail.amount.discountDescription;
            }
        }
        else if([[sectionTitle objectAtIndex:indexPath.section] isEqualToString:@"CardHolderInfo"]){
            if(indexPath.row == 0){
                cell.textLabel.text = @"FirstName:";
                cell.detailTextLabel.text = _transactionDetail.cardholderInfo.firstName;
            }
            else if(indexPath.row == 1){
                cell.textLabel.text = @"LastName:";
                cell.detailTextLabel.text = _transactionDetail.cardholderInfo.lastName;
            }
            else if(indexPath.row == 2){
                cell.textLabel.text = @"MiddleName:";
                cell.detailTextLabel.text = _transactionDetail.cardholderInfo.middleName;
            }
            else if(indexPath.row == 3){
                cell.textLabel.text = @"Email:";
                cell.detailTextLabel.text = _transactionDetail.cardholderInfo.email;
            }
            else if(indexPath.row == 4){
                cell.textLabel.text = @"Phone:";
                cell.detailTextLabel.text = _transactionDetail.cardholderInfo.phone;
            }
            else if(indexPath.row == 5){
                cell.textLabel.text = @"Address1:";
                cell.detailTextLabel.text = _transactionDetail.cardholderInfo.address1;
            }
            else if(indexPath.row == 6){
                cell.textLabel.text = @"Address2:";
                cell.detailTextLabel.text = _transactionDetail.cardholderInfo.address2;
            }
            else if(indexPath.row == 7){
                cell.textLabel.text = @"City:";
                cell.detailTextLabel.text = _transactionDetail.cardholderInfo.city;
            }
            else if(indexPath.row == 8){
                cell.textLabel.text = @"State:";
                cell.detailTextLabel.text = _transactionDetail.cardholderInfo.state;
            }
            else if(indexPath.row == 9){
                cell.textLabel.text = @"PostalCode:";
                cell.detailTextLabel.text = _transactionDetail.cardholderInfo.postalCode;
            }
        }
        else if([[sectionTitle objectAtIndex:indexPath.section] isEqualToString:@"TokenResponse"]){
            if(indexPath.row == 0){
                cell.textLabel.text = @"TokenResponseCode:";
                cell.detailTextLabel.text = [self getStringFromTokenResponseCode:_transactionDetail.tokenResponse.responseCode];
            }
            else if(indexPath.row == 1){
                cell.textLabel.text = @"TokenID:";
                cell.detailTextLabel.text = _transactionDetail.tokenResponse.tokenIdentifier;
            }
            else if(indexPath.row == 2){
                cell.textLabel.text = @"TokenSource:";
                cell.detailTextLabel.text = _transactionDetail.tokenResponse.tokenSource;
            }
            else if(indexPath.row == 3){
                cell.textLabel.text = @"TokenSourceData:";
                cell.detailTextLabel.text = _transactionDetail.tokenResponse.tokenSourceData;
            }
            else if(indexPath.row == 4){
                cell.textLabel.text = @"TokenFeeInCents:";
                cell.detailTextLabel.text = [[NSString alloc] initWithFormat:@"%ld",(long)_transactionDetail.tokenResponse.tokenFeeInCents];
            }
        }
        else if([[sectionTitle objectAtIndex:indexPath.section] isEqualToString:@"EmvData"]){
            if(indexPath.row == 0){
                cell.textLabel.text = @"AppIdentifier:";
                cell.detailTextLabel.text = _transactionDetail.emvData.appIdentifier;
            }
            else if(indexPath.row == 1){
                cell.textLabel.text = @"AppPreferredName:";
                cell.detailTextLabel.text = _transactionDetail.emvData.appPreferredName;
            }
            else if(indexPath.row == 2){
                cell.textLabel.text = @"AppLabel:";
                cell.detailTextLabel.text = _transactionDetail.emvData.appLabel;
            }
            else if(indexPath.row == 3){
                cell.textLabel.text = @"CryptogramType:";
                cell.detailTextLabel.text = _transactionDetail.emvData.cryptogramType;
            }
            else if(indexPath.row == 4){
                cell.textLabel.text = @"PinStatement:";
                cell.detailTextLabel.text = _transactionDetail.emvData.pinStatement;
            }
            else if(indexPath.row == 5){
                cell.textLabel.text = @"EmvOfflineData:";
                cell.detailTextLabel.text = _transactionDetail.emvData.pinStatement;
            }
            else if(indexPath.row == 5){
                cell.textLabel.text = @"ApplicationInterchangeProfile:";
                cell.detailTextLabel.text = _transactionDetail.emvData.emvOfflineData.aip;
            }
            else if(indexPath.row == 6){
                cell.textLabel.text = @"ApplicationCryptogram:";
                cell.detailTextLabel.text = _transactionDetail.emvData.emvOfflineData.appCryptogram;
            }
            else if(indexPath.row == 7){
                cell.textLabel.text = @"AuthorisationResponseCode:";
                cell.detailTextLabel.text = _transactionDetail.emvData.emvOfflineData.arc;
            }
            else if(indexPath.row == 8){
                cell.textLabel.text = @"ApplicationTransactionCounter:";
                cell.detailTextLabel.text = _transactionDetail.emvData.emvOfflineData.atc;
            }
            else if(indexPath.row == 9){
                cell.textLabel.text = @"ApplicationUsageControl:";
                cell.detailTextLabel.text = _transactionDetail.emvData.emvOfflineData.auc;
            }
            else if(indexPath.row == 10){
                cell.textLabel.text = @"CryptogramInformationData:";
                cell.detailTextLabel.text = _transactionDetail.emvData.emvOfflineData.cid;
            }
            else if(indexPath.row == 11){
                cell.textLabel.text = @"CVMResults:";
                cell.detailTextLabel.text = _transactionDetail.emvData.emvOfflineData.cvmResults;
            }
            else if(indexPath.row == 12){
                cell.textLabel.text = @"IssuerActionCode–Default:";
                cell.detailTextLabel.text = _transactionDetail.emvData.emvOfflineData.iacDefault;
            }
            else if(indexPath.row == 13){
                cell.textLabel.text = @"IssuerActionCode–Denial:";
                cell.detailTextLabel.text = _transactionDetail.emvData.emvOfflineData.iacDenial;
            }
            else if(indexPath.row == 14){
                cell.textLabel.text = @"IssuerActionCode–Online::";
                cell.detailTextLabel.text = _transactionDetail.emvData.emvOfflineData.iacOnline;
            }
            else if(indexPath.row == 15){
                cell.textLabel.text = @"IssuerApplicationData:";
                cell.detailTextLabel.text = _transactionDetail.emvData.emvOfflineData.iad;
            }
            else if(indexPath.row == 16){
                cell.textLabel.text = @"MerchantIdentifier:";
                cell.detailTextLabel.text = _transactionDetail.emvData.emvOfflineData.mid;
            }
            else if(indexPath.row == 17){
                cell.textLabel.text = @"PANSequenceNumber:";
                cell.detailTextLabel.text = _transactionDetail.emvData.emvOfflineData.panSeqNum;
            }
            else if(indexPath.row == 18){
                cell.textLabel.text = @"Rewards:";
                cell.detailTextLabel.text = _transactionDetail.emvData.emvOfflineData.rewards;
            }
            else if(indexPath.row == 19){
                cell.textLabel.text = @"TerminalActionCode–Default:";
                cell.detailTextLabel.text = _transactionDetail.emvData.emvOfflineData.tacDefault;
            }
            else if(indexPath.row == 20){
                cell.textLabel.text = @"TerminalActionCode–Denial:";
                cell.detailTextLabel.text = _transactionDetail.emvData.emvOfflineData.tacDenial;
            }
            else if(indexPath.row == 21){
                cell.textLabel.text = @"TerminalActionCode–Online:";
                cell.detailTextLabel.text = _transactionDetail.emvData.emvOfflineData.tacOnline;
            }
            else if(indexPath.row == 22){
                cell.textLabel.text = @"TerminalCountryCode:";
                cell.detailTextLabel.text = _transactionDetail.emvData.emvOfflineData.tcc;
            }
            else if(indexPath.row == 23){
                cell.textLabel.text = @"TerminalIdentification:";
                cell.detailTextLabel.text = _transactionDetail.emvData.emvOfflineData.tid;
            }
            else if(indexPath.row == 24){
                cell.textLabel.text = @"TransactionCurrencyCode:";
                cell.detailTextLabel.text = _transactionDetail.emvData.emvOfflineData.tcc;
            }
            else if(indexPath.row == 25){
                cell.textLabel.text = @"RetrievalReferenceNumber:";
                cell.detailTextLabel.text = _transactionDetail.emvData.emvOfflineData.trnRef;
            }
            else if(indexPath.row == 26){
                cell.textLabel.text = @"TransactionStatusInformation:";
                cell.detailTextLabel.text = _transactionDetail.emvData.emvOfflineData.tsi;
            }
            else if(indexPath.row == 27){
                cell.textLabel.text = @"TerminalVerificationResults:";
                cell.detailTextLabel.text = _transactionDetail.emvData.emvOfflineData.tvr;
            }
            else if(indexPath.row == 28){
                cell.textLabel.text = @"UnpredictableNumber:";
                cell.detailTextLabel.text = _transactionDetail.emvData.emvOfflineData.upn;
            }
            else if(indexPath.row == 29){
                cell.textLabel.text = @"ValidationCode:";
                cell.detailTextLabel.text = _transactionDetail.emvData.emvOfflineData.valCode;
            }
            else if(indexPath.row == 30){
                cell.textLabel.text = @"DeclineCode:";
                cell.detailTextLabel.text = _transactionDetail.emvData.emvOfflineData.declineCode;
            }
            else if(indexPath.row == 31){
                cell.textLabel.text = @"DeclineStatement:";
                cell.detailTextLabel.text = _transactionDetail.emvData.emvOfflineData.declineStatement;
            }
            else if(indexPath.row == 32){
                cell.textLabel.text = @"AVSResults:";
                cell.detailTextLabel.text = _transactionDetail.emvData.emvOfflineData.avsResults;
            }
        }
    }
    else{
        IMSProduct *product = [_transactionDetail.products objectAtIndex:(indexPath.section-sectionTitle.count)];
        if(indexPath.row == 0){
            cell.textLabel.text = @"Name:";
            cell.detailTextLabel.text = product.name;
        }
        else if(indexPath.row == 1){
            cell.textLabel.text = @"Price:";
            cell.detailTextLabel.text = [[NSString alloc] initWithFormat:@"%ld",(long)product.price];
        }
        else if(indexPath.row == 2){
            cell.textLabel.text = @"Note:";
            cell.detailTextLabel.text = product.note;
        }
        else if(indexPath.row == 3){
            cell.textLabel.text = @"Quantity:";
            cell.detailTextLabel.text = [[NSString alloc] initWithFormat:@"%ld",(long)product.quantity];
        }
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}

@end
