//
//  UIAlertController+Utility.m
//  mPOSSDKTestApp
//
//  Created by Abhiram Dinesh on 2/14/18.
//  Copyright © 2018 RoamData. All rights reserved.
//

#import "UIAlertController+Utility.h"

@implementation UIAlertController (Utility)

-(void) addCheckBoxWithTitle: (NSString*_Nullable) title andConfigurationHandler:(void (^ __nullable)(UIButton * _Nonnull checkBox))configurationHandler {
    __weak typeof(self) weakSelf = self;
    UIButton *checkbox = [UIButton buttonWithType:UIButtonTypeCustom];
    [checkbox setFrame:CGRectMake(0 , 0, 30, 30)];
    [checkbox addTarget:self action:@selector(buttonPressed:) forControlEvents:UIControlEventTouchUpInside];
    [checkbox setContentMode:UIViewContentModeScaleAspectFit];
    [checkbox setReversesTitleShadowWhenHighlighted:true];
    [checkbox setTitle:@"🔲" forState:UIControlStateNormal];
    [checkbox setTitle:@"☑️" forState:UIControlStateSelected];
    [checkbox setTitle:@"☑️" forState:UIControlStateHighlighted];
    [checkbox setAdjustsImageWhenHighlighted:TRUE];
    [self addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        [textField setText:title];
        textField.delegate = weakSelf;
        [textField setRightViewMode:UITextFieldViewModeAlways];
        [textField setRightView:checkbox];
    }];
    configurationHandler(checkbox);
}

-(void)buttonPressed:(UIButton*)sender {
    if(sender.selected){
        [sender setSelected:FALSE];
    } else {
        [sender setSelected:TRUE];
    }
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    return NO;
}
@end
