//
//  AppDelegate.swift
//  EMVSDKSwiftTestApp
//
//  Created by Mallikarjun Patil on 9/8/16.
//  Copyright © 2016 Ingenico. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        #if DEBUG
        #else
        //Store the crash logs
        //comment this code to see the logs in Xcode console view while debugging
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentsDirectory = paths.first
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let dateString = dateFormatter.string(from:Date() as Date)
        let fileName = String(format: "%@.log", dateString)
        let logFilePath = NSString(string: documentsDirectory!).appendingPathComponent(fileName)
        freopen(NSString(string: logFilePath).cString(using: String.Encoding.ascii.rawValue),"a+",stderr);
        UserDefaults.standard.set(logFilePath, forKey: "log_file_path")
        #endif
        return true
    }


}

