//
//  Constants.swift
//  EMVSDKSwiftTestApp
//
//  Copyright © 2019 Ingenico. All rights reserved.
//

import Foundation

struct Constant {
    static let CLIENT_VERSION = "4.2.3"
    static let API_KEY = "Set your API key here"
    static let BASE_URL = "https://uatmcm.roamdata.com"
}
