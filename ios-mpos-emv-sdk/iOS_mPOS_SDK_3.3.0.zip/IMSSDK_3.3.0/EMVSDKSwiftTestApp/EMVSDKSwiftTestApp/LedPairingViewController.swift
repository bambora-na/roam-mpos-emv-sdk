//
//  LedPairingViewController.swift
//  EMVSDKSwiftTestApp
//
//  Created by Abhiram Dinesh on 11/20/19.
//  Copyright © 2019 Ingenico. All rights reserved.
//

import UIKit

class LedPairingViewController: UIViewController {
    
    @IBOutlet weak var containerView: UIImageView!
    
    var confirmationCallback: RUALedPairingConfirmationCallback?
    var ledSequence:[Any] = []
    var ledPairingView : RUALedPairingView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let ledArrayWidth = containerView.frame.size.width/3
        ledPairingView = RUALedPairingView(frame: CGRect(x: ledArrayWidth, y: ledArrayWidth/3, width: ledArrayWidth, height: ledArrayWidth/4))
        containerView.addSubview(ledPairingView!)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        ledPairingView?.showSequences(ledSequence)
    }
    
    @IBAction func cancel(_ sender: Any) {
        confirmationCallback?.cancel()
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func restart(_ sender: Any) {
        self.dismiss(animated: true) {
            self.confirmationCallback?.restartLedPairingSequence()
        }
    }
    
    @IBAction func confirm(_ sender: Any) {
        confirmationCallback?.confirm()
        self.dismiss(animated: true, completion: nil)
    }
    
}
