//
//  PaymentAPIViewController.swift
//  EMVSDKSwiftTestApp
//
//  Created by Mallikarjun Patil on 9/12/16.
//  Copyright © 2016 Ingenico. All rights reserved.
//

import UIKit


class PaymentAPIViewController: IMSBaseViewController {
    
    static var Transaction_Message:String = "Provide normalized transaction amount and clerkID"
    static var RefundTransaction_Message:String = "Provide normalized refund transaction amount and clerkID"


    @IBOutlet weak var paymentAPITableView: UITableView!
    var staticDataArray = [[String: [String]]] ()
    var ingenico:Ingenico?
    var doneCallback:TransactionOnDone?
    var progressCallback:UpdateProgress?
    var applicationSelectionCallback:ApplicationSelectionHandler?
    var transactionTypeSelectionCallback:IMSTransactionTypeSelectionHandler?
    var isViewController = false
    var sceViewController : IMSSecureCardEntryViewController?
    var tapGesture : UITapGestureRecognizer?
    
    var canEnrollToken = false
    var checkIfCardPresent = false
    var canUpdateToken = false
    var isTokenTransaction = false
    var isResale = false
    var isReauth = false
    var isPartialAuth = false
    var withCardReader = false
    var isManualKeyed = false
    var isSCETransaction = false
    var isPerformingPartialAuth = false
    var initialSubmittedAmount = 0
    var partialAuthAmount = 0
    var transactionType = IMSTransactionType.TransactionTypeUnknown
    var alertTitle = ""
    var ignoreReversalBeforeTransaction = false
    
    var  totalTF:UITextField?
    var  subtotalTF:UITextField?
    var  discountTF:UITextField?
    var  taxTF:UITextField?
    var  tipTF:UITextField?
    var  surchargeTF:UITextField?
    var  clerkIDTF:UITextField?
    var  authCodeTF:UITextField?
    var  stanTF:UITextField?
    var  invocieIDTF:UITextField?
    var  transactionNoteTF:UITextField?
    var  tokenFeeTF:UITextField?
    var  customRefTF:UITextField?
    var  tokenIDTF:UITextField?
    var  avsZipCodeTF:UITextField?
    var  avsAddressTF:UITextField?
    var  orderNumberTF:UITextField?
    var  currencyCodeTF:UITextField?
    var  localeTF:UITextField?
    
    var cvvCheckBox: UIButton?
    var avsCheckBox: UIButton?
    var tokenEnrollCheckBox: UIButton?
    var tokenUpdateCheckBox: UIButton?
    var cardPresentCheckBox: UIButton?
    var showNoteAndInvoiceOnReceiptCheckBox: UIButton?
    
    var transactionResponse : IMSTransactionResponse?
    var partialAuthTxnIds : [String] = []
    var pendingTransactions : [IMSPendingTransaction] = []
    var transactionGroupId = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ingenico = Ingenico.sharedInstance()
        paymentAPITableView.dataSource = self
        paymentAPITableView.delegate = self
        paymentAPITableView.tableFooterView = UIView()

        let cashTransactionMap:[String: [String]] = ["Cash Transaction":
                                                        ["* Cash Sale",
                                                         "* Cash Refund"
                                                        ]
                                                    ]
        staticDataArray.append(cashTransactionMap)
        let txnsWithoutReaderMap:[String: [String]] = ["Transaction without card reader":
                                                        ["* Keyed sale",
                                                         "* Keyed auth",
                                                         "* Keyed force sale",
                                                         "* Keyed token enrollment",
                                                         "* Keyed token update",
                                                         "* Auth complete",
                                                         "* Credit refund against transaction",
                                                         "* Void transaction",
                                                         "* Token sale",
                                                         "* Credit sale adjust",
                                                         "* Partial Auth",
                                                         "* Credit Re-Sale",
                                                         "* Credit Re-Auth",
                                                         "* Credit auth adjust",
                                                         "* Partial Void",
                                                         "* Token Auth",
                                                        ]
                                                    ]
        staticDataArray.append(txnsWithoutReaderMap)
        let txnsWithReaderMap:[String: [String]] = ["Transaction with card reader":
                                                        ["* Credit sale",
                                                         "* Credit auth",
                                                         "* Credit force sale",
                                                         "* Credit balance inquiry",
                                                         "* Debit sale",
                                                         "* Debit refund",
                                                         "* Credit refund",
                                                         "* Keyed Credit Sale",
                                                         "* Token enrollment",
                                                         "* Token update",
                                                         "* Debit balance inquiry",
                                                         "* AVS Only",
                                                         "* Sale",
                                                         "* Refund",
                                                         "* Balance Inquiry",
                                                         "* Keyed Credit Auth",
                                                         "* Keyed Credit Refund",
                                                         "* Keyed Token Enrollment",
                                                         "* Keyed Token Update",
                                                         "* VAS only",
                                                         "* Void Transaction",
                                                        ]
                                                    ]
        staticDataArray.append(txnsWithReaderMap)
        let pendingTxnMap:[String: [String]] = ["Manage pending transactions":
                                                        ["* Get pending transactions",
                                                         "* Ignore pending transactions",
                                                         "* Reverse pending transactions",
                                                         "* Ignore Reversal Before Transaction",
                                                         "* Reverse single transaction"
                                                        ]
                                                ]
        staticDataArray.append(pendingTxnMap)
        let sceMap:[String: [String]] = ["Secure card entry":
                                            ["* Model view - Credit Sale",
                                             "* View controller - Credit Sale",
                                             "* Model view - Credit Auth",
                                             "* View controller - Credit Auth",
                                             "* Model view - Credit Refund",
                                             "* View controller - Credit Refund"
                                            ]
                                        ]
        staticDataArray.append(sceMap)
        let loadTestMap:[String: [String]] = ["Load Testing":
                                                ["* Transaction load testing"]
                                            ]
        staticDataArray.append(loadTestMap)
        let othersMap:[String: [String]] = ["Others":
                                                ["* Get Current Capabilities",
                                                 "* Update Preference"]
                                            ]
        staticDataArray.append(othersMap)

        doneCallback = { (response, error) in
            self.dismissProgress()
            self.transactionResponse = response
            if let response = response {
                if (response.transactionID?.count ?? 0 > 0) {
                    self.setLastTransactionID(response.transactionID)
                }
                if (response.tokenResponseParameters?.tokenIdentifier?.count ?? 0 > 0) {
                    self.setLastTokenID(response.tokenResponseParameters.tokenIdentifier)
                }
                if (response.clientTransactionID?.count ?? 0 > 0) {
                    self.setLastClientTransactionID(response.clientTransactionID)
                }
                if(response.transactionType != .TransactionTypeUnknown) {
                    self.setLastTransactionType(response.transactionType)
                }
            }
            if (error == nil && response?.posEntryMode == .POSEntryModeContactEMV) {
                self.showProgressMessage("Please remove card")
                Ingenico.sharedInstance()?.paymentDevice.wait(forCardRemoval: 50, andOnDone: { (error) in
                    self.dismissProgress()
                    self.showResponse(response, error: error as NSError?)
                })
            }
            else {
                self.showResponse(response, error: error as NSError?)
            }
            
        }
        
        progressCallback = {(message, extraMessage) in
            self.consoleLog("OnProgress:\(self.getProgressStrFromMessage(message))")
            self.showProgressMessage(self.getProgressStrFromMessage(message)) {
                Ingenico.sharedInstance()?.payment.abortTransaction()
            }
        }
        
        applicationSelectionCallback = { ( list, error, response) in
            self.dismissProgress()
            let applicationList = list as! [RUAApplicationIdentifier]
            let viewcontroller:UIAlertController = UIAlertController.init(title: "Select application for your card", message: "Make your choice", preferredStyle: .actionSheet)
            for appID in applicationList {
                let okAction:UIAlertAction = UIAlertAction.init(title: appID.applicationLabel, style: .default, handler: { (action) in
                    self.showProcessingMessage()
                    viewcontroller.dismiss(animated: true, completion: nil)
                    response!(appID)
                })
                viewcontroller.addAction(okAction)
            }
            let cancel = UIAlertAction(title: "Cancel", style: .cancel) { (action) in
                response!(nil)
            }
            viewcontroller.addAction(cancel)
            self.present(viewcontroller, animated: true, completion: nil)
        }
        transactionTypeSelectionCallback = { (error, response) in
            self.dismissProgress()
            let viewcontroller:UIAlertController = UIAlertController.init(title: "Select application for your card", message: "Make your choice", preferredStyle: .actionSheet)
            let credit = UIAlertAction(title: "Credit", style: .default) { (action) in
                response!(.ApplicationTypeCredit)
            }
            viewcontroller.addAction(credit)
            let debit = UIAlertAction(title: "Debit", style: .default) { (action) in
                response!(.ApplicationTypeDebit)
            }
            viewcontroller.addAction(debit)
            let cancel = UIAlertAction(title: "Cancel", style: .cancel) { (action) in
                response!(.ApplicationTypeUnknown)
            }
            viewcontroller.addAction(cancel)
            self.present(viewcontroller, animated: true, completion: nil)
        }
        
        deviceStatusBarButton = UIBarButtonItem.init(customView: getDeviceStatusImage())
        self.tabBarController?.navigationItem.hidesBackButton = true
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if isLogViewDisplayed == true {
            self.tabBarController?.navigationItem.leftBarButtonItem = nil
            self.tabBarController?.navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Hide Log", style: UIBarButtonItem.Style.plain, target: self, action: #selector(showLog))
            self.tabBarController?.navigationItem.rightBarButtonItems = nil
            self.tabBarController?.navigationItem.rightBarButtonItems = [UIBarButtonItem(title: "Clear Log", style: UIBarButtonItem.Style.plain, target: self, action:#selector(doLogoff)),
                                                                         deviceStatusBarButton!]
            
        }else {
            self.tabBarController?.navigationItem.leftBarButtonItem = nil
            self.tabBarController?.navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Show Log", style: UIBarButtonItem.Style.plain, target: self, action: #selector(showLog))
            self.tabBarController?.navigationItem.rightBarButtonItems = nil
            self.tabBarController?.navigationItem.rightBarButtonItems = [UIBarButtonItem(title: "Logout", style: UIBarButtonItem.Style.plain, target: self, action:#selector(doLogoff)),
                                                                         deviceStatusBarButton!]
        }
    }
    
    func showResponse(_ response: IMSTransactionResponse?, error: NSError?) {
        let responseStr = self.getStringFromResponse(response)
        self.consoleLog(String.init(format: "Transaction Response:\n%@", responseStr))
        let alertMessage = (error == nil) ? "\(alertTitle) success : \n Transaction Response:\n\(responseStr)"  : "\(alertTitle) Failed with error code: \(self.getResponseCodeString((error!.code)))"
        self.consoleLog(alertMessage)
        let alert = UIAlertController(title: alertTitle, message: alertMessage, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default) { (action) in
            if (response?.transactionID?.count ?? 0 > 0) {
                if (error == nil) {
                    self.getSignatureOrUpdateTransaction(response!)
                }
                else {
                    if (self.isPerformingPartialAuth) {
                        self.doPartialAuthorization()
                    }
                    else {
                        self.resetPartialAuthState()
                    }
                }
            }
        }
        alert.addAction(okAction)
        self.present(alert, animated: false, completion: nil)

    }

    func showErrorMessage (_ errorMessage:String, andErrorTitle errortitle:String){

        let controller:UIAlertController = UIAlertController.init(title: errortitle, message: errorMessage, preferredStyle: .alert)
        let action:UIAlertAction = UIAlertAction.init(title: "OK", style: .default, handler: nil)
        controller.addAction(action)
        self.present(controller, animated: true, completion: nil)
    }
    
    func showSecureCardEntryView(_ secureCardEntryViewController: IMSSecureCardEntryViewController) {
        dismissProgress()
        if self.isViewController {
            let navigationController = IMSNavigationViewController(rootViewController: secureCardEntryViewController)
            self.present(navigationController, animated: true, completion: nil)
        }
        else {
            self.sceViewController = secureCardEntryViewController
            self.sceViewController?.view.frame = CGRect(x: 0, y: 0, width: (self.view.bounds.size.width * 90) / 100, height: (self.view.bounds.size.height * 90) / 100)
            self.tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.dismissModalView))
            self.tapGesture?.numberOfTapsRequired = 1
            self.view.addGestureRecognizer(self.tapGesture!)
            let cancelButton = UIButton(type: .system)
            cancelButton.frame = CGRect(x: 0, y: 0, width: 40, height: 40)
            cancelButton.setTitle("𝖷", for: .normal)
            cancelButton.addTarget(self, action: #selector(self.dismissModalView), for: .touchUpInside)
            sceViewController?.view.addSubview(cancelButton)
            self.sceViewController?.didMove(toParent: self)
            self.sceViewController?.view.center = CGPoint(x: self.view.center.x, y: self.view.center.y)
            self.sceViewController?.view.layer.borderWidth = 1
            self.sceViewController?.view.layer.borderColor = UIColor.darkGray.cgColor
            self.addChild(self.sceViewController!)
            self.view.addSubview((self.sceViewController?.view)!)
        }
    }
    
    @objc func dismissModalView() {
        sceViewController?.view.removeFromSuperview()
        sceViewController?.removeFromParent()
        sceViewController = nil;
        if (tapGesture != nil) {
            self.view.removeGestureRecognizer(tapGesture!)
            tapGesture = nil
        }
    }
    
    func getCurrentCapabilities() {
        if let capabilities = ingenico?.getCurrentCapabilities(){
            self.consoleLog("Store and Forward capable: \(capabilities.storeAndForwardCapable) \nEMV capable: \(capabilities.emvCapable) \nFW update action: \(self.getStringFromFirmwareUpdateOption(capabilities.firmwareUpdateAction)) \nisEMVConfigUptoDate : \(capabilities.isEMVConfigUptoDate) \nstoredTransactionsAmountLimit : \(capabilities.storedTransactionsAmountLimit)")
        }
    }
    
    func updatePreference() {
        let pref = IMSPreference();
        let setConfigMode: (IMSConfigMode) -> Void = { mode in
            pref.configMode = mode;
            let setRetryCount: (UInt) -> Void = { count in
                pref.retryCount = count;
                let setMerchantLocale: (Locale) -> Void = { merchantLocale in
                    pref.merchantLocale = merchantLocale;
                    self.setIsConfigModeSet(true);
                    Ingenico.sharedInstance()?.updatePreference(pref)
                    self.consoleLog("Update Preference, Config Mode: \(pref.configMode.rawValue) \nRetry Count: \(pref.retryCount) \nMerchant Locale: \(pref.merchantLocale ?? NSLocale.current)")
                    }
                    let merchantLocaleAlert = UIAlertController(title: "Select Locale:", message: "", preferredStyle: .alert)
                    let enUs = UIAlertAction(title: "en_US", style: .default) { (action) in
                        setMerchantLocale(Locale.init(identifier: "en_US"))
                    }
                    let enCa = UIAlertAction(title: "en_CA", style: .default) { (action) in
                        setMerchantLocale(Locale.init(identifier: "en_CA"))
                    }
                    let frCa = UIAlertAction(title: "fr_CA", style: .default) { (action) in
                        setMerchantLocale(Locale.init(identifier: "fr_CA"))
                    }
                    let cancelAction = UIAlertAction(title: "cancel", style: .cancel, handler: nil)
                    merchantLocaleAlert.addAction(enUs)
                    merchantLocaleAlert.addAction(enCa)
                    merchantLocaleAlert.addAction(frCa)
                    merchantLocaleAlert.addAction(cancelAction)
                    self.present(merchantLocaleAlert, animated: false, completion: nil)
            }
            let retryCountAlert = UIAlertController(title: "Select Config Mode:", message: "", preferredStyle: .alert)
            let zero = UIAlertAction(title: "0", style: .default) { (action) in
                setRetryCount(0)
            }
            let one = UIAlertAction(title: "1", style: .default) { (action) in
                setRetryCount(1)
            }
            let two = UIAlertAction(title: "2", style: .default) { (action) in
                setRetryCount(2)
            }
            let three = UIAlertAction(title: "3", style: .default) { (action) in
                setRetryCount(3)
            }
            let cancelAction = UIAlertAction(title: "cancel", style: .cancel, handler: nil)
            retryCountAlert.addAction(zero)
            retryCountAlert.addAction(one)
            retryCountAlert.addAction(two)
            retryCountAlert.addAction(three)
            retryCountAlert.addAction(cancelAction)
            self.present(retryCountAlert, animated: false, completion: nil)
        }
        let configModeAlert = UIAlertController(title: "Select Config Mode:", message: "", preferredStyle: .alert)
        let manual = UIAlertAction(title: "Manual", style: .default) { (action) in
            setConfigMode(IMSConfigMode.manual)
        }
        let optimal = UIAlertAction(title: "Optimal", style: .default) { (action) in
            setConfigMode(IMSConfigMode.optimal)
        }
        let auto = UIAlertAction(title: "Auto", style: .default) { (action) in
            setConfigMode(IMSConfigMode.auto)
        }
        let cancelAction = UIAlertAction(title: "cancel", style: .cancel, handler: nil)
        configModeAlert.addAction(manual)
        configModeAlert.addAction(optimal)
        configModeAlert.addAction(auto)
        configModeAlert.addAction(cancelAction)
        present(configModeAlert, animated: false, completion: nil)
    }


    func doTestTransactionWithNumber(_ number:Int) {
        self.view.endEditing(true)
        self.showProgressMessage("Processing Transaction")
        let amount = IMSAmount(total: 100, andSubtotal: 100, andTax: 0, andDiscount: 0, andDiscountDescription: "ROAMDiscount", andTip: 0, andCurrency: "USD")!
        let request = IMSCreditSaleTransactionRequest(amount: amount, andIsCompleted: false)!
        ingenico?.payment.processCreditSaleTransaction(withCardReader: request, andUpdateProgress: self.progressCallback!,
                                                       andSelectApplication: { (applicationList, error, appResponse) in
                                                        appResponse!(applicationList?[0] as? RUAApplicationIdentifier)
        }, andOnDone: { (response, error) in
            self.dismissProgress()
            self.consoleLog("Card Transaction  number \(number) Response:\n\(self.getStringFromResponse(response!))")
            if error != nil {
                let nserror = error as NSError?
                self.showError("Failed with error: \(self.getResponseCodeString((nserror?.code)!))")
                self.consoleLog("Card Transaction failed with error code \((self.getResponseCodeString((nserror?.code)!)))")
                if(nserror?.code == Int(IMSResponseCode.TransactionCancelled.rawValue)){
                    return;
                }
            } else {
                if number < 100 {
                    let newNumber:Int = number + 1
                    Thread.sleep(forTimeInterval: 0.5)
                    self.doTestTransactionWithNumber(newNumber)
                }
            }
        })
    }
    

    func uploadSignature(){
        self.showProgressMessage("Uploading Signature...")
        let encodedString:String = (UIImage.init(named: "signature.png")!.pngData()?.base64EncodedString(options: .endLineWithLineFeed))!
        ingenico?.user.uploadSignatureForTransaction(withId: getLastTransactionID() ?? "", andSignature: encodedString, andOnDone: { (error) in
            self.dismissProgress()
            if (self.isPartialAuth) {
                self.doPartialAuthorization()
            }
            else {
                self.updateTranasctionWithTransactionId((self.transactionResponse?.transactionID)!)
            }
            if error == nil {
                self.showSucess( "Uploading signature Succeeded")
                self.consoleLog("Uploading signature Succeeded")
            } else {
                self.showError("Uploading signature failed")
                self.consoleLog("Uploading signature failed")
            }
        })

    }
    
    func doVoidTransaction(_ isWithCardReader: Bool) {
        if ((self.getLastTransactionType() != .TransactionTypeCreditSale &&
            self.getLastTransactionType() != .TransactionTypeDebitSale &&
            self.getLastTransactionType() != .TransactionTypeCreditAuth &&
            self.getLastTransactionType() != .TransactionTypeCreditAuthCompletion &&
            self.getLastTransactionType() != .TransactionTypeCreditForceSale &&
            self.getLastTransactionType() != .TransactionTypeCreditRefund &&
            self.getLastTransactionType() != .TransactionTypeDebitRefund &&
            self.getLastTransactionType() != .TransactionTypeCreditSaleAdjust &&
            self.getLastTransactionType() != .TransactionTypeCreditAuthAdjust &&
            self.getLastTransactionType() != .TransactionTypeSale &&
            self.getLastTransactionType() != .TransactionTypeRefund)
            || self.getLastTransactionID() == nil) {
            self.showErrorMessage("Please do a Transaction First", andErrorTitle: "Error")
        }
        else {
            let alertController:UIAlertController = UIAlertController.init(title: alertTitle, message: "Enter void Info", preferredStyle: .alert)
            alertController.addTextField(configurationHandler: { (textField) in
                textField.keyboardType = .default
                textField.placeholder = "ClerkID(Optional)"
                self.clerkIDTF = textField
            })
            alertController.addTextField(configurationHandler: { (textField) in
                textField.keyboardType = .default
                textField.placeholder = "Transaction Note(optional)"
                self.transactionNoteTF = textField
            })
            alertController.addTextField(configurationHandler: { (textField) in
                textField.keyboardType = .default
                textField.placeholder = "Custom Reference(Optional)"
                self.customRefTF = textField
            })
            alertController.addTextField(configurationHandler: { (textField) in
                textField.keyboardType = .numberPad
                textField.placeholder = "Order Number(Optional)"
                self.orderNumberTF = textField
            })
            alertController.addCheckBoxWithTitle("ShowNoteAndInvoiceOnReceipt") { (checkbox) in
                self.showNoteAndInvoiceOnReceiptCheckBox = checkbox
            }
            let okAction:UIAlertAction = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.view.endEditing(true)
                let transactionRequest:IMSVoidTransactionRequest = IMSVoidTransactionRequest(originalSaleTransactionID: self.getLastTransactionID(), andClerkID: self.clerkIDTF!.text, andLongitude: self.getLongitude(), andLatitude: self.getLatitude(), andCustomReference: self.customRefTF!.text, andTransactionNotes: self.transactionNoteTF!.text, andOrderNumber: self.orderNumberTF!.text, andShowNotesAndInvoiceOnReceipt: self.showNoteAndInvoiceOnReceiptCheckBox!.isSelected)
                self.setLastTransactionType(.TransactionTypeUnknown)
                self.clerkIDTF = nil
                self.transactionNoteTF = nil
                self.customRefTF = nil
                self.orderNumberTF = nil
                if(isWithCardReader){
                    self.ingenico?.payment.processVoidTransaction(withCardReader: transactionRequest, andUpdateProgress: self.progressCallback!, andSelectApplication: self.applicationSelectionCallback!, andOnDone: self.doneCallback!)
                }else{
                    self.showProcessingMessage()
                    self.ingenico?.payment.processVoidTransaction(transactionRequest, andOnDone: self.doneCallback!)
                }
            })
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
            alertController.addAction(okAction)
            alertController.addAction(cancelAction)
            self.present(alertController, animated: true, completion: nil)
        }
    }

    func doPartialVoidTransaction() {
        if (self.getLastTransactionID() == nil) {
            self.showErrorMessage("Please do a Transaction First", andErrorTitle: "Error")
        }
        else {
            let alertController:UIAlertController = UIAlertController.init(title: alertTitle, message: "Enter void Info", preferredStyle: .alert)
            alertController.addTextField(configurationHandler: { (textField) in
                textField.keyboardType = .numberPad
                textField.placeholder = "Total Amount"
                self.totalTF = textField
            })
            alertController.addTextField(configurationHandler: { (textField) in
                textField.keyboardType = .default
                textField.placeholder = "ClerkID(Optional)"
                self.clerkIDTF = textField
            })
            alertController.addTextField(configurationHandler: { (textField) in
                textField.keyboardType = .default
                textField.placeholder = "Transaction Note(optional)"
                self.transactionNoteTF = textField
            })
            alertController.addTextField(configurationHandler: { (textField) in
                textField.keyboardType = .default
                textField.placeholder = "Custom Reference(Optional)"
                self.customRefTF = textField
            })
            alertController.addTextField(configurationHandler: { (textField) in
                textField.keyboardType = .numberPad
                textField.placeholder = "Order Number(Optional)"
                self.orderNumberTF = textField
            })
            let okAction:UIAlertAction = UIAlertAction.init(title: "OK", style: .default, handler: { (action) in
                self.view.endEditing(true)
                self.showProcessingMessage()
                let transactionRequest = IMSPartialVoidTransactionRequest(amount: self.getAmount(), andOriginalSaleTransactionID: self.getLastTransactionID(), andClerkID: self.clerkIDTF!.text, andLongitude: self.getLongitude(), andLatitude: self.getLatitude(), andCustomReference: self.customRefTF!.text, andTransactionNotes: self.transactionNoteTF!.text, andOrderNumber: self.orderNumberTF!.text)!
                self.setLastTransactionType(.TransactionTypeUnknown)
                self.totalTF = nil
                self.clerkIDTF = nil
                self.transactionNoteTF = nil
                self.customRefTF = nil
                self.orderNumberTF = nil
                self.ingenico?.payment.processPartialVoidTransaction(transactionRequest, andOnDone: self.doneCallback!)
            })
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
            alertController.addAction(okAction)
            alertController.addAction(cancelAction)
            self.present(alertController, animated: true, completion: nil)
        }
    }

    func getSignatureOrUpdateTransaction(_ response: IMSTransactionResponse) {
        if (getLastTransactionType() == .TransactionTypeCreditBalanceInquiry ||
            getLastTransactionType() == .TransactionTypeDebitBalanceInquiry  ||
            getLastTransactionType() == .TransactionTypeBalanceInquiry  ||
            getLastTransactionType() == .TransactionTypeTokenEnrollment  ||
            getLastTransactionType() == .TransactionTypeAVSOnly) {
            updateTranasctionWithTransactionId(response.transactionID!)
        }
        else {
            if ((response.cardVerificationMethod == .CardVerificationMethodPinAndSignature ||
                response.cardVerificationMethod == .CardVerificationMethodSignature) &&
                ( response.posEntryMode == .POSEntryModeContactEMV ||
                    response.posEntryMode == .POSEntryModeContactlessEMV ||
                    response.posEntryMode == .POSEntryModeMagStripeEMVFail
                )){
                self.dismissProgress()
                let controller:UIAlertController = UIAlertController.init(title: "Select action", message: String.init(format: "Please select action for pending signature transaction: %@", getLastTransactionID()!), preferredStyle:.alert)
                let uploadAction:UIAlertAction = UIAlertAction.init(title: "Upload Signature", style: .default, handler: { (action) in
                    self.showProgressMessage("Adding Signature progrmatically")
                    self.uploadSignature()
                })
                let voidAction:UIAlertAction = UIAlertAction.init(title: "Void", style: .default, handler: { (action) in
                    self.doVoidTransaction(false)
                })
                let dismissAction = UIAlertAction.init(title: "Dismiss", style: .default, handler: nil)
                controller.addAction(voidAction)
                controller.addAction(uploadAction)
                controller.addAction(dismissAction)
                self.present(controller, animated: true, completion: nil)
            }else {
                if response.cardVerificationMethod == .CardVerificationMethodSignature {
                    self.consoleLog("Adding Signature progrmatically")
                    self.showProgressMessage("Adding Signature progrmatically")
                    self.uploadSignature()
                }else {
                    updateTranasctionWithTransactionId(response.transactionID!)
                }
            }
        }
    }
    
    
    func updateTranasctionWithTransactionId(_ transactionID: String) {
        
        ingenico?.user.updateTransaction(withTransactionID: transactionID, andCardholderInfo:getSampleCardholderInfo(), andTransactionNote: nil, andIsCompleted: false, andDisplayNotesAndInvoice: true, andOnDone: { (error) in
            if error == nil{
                self.consoleLog(String("Update transaction succeeded"))
            } else {
                let nserror = error as NSError?
                self.consoleLog(String("Update transaction Failed with error\(self.getResponseCodeString((nserror?.code)!))"))
            }
            self.sendReceipt(transactionID)
        })
    }
    
    func resetPartialAuthState() {
        isPartialAuth = false
        isPerformingPartialAuth = false
        initialSubmittedAmount = 0
        partialAuthAmount = 0
        partialAuthTxnIds = []
        transactionGroupId = "";
    }
    
    func resetTransactionProperties() {
        setLastTransactionType(transactionType)
        transactionType = .TransactionTypeUnknown
        withCardReader = false
        canEnrollToken = false
        canUpdateToken = false
        isManualKeyed = false
        isTokenTransaction = false
        isResale = false
        isReauth = false
        isSCETransaction = false
        isPartialAuth = false
        checkIfCardPresent = false
        totalTF = nil
        clerkIDTF = nil
        transactionNoteTF = nil
        customRefTF = nil
        orderNumberTF = nil
        discountTF = nil
        subtotalTF = nil
        taxTF = nil
        tipTF = nil
        surchargeTF = nil
        authCodeTF = nil
        stanTF = nil
        invocieIDTF = nil
        avsAddressTF = nil
        avsZipCodeTF = nil
        orderNumberTF = nil
        cvvCheckBox = nil
        avsCheckBox = nil
        tokenEnrollCheckBox = nil
        tokenUpdateCheckBox = nil
        cardPresentCheckBox = nil
        showNoteAndInvoiceOnReceiptCheckBox = nil
        currencyCodeTF = nil
        localeTF = nil
    }
    
    func doPartialAuthorization() {
        if (!isPerformingPartialAuth) {
            //First transaction
            initialSubmittedAmount = transactionResponse?.submittedAmount.total ?? 0
            if (transactionResponse?.authorizedAmount ?? 0 < initialSubmittedAmount) {
                isPerformingPartialAuth = true
            }
            else {
                updateTranasctionWithTransactionId((transactionResponse?.transactionID!)!)
            }
        }
        else {
            //Subsequent transactions
            partialAuthAmount += transactionResponse?.authorizedAmount ?? 0
            if (partialAuthAmount < initialSubmittedAmount) {
                if (transactionResponse?.transactionResponseCode == .TransactionResponseCodeApproved) {
                    transactionGroupId = (transactionResponse?.transactionGroupID)!
                    partialAuthTxnIds.append((transactionResponse?.transactionGUID)!)
                }
                showFormAlert {
                    self.processKeyedCreditSale()
                }
            }
            else {
                updateTranasctionWithTransactionId(partialAuthTxnIds.first!)
                resetPartialAuthState()
            }
        }
    }

    
    func voidLastPartialTransaction() {
        self.showProgressMessage("Voiding partial auth transactions...")
        if (!partialAuthTxnIds.isEmpty) {
            let transactionId = partialAuthTxnIds.removeLast()
            let request = IMSVoidTransactionRequest(originalSaleTransactionID: transactionId, andClerkID: nil, andLongitude: getLongitude(), andLatitude: getLatitude())!
            Ingenico.sharedInstance()?.payment.processVoidTransaction(request, andOnDone: { (response, error) in
                self.consoleLog(String.init(format: "Transaction Response:\n%@", self.getStringFromResponse(response)))
                self.dismissProgress()
                if (error == nil && !self.partialAuthTxnIds.isEmpty) {
                    self.voidLastPartialTransaction()
                }
            })
            
        }
    }
    
    func sendReceipt(_ transactionID:String){
        
        ingenico?.user.sendEmailReceipt(transactionID, andEmailAddress: "ims@ims.com", andOnDone: { (error) in
            if error == nil {
                self.consoleLog( "send email receipt succeeded\n")
            }else {
                let nserror = error as NSError?
                self.consoleLog("send email receipt failed with error:\(self.getResponseCodeString((nserror?.code)!))")
            }
        })
    }
    
    @objc func checkBoxSelected(_ sender: UIButton) {
        if (sender == tokenUpdateCheckBox) {
            tokenEnrollCheckBox?.isSelected = false
        }
        else if (sender == tokenEnrollCheckBox) {
            tokenUpdateCheckBox?.isSelected = false
        }
    }
    
    func showFormAlert(_ completion: @escaping () -> ()) {
        if (!self.ignoreReversalBeforeTransaction && (Ingenico.sharedInstance()?.payment.hasPendingTransactions())!) {
            showErrorMessage("Found pending transactions. Reverse them to proceed.", andErrorTitle: "")
            return
        }
        let alert = UIAlertController(title: alertTitle, message: "Provide transaction Info", preferredStyle: .alert)
        if(transactionType != .TransactionTypeCreditBalanceInquiry
            && transactionType != .TransactionTypeDebitBalanceInquiry
            && transactionType != .TransactionTypeBalanceInquiry
            && transactionType != .TransactionTypeTokenEnrollment
            && transactionType != .TransactionTypeAVSOnly){
            alert.addTextField { (textField) in
                textField.keyboardType = .numberPad
                textField.placeholder = "Total Amount"
                if (self.isPerformingPartialAuth) {
                    textField.text = "\(self.initialSubmittedAmount - self.partialAuthAmount)"
                }
                self.totalTF = textField;
            }
        }
        if(transactionType == .TransactionTypeCreditForceSale){
            alert.addTextField { (textField) in
                textField.keyboardType = .default
                textField.placeholder = "AuthCode"
                self.authCodeTF = textField
            }
            alert.addTextField { (textField) in
                textField.keyboardType = .numberPad
                textField.placeholder = "SystemTraceAuditNumber"
                self.stanTF = textField
            }
        }
        if(transactionType != .TransactionTypeCreditBalanceInquiry &&
            transactionType != .TransactionTypeDebitBalanceInquiry &&
            transactionType != .TransactionTypeBalanceInquiry &&
            transactionType != .TransactionTypeTokenEnrollment &&
            transactionType != .TransactionTypeAVSOnly){
            alert.addTextField { (textField) in
                textField.keyboardType = .numberPad
                textField.placeholder = "Normalized Subtotal"
                self.subtotalTF = textField
            }
            if(transactionType != .TransactionTypeCreditRefund &&
                transactionType != .TransactionTypeDebitRefund &&
                transactionType != .TransactionTypeCashRefund){
                alert.addTextField { (textField) in
                    textField.keyboardType = .numberPad
                    textField.placeholder = "Normalized Tip(optional)"
                    self.tipTF = textField
                }
            }
            alert.addTextField { (textField) in
                textField.keyboardType = .numberPad
                textField.placeholder = "Normalized Discount(optional)"
                self.discountTF = textField
            }
            alert.addTextField { (textField) in
                textField.keyboardType = .numberPad
                textField.placeholder = "Normalized Tax(optional)"
                self.taxTF = textField
            }
            alert.addTextField { (textField) in
                textField.keyboardType = .numberPad
                textField.placeholder = "Normalized Surcharge(optional)"
                self.surchargeTF = textField
            }
            alert.addTextField { (textField) in
                textField.placeholder = "Currency Code"
                textField.text = UserDefaults.standard.string(forKey: "currencyCode") ?? "USD"
                self.currencyCodeTF = textField
                
            }
            alert.addTextField { (textField) in
                textField.keyboardType = .default
                textField.placeholder = "Transaction Note(optional)"
                self.transactionNoteTF = textField
            }
            if(transactionType != .TransactionTypeCreditAuthCompletion) {
                if(transactionType != .TransactionTypeCashRefund && !(transactionType == .TransactionTypeCreditRefund && !(withCardReader || isSCETransaction))){
                    alert.addTextField { (textField) in
                        textField.keyboardType = .default
                        textField.placeholder = "Merchant Invoice ID(optional)"
                        self.invocieIDTF = textField
                    }
                }
                alert.addCheckBoxWithTitle("ShowNoteAndInvoiceOnReceipt") { (checkbox) in
                    self.showNoteAndInvoiceOnReceiptCheckBox = checkbox
                }
            }
        }
        alert.addTextField { (textField) in
            textField.keyboardType = .default
            textField.placeholder = "ClerkID(Optional)"
            self.clerkIDTF = textField
        }
        alert.addTextField { (textField) in
            textField.keyboardType = .numberPad
            textField.placeholder = "Order Number(Optional)"
            self.orderNumberTF = textField
        }
        if (canEnrollToken || canUpdateToken) {
            alert.addTextField { (textField) in
                textField.keyboardType = .numberPad
                textField.placeholder = "Normalized Token Fee(Optional)"
                self.tokenFeeTF = textField
            }
            if (transactionType != .TransactionTypeTokenEnrollment) {
                alert.addCheckBoxWithTitle("Token Enroll") { (checkbox) in
                    checkbox.isSelected = false
                    checkbox.addTarget(self, action: #selector(checkBoxSelected(_:)), for: .touchUpInside)
                    tokenEnrollCheckBox = checkbox
                }
                if (canUpdateToken) {
                    alert.addCheckBoxWithTitle("Token Update") { (checkbox) in
                        checkbox.isSelected = false
                        checkbox.addTarget(self, action: #selector(checkBoxSelected(_:)), for: .touchUpInside)
                        self.tokenUpdateCheckBox = checkbox
                    }
                }
            }
        }
        if (canUpdateToken || isTokenTransaction) {
            alert.addTextField { (textField) in
                textField.keyboardType = .default
                textField.placeholder = "Token Identifier"
                if (self.getLastTokenID() != nil) {
                    textField.text = self.getLastTokenID()
                }
                self.tokenIDTF = textField
            }
        }
        if(transactionType != .TransactionTypeTokenEnrollment) {
            alert.addTextField { (textField) in
                textField.keyboardType = .default
                textField.placeholder = "Custom Reference(Optional)"
                self.customRefTF = textField
            }
        }
        if (isManualKeyed && withCardReader && transactionType != .TransactionTypeCreditRefund) {
            alert.addCheckBoxWithTitle("Request CVV") { (checkbox) in
                checkbox.isSelected = true
                self.cvvCheckBox = checkbox
            }
            alert.addCheckBoxWithTitle("Request AVS") { (checkbox) in
                checkbox.isSelected = false
                self.avsCheckBox = checkbox
            }
        }
        if (checkIfCardPresent) {
            alert.addCheckBoxWithTitle("Card Present") { (checkbox) in
                checkbox.isSelected = false
                self.cardPresentCheckBox = checkbox
            }
        }
        if (transactionType == .TransactionTypeAVSOnly) {
            alert.addTextField { (textField) in
                textField.keyboardType = .default
                textField.placeholder = "AVS Zip Code"
                self.avsZipCodeTF = textField
            }
            alert.addTextField { (textField) in
                textField.keyboardType = .default
                textField.placeholder = "AVS Address)"
                self.avsAddressTF = textField
            }
        }
        alert.addTextField { (textField) in
            textField.keyboardType = .default
            if let locale = Ingenico.sharedInstance()?.preference?.merchantLocale {
                textField.text = locale.identifier
            }else{
                textField.text = "en_US"
            }
            self.localeTF = textField
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (action) in
            if (self.isPerformingPartialAuth) {
                self.voidLastPartialTransaction()
            }
        }
        let okAction = UIAlertAction(title: "OK", style: .default) { (action) in
            if (!self.isSCETransaction) {
                self.showProcessingMessage()
            }
            completion()
            UserDefaults.standard.setValue(self.currencyCodeTF?.text, forKey: "currencyCode")
        }
        alert.addAction(cancelAction)
        alert.addAction(okAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    func getAmount() -> IMSAmount {
        return IMSAmount(total: Int(totalTF?.text ?? "") ?? 0, andSubtotal: Int(subtotalTF?.text ?? "") ?? 0, andTax: Int(taxTF?.text ?? "") ?? 0, andDiscount: Int(discountTF?.text ?? "") ?? 0, andDiscountDescription: "ROAMDiscount", andTip: Int(tipTF?.text ?? "") ?? 0, andCurrency: currencyCodeTF?.text ?? "USD", andSurcharge: Int(surchargeTF?.text ?? "") ?? 0)
    }
    
    func getCard() -> IMSCard {
        return IMSCard(number: "5424180000005550", andExpirationDate: "0150", andCVV: "123", andAVS: "82560", andPOSEntryMode:.POSEntryModeKeyed)
    }

    func getTokenRequestParams() -> IMSTokenRequestParameters? {
        let builder = IMSTokenRequestParametersBuilder()
        builder.tokenReferenceNumber = "test-123"
        builder.tokenFeeInCents = Int(tokenFeeTF!.text ?? "") ?? 0
        builder.cardholderLastName = "appleseed"
        builder.cardholderFirstName = "john"
        builder.billToEmail = "john.appleseed@example.com"
        builder.billToAddress1 = "1 Federal St"
        builder.billToAddress2 = "Suite 1"
        builder.billToCity = "Boston"
        builder.billToState = "MA"
        builder.billToCountry = "USA"
        builder.billToZip = "02110"
        builder.ignoreAVSResult = true
        if ((transactionType == .TransactionTypeTokenEnrollment && canEnrollToken) || tokenEnrollCheckBox?.isSelected == true ) {
            return builder.createTokenEnrollmentRequestParameters()
        }
        else if ((transactionType == .TransactionTypeTokenEnrollment && canUpdateToken) || tokenUpdateCheckBox?.isSelected == true) {
            builder.tokenIdentifier = tokenIDTF?.text
            return builder.createTokenUpdateRequestParameters()
        }
        return nil
    }
    
    // Cash Sale
    func processCashSale() {
        let request = IMSCashSaleTransactionRequest(amount: getAmount(), andProducts: getSampleProducts(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andTransactionGroupID: nil, andTransactionNotes: transactionNoteTF!.text, andMerchantInvoiceID: invocieIDTF!.text, andShowNotesAndInvoiceOnReceipt: showNoteAndInvoiceOnReceiptCheckBox!.isSelected, andIsCompleted: false, andCustomReference: customRefTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processCashTransaction(request, andOnDone: doneCallback!)
    }
    
    // Cash Refund
    func processCashRefund() {
        let request = IMSCashRefundTransactionRequest(originalSaleTransactionID: getLastTransactionID(), andAmount: getAmount(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andCustomReference: customRefTF!.text, andTransactionNotes:transactionNoteTF!.text, andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckBox!.isSelected)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processCashRefundTransaction(request, andOnDone: doneCallback!)
    }
    
    // Keyed credit sale
    func processKeyedCreditSale() {
        let request = IMSKeyedCardSaleTransactionRequest(card: getCard(), andAmount: getAmount(), andProducts: getSampleProducts(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andTransactionGroupID: nil, andTransactionNotes: transactionNoteTF!.text, andMerchantInvoiceID: invocieIDTF!.text, andShowNotesAndInvoiceOnReceipt: showNoteAndInvoiceOnReceiptCheckBox!.isSelected, andTokenRequestParameters: getTokenRequestParams(), andCustomReference: customRefTF!.text, andIsCompleted: false, andUCIFormat: .UCIFormatIngenico, andIsCardPresent: cardPresentCheckBox!.isSelected, andOrderNumber: orderNumberTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processKeyedTransaction(request, andOnDone: doneCallback!)
    }
    
    // Keyed credit auth
    func processKeyedCreditAuth() {
        let request = IMSKeyedCreditAuthTransactionRequest(card: getCard(), andAmount: getAmount(), andProducts: getSampleProducts(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andTransactionGroupID: nil, andTransactionNotes: transactionNoteTF!.text, andMerchantInvoiceID: invocieIDTF!.text, andShowNotesAndInvoiceOnReceipt: showNoteAndInvoiceOnReceiptCheckBox!.isSelected, andTokenRequestParameters: getTokenRequestParams(), andCustomReference: customRefTF!.text, andIsCompleted: false, andUCIFormat: .UCIFormatIngenico, andIsCardPresent: cardPresentCheckBox!.isSelected, andOrderNumber: orderNumberTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processKeyedCreditAuthTransaction(request, andOnDone: doneCallback!)
    }
    
    // Keyed force sale
    func processKeyedCreditForceSale() {
        let request = IMSKeyedCreditForceSaleTransactionRequest(amount: getAmount(), andProducts: getSampleProducts(), andCard: getCard(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andTransactionGroupID: nil, andAuthorizationCode: authCodeTF!.text ?? "", andSystemTraceAuditNumber: Int(stanTF!.text!) ?? -1, andTransactionNotes: transactionNoteTF!.text, andMerchantInvoiceID: invocieIDTF!.text, andShowNotesAndInvoiceOnReceipt: showNoteAndInvoiceOnReceiptCheckBox!.isSelected, andCustomReference: customRefTF!.text, andIsCompleted: false, andUCIFormat: .UCIFormatIngenico, andIsCardPresent: cardPresentCheckBox!.isSelected, andOrderNumber: orderNumberTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processKeyedCreditForceSaleTransaction(request, andOnDone: doneCallback!)
    }
    
    // Keyed Token Enroll
    func processKeyedTokenEnroll() {
        let request = IMSKeyedTokenEnrollmentTransactionRequest(tokenRequestParameters: getTokenRequestParams(), andCard: getCard(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andUCIFormat: .UCIFormatIngenico, andOrderNumber: orderNumberTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processKeyedTokenEnrollment(request, andOnDone: doneCallback!)
    }
    
    // Auth Complete
    func processAuthComplete() {
        let request = IMSCreditAuthCompleteTransactionRequest(originalSaleTransactionID: getLastTransactionID(), andAmount: getAmount(), andProducts: getSampleProducts(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andTransactionGroupID: nil, andCustomReference: customRefTF!.text, andIsCompleted: false, andTransactionNotes: transactionNoteTF!.text, andOrderNumber: orderNumberTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processCreditAuthCompleteTransaction(request, andOnDone: doneCallback!)
    }
    
    // Closed refund
    func processClosedRefund() {
        let request = IMSCreditRefundTransactionRequest(originalSaleTransactionID:  getLastTransactionID(), andAmount: getAmount(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andCustomReference: customRefTF!.text, andTransactionNotes: transactionNoteTF!.text, andOrderNumber: orderNumberTF!.text, andShowNotesAndInvoiceOnReceipt: showNoteAndInvoiceOnReceiptCheckBox!.isSelected)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processCreditRefundAgainstTransaction(request, andOnDone: doneCallback!)
    }
    
    // Token Sale
    func processTokenSale() {
        let request = IMSTokenSaleTransactionRequest(tokenReferenceNumber: "test-123", andTokenIdentifier: tokenIDTF!.text ?? "", andAmount: getAmount(), andProducts: getSampleProducts(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude()!, andLatitude: getLatitude()!, andTransactionGroupID: nil, andTransactionNotes: transactionNoteTF!.text, andMerchantInvoiceID: invocieIDTF!.text, andShowNotesAndInvoiceOnReceipt: showNoteAndInvoiceOnReceiptCheckBox!.isSelected, andCustomReference: customRefTF!.text, andIsCompleted: false, andOrderNumber: orderNumberTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processTokenSaleTransaction(request, andUpdateProgress: progressCallback!, andOnDone: doneCallback!)
    }
    
    // Token Auth
    func processTokenAuth() {
        let request = IMSTokenAuthTransactionRequest(tokenReferenceNumber: "test-123", andTokenIdentifier: tokenIDTF!.text ?? "", andAmount: getAmount(), andProducts: getSampleProducts(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude()!, andLatitude: getLatitude()!, andTransactionGroupID: nil, andTransactionNotes: transactionNoteTF!.text, andMerchantInvoiceID: invocieIDTF!.text, andShowNotesAndInvoiceOnReceipt: showNoteAndInvoiceOnReceiptCheckBox!.isSelected, andCustomReference: customRefTF!.text, andIsCompleted: false, andOrderNumber: orderNumberTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processTokenAuthTransaction(request, andUpdateProgress: progressCallback!, andOnDone: doneCallback!)
    }
    
    // Sale adjust
    func processSaleAdjust() {
        let request = IMSCreditSaleAdjustTransactionRequest(originalSaleTransactionId: getLastTransactionID() ?? "", andAmount: getAmount(), andProducts: getSampleProducts(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andTransactionGroupID: nil, andTransactionNotes: transactionNoteTF!.text, andMerchantInvoiceID: invocieIDTF!.text, andShowNotesAndInvoiceOnReceipt: showNoteAndInvoiceOnReceiptCheckBox!.isSelected, andCustomReference: customRefTF!.text, andIsCompleted: false, andOrderNumber: orderNumberTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processCreditSaleAdjustTransaction(request, andUpdateProgress: progressCallback!, andOnDone: doneCallback!)
    }
    
    // Credit resale
    func processCreditResale() {
        let request = IMSCreditResaleTransactionRequest(originalSaleTransactionID: getLastTransactionID()!, andAmount: getAmount(), andProducts: getSampleProducts(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andTransactionGroupID: nil, andTransactionNotes: transactionNoteTF!.text, andMerchantInvoiceID: invocieIDTF!.text, andShowNotesAndInvoiceOnReceipt: showNoteAndInvoiceOnReceiptCheckBox!.isSelected, andCustomReference: customRefTF!.text, andIsCompleted: false, andTokenRequestParameters: getTokenRequestParams(), andOrderNumber: orderNumberTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processCreditResaleTransaction(request, andUpdateProgress: progressCallback!, andOnDone: doneCallback!)
    }
    
    // Credit reauth
    func processCreditReauth() {
        let request = IMSCreditReauthTransactionRequest(originalSaleTransactionID: getLastTransactionID()!, andAmount: getAmount(), andProducts: getSampleProducts(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andTransactionGroupID: nil, andTransactionNotes: transactionNoteTF!.text, andMerchantInvoiceID: invocieIDTF!.text, andShowNotesAndInvoiceOnReceipt: showNoteAndInvoiceOnReceiptCheckBox!.isSelected, andCustomReference: customRefTF!.text, andIsCompleted: false, andTokenRequestParameters: getTokenRequestParams(), andOrderNumber: orderNumberTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processCreditReauthTransaction(request, andUpdateProgress: progressCallback!, andOnDone: doneCallback!)
    }
    
    // Auth adjust
    func processAuthAdjust() {
        let request = IMSCreditAuthAdjustTransactionRequest(originalSaleTransactionId: getLastTransactionID() ?? "", andAmount: getAmount(), andProducts: getSampleProducts(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andTransactionGroupID: nil, andTransactionNotes: transactionNoteTF!.text, andMerchantInvoiceID: invocieIDTF!.text, andShowNotesAndInvoiceOnReceipt: showNoteAndInvoiceOnReceiptCheckBox!.isSelected, andCustomReference: customRefTF!.text, andIsCompleted: false, andOrderNumber: orderNumberTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processCreditAuthAdjustTransaction(request, andUpdateProgress: progressCallback!, andOnDone: doneCallback!)
    }
    
    // Credit Sale
    func processCreditSale() {
        let request = IMSCreditSaleTransactionRequest(amount: getAmount(), andProducts: getSampleProducts(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andTransactionGroupID: nil, andTransactionNotes: transactionNoteTF!.text, andMerchantInvoiceID: invocieIDTF!.text, andShowNotesAndInvoiceOnReceipt: showNoteAndInvoiceOnReceiptCheckBox!.isSelected, andTokenRequestParameters: getTokenRequestParams(), andCustomReference: customRefTF!.text, andIsCompleted: false, andUCIFormat: .UCIFormatIngenico, andOrderNumber: orderNumberTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processCreditSaleTransaction(withCardReader: request, andUpdateProgress: progressCallback!, andSelectApplication: applicationSelectionCallback!, andOnDone: doneCallback!)
    }
    
    // Debit Sale
    func processDebitSale() {
        let request = IMSDebitSaleTransactionRequest(amount: getAmount(), andProducts: getSampleProducts(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andTransactionGroupID: nil, andTransactionNotes: transactionNoteTF!.text, andMerchantInvoiceID: invocieIDTF!.text, andShowNotesAndInvoiceOnReceipt: showNoteAndInvoiceOnReceiptCheckBox!.isSelected, andCustomReference: customRefTF!.text, andIsCompleted: false, andUCIFormat: .UCIFormatIngenico, andOrderNumber: orderNumberTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processDebitSaleTransaction(withCardReader: request, andUpdateProgress: progressCallback!, andSelectApplication: applicationSelectionCallback!, andOnDone: doneCallback!)
    }
    
    // Sale
    func processSale() {
        let request = IMSSaleTransactionRequest(amount: getAmount(), andProducts: getSampleProducts(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andTransactionGroupID: nil, andTransactionNotes: transactionNoteTF!.text, andMerchantInvoiceID: invocieIDTF!.text, andShowNotesAndInvoiceOnReceipt: showNoteAndInvoiceOnReceiptCheckBox!.isSelected, andTokenRequestParameters: getTokenRequestParams(), andCustomReference: customRefTF!.text, andIsCompleted: false, andUCIFormat: .UCIFormatIngenico, andOrderNumber: orderNumberTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processSaleTransaction(withCardReader: request, andUpdateProgress: progressCallback!, andSelectApplication: applicationSelectionCallback!, andTransactionTypeSelection: transactionTypeSelectionCallback!, andOnDone: doneCallback!)
    }
    
    // Credit Auth
    func processCreditAuth() {
        let request = IMSCreditAuthTransactionRequest(amount: getAmount(), andProducts: getSampleProducts(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andTransactionGroupID: nil, andTransactionNotes: transactionNoteTF!.text, andMerchantInvoiceID: invocieIDTF!.text, andShowNotesAndInvoiceOnReceipt: showNoteAndInvoiceOnReceiptCheckBox!.isSelected, andTokenRequestParameters: getTokenRequestParams(), andCustomReference: customRefTF!.text, andIsCompleted: false, andUCIFormat: .UCIFormatIngenico, andOrderNumber: orderNumberTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processCreditAuthTransaction(withCardReader: request, andUpdateProgress: progressCallback!, andSelectApplication: applicationSelectionCallback!, andOnDone: doneCallback!)
    }
    
    // Credit force sale
    func processCreditForceSale() {
        let request = IMSCreditForceSaleTransactionRequest(amount: getAmount(), andProducts: getSampleProducts(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andTransactionGroupID: nil, andAuthorizationCode: authCodeTF!.text ?? "", andSystemTraceAuditNumber: Int(stanTF!.text ?? "") ?? -1, andTransactionNotes: transactionNoteTF!.text, andMerchantInvoiceID: invocieIDTF!.text, andShowNotesAndInvoiceOnReceipt: showNoteAndInvoiceOnReceiptCheckBox!.isSelected, andCustomReference: customRefTF!.text, andIsCompleted: false, andUCIFormat: .UCIFormatIngenico, andOrderNumber: orderNumberTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processCreditForceSaleTransaction(withCardReader: request, andUpdateProgress: progressCallback!, andSelectApplication: applicationSelectionCallback!, andOnDone: doneCallback!)
    }
    
    // Credit balance inquiry
    func processCreditBalanceInquiry() {
        let request = IMSCreditBalanceInquiryTransactionRequest(clerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andCustomReference: customRefTF!.text, andUCIFormat: .UCIFormatIngenico, andOrderNumber: orderNumberTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processCreditBalanceInquiry(withCardReader: request, andUpdateProgress: progressCallback!, andSelectApplication: applicationSelectionCallback!, andOnDone: doneCallback!)
    }
    
    // Debit balance inquiry
    func processDebitBlanceInquiry() {
        let request = IMSDebitBalanceInquiryTransactionRequest(clerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andCustomReference: customRefTF!.text, andUCIFormat: .UCIFormatIngenico, andOrderNumber: orderNumberTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processDebitBalanceInquiry(withCardReader: request, andUpdateProgress: progressCallback!, andSelectApplication: applicationSelectionCallback!, andOnDone: doneCallback!)
    }
    
    // Balance inquiry (auto)
    func processBalanceInquiry() {
        let request = IMSBalanceInquiryTransactionRequest(clerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andCustomReference: customRefTF!.text, andUCIFormat: .UCIFormatIngenico, andOrderNumber: orderNumberTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processBalanceInquiry(withCardReader: request, andUpdateProgress: progressCallback!, andSelectApplication: applicationSelectionCallback!, andTransactionTypeSelection: transactionTypeSelectionCallback!, andOnDone: doneCallback!)
    }
    
    // Debit refund
    func processDebitRefund() {
        let request = IMSDebitCardRefundTransactionRequest(amount: getAmount(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andTransactionNotes: transactionNoteTF!.text, andMerchantInvoiceID: invocieIDTF!.text, andShowNotesAndInvoiceOnReceipt: showNoteAndInvoiceOnReceiptCheckBox!.isSelected, andCustomReference: customRefTF!.text, andUCIFormat: .UCIFormatIngenico, andOrderNumber: orderNumberTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processDebitRefund(withCardReader: request, andUpdateProgress: progressCallback!, andSelectApplication: applicationSelectionCallback!, andOnDone: doneCallback!)
    }
    
    // open credit refund
    func processCreditRefund() {
        let request = IMSCreditCardRefundTransactionRequest(amount: getAmount(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andTransactionNotes: transactionNoteTF!.text, andMerchantInvoiceID: invocieIDTF!.text, andShowNotesAndInvoiceOnReceipt: showNoteAndInvoiceOnReceiptCheckBox!.isSelected, andCustomReference: customRefTF!.text, andTokenRequestParameters: getTokenRequestParams(), andUCIFormat: .UCIFormatIngenico, andOrderNumber: orderNumberTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processCreditRefund(withCardReader: request, andUpdateProgress: progressCallback!, andSelectApplication: applicationSelectionCallback!, andOnDone: doneCallback!)
    }
    
    // token enroll
    func processTokenEnroll() {
        let request = IMSTokenEnrollmentTransactionRequest(tokenRequestParameters: getTokenRequestParams(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andUCIFormat: .UCIFormatIngenico, andOrderNumber: orderNumberTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processTokenEnrollment(withCardReader: request, andUpdateProgress: progressCallback!, andSelectApplication: applicationSelectionCallback!, andOnDone: doneCallback!)
    }
    
    // keyed credit sale with reader
    func processKeyedCreditSaleWithReader() {
        let request = IMSKeyedCardSaleTransactionWithCardReaderRequest(amount: getAmount(), andProducts: getSampleProducts(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andTransactionGroupID: nil, andTransactionNotes: transactionNoteTF!.text, andMerchantInvoiceID: invocieIDTF!.text, andShowNotesAndInvoiceOnReceipt: showNoteAndInvoiceOnReceiptCheckBox!.isSelected, andTokenRequestParameters: getTokenRequestParams(), andCustomReference: customRefTF!.text, andIsCompleted: false, andIsCardAVSRequested: avsCheckBox!.isSelected, andIsCardCVVRequested: cvvCheckBox!.isSelected, andUCIFormat: .UCIFormatIngenico, andIsCardPresent: cardPresentCheckBox!.isSelected, andOrderNumber: orderNumberTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processKeyedTransaction(withCardReader: request, andUpdateProgress: progressCallback!, andOnDone: doneCallback!)
    }
    
    // keyed credit Auth with reader
    func processKeyedCreditAuthWithReader() {
        let request = IMSKeyedCreditAuthTransactionWithCardReaderRequest(amount: getAmount(), andProducts: getSampleProducts(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andTransactionGroupID: nil, andTransactionNotes: transactionNoteTF!.text, andMerchantInvoiceID: invocieIDTF!.text, andShowNotesAndInvoiceOnReceipt: showNoteAndInvoiceOnReceiptCheckBox!.isSelected, andTokenRequestParameters: getTokenRequestParams(), andCustomReference: customRefTF!.text, andIsCompleted: false, andIsCardAVSRequested: avsCheckBox!.isSelected, andIsCardCVVRequested: cvvCheckBox!.isSelected, andUCIFormat: .UCIFormatIngenico, andIsCardPresent: cardPresentCheckBox!.isSelected, andOrderNumber: orderNumberTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processKeyedCreditAuthTransaction(withCardReader: request, andUpdateProgress: progressCallback!, andOnDone: doneCallback!)
    }
    
    // keyed credit Refund with reader
    func processKeyedCreditRefundWithReader() {
        let request = IMSKeyedCreditRefundTransactionWithCardReaderRequest(amount: getAmount(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andTransactionNotes: transactionNoteTF!.text, andMerchantInvoiceID: invocieIDTF!.text, andShowNotesAndInvoiceOnReceipt: showNoteAndInvoiceOnReceiptCheckBox!.isSelected, andTokenRequestParameters: getTokenRequestParams(), andCustomReference: customRefTF!.text, andUCIFormat: IMSUCIFormat.UCIFormatIngenico, andIsCardPresent: cardPresentCheckBox!.isSelected, andOrderNumber: orderNumberTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processKeyedCreditRefundTransaction(withCardReader: request, andUpdateProgress: progressCallback!, andOnDone: doneCallback!)
    }
    
    // keyed token enroll/update with reader
    func processKeyedTokenEnrollmentWithReader() {
        let request = IMSKeyedTokenEnrollmentWithCardReaderTransactionRequest(tokenRequestParameters: getTokenRequestParams(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andUCIFormat: IMSUCIFormat.UCIFormatIngenico, andOrderNumber: orderNumberTF!.text, andIsCardCVVRequested: cvvCheckBox!.isSelected, andIsCardAVSRequested: avsCheckBox!.isSelected, andIsCardPresent: cardPresentCheckBox!.isSelected)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processKeyedTokenEnrollmentTransaction(withCardReader: request, andUpdateProgress: progressCallback!, andOnDone: doneCallback!)
    }
    
    //AVS only
    func processAvsOnly() {
        let request = IMSAVSOnlyTransactionRequest(clerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andCustomReference: customRefTF!.text, andUCIFormat: .UCIFormatIngenico, andAVSZipCode: avsZipCodeTF!.text, andAVSAddress: avsAddressTF!.text, andOrderNumber: orderNumberTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processAVSOnlyTransaction(withCardReader: request, andUpdateProgress: progressCallback!, andSelectApplication: applicationSelectionCallback!, andOnDone: doneCallback!)
    }
    
    // refund
    func processRefund() {
        let request = IMSRefundTransactionRequest(amount: getAmount(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andTransactionNotes: transactionNoteTF!.text, andMerchantInvoiceID: invocieIDTF!.text, andShowNotesAndInvoiceOnReceipt: showNoteAndInvoiceOnReceiptCheckBox!.isSelected, andCustomReference: customRefTF!.text, andTokenRequestParameters: getTokenRequestParams(), andUCIFormat: .UCIFormatIngenico, andOrderNumber: orderNumberTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.payment.processRefundTransaction(withCardReader: request, andUpdateProgress: progressCallback!, andSelectApplication: applicationSelectionCallback!, andTransactionTypeSelection: transactionTypeSelectionCallback!, andOnDone: doneCallback!)
    }
    
    // get pending transactions
    func getPendingTransactions() {
        self.showProgressMessage("Getting pending Transactions...")
        Ingenico.sharedInstance()?.payment.getPendingTransactions({ (transactions, error) in
            if (error == nil) {
                self.pendingTransactions = transactions as! [IMSPendingTransaction]
                self.showSucess( "Success")
                self.consoleLog("getPendingTransactions success")
            }
            else {
                self.showError("Failed")
                self.consoleLog("Get pending transactions failed with \((error! as NSError).code)")
            }
        })
    }
    
    // ignore pending transactions
    func ignorePendingTransactions() {
        if (pendingTransactions.count == 0) {
            self.showError("Do getPendingTransactions first")
        }
        else {
            self.showProgressMessage("Ignoring pending Transactions...")
            for txn in pendingTransactions{
                Ingenico.sharedInstance()?.payment.ignorePendingTransaction(txn.clientTransactionId)
            }
            self.showSucess( "Success")
        }
        pendingTransactions = []
    }
    
    // reverse pending transactions
    func reversePendingtransactions() {
        self.showProgressMessage("Reversing pending Transactions...")
        Ingenico.sharedInstance()?.payment.reverseAllPendingTransactions(withRetryCounter: 10, andOnDone: { (error) in
            if (error == nil) {
                self.showSucess( "Success")
                self.consoleLog("reversePendingtransactions success")
            }
            else {
                self.showError("Failed")
                self.consoleLog("reversePendingtransactions failed with \((error! as NSError).code)")
            }
        })
    }
    
    func reverseSingleTransaction() {
        Ingenico.sharedInstance()?.payment.getPendingTransactions({ (transactions, error) in
            if (error == nil) {
                let pendingTransactions = transactions as! [IMSPendingTransaction]
                let viewcontroller:UIAlertController = UIAlertController.init(title: "Select Pending Transaction", message: "Make your choice", preferredStyle: .actionSheet)
                for txn in pendingTransactions {
                    let okAction:UIAlertAction = UIAlertAction.init(title: txn.clientTransactionId, style: .default, handler: { (action) in
                        
                        viewcontroller.dismiss(animated: true, completion: nil)
                        self.showProgressMessage("Reversing pending Transaction...")
                        Ingenico.sharedInstance()?.payment.reversePendingTransaction(txn.clientTransactionId, andOnDone: { (error) in
                            self.dismissProgress()
                            self.showResult("Completed \(self.getResponseCodeString((error! as NSError).code))", isSucess: true);
                            self.consoleLog("reversePendingtransactions completed with \((error! as NSError).code)")
                        })
                    })
                    viewcontroller.addAction(okAction)
                }
                let cancel = UIAlertAction(title: "Cancel", style: .cancel) { (action) in
                    
                }
                viewcontroller.addAction(cancel)
                self.present(viewcontroller, animated: true, completion: nil)
            }
            else {
                self.showError("Failed")
                self.consoleLog("Get pending transactions failed with \((error! as NSError).code)")
            }
        })
    }
    
    // process SCE credit sale
    func processSceCreditSale() {
        let request = IMSSCECreditSaleTransactionRequest(amount: getAmount(), andProducts: getSampleProducts(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andLocale: NSLocale.current, andTransactionGroupID: nil, andTransactionNotes: transactionNoteTF!.text, andMerchantInvoiceID: invocieIDTF!.text, andShowNotesAndInvoiceOnReceipt: showNoteAndInvoiceOnReceiptCheckBox!.isSelected, andTokenRequestParameters: getTokenRequestParams(), andCustomReference: customRefTF!.text, andIsCompleted: false, andUCIFormat: .UCIFormatIngenico, andIsCardPresent: cardPresentCheckBox!.isSelected, andOrderNumber: orderNumberTF!.text)!
        let vc = IMSSecureCardEntryViewController(creditSaleTransactionRequest: request,
                                                  andUpdateProgress: { (message, additionalMessage) in
                                                        self.consoleLog(self.getProgressStrFromMessage(message))
                                                    },
                                                  andOnDone: doneCallback!)!
        showSecureCardEntryView(vc)
    }
    
    // process SCE credit auth
    func processSceCreditAuth() {
        let request = IMSSCECreditAuthTransactionRequest(amount: getAmount(), andProducts: getSampleProducts(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andLocale: NSLocale.current, andTransactionGroupID: nil, andTransactionNotes: transactionNoteTF!.text, andMerchantInvoiceID: invocieIDTF!.text, andShowNotesAndInvoiceOnReceipt: showNoteAndInvoiceOnReceiptCheckBox!.isSelected, andTokenRequestParameters: getTokenRequestParams(), andCustomReference: customRefTF!.text, andIsCompleted: false, andUCIFormat: .UCIFormatIngenico, andIsCardPresent: cardPresentCheckBox!.isSelected, andOrderNumber: orderNumberTF!.text)!
        let vc = IMSSecureCardEntryViewController(creditAuthTransactionRequest: request,
                                                  andUpdateProgress: { (message, additionalMessage) in
                                                        self.consoleLog(self.getProgressStrFromMessage(message))
                                                    },
                                                  andOnDone: doneCallback!)!
        showSecureCardEntryView(vc)
    }
    
    // process SCE credit refund
    func processSceCreditRefund() {
        let request = IMSSCECreditRefundTransactionRequest(amount: getAmount(), andClerkID: clerkIDTF!.text, andLongitude: getLongitude(), andLatitude: getLatitude(), andTransactionNotes: transactionNoteTF!.text, andMerchantInvoiceID: invocieIDTF!.text, andShowNotesAndInvoiceOnReceipt: showNoteAndInvoiceOnReceiptCheckBox!.isSelected, andCustomReference: customRefTF!.text, andTokenRequestParameters: getTokenRequestParams(), andUCIFormat: .UCIFormatIngenico, andIsCardPresent: cardPresentCheckBox!.isSelected, andOrderNumber: orderNumberTF!.text)!
        let vc = IMSSecureCardEntryViewController(creditRefundTransactionRequest: request,
                                                  andUpdateProgress: { (message, additionalMessage) in
                                                        self.consoleLog(self.getProgressStrFromMessage(message))
                                                    },
                                                  andOnDone: doneCallback!)!
        showSecureCardEntryView(vc)
    }
    
    //VAS Only
    func processVasOnlyTransaction() {
        self.showProgressMessage("Processing VAS Only transaction...")
        Ingenico.sharedInstance()?.payment.processVasOnlyTransaction(cardReader: progressCallback!, andOnDone: { (response, error) in
            self.dismissProgress()
            self.showResponse(response, error: error as NSError?)
        })
    }
}

// MARK: UITableView Implementation
extension PaymentAPIViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let sectionTitle = (staticDataArray[section] as NSDictionary).allKeys[0] as! String
        return staticDataArray[section][sectionTitle]!.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        resetTransactionProperties()
        switch indexPath.section {
        case 0:
            //Cash Transactions
            switch indexPath.row {
            case 0:
                alertTitle = "Cash Sale"
                transactionType = .TransactionTypeCashSale
                showFormAlert {
                    self.processCashSale()
                }
            case 1:
                if (self .getLastTransactionID() == nil || self.getLastTransactionType() != .TransactionTypeCashSale) {
                    self.showErrorMessage("Please do a cash sale first", andErrorTitle: "Error")
                }
                else {
                    alertTitle = "Cash Refund"
                    transactionType = .TransactionTypeCashRefund
                    showFormAlert {
                        self.processCashRefund()
                    }
                }
            default:
                break
            }
        // Transaction without card reader
        case 1:
            switch indexPath.row {
            case 0:
                //Keyed sale
                alertTitle = "Keyed Credit Sale"
                transactionType = .TransactionTypeCreditSale
                checkIfCardPresent = true
                canEnrollToken = true
                canUpdateToken = true
                showFormAlert {
                    self.processKeyedCreditSale()
                }
            case 1:
                //Keyed auth
                alertTitle = "Keyed Credit Auth"
                transactionType = .TransactionTypeCreditAuth
                checkIfCardPresent = true
                canEnrollToken = true
                canUpdateToken = true
                showFormAlert {
                    self.processKeyedCreditAuth()
                }
            case 2:
                // Keyed force sale
                alertTitle = "Keyed Credit Force Sale"
                transactionType = .TransactionTypeCreditForceSale
                checkIfCardPresent = true
                showFormAlert {
                    self.processKeyedCreditForceSale()
                }
            case 3:
                // keyed token enrollment
                alertTitle = "Keyed Token Enrollment"
                transactionType = .TransactionTypeTokenEnrollment
                canEnrollToken = true
                showFormAlert {
                    self.processKeyedTokenEnroll()
                }
            case 4:
                //keyed token update
                alertTitle = "Keyed Token Update"
                transactionType = .TransactionTypeTokenEnrollment
                canUpdateToken = true
                showFormAlert {
                    self.processKeyedTokenEnroll()
                }
            case 5:
                //auth complete
                if (self .getLastTransactionID() == nil) {
                    self.showErrorMessage("Please do a credit auth first", andErrorTitle: "Error")
                }
                else {
                    alertTitle = "Credit Auth Completion"
                    transactionType = .TransactionTypeCreditAuthCompletion
                    showFormAlert {
                        self.processAuthComplete()
                    }
                }
            case 6:
                //credit refund against transaction
                if (self .getLastTransactionID() == nil) {
                    self.showErrorMessage("Please do a transaction first", andErrorTitle: "Error")
                }
                else {
                    alertTitle = "Closed Credit Refund"
                    transactionType = .TransactionTypeCreditRefund
                    showFormAlert {
                        self.processClosedRefund()
                    }
                }
            case 7:
                //void transaction
                alertTitle = "Void"
                doVoidTransaction(false)
            case 8:
                //token sale
                if (self .getLastTokenID() == nil) {
                    self.showErrorMessage("Please enroll a token first", andErrorTitle: "Error")
                }
                else {
                    alertTitle = "Token Sale"
                    transactionType = .TransactionTypeCreditSale
                    isTokenTransaction = true
                    showFormAlert {
                        self.processTokenSale()
                    }
                }
            case 9:
                //credit sale adjust
                if (self .getLastTransactionID() == nil) {
                    self.showErrorMessage("Please do a credit sale first", andErrorTitle: "Error")
                }
                else {
                    alertTitle = "Credit Sale Adjust"
                    transactionType = .TransactionTypeCreditSaleAdjust
                    showFormAlert {
                        self.processSaleAdjust()
                    }
                }
            case 10:
                //partial auth
                alertTitle = "Partial Auth"
                transactionType = .TransactionTypeCreditSale
                isPartialAuth = true
                checkIfCardPresent = true
                canEnrollToken = true
                canUpdateToken = true
                showFormAlert {
                    self.processKeyedCreditSale()
                }
            case 11:
                //credit re-sale
                if (self .getLastTransactionID() == nil) {
                    self.showErrorMessage("Please do a credit sale first", andErrorTitle: "Error")
                }
                else {
                    alertTitle = "Credit Resale"
                    transactionType = .TransactionTypeCreditSale
                    isResale = true
                    canEnrollToken = true
                    canUpdateToken = true
                    showFormAlert {
                        self.processCreditResale()
                    }
                }
            case 12:
                //credit re-auth
                if (self .getLastTransactionID() == nil) {
                    self.showErrorMessage("Please do a credit auth first", andErrorTitle: "Error")
                }
                else {
                    alertTitle = "Credit Reauth"
                    transactionType = .TransactionTypeCreditAuth
                    isReauth = true
                    canEnrollToken = true
                    canUpdateToken = true
                    showFormAlert {
                        self.processCreditReauth()
                    }
                }
            case 13:
                //credit auth adjust
                if (self .getLastTransactionID() == nil) {
                    self.showErrorMessage("Please do a credit auth first", andErrorTitle: "Error")
                }
                else {
                    alertTitle = "Credit Auth Adjust"
                    transactionType = .TransactionTypeCreditAuthAdjust
                    showFormAlert {
                        self.processAuthAdjust()
                    }
                }
            case 14:
                //partial void
                alertTitle = "Partial void"
                doPartialVoidTransaction()
            case 15:
            //token auth
            if (self .getLastTokenID() == nil) {
                self.showErrorMessage("Please enroll a token first", andErrorTitle: "Error")
            }
            else {
                alertTitle = "Token Auth"
                transactionType = .TransactionTypeCreditAuth
                isTokenTransaction = true
                showFormAlert {
                    self.processTokenAuth()
                }
            }
            default:
                break
            }
        // Transaction with card reader
        case 2:
            withCardReader = true
            switch indexPath.row {
            case 0:
                //credit sale
                alertTitle = "Credit Sale"
                transactionType = .TransactionTypeCreditSale
                canEnrollToken = true
                canUpdateToken = true
                showFormAlert {
                    self.processCreditSale()
                }
            case 1:
                //credit auth
                alertTitle = "Credit Auth"
                transactionType = .TransactionTypeCreditAuth
                canEnrollToken = true
                canUpdateToken = true
                showFormAlert {
                    self.processCreditAuth()
                }
            case 2:
                //credit force sale
                alertTitle = "Credit Force Sale"
                transactionType = .TransactionTypeCreditForceSale
                showFormAlert {
                    self.processCreditForceSale()
                }
            case 3:
                //credit balance inquiry
                alertTitle = "Credit Balance Inquiry"
                transactionType = .TransactionTypeCreditBalanceInquiry
                showFormAlert {
                    self.processCreditBalanceInquiry()
                }
            case 4:
                //debit sale
                alertTitle = "Debit Sale"
                transactionType = .TransactionTypeDebitSale
                showFormAlert {
                    self.processDebitSale()
                }
            case 5:
                //debit refund
                alertTitle = "Debit Refund"
                transactionType = .TransactionTypeDebitRefund
                showFormAlert {
                    self.processDebitRefund()
                }
            case 6:
                //credit refund
                alertTitle = "Open Credit Refund"
                transactionType = .TransactionTypeCreditRefund
                canEnrollToken = true
                canUpdateToken = true
                showFormAlert {
                    self.processCreditRefund()
                }
            case 7:
                //keyed transaction
                alertTitle = "Keyed Credit Sale With Card Reader"
                transactionType = .TransactionTypeCreditSale
                canEnrollToken = true
                canUpdateToken = true
                isManualKeyed = true
                checkIfCardPresent = true
                showFormAlert {
                    self.processKeyedCreditSaleWithReader()
                }
            case 8:
                //token enrollment
                alertTitle = "Token Enrollment"
                transactionType = .TransactionTypeTokenEnrollment
                canEnrollToken = true
                showFormAlert {
                    self.processTokenEnroll()
                }
            case 9:
                //token update
                alertTitle = "Token Update"
                transactionType = .TransactionTypeTokenEnrollment
                canUpdateToken = true
                showFormAlert {
                    self.processTokenEnroll()
                }
            case 10:
                //debit balance inquiry
                alertTitle = "Debit Balance Inquiry"
                transactionType = .TransactionTypeDebitBalanceInquiry
                showFormAlert {
                    self.processDebitBlanceInquiry()
                }
            case 11:
                //AVS only
                alertTitle = "AVS Only"
                transactionType = .TransactionTypeAVSOnly
                showFormAlert {
                    self.processAvsOnly()
                }
            case 12:
                //sale
                alertTitle = "Sale"
                transactionType = .TransactionTypeSale
                canEnrollToken = true
                canUpdateToken = true
                showFormAlert {
                    self.processSale()
                }
            case 13:
                //refund
                alertTitle = "Refund"
                canEnrollToken = true
                canUpdateToken = true
                transactionType = .TransactionTypeRefund
                showFormAlert {
                    self.processRefund()
                }
            case 14:
                //balance inquiry
                alertTitle = "Balance Inquiry"
                transactionType = .TransactionTypeBalanceInquiry
                showFormAlert {
                    self.processBalanceInquiry()
                }
            case 15:
                //Keyed Credit auth
                alertTitle = "Keyed Credit Auth With Card Reader"
                transactionType = .TransactionTypeCreditAuth
                canEnrollToken = true
                canUpdateToken = true
                isManualKeyed = true
                checkIfCardPresent = true
                showFormAlert {
                    self.processKeyedCreditAuthWithReader()
                }
            case 16:
                //Keyed Credit refund
                alertTitle = "Keyed Credit Refund With Card Reader"
                transactionType = .TransactionTypeCreditRefund
                canEnrollToken = true
                canUpdateToken = true
                isManualKeyed = true
                checkIfCardPresent = true
                showFormAlert {
                    self.processKeyedCreditRefundWithReader()
                }
            case 17:
                //Manual Keyed token enroll
                alertTitle = "Keyed Token Enroll With Card Reader"
                transactionType = .TransactionTypeTokenEnrollment
                canEnrollToken = true
                isManualKeyed = true
                checkIfCardPresent = true
                showFormAlert {
                    self.processKeyedTokenEnrollmentWithReader()
                }
            case 18:
                //Manual Keyed token update
                alertTitle = "Keyed Token Update With Card Reader"
                transactionType = .TransactionTypeTokenEnrollment
                canUpdateToken = true
                isManualKeyed = true
                checkIfCardPresent = true
                showFormAlert {
                    self.processKeyedTokenEnrollmentWithReader()
                }
            case 19:
                // VAS Only
                alertTitle = "VAS Only"
                self.processVasOnlyTransaction()
            case 20:
                // Void with card reader
                alertTitle = "Void Transaction with card reader"
                self.doVoidTransaction(true);
            default:
                break
            }
        // Manage pending transactions
        case 3:
            switch indexPath.row {
            case 0:
                //get pending transactions
                getPendingTransactions()
            case 1:
                //ignore pending transactions
                ignorePendingTransactions()
            case 2:
                //reverse pending transaction
                reversePendingtransactions()
            case 3:
                //ignore reversal before transaction
                self.ignoreReversalBeforeTransaction = true
                Ingenico.sharedInstance()?.payment.ignorePendingReversalsBeforeNextTransaction()
            case 4:
                reverseSingleTransaction()
            default:
                break
            }
        // SCE
        case 4:

            isSCETransaction = true
            isManualKeyed = true
            canEnrollToken = true
            canUpdateToken = true
            checkIfCardPresent = true
            switch indexPath.row {
            case 0:
                // Model view - Credit Sale
                isViewController = false
                alertTitle = "Secure Card Entry Credit Sale"
                transactionType = .TransactionTypeCreditSale
                showFormAlert {
                    self.processSceCreditSale()
                }
            case 1:
                // View controller - Credit Sale
                isViewController = true
                alertTitle = "Secure Card Entry Credit Sale"
                transactionType = .TransactionTypeCreditSale
                showFormAlert {
                    self.processSceCreditSale()
                }
            case 2:
                // Model view - Credit Auth
                isViewController = false
                alertTitle = "Secure Card Entry Credit Auth"
                transactionType = .TransactionTypeCreditAuth
                showFormAlert {
                    self.processSceCreditAuth()
                }
            case 3:
                // View controller - Credit Auth
                isViewController = true
                alertTitle = "Secure Card Entry Credit Auth"
                transactionType = .TransactionTypeCreditAuth
                showFormAlert {
                    self.processSceCreditAuth()
                }
            case 4:
            // Model view - Credit Refund
                isViewController = false
                alertTitle = "Secure Card Entry Credit Refund"
                transactionType = .TransactionTypeCreditRefund
                showFormAlert {
                    self.processSceCreditRefund()
                }
            case 5:
                // View controller - Credit Refund
                isViewController = true
                alertTitle = "Secure Card Entry Credit Refund"
                transactionType = .TransactionTypeCreditRefund
                showFormAlert {
                    self.processSceCreditRefund()
                }
            default:
                break
            }
        //Load testing
        case 5:
            doTestTransactionWithNumber(0)
        case 6:
            switch indexPath.row {
            case 0:
                getCurrentCapabilities()
            case 1:
                updatePreference()
            default:
                break
            }
        default:
            break
        }
        tableView.deselectRow(at: indexPath, animated: false)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.paymentAPITableView.dequeueReusableCell(withIdentifier: "Cell")! as UITableViewCell
        let sectionTitle = (staticDataArray[indexPath.section] as NSDictionary).allKeys[0] as! String
        cell.textLabel?.text = staticDataArray[indexPath.section][sectionTitle]?[indexPath.row]
        cell.textLabel?.textAlignment = .center
        cell.selectionStyle = .default
        return cell
    }
        
    func numberOfSections(in tableView: UITableView) -> Int {
        return staticDataArray.count
    }
        
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        let sectionTitle = (staticDataArray[section] as NSDictionary).allKeys[0] as! String
        return sectionTitle
    }
}

