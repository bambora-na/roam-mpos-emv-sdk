//
//  SetupViewController.swift
//  EMVSDKSwiftTestApp
//
//  Created by Mallikarjun Patil on 9/8/16.
//  Copyright © 2016 Ingenico. All rights reserved.
//

import UIKit
import UserNotifications

class SetupViewController: IMSBaseViewController, RUAPairingListener, RUADeviceSearchListener, UITableViewDelegate, UITableViewDataSource, UIPickerViewDelegate, UIPickerViewDataSource, UNUserNotificationCenterDelegate, UITextFieldDelegate, RUADebugLogListener, DropDownMenuDelegate {
    
    @IBOutlet weak var baseURLTextField: UITextField!
    @IBOutlet weak var apiKeyTextField: UITextField!
    

    @IBOutlet weak var ajAutodetectSwitch: UISwitch!
    
    @IBOutlet weak var btCommInterfaceSwitch: UISwitch!
    @IBOutlet weak var ajCommInterfaceSwitch: UISwitch!
    @IBOutlet weak var usbCommInterfaceSwitch: UISwitch!
    
    @IBOutlet weak var deviceTypePickerView: UIPickerView!
    
    @IBOutlet weak var configModePicker: UIPickerView!
    
    @IBOutlet weak var retryCountPicker: UIPickerView!
    
    @IBOutlet weak var localePicker: UIPickerView!
    
    @IBOutlet weak var searchView: UIView!
    @IBOutlet weak var pairingView: UIStackView!
    
    @IBOutlet weak var searchTableView: UITableView!
    
    fileprivate var ingenico:Ingenico!
    fileprivate var deviceList:[RUADevice] = []
    fileprivate var isConnected=false
    
    fileprivate var baseUrlListMenu:DropDownMenu?
    
    fileprivate var refreshControl = UIRefreshControl()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ingenico = Ingenico.sharedInstance()
        deviceList = [RUADevice]()
        deviceStatusBarButton = UIBarButtonItem(customView: getDeviceStatusImage())
        deviceTypePickerView.delegate = self
        deviceTypePickerView.dataSource = self
        configModePicker.delegate = self
        configModePicker.dataSource = self
        retryCountPicker.delegate = self
        retryCountPicker.dataSource = self
        localePicker.delegate = self
        localePicker.dataSource = self
        apiKeyTextField.delegate = self
        baseURLTextField.delegate = self
        refreshControl.addTarget(self, action: #selector(doSearching), for: .valueChanged)
        searchTableView.delegate = self
        searchTableView.dataSource = self
        searchTableView.addSubview(refreshControl)
    }
    
    
    override func  viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        DeviceManagementHelper.shared.autoconnectionEnabled = false
        self.navigationItem.rightBarButtonItems = [UIBarButtonItem(title: "Setup", style: .plain, target: self, action: #selector(rightNavBtnTapped)),
                                                   deviceStatusBarButton!]
        if let urlValue = UserDefaults.standard.value(forKey: "DefaultURL"){
            baseURLTextField.text=urlValue as? String;
        }
        else {
            baseURLTextField.text = Constant.BASE_URL
        }
        apiKeyTextField.text = Constant.API_KEY
        if UserDefaults.standard.object(forKey: "isFirstTimeUser") == nil || UserDefaults.standard.bool(forKey: "isFirstTimeUser") == true {
            UserDefaults.standard.set(false, forKey: "isFirstTimeUser")
            let introductionViewController: IntroductionViewController = storyboard?.instantiateViewController(withIdentifier: "introductionvc") as! IntroductionViewController
            self.present(introductionViewController, animated: true, completion: nil)
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        DeviceManagementHelper.shared.autoconnectionEnabled = true
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if (Constant.API_KEY.count == 0 ||
            Constant.API_KEY == "Set your API key here") {
            let alertController:UIAlertController  = UIAlertController.init(title: "API key missing", message: "If you have an API Key, please set  API_KEY in Constants.swift file. If not, please contact apisupport.us@ingenico.com to obtain a key.", preferredStyle:.alert)
            let action:UIAlertAction = UIAlertAction.init(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(action)
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    @IBAction func diagonosticsSwitchToggled(_ sender: UISwitch) {
        Ingenico.sharedInstance()?.sendDiagnostics(sender.isOn)
    }
    
    
    @objc func rightNavBtnTapped()  {
        
        if (self.navigationItem.rightBarButtonItem!.title == "Setup") {
            self.navigationItem.rightBarButtonItem!.title = ""
            if (baseURLTextField.text != nil) {
                UserDefaults.standard.setValue(baseURLTextField.text, forKey: "DefaultURL")
                var urls:Set<String> = []
                var data:Data? = UserDefaults.standard.object(forKey: "urlList") as? Data
                if (data != nil){
                    urls = NSKeyedUnarchiver.unarchiveObject(with: data!) as! Set<String>
                }
                urls.insert(baseURLTextField.text!)
                data = NSKeyedArchiver.archivedData(withRootObject: urls)
                UserDefaults.standard.setValue(data, forKey: "urlList")
                UserDefaults.standard.synchronize()
            }
            let preference = IMSPreference();
            let selectedIndex = configModePicker.selectedRow(inComponent: 0);
            if(selectedIndex == 3){
                self.setIsConfigModeSet(false);
                ingenico.initialize(withBaseURL: baseURLTextField.text!,
                                apiKey: apiKeyTextField.text!,
                                clientVersion: Constant.CLIENT_VERSION)
            }else{
                switch selectedIndex {
                case 0:
                    preference.configMode = IMSConfigMode.manual
                    break;
                case 1:
                    preference.configMode = IMSConfigMode.optimal
                    break;
                case 2:
                    preference.configMode = IMSConfigMode.auto
                    break;
                default:
                    break;
                }
                let selectedIndex = retryCountPicker.selectedRow(inComponent: 0);
                preference.retryCount = UInt(selectedIndex)
                let selectedLocaleIndex = localePicker.selectedRow(inComponent: 0);
                switch selectedLocaleIndex {
                case 0:
                    preference.merchantLocale = Locale(identifier: "en_US")
                    break;
                case 1:
                    preference.merchantLocale = Locale(identifier: "en_CA")
                    break;
                case 2:
                    preference.merchantLocale = Locale(identifier: "fr_CA")
                    break;
                default:
                    preference.merchantLocale = Locale(identifier: "en_US")
                    break;
                }
                self.setIsConfigModeSet(true);
                ingenico.initialize(withBaseURL: baseURLTextField.text!, apiKey: apiKeyTextField.text!, clientVersion: Constant.CLIENT_VERSION, timeout: 60, preference: preference)
            }
            ingenico.setLogging(true)
            ingenico.setCustomLogger(self)
            if ajAutodetectSwitch.isOn {
                let devicesList: [NSNumber] = [ NSNumber.init(value: RUADeviceTypeRP450c.rawValue as UInt32)];
                ingenico.paymentDevice.setDeviceTypes(devicesList)
                let loginVC:LoginViewController = self.storyboard?.instantiateViewController(withIdentifier: "loginVC") as! LoginViewController
                self.navigationController?.pushViewController(loginVC, animated: false)
                ingenico.paymentDevice.initialize(self)
            } else {
                showSearchView()
            }
        }
    }

    @objc func goBack()  {
        ingenico.paymentDevice.stopSearch()
        UIView.transition(with: self.view, duration: 0.3, options: .transitionFlipFromLeft, animations: {
            self.searchView.removeFromSuperview()
            self.deviceList.removeAll()
            self.navigationItem.rightBarButtonItem?.title="Setup"
            }, completion: nil)
        self.navigationItem.leftBarButtonItem=nil
    }
    
    func showSearchView()  {
        
        UIView.transition(with: self.view, duration: 0.5, options: .transitionFlipFromLeft, animations: {
            let frame: CGRect  = self.view.frame
            self.navigationItem.leftBarButtonItem = UIBarButtonItem.init(title: "Back", style: .plain, target: self, action: #selector(self.goBack))

            self.searchView.frame = CGRect(x: 0, y: 0, width: frame.size.width, height: frame.size.height)
            
            self.pairingView.isHidden = true
            switch self.deviceTypePickerView.selectedRow(inComponent: 0) {
            case 0:
                self.pairingView.isHidden = false
                self.ingenico.paymentDevice.setDeviceType(RUADeviceTypeRP450c)
            case 1:
                self.ingenico.paymentDevice.setDeviceType(RUADeviceTypeRP750x)
            case 2:
                self.ingenico.paymentDevice.setDeviceType(RUADeviceTypeMOBY3000)
            case 3:
                self.ingenico.paymentDevice.setDeviceType(RUADeviceTypeRP45BT)
            case 4:
                self.pairingView.isHidden = false
                self.ingenico.paymentDevice.setDeviceType(RUADeviceTypeMOBY8500)
            case 5:
                self.ingenico.paymentDevice.setDeviceType(RUADeviceTypeMOBY5500)
            default:
                break
            }
            self.view.addSubview(self.searchView)
            self.doSearching()
        }, completion: nil)
    }
    
    @objc func doSearching() {
        refreshControl.beginRefreshing()
        self.deviceList = []
        self.searchTableView.reloadData()
        var communicationInterfaces:[NSNumber] = []
        if (self.btCommInterfaceSwitch.isOn) {
            communicationInterfaces.append(NSNumber(value: RUACommunicationInterfaceBluetooth.rawValue))
        }
        if (self.ajCommInterfaceSwitch.isOn) {
            communicationInterfaces.append(NSNumber(value: RUACommunicationInterfaceAudioJack.rawValue))
        }
        if (self.usbCommInterfaceSwitch.isOn) {
            communicationInterfaces.append(NSNumber(value: RUACommunicationInterfaceUSB.rawValue))
        }
        self.ingenico.paymentDevice.search(forCommunicationInterfaces: communicationInterfaces, andDuration: 1000, andListener: self)
    }
    
    @IBAction func continueToLogin(_ sender: Any) {
        let loginVC:LoginViewController  = self.storyboard?.instantiateViewController(withIdentifier: "loginVC") as! LoginViewController
        continueToLogin(loginVC)
    }
    
    func continueToLogin(_ loginVC: LoginViewController) {
        ingenico.paymentDevice.stopSearch()
        refreshControl.endRefreshing()
        UIView.transition(with: self.view, duration: 0.3, options: .transitionFlipFromLeft, animations: {
        self.searchView.removeFromSuperview()
        self.deviceList.removeAll()
        self.navigationItem.rightBarButtonItem?.title="Setup"
        self.navigationItem.leftBarButtonItem=nil
        }, completion: nil)
        self.navigationController?.pushViewController(loginVC, animated: false)
    }
    
    
    
    
    @IBAction func doPair(_ sender: AnyObject) {
        ingenico.paymentDevice.stopSearch()
        if (isConnected) {
            ingenico.paymentDevice.requestPairing(self)
            if (self.deviceTypePickerView.selectedRow(inComponent: 0) == 0) {
                let alertController:UIAlertController = UIAlertController.init(title: "", message: "Pairing process in progress.\nPlease go to Settings-> Bluetooth app in your iOS device and select the RP450c device to complete the pairing process.", preferredStyle: .alert)
                let goToSettingAction:UIAlertAction  = UIAlertAction.init(title: "Go To Settings", style:.cancel, handler: { (action: UIAlertAction) in
                    UIApplication.shared.open(URL.init(string: UIApplication.openSettingsURLString)!, options: [:], completionHandler: nil)
                    self.dismiss(animated: true, completion: nil)
                })
                alertController.addAction(goToSettingAction)
                self.present(alertController, animated:true, completion: nil)
            }
        }
        else {
            let alertController:UIAlertController  = UIAlertController.init(title: "", message: "Please make sure that the card reader is connected first.", preferredStyle:.alert)
            let gotoSettingsAction:UIAlertAction = UIAlertAction.init(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(gotoSettingsAction)
            self.present(alertController, animated: true, completion: nil)
        }
        
    }
    
    //MARK: - RUAStatusHandler Implementation
    
    override func onConnected() {
        super.onConnected()
        isConnected = true
    }
    
    override func onDisconnected() {
        super.onDisconnected()
        isConnected = false
    }
    
    override func onError(_ message:String) {
        super.onError(message)
        isConnected = false
    }
    
    //MARK: - RUADelegate Implementation
    func discoveredDevice(_ reader: RUADevice!) {
        NSLog("New Device Discovered")
        if (reader.name != nil) {
            deviceList.append(reader)
            searchTableView.reloadData()
        }
    }
    
    func discoveryComplete() {
        NSLog("Discovery Completed")
        refreshControl.endRefreshing()
    }
    
    //MARK: - RUAPairingListener
    
    func onPairConfirmation(_ readerPasskey: String!, mobileKey mobilePasskey: String!) {
        UNUserNotificationCenter.current().delegate = self
        let notificationContent = UNMutableNotificationContent()
        notificationContent.body = String(format: "Passkey: %@", readerPasskey)
        notificationContent.badge = NSNumber(value: 1)
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
        let request = UNNotificationRequest(identifier: "PairingPasskey", content: notificationContent, trigger: trigger)
        UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
    }
    
    func onPairSucceeded() {
       self.showSucess( "Pairing Success")
    }
    
    func onPairNotSupported() {
        self.showError("Pairing not supported")
    }
    
    func  onPairFailed() {
        self.showError("Pairing Failed")
    }
    
    //MARK: - UITextFeildDelegate Implementation
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if(textField == baseURLTextField) {
            if(baseUrlListMenu == nil) {
                var urls:Set<String> = []
                let data:Data? = UserDefaults.standard.object(forKey: "urlList") as? Data
                if (data != nil){
                    urls = NSKeyedUnarchiver.unarchiveObject(with: data!) as! Set<String>
                }
                var height:CGFloat = CGFloat(50 * urls.count)
                let maxheight = CGFloat((self.view.bounds.size.height - (textField.frame.origin.y + textField.bounds.size.height)))
                if (height > maxheight) {
                    height = maxheight
                }
                self.baseUrlListMenu = DropDownMenu().showDropDown(textField, withHeight: height, withArray: Array(urls) as NSArray, along: "down") as? DropDownMenu
                self.baseUrlListMenu?.delegate = self
                
            }
            else {
                baseUrlListMenu?.hideDropDown(textField)
                baseURLTextField = nil
            }
        }
        return true
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        if (textField == baseURLTextField) {
            if (baseUrlListMenu != nil) {
                baseUrlListMenu?.hideDropDown(textField)
                baseUrlListMenu = nil
            }
        }
        return true
    }
    
    //MARK: - UITableView Delegates Implementatiton
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return deviceList.count
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return CGFloat(80)
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell:SearchTableViewCell! = tableView.dequeueReusableCell(withIdentifier: "searchTableViewCell") as? SearchTableViewCell
        if (cell == nil) {
            cell = Bundle.main.loadNibNamed("SearchTableViewCell", owner: self, options: nil)![0] as? SearchTableViewCell
        }
        let device:RUADevice = deviceList[(indexPath as NSIndexPath).row]
        if device.name != nil{
            cell.nameLabel.text =  String.init(format: "Name: %@", device.name)
        }
        cell.identifierLabel.text = String.init(format: "ID: %@", device.identifier)
        cell.communicationLabel.text = self.getStringFromCommunication(device.communicationInterface)
        cell.accessoryType = .disclosureIndicator
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //Making sure that discovery is complete initializing the card reader
        ingenico.paymentDevice.stopSearch()
        connectingDevice = deviceList[(indexPath as NSIndexPath).row]
        ingenico.paymentDevice.select(connectingDevice!)
        let loginVC:LoginViewController  = self.storyboard?.instantiateViewController(withIdentifier: "loginVC") as! LoginViewController
        ingenico.paymentDevice.initialize(self, ledPairingListener: loginVC as RUAPairingListener)
        ingenico.setLogging(true)
        ingenico.setCustomLogger(self)
        if (connectingDevice?.communicationInterface == RUACommunicationInterfaceBluetooth) {
            continueToLogin(loginVC)
        }
    
    }
    
    //Mark: - UIPicker delegate
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if(pickerView == deviceTypePickerView){
            return 6;
        }else if (pickerView == configModePicker){
            return 4;
        }else {
            return 3;
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if(pickerView == deviceTypePickerView){
            switch row {
            case 0:
                return "RP450c"
            case 1:
                return "RP750x"
            case 2:
                return "Moby3000"
            case 3:
                return "RP45BT"
            case 4:
                return "Moby8500"
            case 5:
                return "Moby5500"
            default:
                return ""
            }
        }else if (pickerView == configModePicker){
            switch row {
            case 0:
                return "Manual";
            case 1:
                return "Optimal";
            case 2:
                return "Auto";
            case 3:
                return "Not Set";
            default:
                return "";
            }
        }else if (pickerView == retryCountPicker){
            switch row {
            case 0:
                return "0";
            case 1:
                return "1";
            case 2:
                return "2";
            case 3:
                return "3";
            default:
                return "";
            }
        }else{
            switch row {
            case 0:
                return "en_US";
            case 1:
                return "en_CA";
            case 2:
                return "fr_CA";
            default:
                return "";
            }
        }
    }
    
    //Mark: - Usernotification delegate
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.badge, .sound, .alert])
    }
    
    //Mark: Debug log listener
    func d(_ tag: String!, _ message: String!) {
        NSLog("debug: \(String(format: "%@", message))")
    }
    
    func i(_ tag: String!, _ message: String!) {
        NSLog("info: \(String(format: "%@", message))")
    }
    
    func e(_ tag: String!, _ message: String!) {
        NSLog("error: \(String(format: "%@", message))")
    }
    
    //Mark: - DropDownMenu delegate
    
    func delegateMethod(_ sender: DropDownMenu) {
        baseURLTextField.resignFirstResponder()
        baseUrlListMenu = nil
    }
    
}
