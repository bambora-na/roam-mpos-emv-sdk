//
//  StoreAndFwdViewController.swift
//  EMVSDKSwiftTestApp
//  Copyright 2015-2024 Worldline SMB US Inc. All Rights Reserved.
//

import UIKit

class StoreAndFwdViewController: IMSBaseViewController{
    
    @IBOutlet weak var tableView: UITableView!
    let sectionHeader = "Store And Forward APIs"
    let apiArray = [
        "* Credit sale (Swipe Only)",
        "* Credit auth (Swipe Only)",
        "* Keyed Credit Sale",
        "* Update stored transaction",
        "* Upload stored transaction",
        "* Store receipt for stored transaction",
        "* Void stored transaction",
        "* Get stored transaction",
        "* Get stored transactions",
        "* Get stored transactions in service group",
        "* Upload stored transactions",
        "* Upload stored transactions in service group",
        "* Delete stored transaction",
        "* Cash Sale",
        "* Token Enrollment/Update (Swipe Only)",
        "* Keyed Token Enrollement/Update",
        "* Credit sale (EMV)",
        "* Credit auth (EMV)",
        "* Token enrollment/update (EMV)",
        "* Delete stored transaction with client id",
        "* Delete expired stored transactions",
        "* Get old transactions count"
    ]
    
    var totalTF: UITextField?
    var subtotalTF: UITextField?
    var discountTF: UITextField?
    var taxTF: UITextField?
    var tipTF: UITextField?
    var surchargeTF: UITextField?
    var authCodeTF: UITextField?
    var invoiceIdTF: UITextField?
    var transactionNoteTF: UITextField?
    var tokenFeeTF: UITextField?
    var tokenIdentifierTF: UITextField?
    var customRefTF: UITextField?
    var orderNumberTF: UITextField?
    var userEmailTextField: UITextField?
    var clerkIDTF: UITextField?
    var currencyCodeTF: UITextField?
    var localeTF: UITextField?
    
    var cvvCheckbox: UIButton?
    var avsCheckbox: UIButton?
    var cardPresentCheckbox: UIButton?
    var showNoteAndInvoiceOnReceiptCheckbox: UIButton?
    var tokenEnrollmentCheckbox: UIButton?
    var tokenUpdateCheckbox: UIButton?
    var validateExpirationDateCheckbox: UIButton?
    var successCount = 0
    var failureCount = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.tableFooterView = UIView()
        deviceStatusBarButton = UIBarButtonItem.init(customView: getDeviceStatusImage())
        self.tabBarController?.navigationItem.hidesBackButton = true
    }
    
    func checkForClientTransactionId(completion: @escaping () -> ()) {
        if (self.getLastClientTransactionID()?.count ?? 0 > 0) {
            completion()
        }
        else {
            self.showError("Please run a store and forward transaction first or call GetStoredTransactions")
        }
    }
    
    func showFormAlert(requiresAmount: Bool, manualKeyed: Bool, isCashSale: Bool, completion: @escaping () -> ()) {
        let alert = UIAlertController(title: "Transaction request", message: "Enter the fields below", preferredStyle: .alert)
        if (requiresAmount) {
            alert.addTextField { (textfield) in
                textfield.keyboardType = .numberPad
                textfield.placeholder = "Total amount"
                self.totalTF = textfield
            }
            alert.addTextField { (textfield) in
                textfield.keyboardType = .numberPad
                textfield.placeholder = "Normalized Subtotal"
                self.subtotalTF = textfield
            }
            alert.addTextField { (textfield) in
                textfield.keyboardType = .numberPad
                textfield.placeholder = "Normalized Discount(optional)"
                self.discountTF = textfield
            }
            alert.addTextField { (textfield) in
                textfield.keyboardType = .numberPad
                textfield.placeholder = "Normalized Tax(optional)"
                self.taxTF = textfield
            }
            alert.addTextField { (textfield) in
                textfield.keyboardType = .numberPad
                textfield.placeholder = "Normalized Tip(optional)"
                self.tipTF = textfield
            }
            alert.addTextField { (textfield) in
                textfield.keyboardType = .numberPad
                textfield.placeholder = "Normalized Surcharge(optional)"
                self.surchargeTF = textfield
            }
            alert.addTextField { (textfield) in
                textfield.placeholder = "Currency Code"
                textfield.text = UserDefaults.standard.string(forKey: "currencyCode") ?? "USD"
                self.currencyCodeTF = textfield
            }
            alert.addCheckBoxWithTitle("Show note/invoice on receipt") { (checkbox) in
                checkbox.isSelected = false
                showNoteAndInvoiceOnReceiptCheckbox = checkbox
            }
        }
        alert.addTextField { (textfield) in
            textfield.keyboardType = .default
            textfield.placeholder = "Merchant Invoice ID(optional)"
            self.invoiceIdTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.keyboardType = .default
            textfield.placeholder = "Transaction Note(optional)"
            self.transactionNoteTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.keyboardType = .default
            textfield.placeholder = "ClerkID(Optional)"
            self.clerkIDTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.keyboardType = .default
            textfield.placeholder = "Custom Reference(Optional)"
            self.customRefTF = textfield
        }
        if (manualKeyed) {
            alert.addCheckBoxWithTitle("Request CVV") { (checkbox) in
                checkbox.isSelected = false
                cvvCheckbox = checkbox
            }
            alert.addCheckBoxWithTitle("Request AVS") { (checkbox) in
                checkbox.isSelected = false
                avsCheckbox = checkbox
            }
            alert.addCheckBoxWithTitle("Card Present") { (checkbox) in
                checkbox.isSelected = false
                cardPresentCheckbox = checkbox
            }
        }
        if (!isCashSale) {
            alert.addTextField { (textfield) in
                textfield.keyboardType = .default
                textfield.placeholder = "Token Identifier"
                if (self.getLastTokenID() !=  nil) {
                    textfield.text = self.getLastTokenID()
                }
                self.tokenIdentifierTF = textfield
            }
            alert.addTextField { (textfield) in
                textfield.keyboardType = .numberPad
                textfield.placeholder = "Normalized Token Fee(Optional)"
                self.tokenFeeTF = textfield
            }
            alert.addTextField { (textfield) in
                textfield.keyboardType = .numberPad
                textfield.placeholder = "Order Number(Optional)"
                self.orderNumberTF = textfield
            }
            alert.addCheckBoxWithTitle("Token Enrollment") { (checkbox) in
                checkbox.isSelected = true
                tokenEnrollmentCheckbox = checkbox
                tokenEnrollmentCheckbox?.addTarget(self, action: #selector(checkBoxSelected), for: .touchUpInside)
            }
            alert.addCheckBoxWithTitle("Token Update") { (checkbox) in
                checkbox.isSelected = false
                tokenUpdateCheckbox = checkbox
                tokenUpdateCheckbox?.addTarget(self, action: #selector(checkBoxSelected), for: .touchUpInside)
            }
            if (!manualKeyed) {
                alert.addCheckBoxWithTitle("Validate Expiry Date") { (checkbox) in
                    checkbox.isSelected = false
                    validateExpirationDateCheckbox = checkbox
                }
            }
        }
        alert.addTextField { (textField) in
            textField.keyboardType = .default
            if let locale = Ingenico.sharedInstance()?.preference?.merchantLocale {
                textField.text = locale.identifier
            }else{
                textField.text = "en_US"
            }
            self.localeTF = textField
        }
        let okAction = UIAlertAction(title: "OK", style: .default) { (action) in
            self.showProcessingMessage()
            completion()
            UserDefaults.standard.setValue(self.currencyCodeTF?.text, forKey: "currencyCode")
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alert.addAction(okAction)
        alert.addAction(cancelAction)
        self.present(alert, animated: false, completion: nil)
    }
    
    @objc func checkBoxSelected(_ sender: UIButton) {
        if (sender == tokenUpdateCheckbox) {
            tokenEnrollmentCheckbox?.isSelected = false
        }
        else if (sender == tokenEnrollmentCheckbox) {
            tokenUpdateCheckbox?.isSelected = false
        }
    }
    
    func onDone(_ response: IMSTransactionResponse?, error: NSError?) {
        self.dismissProgress()
        if error != nil {
            let nserror = error as NSError?
            self.showError("Transaction Failed with error code: \(self.getResponseCodeString((nserror!.code)))")
            self.consoleLog( "Transaction Failed with error code: \(self.getResponseCodeString((nserror!.code)))")
        }
        else {
            if (response?.transactionID != nil) {
                self.setLastTransactionID((response?.transactionID)!)
            }
            if (response?.clientTransactionID != nil) {
                self.setLastClientTransactionID((response?.clientTransactionID)!)
            }
            if (response?.tokenResponseParameters?.tokenIdentifier?.count ?? 0 > 0) {
                self.setLastTokenID(((response?.tokenResponseParameters?.tokenIdentifier!)!))
            }
            self.showSucess( "Transaction success")
        }
        self.consoleLog(String.init(format: "Transaction Response:\n%@", self.getStringFromResponse(response)))
    }
    
    func onProgress(_ message: IMSProgressMessage) {
        consoleLog("onProgress:\(self.getProgressStrFromMessage(message))")
        self.showProgressMessage(self.getProgressStrFromMessage(message)) {
            Ingenico.sharedInstance()?.payment.abortTransaction()
        }
    }
    
    func doApplicationSelection(list: [Any], response: @escaping ApplicationSelectedResponse) {
        self.dismissProgress()
        
        let applicationList = list as! [RUAApplicationIdentifier]
        let viewcontroller:UIAlertController = UIAlertController.init(title: "Select application for your card", message: "Make your choice", preferredStyle: .actionSheet)
        for appID in applicationList {
            let okAction:UIAlertAction = UIAlertAction.init(title: appID.applicationLabel, style: .default, handler: { (action) in
                self.showProgressMessage("Processing Card Transaction")
                viewcontroller.dismiss(animated: true, completion: nil)
                response(appID)
            })
            viewcontroller.addAction(okAction)
        }
        self.present(viewcontroller, animated: true, completion: nil)
    }
    
    func getAmount() -> IMSAmount {
        return IMSAmount(total: Int(totalTF?.text ?? "") ?? 0, andSubtotal: Int(subtotalTF?.text ?? "") ?? 0, andTax: Int(taxTF?.text ?? "") ?? 0, andDiscount: Int(discountTF?.text ?? "") ?? 0, andDiscountDescription: "ROAMDiscount", andTip: Int(tipTF?.text ?? "") ?? 0, andCurrency: currencyCodeTF?.text ?? "USD", andSurcharge: Int(surchargeTF?.text ?? "") ?? 0)
    }
    
    func getTokenRequestParams() -> IMSTokenRequestParameters? {
        let builder = IMSTokenRequestParametersBuilder()
        builder.tokenReferenceNumber = "test-123"
        builder.tokenFeeInCents = Int(tokenFeeTF!.text!) ?? 0
        builder.cardholderLastName = "appleseed"
        builder.cardholderFirstName = "john"
        builder.billToEmail = "john.appleseed@example.com"
        builder.billToAddress1 = "1 Federal St"
        builder.billToAddress2 = "Suite 1"
        builder.billToCity = "Boston"
        builder.billToState = "MA"
        builder.billToCountry = "USA"
        builder.billToZip = "02110"
        builder.ignoreAVSResult = true
        if (tokenEnrollmentCheckbox!.isSelected) {
            return builder.createTokenEnrollmentRequestParameters()
        }
        else if (tokenUpdateCheckbox!.isSelected) {
            builder.tokenIdentifier = tokenIdentifierTF?.text
            return builder.createTokenUpdateRequestParameters()
        }
        return nil
    }
    
    func processCreditSale(emv: Bool) {
        let request = IMSStoreAndForwardCreditSaleTransactionRequest(amount: getAmount(),
                                                                        andProducts: getSampleProducts(),
                                                                        andClerkID: clerkIDTF!.text,
                                                                        andLongitude: getLongitude(),
                                                                        andLatitude: getLatitude(),
                                                                        andTransactionGroupID: "",
                                                                        andTransactionNotes: transactionNoteTF!.text,
                                                                        andMerchantInvoiceID: invoiceIdTF!.text,
                                                                        andShowNotesAndInvoiceOnReceipt: showNoteAndInvoiceOnReceiptCheckbox!.isSelected,
                                                                        andCustomReference: customRefTF!.text,
                                                                        andIsCompleted: false,
                                                                        andUCIFormat:.UCIFormatIngenico,
                                                                        andOrderNumber: orderNumberTF!.text,
                                                                        andTokenRequestParameters: getTokenRequestParams(),
                                                                        andValidateCardExpirationDate: validateExpirationDateCheckbox!.isSelected)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        if (emv) {
            Ingenico.sharedInstance()?.storeAndForward.processEmvStoreAndForwardCreditSaleTransaction(withCardReader: request, andUpdateProgress: { (message, additionalMessage) in
                self.onProgress(message)
            }, andSelectApplication: { (list, error, response) in
                self.doApplicationSelection(list: list!, response: response!)
            }, andOnDone: { (response, error) in
                self.onDone(response, error: error as NSError?)
            })
        }
        else {
            Ingenico.sharedInstance()?.storeAndForward.processStoreAndForwardCreditSaleTransaction(withCardReader: request, andUpdateProgress: { (message, additionalMessage) in
                self.onProgress(message)
            }, andOnDone: { (response, error) in
                self.onDone(response, error: error as NSError?)
            })
        }
        
    }
    
    func processCreditAuth(emv: Bool) {
        let request = IMSStoreAndForwardCreditAuthTransactionRequest(amount: getAmount(),
                                                                        andProducts: getSampleProducts(),
                                                                        andClerkID: clerkIDTF!.text,
                                                                        andLongitude: getLongitude(),
                                                                        andLatitude: getLatitude(),
                                                                        andTransactionGroupID: "",
                                                                        andTransactionNotes: transactionNoteTF!.text,
                                                                        andMerchantInvoiceID: invoiceIdTF!.text,
                                                                        andShowNotesAndInvoiceOnReceipt:showNoteAndInvoiceOnReceiptCheckbox!.isSelected,
                                                                        andCustomReference: customRefTF!.text,
                                                                        andIsCompleted: false,
                                                                        andUCIformat: .UCIFormatIngenico,
                                                                        andOrderNumber: orderNumberTF!.text,
                                                                        andTokenRequestParameters: getTokenRequestParams(),
                                                                        andValidateCardExpirationDate: validateExpirationDateCheckbox!.isSelected)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        if (emv) {
            Ingenico.sharedInstance()?.storeAndForward.processEmvStoreAndForwardCreditAuthTransaction(withCardReader: request, andUpdateProgress: { (message, additionalMessage) in
                self.onProgress(message)
            }, andSelectApplication: { (list, error, response) in
                self.doApplicationSelection(list: list!, response: response!)
            }, andOnDone: { (response, error) in
                self.onDone(response, error: error as NSError?)
            })
        }
        else {
            Ingenico.sharedInstance()?.storeAndForward.processStoreAndForwardCreditAuthTransaction(withCardReader: request, andUpdateProgress: { (message, additionalMessage) in
                self.onProgress(message)
            }, andOnDone: { (response, error) in
                self.onDone(response, error: error as NSError?)
            })
        }
   }
    
    func processKeyedCreditSale() {
        let request = IMSStoreAndForwardKeyedCardSaleTransactionRequest(amount: getAmount(),
                                                                           andProducts: getSampleProducts(),
                                                                           andClerkID: clerkIDTF!.text,
                                                                           andLongitude: getLongitude(),
                                                                           andLatitude: getLatitude(),
                                                                           andTransactionGroupID: "",
                                                                           andTransactionNotes: transactionNoteTF!.text,
                                                                           andMerchantInvoiceID: invoiceIdTF!.text,
                                                                           andShowNotesAndInvoiceOnReceipt: showNoteAndInvoiceOnReceiptCheckbox!.isSelected,
                                                                           andCustomReference: customRefTF!.text,
                                                                           andIsCompleted: false,
                                                                           andIsCardAVSRequested: avsCheckbox!.isSelected,
                                                                           andIsCardCVVRequested: cvvCheckbox!.isSelected,
                                                                           andUCIFormat: .UCIFormatIngenico,
                                                                           andIsCardPresent:cardPresentCheckbox!.isSelected,
                                                                           andOrderNumber: orderNumberTF!.text,
                                                                           andTokenRequestParameters: getTokenRequestParams())!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.storeAndForward.processStoreAndForwardKeyedCardSaleTransaction(withCardReader: request, andUpdateProgress: { (message, additionalMessage) in
            self.onProgress(message)
        }, andOnDone: { (response, error) in
            self.onDone(response, error: error as NSError?)
        })
    }
    
    func updateStoredTransaction() {
        
        var origTxnIdTF:UITextField?
        var firstnameTF:UITextField?
        var lastnameTF:UITextField?
        var middlenameTF:UITextField?
        var emailTF:UITextField?
        var phoneTF:UITextField?
        var address1TF:UITextField?
        var address2TF:UITextField?
        var cityTF:UITextField?
        var stateTF:UITextField?
        var postalCodeTF:UITextField?
        var noteTF:UITextField?
        var signatureCB:UIButton?
        var isCompleteCB:UIButton?
        var showNotesCB:UIButton?
        
        let alert = UIAlertController(title: "Update Transaction", message: "Enter the following:", preferredStyle: .alert)
        alert.addTextField { (textfield) in
            textfield.placeholder = "Original Transaction Id"
            textfield.text = self.getLastClientTransactionID()
            origTxnIdTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.placeholder = "First Name"
            firstnameTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.placeholder = "Last Name"
            lastnameTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.placeholder = "Middle Name"
            middlenameTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.placeholder = "Email"
            emailTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.placeholder = "Phone"
            phoneTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.placeholder = "Address 1"
            address1TF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.placeholder = "Address 2"
            address2TF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.placeholder = "City"
            cityTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.placeholder = "State"
            stateTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.placeholder = "Postal Code"
            postalCodeTF = textfield
        }
        alert.addTextField { (textfield) in
            textfield.placeholder = "Transaction Note"
            noteTF = textfield
        }
        alert.addCheckBoxWithTitle("Include Signature") { (checkbox) in
            signatureCB = checkbox
        }
        alert.addCheckBoxWithTitle("Display Notes And Invoice") { (checkbox) in
            showNotesCB = checkbox
        }
        alert.addCheckBoxWithTitle("Is Complete") { (checkbox) in
            isCompleteCB = checkbox
        }
        let ok = UIAlertAction(title: "Ok", style: .default) { (action) in
            self.showProgressMessage("Processing Transaction")
            let carholderInfo = IMSCardholderInfo(firstName: firstnameTF!.text, andLastName: lastnameTF!.text, andMiddleName: middlenameTF!.text, andEmail: emailTF!.text, andPhone: phoneTF!.text, andAddress1: address1TF!.text, andAddress2: address2TF!.text, andCity: cityTF!.text, andState: stateTF!.text, andPostalCode: postalCodeTF!.text)
            let image = signatureCB!.isSelected ? UIImage(named: "signature.png")?.pngData()?.base64EncodedString(options: .endLineWithLineFeed) : nil
            Ingenico.sharedInstance()?.storeAndForward.updateStoredTransaction(withClientTransactionID: origTxnIdTF!.text!, andCardholderInfo: carholderInfo, andTransactionNote: noteTF!.text, andIsCompleted: isCompleteCB!.isSelected, andDisplayNotesAndInvoice: showNotesCB!.isSelected, andSignatureImage: image, andOnDone: { (error) in
                if (error == nil) {
                    self.consoleLog("updateStoredTransactionWithClientTransactionID success")
                    self.showSucess( "update success")
                }
                else {
                    let nserror = error as NSError?
                    self.consoleLog("updateStoredTransactionWithClientTransactionID failed with error code: \(self.getResponseCodeString((nserror!.code)))")
                    self.showError("update failed")
                }
            })
        }
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alert.addAction(ok)
        alert.addAction(cancel)
        self.present(alert, animated: true, completion: nil)
        
    }
    
    func uploadStoredTransaction() {
        self.showProgressMessage("Processing Transaction")
        Ingenico.sharedInstance()?.storeAndForward.uploadStoredTransaction(self.getLastClientTransactionID()!, andUpdateProgress: { (message, additionalMessage) in
            self.showProgressMessage(self.getProgressStrFromMessage(message))
        }, andOnDone: { (response, error) in
            self.onDone(response, error: error as NSError?)
        })
    }
    
    func storeReceiptForStoredTransaction() {
        let alert = UIAlertController(title: "enter email", message: "enter email adress for receipt", preferredStyle: .alert)
        var emailTextField:UITextField? = nil
        alert.addTextField { (textfield) in
            textfield.placeholder = "email address"
            emailTextField = textfield
        }
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        let ok = UIAlertAction(title: "OK", style: .default) { (action) in
            Ingenico.sharedInstance()?.storeAndForward.storeReceipt(forStoredTransaction: self.getLastClientTransactionID()!, andEmail: emailTextField!.text!, andOnDone: { (error) in
                if (error == nil) {
                    self.consoleLog("storeReceiptForStoredTransaction success")
                    self.showSucess( "store receipt success")
                }
                else {
                    let nserror = error as NSError?
                    self.consoleLog("storeReceiptForStoredTransaction failed with error code: \(self.getResponseCodeString((nserror!.code)))")
                    self.showError("store receipt failed")
                }
            })
        }
        alert.addAction(ok)
        alert.addAction(cancel)
        self.present(alert, animated: true, completion: nil)
    }
    
    func processVoid() {
        let alert = UIAlertController(title: "Void Stored Transaction", message: "Enter the following:", preferredStyle: .alert)
        var displayNotesCB:UIButton? = nil
        alert.addCheckBoxWithTitle("Display Notes And Invoice") { (checkbox) in
            displayNotesCB = checkbox
        }
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        let ok = UIAlertAction(title: "OK", style: .default) { (action) in
            self.showProgressMessage("Processing Transaction")
            let request = IMSStoreAndForwardVoidTransactionRequest(originalClientTransactionID: self.getLastClientTransactionID()!, andClerkID: "", andLongitude: self.getLongitude(), andLatitude: self.getLatitude(), andCustomReference: "", andOrderNumber: "", andShowNotesAndInvoiceOnReceipt:displayNotesCB!.isSelected)
            Ingenico.sharedInstance()?.storeAndForward.processVoidStoredTransaction(request!, andOnDone: { (response, error) in
                self.onDone(response, error: error as NSError?)
            })
        }
        alert.addAction(ok)
        alert.addAction(cancel)
        self.present(alert, animated: true, completion: nil)
    }
    
    func getStoredTransaction() {
        self.showProgressMessage("Get Stored Transaction")
        Ingenico.sharedInstance()?.storeAndForward.getStoredTransaction(withClientTransactionID: self.getLastClientTransactionID()!, andOnDone: { (summary, error) in
            self.dismissProgress()
            if (error == nil) {
                self.consoleLog("getStoredTransaction success")
                if (summary != nil) {
                    self.consoleLog(summary!.description)
                    self.setLastClientTransactionID(summary!.clientTransactionID)
                }
                self.showSucess( "getStoredTransaction success")
            }
            else {
                let nserror = error as NSError?
                self.consoleLog("getStoredTransaction failed with error code: \(self.getResponseCodeString((nserror!.code)))")
                self.showError("getStoredTransaction failed")
            }
        })
    }
    
    func getStoredTransactions(includeGroupTransactions: Bool) {
        self.showProgressMessage("Get Stored Transactions")
        Ingenico.sharedInstance()?.storeAndForward.getStoredTransactions(true, andIncludeGroupTransactions: includeGroupTransactions, andOnDone: { (storedTransactionSummaryList, totalMaches, error) in
            self.dismissProgress()
            if (error == nil) {
                var messageResult = "No stored transactions"
                if (totalMaches > 0) {
                    messageResult = "\(totalMaches) transactions found"
                    self.setLastClientTransactionID((storedTransactionSummaryList![storedTransactionSummaryList!.count - 1] as! IMSStoredTransactionSummary).clientTransactionID)
                }
                self.consoleLog(messageResult)
                self.showSucess(messageResult)
            }
            else {
                let nserror = error as NSError?
                self.consoleLog("getStoredTransactions failed with error code: \(self.getResponseCodeString((nserror!.code)))")
                self.showError("getStoredTransactions failed")
            }
        })
    }
    
    func getOldStoredTransactionsCount(hoursOfAge: Int32) {
        self.showProgressMessage("Get Old Stored Transactions Count")
        Ingenico.sharedInstance()?.storeAndForward.getOldStoredTransactionsCount(hoursOfAge,
                                                                                 andOnDone: { 
            (transactionCount, error) in
            self.dismissProgress()
            if (error == nil) {
                var messageResult = "No old stored transactions"
                if (transactionCount > 0) {
                    messageResult = "\(transactionCount) transactions found"
                }
                self.consoleLog(messageResult)
                self.showSucess(messageResult)
            } else {
                let nserror = error as NSError?
                self.consoleLog("getOldStoredTransactionsCount failed with error code: \(self.getResponseCodeString((nserror!.code)))")
                self.showError("getOldStoredTransactionsCount failed")
            }
        })
    }
    
    func uploadStoredTransactions(includeGroupTransactions: Bool) {
        successCount = 0
        failureCount = 0
        Ingenico.sharedInstance()?.storeAndForward.getStoredTransactions(true, andIncludeGroupTransactions: includeGroupTransactions, andOnDone: { (storedTransactionSummaryList, totalMaches, error) in
            if (error == nil) {
                self.consoleLog("getStoredTransactions success")
                self.showProgressMessage( "getStoredTransactions success")
                if (totalMaches == 0) {
                    self.consoleLog("No stored transactions")
                    self.showError("No stored transactions")
                }
                else {
                    self.consoleLog("\(totalMaches) transaction found")
                    self.uploadTransaction(index: 0, transactionList: storedTransactionSummaryList!)
                }
            }
            else {
                let nserror = error as NSError?
                self.consoleLog("getStoredTransactions failed with error code: \(self.getResponseCodeString((nserror!.code)))")
                self.showError("getStoredTransactions failed")
            }
        })
    }
    
    func uploadTransaction(index: Int, transactionList: [Any]) {
        if (index < transactionList.count) {
            self.showProgressPercent(Float(index)/Float(transactionList.count), message: "uploading transaction \(index + 1)/\(transactionList.count)")
            self.consoleLog("uploading transaction \(index + 1)/\(transactionList.count)")
            let clientTxnId = (transactionList[index] as! IMSStoredTransactionSummary).clientTransactionID!
            Ingenico.sharedInstance()?.storeAndForward.uploadStoredTransaction(clientTxnId, andUpdateProgress: { (progress, additionalMessage) in
                self.consoleLog(self.getProgressStrFromMessage(progress))
            }, andOnDone: { (response, error) in
                if error != nil {
                    self.failureCount += 1
                    let nserror = error as NSError?
                    self.consoleLog( "Transaction \(index + 1) Failed with error code: \(self.getResponseCodeString((nserror!.code)))")
                }
                else {
                    self.successCount += 1
                    self.consoleLog( "Transaction \(index + 1) success")
                    if (response?.transactionID != nil) {
                        self.setLastTransactionID((response?.transactionID)!)
                    }
                    if (response?.clientTransactionID != nil) {
                        self.setLastClientTransactionID((response?.clientTransactionID)!)
                    }
                    if (response?.tokenResponseParameters?.tokenIdentifier?.count ?? 0 > 0) {
                        self.setLastTokenID(((response?.tokenResponseParameters?.tokenIdentifier!)!))
                    }
                }
                self.consoleLog(String.init(format: "Transaction \(index + 1) Response:\n%@", self.getStringFromResponse(response)))
                self.uploadTransaction(index: index+1, transactionList: transactionList)
            })
        }
        else {
            self.showProgressPercent(1.0, message: "uploading transactions")
            self.consoleLog("uploadStoredTransactions complete \n (Success:\(successCount), Failure:\(failureCount))")
            self.showSucess("uploadStoredTransactions complete \n (Success:\(successCount), Failure:\(failureCount))")
        }
    }
    
    func deleteStoredTransaction() {
        Ingenico.sharedInstance()?.storeAndForward.deleteStoredTransaction(withClientTransactionID: self.getLastClientTransactionID()!, andOnDone: { (error) in
            if (error == nil) {
                self.consoleLog("deleteStoredTransaction success")
                self.showSucess( "deleteStoredTransaction success")
            }
            else {
                let nserror = error as NSError?
                self.consoleLog("deleteStoredTransaction failed with error code: \(self.getResponseCodeString((nserror!.code)))")
                self.showError("deleteStoredTransaction failed")
            }
        })
    }
    
    func deleteExpiredStoredTransactions() {
        Ingenico.sharedInstance()?.storeAndForward.deleteExpiredStoredTransactions(nil, { (error) in
            if (error == nil) {
                self.consoleLog("deleteExpiredStoredTransactions success")
                self.showSucess( "deleteExpiredStoredTransactions success")
            }
            else {
                let nserror = error as NSError?
                self.consoleLog("deleteExpiredStoredTransactions failed with error code: \(self.getResponseCodeString((nserror!.code)))")
                self.showError("deleteExpiredStoredTransactions failed")
            }
        })
    }
    
    func processCashSale() {
        let request = IMSStoreAndForwardCashSaleTransactionRequest(amount: getAmount(),
                                                                   andProducts: getSampleProducts(),
                                                                   andClerkID: clerkIDTF!.text,
                                                                   andLongitude: getLongitude(),
                                                                   andLatitude: getLatitude(),
                                                                   andTransactionGroupID: "",
                                                                   andTransactionNotes: transactionNoteTF!.text,
                                                                   andMerchantInvoiceID: invoiceIdTF!.text,
                                                                   andShowNotesAndInvoiceOnReceipt: showNoteAndInvoiceOnReceiptCheckbox!.isSelected,
                                                                   andIsCompleted: false)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.storeAndForward.processStoreAndForwardCashTransaction(request, andOnDone: { (response, error) in
            self.onDone(response, error: error as NSError?)
        })
    }
    
    func processTokenEnrollment(emv: Bool) {
        let request = IMSStoreAndForwardTokenEnrollmentTransactionRequest(tokenRequestParameters:getTokenRequestParams(),
                                                                          andClerkID: clerkIDTF!.text,
                                                                          andLongitude: getLongitude(),
                                                                          andLatitude: getLatitude(),
                                                                          andUCIFormat: .UCIFormatIngenico,
                                                                          andOrderNumber: orderNumberTF!.text,
                                                                          andValidateCardExpirationDate: validateExpirationDateCheckbox!.isSelected)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        if (emv) {
            Ingenico.sharedInstance()?.storeAndForward.processEmvStoreAndForwardTokenEnrollment(withCardReader: request, andUpdateProgress: { (progress, additionalMessage) in
                self.showProgressMessage(self.getProgressStrFromMessage(progress))
            }, andSelectApplication: { (list, error, response) in
                self.doApplicationSelection(list: list!, response: response!)
            }, andOnDone: { (response, error) in
                self.onDone(response, error: error as NSError?)
            })
        }
        else {
            Ingenico.sharedInstance()?.storeAndForward.processStoreAndForwardTokenEnrollment(withCardReader: request, andUpdateProgress: { (progress, additionalMessage) in
                self.showProgressMessage(self.getProgressStrFromMessage(progress))
            }, andOnDone: { (response, error) in
                self.onDone(response, error: error as NSError?)
            })
        }
    }
    
    func processKeyedTokenEnrollment() {
        let request = IMSStoreAndForwardKeyedTokenEnrollmentTransactionRequest(tokenRequestParameters: getTokenRequestParams(),
                                                                          andClerkID: clerkIDTF!.text,
                                                                          andLongitude: getLongitude(),
                                                                          andLatitude: getLatitude(),
                                                                          andUCIFormat: .UCIFormatIngenico,
                                                                          andOrderNumber: orderNumberTF!.text)!
        request.locale = getValidLocaleForTransactionRequest(localeTF?.text);
        Ingenico.sharedInstance()?.storeAndForward.processStoreAndForwardKeyedTokenEnrollment(withCardReader: request, andUpdateProgress: { (progress, additionalMessage) in
            self.showProgressMessage(self.getProgressStrFromMessage(progress))
        }, andOnDone: { (response, error) in
            self.onDone(response, error: error as NSError?)
        })
    }
}

// MARK: UITableView Implementation

extension StoreAndFwdViewController: UITableViewDelegate, UITableViewDataSource  {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.row {
            case 0:
                showFormAlert(requiresAmount:true, manualKeyed: false, isCashSale: false) {
                    self.processCreditSale(emv: false)
                }
            case 1:
                showFormAlert(requiresAmount:true, manualKeyed: false, isCashSale: false) {
                    self.processCreditAuth(emv:false)
                }
            case 2:
                showFormAlert(requiresAmount:true, manualKeyed: true, isCashSale: false) {
                    self.processKeyedCreditSale();
                }
            case 3:
                checkForClientTransactionId {
                    self.updateStoredTransaction()
                }
            case 4:
                checkForClientTransactionId {
                    self.uploadStoredTransaction()
                }
            case 5:
                checkForClientTransactionId {
                    self.storeReceiptForStoredTransaction()
                }
            case 6:
                checkForClientTransactionId {
                    self.processVoid()
                }
            case 7:
                checkForClientTransactionId {
                    self.getStoredTransaction()
                }
            case 8:
                self.getStoredTransactions(includeGroupTransactions: false)
            case 9:
                self.getStoredTransactions(includeGroupTransactions: true)
            case 10:
                self.uploadStoredTransactions(includeGroupTransactions: false)
            case 11:
                self.uploadStoredTransactions(includeGroupTransactions: true)
            case 12:
                checkForClientTransactionId {
                    self.deleteStoredTransaction()
                }
            case 13:
                showFormAlert(requiresAmount:true, manualKeyed: false, isCashSale: true) {
                    self.processCashSale()
                }
            case 14:
                showFormAlert(requiresAmount:false, manualKeyed: false, isCashSale: false) {
                    self.processTokenEnrollment(emv:false)
                }
            case 15:
                showFormAlert(requiresAmount:false, manualKeyed: false, isCashSale: false) {
                    self.processKeyedTokenEnrollment()
                }
            case 16:
                showFormAlert(requiresAmount:true, manualKeyed: false, isCashSale: false) {
                    self.processCreditSale(emv:true)
                }
            case 17:
                showFormAlert(requiresAmount:true, manualKeyed: false, isCashSale: false) {
                    self.processCreditAuth(emv:true)
                }
            case 18:
                showFormAlert(requiresAmount:false, manualKeyed: false, isCashSale: false) {
                    self.processTokenEnrollment(emv:true)
                }
            case 19:
                promptForDeleteStoredTransactionWithClientTxnId();
            case 20:
                self.deleteExpiredStoredTransactions()
            case 21:
                self.getOldStoredTransactionsCount(hoursOfAge: 24)
            default:
                break
        }
        tableView.deselectRow(at: indexPath, animated: false)
    }
    
    func promptForDeleteStoredTransactionWithClientTxnId() {
        let alert = UIAlertController(title: "Please enter client transaction id", message: "Please enter client transaction id", preferredStyle: .alert)
        var clientTxnIdTextField:UITextField? = nil
        alert.addTextField { (textfield) in
            textfield.placeholder = "client transaction id"
            clientTxnIdTextField = textfield
        }
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        let ok = UIAlertAction(title: "OK", style: .default) { (action) in
            Ingenico.sharedInstance()?.storeAndForward.deleteStoredTransaction(withClientTransactionID: clientTxnIdTextField?.text ?? "", andOnDone: { (error) in
                if (error == nil) {
                    self.consoleLog("deleteStoredTransaction success")
                    self.showSucess( "deleteStoredTransaction success")
                }
                else {
                    let nserror = error as NSError?
                    self.consoleLog("deleteStoredTransaction failed with error code: \(self.getResponseCodeString((nserror!.code)))")
                    self.showError("deleteStoredTransaction failed")
                }
            })
        }
        alert.addAction(ok)
        alert.addAction(cancel)
        self.present(alert, animated: true, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return apiArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "Cell")! as UITableViewCell
        cell.textLabel?.text = apiArray[indexPath.row]
        cell.textLabel?.textAlignment = .center
        cell.selectionStyle = .default;
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return sectionHeader
    }
}
