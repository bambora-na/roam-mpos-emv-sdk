//
//  TabBarViewController.swift
//  EMVSDKSwiftTestApp
//
//  Created by Abhiram Dinesh on 11/8/18.
//  Copyright © 2018 Ingenico. All rights reserved.
//

import UIKit

class TabBarViewController: UITabBarController {

    var logString:NSMutableString = NSMutableString()
    
    
}
