//
//  LDTmsCmdCrtVersionInfo.h
//  MPOSCommunicationManager
//
//  Created by Wu Robert on 5/20/15.
//  Copyright (c) 2015 Landi 联迪. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LDTmsCmdCrtVersionInfo : NSObject

@property (strong,nonatomic) NSArray* FileVerInfos;

@end
