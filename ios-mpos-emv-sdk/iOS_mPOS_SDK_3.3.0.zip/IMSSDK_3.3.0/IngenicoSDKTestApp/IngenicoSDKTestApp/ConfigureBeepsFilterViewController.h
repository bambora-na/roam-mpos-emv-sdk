//
//  ConfigureBeepsFilterViewController.h
//  IngenicoSDKTestApp
//
//  Created by Bin Lang on 9/25/17.
//  Copyright © 2017 RoamData. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IMSBaseViewController.h"

@interface ConfigureBeepsFilterViewController : IMSBaseViewController

@property (weak, nonatomic) IBOutlet UITableView *filterTableView;
@property (strong ,nonatomic) void (^callback)(bool disableCardRemovalBeep,bool disableEMVStartTransactionBeep);

@end
