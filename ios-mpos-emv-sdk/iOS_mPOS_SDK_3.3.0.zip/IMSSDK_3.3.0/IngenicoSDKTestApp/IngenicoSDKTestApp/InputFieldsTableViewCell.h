//
//  PaymentDeviceViewController.h
//  IngenicoSDKTestApp
//
//  Copyright © 2016 RoamData. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InputFieldsTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UITextField *inputTextField;

@end
