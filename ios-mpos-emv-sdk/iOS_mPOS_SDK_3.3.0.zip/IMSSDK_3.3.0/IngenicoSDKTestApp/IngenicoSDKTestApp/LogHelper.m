//
//  LogHelper.m
//  IngenicoSDKTestApp
//
//  Created by Abhiram Dinesh on 3/2/21.
//  Copyright © 2021 RoamData. All rights reserved.
//

#import "LogHelper.h"

@interface LogHelper()
{
    NSMutableString *logString;
}

@end

@implementation LogHelper

+ (id)sharedInstance {
    static LogHelper *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[LogHelper alloc] init];
    });
    return instance;
}

- (id)init {
    if (self = [super init]) {
        logString = [[NSMutableString alloc]init];
    }
    return self;
}

-(void) consoleLog:(NSString *) message {
    NSDateFormatter *format = [[NSDateFormatter alloc] init];
    [format setDateFormat:@"HH:mm:ss"];
    NSString *dateStr = [format stringFromDate:[NSDate date]];
    [logString appendString:[NSString stringWithFormat:@"[%@]:%@\n", dateStr, message]];
}

-(NSString *) getLogString {
    return logString;
}

-(void) clearLog {
    logString.string = @"";
}

@end
