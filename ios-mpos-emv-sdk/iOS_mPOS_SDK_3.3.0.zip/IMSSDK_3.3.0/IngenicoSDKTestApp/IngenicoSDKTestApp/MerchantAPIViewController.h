//
//  MerchantAPIViewController.h
//  IngenicoSDKTestApp
//
//  Copyright © 2016 RoamData. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IMSBaseViewController.h"

@interface MerchantAPIViewController : IMSBaseViewController

@property (weak, nonatomic) IBOutlet UITableView *merchantTableView;

@end
