//
//  PaymentAPIViewController.m
//  IngenicoSDKTestApp
//
//  Copyright © 2016 RoamData. All rights reserved.
//

#import "MerchantAPIViewController.h"
#import "HistoryFilterViewController.h"
#import "TabBarViewController.h"
#import "TransactionHistoryListViewController.h"
#import "TransactionDetailViewController.h"
#import "UIAlertController+Utility.h"

@interface MerchantAPIViewController ()<UITableViewDelegate, UITableViewDataSource>{
    NSArray *emailAPIArray;
    NSArray *securityQuestionAPIArray;
    NSArray *merchantInfoAPIArray;
    NSArray *passwordAPIArray;
    NSArray *transactionHistoryAPIArray;
    NSArray *updateTransactionAPIArray;
    NSArray *otherAPIArray;
    NSArray *merchantAPIArray;
    NSArray *sectionTitleArray;
    __block UITextField *clerkIdTextField;
    __block UITextField *invoiceIdTextField;
    __block UITextField *userEmailTextField;
    __block UITextField *startDateTextField;
    __block UITextField *endDateTextField;
    __block UIDatePicker *datePicker;
    __block UITextField *oldPWTextField;
    __block UITextField *newPWTextField;
    __block UITextField *phoneTextField;
    NSDateFormatter *dateFormatter;
}

@end

@implementation MerchantAPIViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    emailAPIArray = [[NSArray alloc] initWithObjects:
                     @"* Set user email",
                     @"* send email receipt",nil];
    securityQuestionAPIArray = [[NSArray alloc] initWithObjects:
                                @"* Get security questions",
                                @"* Set security questions",nil];
    merchantInfoAPIArray = [[NSArray alloc] initWithObjects:
                     @"* Get merchant receipt info",
                     @"* Set merchant receipt info",
                     @"* Get processor info",nil];
    passwordAPIArray = [[NSArray alloc] initWithObjects:
                                @"* Change password",
                                @"* Forgot password",nil];
    transactionHistoryAPIArray = [[NSArray alloc] initWithObjects:
                                @"* Get transaction detail",
                                @"* Get transaction history",
                                @"* Get invoice history",
                                @"* Get transaction summary", nil];
    updateTransactionAPIArray = [[NSArray alloc] initWithObjects:
                                @"* Upload signature",
                                @"* Update transaction",nil];
    otherAPIArray = [[NSArray alloc] initWithObjects:
                                @"* Refresh user session",
                                @"* Accept terms and conditions",nil];
    merchantAPIArray = [[NSArray alloc] initWithObjects:
                        emailAPIArray,
                        securityQuestionAPIArray,
                        merchantInfoAPIArray,
                        passwordAPIArray,
                        transactionHistoryAPIArray,
                        updateTransactionAPIArray,
                        otherAPIArray,nil];
    sectionTitleArray = [[NSArray alloc] initWithObjects:
                         @"Email API",
                         @"Security Question API",
                         @"MerchantReceipt API",
                         @"Password API",
                         @"Transaction API",
                         @"Update API",
                         @"Other API",nil];
    _merchantTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    _merchantTableView.tableHeaderView = [[UIView alloc] initWithFrame:CGRectZero];
    dateFormatter = [[NSDateFormatter alloc] init];
    datePicker = [[UIDatePicker alloc] init];
    datePicker.datePickerMode = UIDatePickerModeDate;
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [(TabBarViewController *)self.parentViewController setCurrentVisibleChildViewController:self];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    _merchantTableView.frame = CGRectMake(0, _merchantTableView.frame.origin.y-([UIApplication sharedApplication].statusBarFrame.size.height+self.parentViewController.navigationController.navigationBar.frame.size.height), _merchantTableView.frame.size.width, _merchantTableView.frame.size.height+[UIApplication sharedApplication].statusBarFrame.size.height+self.parentViewController.navigationController.navigationBar.frame.size.height);
}

- (void)forgotPassword {
    [self showProgressMessage:@"Sending forgot password request" andIsTransactionStoppable:NO];
    [[Ingenico sharedInstance].User
     forgotPassword:[[NSUserDefaults standardUserDefaults] objectForKey:@"lastLoggedInUN"]
     andOnDone:^(NSError *error) {
         [self dismissProgress];
         if (error == nil) {
             [LogHelper.sharedInstance consoleLog:@"Forgot password succeeded"];
         } else {
             [LogHelper.sharedInstance consoleLog:[[NSString alloc]
                          initWithFormat:@"Forgot password failed with "
                          @"error code : %ld",
                          (long)error.code]];
         }
     }];
}

- (void)setEmail {
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        [self showProgressMessage:@"Sending set email request" andIsTransactionStoppable:NO];
        [[Ingenico sharedInstance].User
         setUserEmail:userEmailTextField.text
         andOnDone:^(NSError *error) {
             [self dismissProgress];
             if (error == nil) {
                 [LogHelper.sharedInstance consoleLog:@"Set Email succeeded"];
             } else {
                 [LogHelper.sharedInstance consoleLog:[[NSString alloc]
                              initWithFormat:
                              @"Set email failed with error code : %ld\n",
                              (long)error.code]];
             }
         }];
    }];
    [self promptForEmailAddress:okAction isOptional:false];
}

- (void)changePW {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"ChangePassword" message:@"Send change password request" preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        [textField setPlaceholder:@"Old Password"];
        textField.accessibilityLabel = @"vc_merchantapi_old_password";
        oldPWTextField = textField;
    }];
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        [textField setPlaceholder:@"New Password"];
        textField.accessibilityLabel = @"vc_merchantapi_new_password";
        newPWTextField = textField;
    }];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self showProgressMessage:@"Sending change password request" andIsTransactionStoppable:NO];
        [[Ingenico sharedInstance].User
         changePasswordWithOldPassword:oldPWTextField.text
         andNewPassword:newPWTextField.text
         andOnDone:^(NSError *error) {
             [self dismissProgress];
             if (!error) {
                 [LogHelper.sharedInstance consoleLog:@"ChangePW succeeded"];
             }
             else{
                 [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat: @"ChangePW failed with error code : %ld", (long)error.code]];
             }
             oldPWTextField = nil;
             newPWTextField = nil;
         }];
    }];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
    [alert addAction:okAction];
    [alert addAction:cancelAction];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)updateTransaction {
    if([self getLastTransactionID] == nil){
        [self showErrorMessage:@"Please perform a transaction first" andErrorTitle:@"Error"];
    }
    else{
       __block UITextField *origTxnIdTF;
       __block UITextField *firstNameTF;
       __block UITextField *lastNameTF;
       __block UITextField *middleNameTF;
       __block UITextField *emailTF;
       __block UITextField *phoneTF;
       __block UITextField *address1TF;
       __block UITextField *address2TF;
       __block UITextField *cityTF;
       __block UITextField *stateTF;
       __block UITextField *postalCodeTF;
       __block UITextField *transactionNoteTF;
       __block UIButton *displayNotesCB;
       __block UIButton *isCompleteCB;
       
       UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Update Transaction" message:@"Enter the following:" preferredStyle:UIAlertControllerStyleAlert];
       [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
           textField.placeholder = @"Original Transaction Id";
           textField.text = [self getLastTransactionID];
           textField.accessibilityLabel = @"vc_merchantapi_original_transaction_id";
           origTxnIdTF = textField;
       }];
       [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
           textField.placeholder = @"First name";
           textField.accessibilityLabel = @"vc_merchantapi_original_first_name";
           firstNameTF = textField;
       }];
       [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
           textField.placeholder = @"Last name";
           textField.accessibilityLabel = @"vc_merchantapi_last_name";
           lastNameTF = textField;
       }];
       [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
           textField.placeholder = @"Middle name";
           textField.accessibilityLabel = @"vc_merchantapi_middle_name";
           middleNameTF = textField;
       }];
       [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
           textField.placeholder = @"Email";
           textField.accessibilityLabel = @"vc_merchantapi_email";
           emailTF = textField;
       }];
       [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
           textField.placeholder = @"Phone";
           textField.accessibilityLabel = @"vc_merchantapi_phone";
           phoneTF = textField;
       }];
       [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
           textField.placeholder = @"Address 1";
           textField.accessibilityLabel = @"vc_merchantapi_address_1";
           address1TF = textField;
       }];
       [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
           textField.placeholder = @"Address 2";
           textField.accessibilityLabel = @"vc_merchantapi_address_2";
           address2TF = textField;
       }];
       [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
           textField.placeholder = @"City";
           textField.accessibilityLabel = @"vc_merchantapi_city";
           cityTF = textField;
       }];
       [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
           textField.placeholder = @"State";
           textField.accessibilityLabel = @"vc_merchantapi_state";
           stateTF = textField;
       }];
       [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
           textField.placeholder = @"Postal code";
           textField.accessibilityLabel = @"vc_merchantapi_postal_code";
           postalCodeTF = textField;
       }];
       [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
           textField.placeholder = @"Transaction Note";
           textField.accessibilityLabel = @"vc_merchantapi_transaction_note";
           transactionNoteTF = textField;
       }];
       [alert addCheckBoxWithTitle:@"Display Notes And Invoice" andConfigurationHandler:^(UIButton * _Nonnull checkBox) {
           checkBox.accessibilityLabel = @"vc_merchantapi_display_note_cb";
           displayNotesCB = checkBox;
       }];
       [alert addCheckBoxWithTitle:@"Is Complete" andConfigurationHandler:^(UIButton * _Nonnull checkBox) {
           checkBox.accessibilityLabel = @"vc_merchantapi_is_complete_cb";
           isCompleteCB = checkBox;
       }];
       UIAlertAction *ok = [UIAlertAction actionWithTitle:@"Ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
             [self showProgressMessage:@"Sending update transaction request" andIsTransactionStoppable:NO];
           IMSCardholderInfo *cardholderInfo =  [[IMSCardholderInfo alloc] initWithFirstName:firstNameTF.text
                                                                                 andLastName:lastNameTF.text
                                                                               andMiddleName:middleNameTF.text
                                                                                    andEmail:emailTF.text
                                                                                    andPhone:phoneTF.text
                                                                                 andAddress1:address1TF.text
                                                                                 andAddress2:address2TF.text
                                                                                     andCity:cityTF.text
                                                                                    andState:stateTF.text
                                                                               andPostalCode:postalCodeTF.text];
           [[Ingenico sharedInstance].User updateTransactionWithTransactionID:origTxnIdTF.text
                                                            andCardholderInfo:cardholderInfo
                                           andTransactionNote:transactionNoteTF.text
                                               andIsCompleted:isCompleteCB.selected
                                    andDisplayNotesAndInvoice:displayNotesCB.selected
                                                    andOnDone:^(NSError *error) {
                                                        [self dismissProgress];
                                                        if (error == nil) {
                                                            [LogHelper.sharedInstance consoleLog:@"Update Transaction succeeded"];
                                                        } else {
                                                            [LogHelper.sharedInstance consoleLog:[[NSString alloc]
                                                                              initWithFormat:@"Update Transaction failed with "
                                                                              @"error code : %ld\n",
                                                                              (long)error.code]];
                                                        }
               [[Ingenico sharedInstance].User sendEmailReceipt:origTxnIdTF.text andEmailAddress:nil andOnDone:^(NSError *error) {
                   if (nil == error) {
                       [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"send email receipt succeeded\n"]];
                   } else {
                       [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"send email receipt failed with %@", [self getResponseCodeString:error.code]]];
                   }
               }];
           }];
       }];
       UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
       [alert addAction:ok];
       [alert addAction:cancel];
       [self presentViewController:alert animated:YES completion:nil];
    }
}

- (void)getEmailReceiptInfo {
    [self showProgressMessage:@"Getting email receipt info" andIsTransactionStoppable:NO];
    [[Ingenico sharedInstance].User getEmailReceiptInfo:^(IMSEmailReceiptInfo *
                                          emailReceiptInfo,
                                          NSError *error) {
        [self dismissProgress];
        if (error == nil) {
            [LogHelper.sharedInstance consoleLog:[[NSString alloc]
                                                                           initWithFormat:@"Get Email Receipt Info succeeded : %@",
                                                                           emailReceiptInfo.description]];
        } else {
            [LogHelper.sharedInstance consoleLog:[[NSString alloc]
                              initWithFormat:@"Get Email Receipt Info failed with error code : %ld",
                              (long)error.code]];
        }
    }];
}

- (void)setEmailReceiptInfo {
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        [self showProgressMessage:@"Setting email receipt info" andIsTransactionStoppable:NO];
        [[Ingenico sharedInstance].User
         setEmailReceiptInfo:[[IMSEmailReceiptInfo alloc]
                              initWithLogoBase64:[IMSUtil encodedImageToBase64String:[UIImage imageNamed:@"merchant_receipt_info.png"] withImageFormat:ImageFormatPNG]
                              andMerchantMessage:@"Ingenico Mobile Solution"
                              andEmail:@"ims@ims.com"
                              andPhoneNumber:phoneTextField.text
                              andWebsiteURL:@"www.ingenico.com"
                              andFacebookURL:@"facebookURLTEST"
                              andTwitterURL:@"TwitterURLTEST"
                              andInstagramURL:@"InstagramURLTEST"
                              andBusinessName:@"TheBakery"
                              andAddress1:@"123 Boston Ave"
                              andAddress2:@"Suite 007"
                              andCity:@"Boston"
                              andState:@"MA"
                              andCountry:@"US"
                              andPostalCode:@"01234"]
         andOnDone:^(NSError *error) {
             [self dismissProgress];
             if (error == nil) {
                 [LogHelper.sharedInstance consoleLog:@"Set Email Receipt Info succeeded\n"];
             } else {
                 [LogHelper.sharedInstance consoleLog:[[NSString alloc]
                              initWithFormat:@"Set Email Receipt "
                              @"failed with error "
                              @"code : %ld\n",
                              (long)error.code]];
             }
         }];
    }];
    UIAlertController *alertontroller = [UIAlertController
                                         alertControllerWithTitle:@"Set Email Receipt Info"
                                         message:@"Enter cardholder phone number"
                                         preferredStyle:UIAlertControllerStyleAlert];
    [alertontroller addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeEmailAddress;
        textField.placeholder = @"Phone number";
        textField.accessibilityLabel = @"vc_merchantapi_phone";
        phoneTextField = textField;
    }];
    [alertontroller addAction:okAction];
    [self presentViewController:alertontroller animated:YES completion:nil];
    
    
}

- (void)getSecurityQuestions {
    [self showProgressMessage:@"Getting security questions" andIsTransactionStoppable:NO];
    [[Ingenico sharedInstance].User getSecurityQuestions:^(NSArray *questions, NSError *error) {
        [self dismissProgress];
        if (error == nil) {
            [LogHelper.sharedInstance consoleLog:[self getStringFromSecurityQuestionsArray:questions]];
        } else {
            [LogHelper.sharedInstance consoleLog:[[NSString alloc]
                              initWithFormat:@"Get Security Questions failed "
                              @"with error code : %ld\n",
                              (long)error.code]];
        }
    }];
}

- (void)setSecurityQuestions {
    [self performSegueWithIdentifier:@"segue_to_security_questions" sender:self];
}

- (void)sendEmailReceipt {
    if([self getLastTransactionID] == nil){
        [self showErrorMessage:@"Please perform a transaction first" andErrorTitle:@"Error"];
    }
    else{
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
            [self showProgressMessage:@"Sending email receipt request" andIsTransactionStoppable:NO];
            [[Ingenico sharedInstance].User
             sendEmailReceipt:[self getLastTransactionID]
             andEmailAddress:userEmailTextField&&userEmailTextField.text?userEmailTextField.text:nil
             andOnDone:^(NSError *error) {
                 [self dismissProgress];
                 if (error == nil) {
                     [LogHelper.sharedInstance consoleLog:@"Send Email Receipt succeeded"];
                 } else {
                     [LogHelper.sharedInstance consoleLog:[[NSString alloc]
                                  initWithFormat:@"Send Email Receipt failed with error code : %ld",
                                  (long)error.code]];
                 }
             }];
        }];
        [self promptForEmailAddress:okAction isOptional:true];
    }
}

- (void)promptForEmailAddress:(UIAlertAction *)action isOptional:(BOOL)isOpetional{
    UIAlertController *alertontroller = [UIAlertController
                                         alertControllerWithTitle:@"Email Address"
                                         message:nil
                                         preferredStyle:UIAlertControllerStyleAlert];
    [alertontroller addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeEmailAddress;
        if(isOpetional){
            textField.placeholder = @"Email Address (optional)";
        }
        else{
            textField.placeholder = @"Email Address";
        }
        textField.accessibilityLabel = @"vc_merchantapi_email_address";
        userEmailTextField = textField;
    }];
    [alertontroller addAction:action];
    [self presentViewController:alertontroller animated:YES completion:nil];
}

- (void)getTransactionDetails {
    if([self getLastTransactionID] == nil){
        [self showErrorMessage:@"Please perform a transaction first" andErrorTitle:@"Error"];
    }
    else{
        [self showProgressMessage:@"Getting transaction detail" andIsTransactionStoppable:NO];
        [[Ingenico sharedInstance].User
         getTransactionDetailsWithTransactionID:[self getLastTransactionID]
         andOnDone:^(IMSTransactionHistoryDetail *transaction, NSError *error){
             [self dismissProgress];
             if(error == nil) {
                 [LogHelper.sharedInstance consoleLog:@"Get Transaction Details Succeeded"];
                 [LogHelper.sharedInstance consoleLog:transaction.description];
#ifndef APPIUM
                 TransactionDetailViewController *controller = (TransactionDetailViewController *)[self.storyboard instantiateViewControllerWithIdentifier:@"transactionDetailVC"] ;
                 controller.transactionDetail = transaction;
                 [self.navigationController pushViewController:controller animated:NO];
#endif
             }else{
                 [LogHelper.sharedInstance consoleLog:[[NSString alloc]
                                   initWithFormat:@"Get Transaction Details failed with error code : %ld",
                                   (long)error.code]];
             }
         }];
    }
}

- (void)filterInvoiceHistory{
    HistoryFilterViewController *historyVC = [self.storyboard instantiateViewControllerWithIdentifier:@"historyFilterVC"];
    historyVC.callback = ^(IMSHistoryQueryBuilder *builder) {
        [self.navigationController popViewControllerAnimated:NO];
        if(builder){
            [self showProgressMessage:@"Getting invoice history" andIsTransactionStoppable:NO];
            [[Ingenico sharedInstance].User getInvoiceHistoryWithQuery:[builder createQueryCriteria] andOnDone:^(NSArray *invoiceList, int totalMatches, NSError *error) {
                [self dismissProgress];
                if(error == nil) {
                    [LogHelper.sharedInstance consoleLog:[[NSString alloc]initWithFormat:@"Get Invoice History Succeeded with totalMatches: %d and %lu invoices returned",totalMatches, (unsigned long)(invoiceList?[invoiceList count]:0)]];
                    for(IMSInvoiceHistorySummary *summary in invoiceList){
                        [LogHelper.sharedInstance consoleLog:summary.description];
                    }
#ifndef APPIUM
                    TransactionHistoryListViewController *listVC = [self.storyboard instantiateViewControllerWithIdentifier:@"historyListVC"];
                    listVC.historyList = invoiceList;
                    listVC.isInvoiceBased = true;
                    [self.parentViewController.navigationController pushViewController:listVC animated:YES];
#endif
                }else{
                    [LogHelper.sharedInstance consoleLog:[[NSString alloc]
                                                                                   initWithFormat:@"Get Invoice History failed with error code : %ld",
                                                                                   (long)error.code]];
                }
            }];
        }
        else{
            [self showProgressMessage:@"Get Invoice History Failed" andIsSuccess:NO];
        }
    };
    [self.parentViewController.navigationController pushViewController:historyVC animated:YES];
}

-(void) getTransactionSummary {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Get transaction summary" message:@"Enter start date and end date:" preferredStyle:UIAlertControllerStyleAlert];
    UIBarButtonItem *space=[[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        [textField setPlaceholder:@"Start date"];
        textField.inputView = datePicker;
        UIToolbar *startDateToolBar=[[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 44)];
        [startDateToolBar setTintColor:[UIColor grayColor]];
        [startDateToolBar setItems:[NSArray arrayWithObjects:space,[[UIBarButtonItem alloc]initWithTitle:@"Done" style:UIBarButtonItemStylePlain target:self action:@selector(confirmStartDate)], nil]];
        textField.inputAccessoryView = startDateToolBar;
        textField.accessibilityLabel = @"vc_merchantapi_start_date";
        startDateTextField = textField;
        [startDateTextField setText:[self getUTCFormatDateString:[NSDate date]]];
    }];
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        [textField setPlaceholder:@"End date"];
        textField.inputView = datePicker;
        UIToolbar *endDateToolBar=[[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 44)];
        [endDateToolBar setTintColor:[UIColor grayColor]];
        [endDateToolBar setItems:[NSArray arrayWithObjects:space,[[UIBarButtonItem alloc]initWithTitle:@"Done" style:UIBarButtonItemStylePlain target:self action:@selector(confirmEndDate)], nil]];
        textField.inputAccessoryView = endDateToolBar;
        textField.accessibilityLabel = @"vc_merchantapi_end_date";
        endDateTextField = textField;
        [endDateTextField setText:[self getUTCFormatDateString:[NSDate date]]];
    }];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self showProgressMessage:@"Getting transaction summary" andIsTransactionStoppable:NO];
        [Ingenico.sharedInstance.User getTransactionsSummary:startDateTextField.text andEndDate:endDateTextField.text andOnDone:^(IMSTransactionsSummary * _Nullable transactionsSummary, NSError * _Nullable error) {
            if(error == nil) {
                NSString *result = [[NSString alloc] initWithFormat:@"Transation Summary:\nTotal number of transactions: %ld,\nNet Amount: %ld", transactionsSummary.totalNumberOfTransactions,transactionsSummary.netTransactionAmount];
                [LogHelper.sharedInstance consoleLog:result];
                [self dismissProgress];
                [self showProgressMessage:result andIsSuccess:YES];
            }else{
                [LogHelper.sharedInstance consoleLog:[[NSString alloc]
                                                                               initWithFormat:@"Get Transaction History failed with error code : %ld",
                                                                               (long)error.code]];
            }
        }];
    }];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
    }];
    [alert addAction:okAction];
    [alert addAction:cancelAction];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)filterTransactionHistory{
    HistoryFilterViewController *historyVC = [self.storyboard instantiateViewControllerWithIdentifier:@"historyFilterVC"];
    historyVC.callback = ^(IMSHistoryQueryBuilder *builder) {
        [self.navigationController popViewControllerAnimated:NO];
        if(builder){
            [self showProgressMessage:@"Getting transaction history" andIsTransactionStoppable:NO];
            [[Ingenico sharedInstance].User getTransactionHistoryWithQuery:[builder createQueryCriteria] andOnDone:^(NSArray *transactionList, int totalMatches, NSError *error) {
                [self dismissProgress];
                if(error == nil) {
                    [LogHelper.sharedInstance consoleLog:[[NSString alloc]initWithFormat:@"Get Transaction History Succeeded with totalMatches: %d and %lu transactions returned",totalMatches, (unsigned long)(transactionList?[transactionList count]:0)]];
                    for(IMSTransactionHistorySummary *summary in transactionList){
                        [LogHelper.sharedInstance consoleLog:summary.description];
                    }
#ifndef APPIUM
                    TransactionHistoryListViewController *listVC = [self.storyboard instantiateViewControllerWithIdentifier:@"historyListVC"];
                    listVC.historyList = transactionList;
                    listVC.isInvoiceBased = false;
                    [self.parentViewController.navigationController pushViewController:listVC animated:YES];
#endif
                }else{
                    [LogHelper.sharedInstance consoleLog:[[NSString alloc]
                                                                                   initWithFormat:@"Get Transaction History failed with error code : %ld",
                                                                                   (long)error.code]];
                }
            }];
        }
        else{
            [self showProgressMessage:@"Get Transaction History Failed" andIsSuccess:NO];
        }
    };
    [self.parentViewController.navigationController pushViewController:historyVC animated:YES];
}

- (void)uploadSignature{
    [self showProgressMessage:@"Uploading signature..." andIsTransactionStoppable:NO];
    NSString *encodedString = [UIImagePNGRepresentation([UIImage imageNamed:@"signature.png"])
                               base64EncodedStringWithOptions:NSDataBase64EncodingEndLineWithLineFeed];
    [[Ingenico sharedInstance].User uploadSignatureForTransactionWithId:[self getLastTransactionID] andSignature:encodedString andOnDone:^(NSError *error) {
        [self dismissProgress];
        if(error == nil) {
            [LogHelper.sharedInstance consoleLog:@"uploadSignature success"];
        }else{
            [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"uploadSignature failed with error code :%ld",(long)error.code]];
        }
    }];
}

- (void)refreshUserSession{
    [self showProgressMessage:@"Refreshing user session..." andIsTransactionStoppable:NO];
    [[Ingenico sharedInstance].User refreshUserSession:^(IMSUserProfile *user, NSError *error) {
        [self dismissProgress];
        if(error == nil) {
            [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Refreshing user session succeeded with new expireTime: %@", user.session.expiresTime]];
        }else{
            [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Refreshing user session failed with error code :%ld",(long)error.code]];
        }
    }];
}

- (void)acceptTermsAndConditions{
    [self showProgressMessage:@"Accepting Terms And Conditions..." andIsTransactionStoppable:NO];
    [[Ingenico sharedInstance].User acceptTermsAndConditions:^(NSError *error) {
        [self dismissProgress];
        if (error == nil) {
            [LogHelper.sharedInstance consoleLog:@"Accept Terms and Conditions success"];
        } else{
            [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Accept Terms and Conditions failed with error code :%ld",(long)error.code]];
        }
    }];
}

- (void)getProcessorInfo {
    [self showProgressMessage:@"Getting processor info" andIsTransactionStoppable:NO];
    [[Ingenico sharedInstance].User getProcessorInfo:^(IMSProcessorInfo *processorInfo, NSError *error) {
        [self dismissProgress];
        if (error == nil) {
            [LogHelper.sharedInstance consoleLog:processorInfo.description];
        } else {
            [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Get Processor Info failed with error code : %ld",
                                                                           (long)error.code]];
        }
    }];
}

- (void)showTransactionFilterAlertControllerWithAction:(UIAlertAction *)action{
    UIAlertController *alertontroller = [UIAlertController
                                         alertControllerWithTitle:@"Filter By"
                                         message:nil
                                         preferredStyle:UIAlertControllerStyleAlert];
    [alertontroller addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeDefault;
        textField.placeholder = @"Clerk ID (max 4 alphanumeric chars)";
        textField.accessibilityLabel = @"vc_merchantapi_clerk_id";
        clerkIdTextField = textField;
    }];
    [alertontroller addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeDefault;
        textField.placeholder = @"Invoice ID";
        textField.accessibilityLabel = @"vc_merchantapi_invoice_id";
        invoiceIdTextField = textField;
    }];
    [alertontroller addAction:action];
    [self presentViewController:alertontroller animated:YES completion:nil];

}

- (void)showErrorMessage:(NSString *)errorMessage andErrorTitle:(NSString *)errorTitle{
    UIAlertController *controller = [UIAlertController alertControllerWithTitle:errorTitle message:errorMessage preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
    [controller addAction:action];
    [self presentViewController:controller animated:YES completion:nil];
}

- (void)showWrongClerkIdAlert{
    UIAlertController *controller = [UIAlertController alertControllerWithTitle:@"Error" message:@"ClerkID is up-to 4 alphanumerics" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
    [controller addAction:action];
    [self presentViewController:controller animated:YES completion:nil];
}

#pragma mark TableViewDelegate Implementation

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.bounds.size.width, 35)];
    UILabel *sectionLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 0, tableView.bounds.size.width-20, 35)];
    sectionLabel.text = [sectionTitleArray objectAtIndex:section];
    sectionLabel.font = [UIFont fontWithName:@"Palatino-Italic" size:16];
    [headerView setBackgroundColor:[UIColor lightGrayColor]];
    [headerView addSubview:sectionLabel];
    return headerView;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return merchantAPIArray.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [[merchantAPIArray objectAtIndex:section] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *CellIdentifier = @"PaymentAPICell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    cell.textLabel.text = [[merchantAPIArray objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    cell.textLabel.textColor = [UIColor darkGrayColor];
    cell.textLabel.font = [UIFont fontWithName:@"Palatino" size:14];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    [cell setAccessibilityLabel:[NSString stringWithFormat:@"vc_merchantapi_section_%d_row_%d", (int)indexPath.section, (int)indexPath.row]];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if(indexPath.section == 0){
        if(indexPath.row == 0){
            [self setEmail];
        }
        else if(indexPath.row == 1){
            [self sendEmailReceipt];
        }
    }
    else if(indexPath.section == 1){
        if(indexPath.row == 0){
            [self getSecurityQuestions];
        }
        else if(indexPath.row == 1){
            [self setSecurityQuestions];
        }
    }
    else if(indexPath.section == 2){
        if(indexPath.row == 0){
            [self getEmailReceiptInfo];
        }
        else if(indexPath.row == 1){
            [self setEmailReceiptInfo];
        }
        else if(indexPath.row ==2) {
            [self getProcessorInfo];
        }
    }
    else if(indexPath.section == 3){
        if(indexPath.row == 0){
            [self changePW];
        }
        else if(indexPath.row == 1){
            [self forgotPassword];
        }
    }
    else if(indexPath.section == 4){
        if(indexPath.row == 0){
            [self getTransactionDetails];
        }
        else if(indexPath.row == 1){
            [self filterTransactionHistory];
        }
        else if(indexPath.row == 2){
            [self filterInvoiceHistory];
        }
        else if (indexPath.row == 3) {
            [self getTransactionSummary];
        }
    }
    else if(indexPath.section == 5){
        if(indexPath.row == 0){
            [self uploadSignature];
        }
        else if(indexPath.row == 1){
            [self updateTransaction];
        }
    }
    else if(indexPath.section == 6){
        if(indexPath.row == 0){
            [self refreshUserSession];
        }
        else if(indexPath.row == 1){
            [self acceptTermsAndConditions];
        }
    }
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}

#pragma Helper Methods

- (NSString *)getStringFromSecurityQuestionsArray:(NSArray *)questions {
    NSMutableString *string = [[NSMutableString alloc] init];
    [string appendString:@"Get Security Questions Succeeded\n"];
    for (IMSSecurityQuestion *question in questions) {
        if (question.questionId) {
            [string appendString:[[NSString alloc] initWithFormat:@" Id: %@\n",
                                  [NSString stringWithFormat:@"%ld",(long)question.questionId]]];
        }
        if (question.question) {
            [string appendString:[[NSString alloc] initWithFormat:@" Question: %@\n",
                                  question.question]];
        }
    }
    return string;
}

#pragma Helper Methods

- (void)confirmStartDate{
    [startDateTextField setText:[self getUTCFormatDateString:[datePicker date]]];
}

- (void)confirmEndDate{
    [endDateTextField setText:[self getUTCFormatDateString:[datePicker date]]];
}

-(NSString *)getUTCFormatDateString:(NSDate *)localDate
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    NSTimeZone *timeZone = [NSTimeZone timeZoneWithName:@"UTC"];
    [dateFormatter setTimeZone:timeZone];
    [dateFormatter setDateFormat:@"yyyyMMdd"];
    NSString *dateString = [dateFormatter stringFromDate:localDate];
    return dateString;
}
@end
