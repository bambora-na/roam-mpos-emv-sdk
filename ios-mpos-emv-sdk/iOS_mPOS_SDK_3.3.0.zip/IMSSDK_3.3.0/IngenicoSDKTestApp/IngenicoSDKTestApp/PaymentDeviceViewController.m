//
//  PaymentAPIViewController.m
//  IngenicoSDKTestApp
//
//  Copyright © 2016 RoamData. All rights reserved.
//
#import "PaymentDeviceViewController.h"
#import "TabBarViewController.h"
#import "ConfigureBeepsFilterViewController.h"

@interface PaymentDeviceViewController ()<UITableViewDelegate, UITableViewDataSource>{
    NSArray *firmwareAPIArray;
    NSArray *setupAPIArray;
    NSArray *otherAPIArray;
    NSArray *paymentDeviceArray;
    NSArray *sectionTitleArray;
}

@end

@implementation PaymentDeviceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    firmwareAPIArray = [[NSArray alloc] initWithObjects:
                        @"* Check firmware update",
                        @"* Firmware update",
                        @"* Firmware Info", nil];
    setupAPIArray = [[NSArray alloc] initWithObjects:
                        @"* Check device setup",
                        @"* Device setup", nil];
    otherAPIArray = [[NSArray alloc] initWithObjects:
                        @"* Get battery level",
                        @"* Get allowed pos entry mode",
                        @"* Get communication type",
                        @"* Configure beeps",
                        @"* Read magnetic card data",
                        @"* Configure idle shutdown timeout",
                        @"* Get Device Serial Number",
					 	@"* Display Text",
					 	@"* Show Home Screen",
                        @"* Configure Application Selection",
                        @"* Retrieve tip amount",
                        @"* Reset device",
                        @"* Read magnetic card data with amount",
                        @"* Get battery level with charging status",
                        @"* Menu selection",
                        @"* Enable device logging",
                        @"* Disable device logging",
                        @"* Retrieve log",
                        @"* Select E2E Key",
                        @"* Get card details",
                        @"* Set VAS Merchant",
                        @"* Update Working Key",
                        @"* Set Brightness Level",
                        nil];
    sectionTitleArray = [[NSArray alloc] initWithObjects:
                         @"Firmware update API",
                         @"Setup API",
                         @"Other API",nil];
    paymentDeviceArray = [[NSArray alloc] initWithObjects:
                          firmwareAPIArray,
                          setupAPIArray,
                          otherAPIArray, nil];
    _paymentDeviceTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    _paymentDeviceTableView.tableHeaderView = [[UIView alloc] initWithFrame:CGRectZero];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [(TabBarViewController *)self.parentViewController setCurrentVisibleChildViewController:self];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    _paymentDeviceTableView.frame = CGRectMake(0, _paymentDeviceTableView.frame.origin.y-([UIApplication sharedApplication].statusBarFrame.size.height+self.parentViewController.navigationController.navigationBar.frame.size.height), _paymentDeviceTableView.frame.size.width, _paymentDeviceTableView.frame.size.height+[UIApplication sharedApplication].statusBarFrame.size.height+self.parentViewController.navigationController.navigationBar.frame.size.height);
}

- (void)setupDevice{
    if(![self isDeviceConnected]){
        [self showDeviceNotConnectedErrorMessage];
    }
    else{
        [self showProgressMessage:@"Setting up device..." andIsTransactionStoppable:NO];
        [[Ingenico sharedInstance].PaymentDevice setupWithProgressHandler:^(NSInteger current, NSInteger total) {
            float progress = (float)current/total;
            [self showProgressPercent:progress andMessage:@"Setting up device..." andIsFirmwareUpdate:false];
        } andOnDone:^(NSError *error) {
            [self dismissProgress];
            if(!error){
                [LogHelper.sharedInstance consoleLog:@"Setup completed"];
            }
            else{
                [LogHelper.sharedInstance consoleLog:@"Setup failed"];
            }
        }];
    }
}

- (void)checkFirmwareUpdate{
    if(![self isDeviceConnected]){
        [self showDeviceNotConnectedErrorMessage];
    }
    else{
        [self showProgressMessage:@"Checking firmware update!" andIsTransactionStoppable:NO];
        [[Ingenico sharedInstance].PaymentDevice checkFirmwareUpdate:^(NSError *error, IMSFirmwareUpdateAction action, IMSFirmwareInfo *firmwareInfo) {
            [self dismissProgress];
            if(!error){
                [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Checking firmware update succeeded : %@Firmware update action: %@",[self getStringFromFirmwreInfo:firmwareInfo],[self getStringFromIMSFirmwareUpdateAction:action]]];
            }
            else{
                [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Checking firmware update failed with %ld",(long)error.code]];
            }
        }];
    }
}

- (void)checkDeviceSetup{
    if(![self isDeviceConnected]){
        [self showDeviceNotConnectedErrorMessage];
    }
    else{
        [self showProgressMessage:@"Checking device setup" andIsTransactionStoppable:NO];
        [[Ingenico sharedInstance].PaymentDevice checkDeviceSetup:^(NSError *error,bool isSetupRequired){
            [self dismissProgress];
            if(!error){
                [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Check device setup required : %@",isSetupRequired?@"Yes":@"No"]];
                if(!isSetupRequired && ![[Ingenico sharedInstance] getCurrentCapabilities].isEMVConfigUptoDate){
                    [LogHelper.sharedInstance consoleLog:@"Device set up is recommendd"];
                }
            }
            else{
                [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Checking device setup failed with %ld",(long)error.code]];
            }
        }];
    }
}

- (void)doFirmwareUpdate{
    if(![self isDeviceConnected]){
        [self showDeviceNotConnectedErrorMessage];
    }
    else{
        [self showProgressMessage:@"Updating device firmware" andIsTransactionStoppable:NO];
        [[Ingenico sharedInstance].PaymentDevice updateFirmwareWithDownloadProgress:^(long downloadedSize, long totalFileSize) {
            [self showProgressPercent:downloadedSize/(float)totalFileSize andMessage:@"Downloading firmware..." andIsFirmwareUpdate:false];
        } andFirmwareUpdateProgress:^(NSInteger current, NSInteger total) {
            [self showProgressPercent:current/(float)total andMessage:@"Updating firmware..." andIsFirmwareUpdate:true];
        } andOnDone:^(NSError *error) {
            [self dismissProgress];
            if(!error){
                [LogHelper.sharedInstance consoleLog:@"Update device firmware succeeded"];
            }
            else{
                [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Update device firmware failed with %ld",(long)error.code]];
            }
        }];
    }
}

- (void)getBatteryLevel{
    if(![self isDeviceConnected]){
        [self showDeviceNotConnectedErrorMessage];
    }
    else{
        [self showProgressMessage:@"Getting battery level!" andIsTransactionStoppable:NO];
        [[Ingenico sharedInstance].PaymentDevice getDeviceBatteryLevel:^(NSInteger batteryLevel, NSError *error) {
            [self dismissProgress];
            if(!error){
                [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Get battery level : %ld",(long)batteryLevel]];
            }
            else{
                [LogHelper.sharedInstance consoleLog:@"Get battery level failed"];
            }
        }];
    }
}

- (void)getBatteryLevelWithChargingStatus{
    if(![self isDeviceConnected]){
        [self showDeviceNotConnectedErrorMessage];
    }
    else{
        [self showProgressMessage:@"Getting battery level with charging status!" andIsTransactionStoppable:NO];
        [[Ingenico sharedInstance].PaymentDevice getDeviceBatteryLevelWithChargingStatus:^(NSInteger batteryLevel, bool isCharging, NSError *error) {
            [self dismissProgress];
            if(!error){
                [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Get battery level : %ld and is charging: %s",(long)batteryLevel, (isCharging == YES ? "true" : "false")]];
            }
            else{
                [LogHelper.sharedInstance consoleLog:[NSString stringWithFormat:@"Get battery level with charging status failed: %ld", error.code]];
            }
        }];
    }
}

- (void)retrieveTipAmount {
    if(![self isDeviceConnected]){
        [self showDeviceNotConnectedErrorMessage];
    }
    else{
        [self showProgressMessage:@"Retrieveing tip amount" andIsTransactionStoppable:NO];
        [[Ingenico sharedInstance].PaymentDevice retrieveTipAmount:^(NSError * _Nullable error, NSInteger tipAmount) {
            [self dismissProgress];
            if(!error){
                [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Tip Amount entered : %ld",(long)tipAmount]];
            }
            else{
                [LogHelper.sharedInstance consoleLog:[NSString stringWithFormat:@"Retrieve tip amount failed: %ld", error.code]];
            }
        }];
    }
}
- (void)readMagneticCardData{
    [self showProgressMessage:@"Getting magnetic card data..." withStopBlock:^{
        [[Ingenico sharedInstance].PaymentDevice abortReadMagneticCardData];
        [self dismissProgress];
    }];
    [[Ingenico sharedInstance].PaymentDevice readMagneticCardData:^(NSString * _Nullable decryptedTrackData, NSError * _Nullable error) {
        [self dismissProgress];
        if (error == nil) {
            [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Read magnetic card data succeed with decryptedTrackData %@",decryptedTrackData]];
        }else{
            [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Read magnetic card data failed with %@", [self getResponseCodeString:error.code]]];
        }
    }];
}

-(void)readMagneticCardDataWithAmountDisplay{
    __block UITextField *totalTF;
    __block UITextField *subtotalTF;
    __block UITextField *tipTF;
    __block UITextField *discountTF;
    __block UITextField *taxTF;
    __block UITextField *surchargeTF;
    __block UITextField *currencyTF;
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        [self showProgressMessage:@"Getting magnetic card data..." withStopBlock:^{
            [[Ingenico sharedInstance].PaymentDevice abortReadMagneticCardData];
            [self dismissProgress];
        }];
        IMSAmount *amount = [[IMSAmount alloc] initWithTotal:[totalTF.text integerValue] andSubtotal:[subtotalTF.text integerValue]  andTax:[taxTF.text integerValue] andDiscount:[discountTF.text integerValue] andDiscountDescription:nil andTip:[tipTF.text integerValue] andCurrency:currencyTF.text];
        [[Ingenico sharedInstance].PaymentDevice readMagneticCardDataWithAmountDisplay:amount andOnDone:^(NSString * _Nullable decryptedTrackData, NSError * _Nullable error) {
            [self dismissProgress];
            if (error == nil) {
                [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Read magnetic card data succeed with decryptedTrackData %@",decryptedTrackData]];
            }else{
                [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Read magnetic card data failed with %@", [self getResponseCodeString:error.code]]];
            }
        }];
    }];
    UIAlertController *alertController = [UIAlertController
                                         alertControllerWithTitle:@"Read magnetic card data"
                                         message:@"Enter amount"
                                         preferredStyle:UIAlertControllerStyleAlert];
    
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeDefault;
        textField.placeholder = @"Currency";
        textField.text = @"USD";
        currencyTF = textField;
    }];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeNumberPad;
        textField.placeholder = @"Normalized Total";
        totalTF = textField;
    }];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeNumberPad;
        textField.placeholder = @"Normalized Subtotal";
        subtotalTF = textField;
    }];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeNumberPad;
        textField.placeholder = @"Normalized Tip(optional)";
        tipTF = textField;
    }];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeNumberPad;
        textField.placeholder = @"Normalized Discount(optional)";
        discountTF = textField;
    }];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeNumberPad;
        textField.placeholder = @"Normalized Tax(optional)";
        taxTF = textField;
    }];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeNumberPad;
        textField.placeholder = @"Normalized Surcharge(optional)";
        surchargeTF = textField;
    }];
    [alertController addAction:okAction];
    [self presentViewController:alertController animated:YES completion:nil];
}

- (void)getAllowedPosEntryModes{
    if(![self isDeviceConnected]){
        [self showDeviceNotConnectedErrorMessage];
    }
    else{
        NSArray *posList = [[Ingenico sharedInstance].PaymentDevice allowedPOSEntryModes];
        [LogHelper.sharedInstance consoleLog:[NSString stringWithFormat:@"  Allowed POS Entry Modes:\n%@\n",
                          [self getPosEntryModeString:posList]]];
    }
}

- (void)getCommunicationType{
    if(![self isDeviceConnected]){
        [self showDeviceNotConnectedErrorMessage];
    }
    else{
        RUACommunicationInterface cType = [[Ingenico sharedInstance].PaymentDevice getActiveCommunicationType];
        [LogHelper.sharedInstance consoleLog:[NSString stringWithFormat:@"  Communication type:\n%@\n",
                          [self getCommunicationString:cType]]];
    }
}

- (void)configureBeeps{
    if(![self isDeviceConnected]){
        [self showDeviceNotConnectedErrorMessage];
    }
    else{
        ConfigureBeepsFilterViewController *configureVC = [self.storyboard instantiateViewControllerWithIdentifier:@"configureBeepVC"];
        configureVC.callback = ^(bool disableCardRemovalBeep,bool disableEMVStartTransactionBeep) {
            [self.navigationController popViewControllerAnimated:NO];
            [self showProgressMessage:@"Configuring beeps!" andIsTransactionStoppable:NO];
            [[[Ingenico sharedInstance] PaymentDevice] configureCardRemovalBeep:disableCardRemovalBeep
                                                         andCardPresentmentBeep:disableEMVStartTransactionBeep
                                                                      andOnDone:^(NSError * _Nullable error) {
                                                                          [self dismissProgress];
                                                                          if(!error){
                                                                              [LogHelper.sharedInstance consoleLog:@"Configure beep succeeded"];
                                                                          }
                                                                          else{
                                                                              [LogHelper.sharedInstance consoleLog:@"Configure beep failed"];
                                                                          }
                                                                      }];
        };
        [self.parentViewController.navigationController pushViewController:configureVC animated:YES];
    }
}

- (void)configureIdleShutdownTimeout{
    if(![self isDeviceConnected]){
        [self showDeviceNotConnectedErrorMessage];
    }
    else{
        __block UITextField *timeoutTF;
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
            [self showProgressMessage:@"Configuring idle shutdown timeout" andIsTransactionStoppable:NO];
            [[[Ingenico sharedInstance] PaymentDevice] configureIdleShutdownTimeout:[timeoutTF.text integerValue] andOnDone:^(NSError * _Nullable error) {
                [self dismissProgress];
                if(!error){
                    [LogHelper.sharedInstance consoleLog:@"Configure idle shutdown timeout succeeded"];
                }
                else{
                    [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Configure idle shutdown timeout failed with %@", [self getResponseCodeString:error.code]]];
                }
            }];
        }];
        UIAlertController *alertontroller = [UIAlertController
                                             alertControllerWithTitle:@"Enter Shutdown Timeout"
                                             message:@"Please provide timeout in seconds"
                                             preferredStyle:UIAlertControllerStyleAlert];
        [alertontroller addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeNumberPad;
            textField.placeholder = @"180 - 1800";
            timeoutTF = textField;
        }];
        [alertontroller addAction:okAction];
        [self presentViewController:alertontroller animated:YES completion:nil];
    }
}

-(void) getDeviceSerialNumber {
    if(![self isDeviceConnected]){
        [self showDeviceNotConnectedErrorMessage];
    }
    else{
        [self showProgressMessage:@"Getting Device Serial Number!" andIsTransactionStoppable:NO];
        [[Ingenico sharedInstance].PaymentDevice getDeviceSerialNumber:^(NSString * _Nullable serialNumber, NSError * _Nullable error){
            [self dismissProgress];
            if(!error){
                [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Device Serial Number: %@",serialNumber]];
            }
            else{
                [LogHelper.sharedInstance consoleLog:@"Get Device Serial Number Failed"];
            }
        }];
    }
}

-(void) displayText {
	if(![self isDeviceConnected]){
		[self showDeviceNotConnectedErrorMessage];
	}
	else{
        UIAlertController *controller = [UIAlertController alertControllerWithTitle:@"Display Text" message:@"Enter text to display" preferredStyle:UIAlertControllerStyleAlert];
        __block UITextField *displayTextTF;
        __block UITextField *rowTF;
        __block UITextField *columnTF;
        [controller addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
            [textField setPlaceholder:@"Display text"];
            [textField setKeyboardType:UIKeyboardTypeDefault];
            displayTextTF = textField;
        }];
        [controller addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
            [textField setPlaceholder:@"Row (1-4)"];
            [textField setKeyboardType:UIKeyboardTypeNumberPad];
            rowTF = textField;
        }];
        [controller addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
            [textField setPlaceholder:@"Column (1-21)"];
            [textField setKeyboardType:UIKeyboardTypeNumberPad];
            columnTF = textField;
        }];
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
        [controller addAction:cancelAction];
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            [self showProgressMessage:@"Displaying text..." andIsTransactionStoppable:NO];
            NSString *displayText = ([displayTextTF.text length] != 0) ? displayTextTF.text : @"Display text";
            NSInteger row = [rowTF.text integerValue];
            NSInteger column = [columnTF.text integerValue];
            [[Ingenico sharedInstance].PaymentDevice displayText:displayText
                                                           atRow:row
                                                       andColumn:column
                                                       andOnDone:^(NSError * _Nullable error){
                [self dismissProgress];
                if(error){
                    [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Display Text failed with %ld",(long)error.code]];
                } else {
                    [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Display text success"]];
                }
            }];
        }];
        [controller addAction:okAction];
        [self presentViewController:controller animated:YES completion:nil];
	}
}


-(void) showHomeScreen {
	if(![self isDeviceConnected]){
		[self showDeviceNotConnectedErrorMessage];
	}
	else{
		[self showProgressMessage:@"Showing home screen..." andIsTransactionStoppable:NO];
		[[Ingenico sharedInstance].PaymentDevice showHomeScreen:^(NSError * _Nullable error){
			[self dismissProgress];
			if(error){
				[LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Show home screen failed with %ld",(long)error.code]];
			} else {
				[LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Show home screen success"]];
			}
		}];
	}
}

-(void) showApplicationSelectionOption {
    if(![self isDeviceConnected]){
        [self showDeviceNotConnectedErrorMessage];
    }
    else{
        UIAlertController *optionAlert = [UIAlertController alertControllerWithTitle:nil message:@"Application Selections Options" preferredStyle:UIAlertControllerStyleActionSheet];
        UIAlertAction *pinpadAction = [UIAlertAction actionWithTitle:@"Pin Pad" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            [self configureApplicationSelection:ApplicationSelectionOptionPinPad];
        }];
        UIAlertAction *externalAction = [UIAlertAction actionWithTitle:@"External Device" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            [self configureApplicationSelection:ApplicationSelectionOptionExternalDevice];
        }];
        UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
        [optionAlert addAction:pinpadAction];
        [optionAlert addAction:externalAction];
        [optionAlert addAction:cancel];
        [self presentViewController:optionAlert animated:YES completion:nil];
    }
}

-(void) resetDevice {
    if(![self isDeviceConnected]){
        [self showDeviceNotConnectedErrorMessage];
    }
    else{
        [self showProgressMessage:@"Resetting device..." andIsTransactionStoppable:NO];
        [[Ingenico sharedInstance].PaymentDevice resetDevice:^(NSError * _Nullable error){
            [self dismissProgress];
            if(error){
                [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Reset device failed with %ld",(long)error.code]];
            } else {
                [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Reset device success"]];
            }
        }];
    }
}

-(void) configureApplicationSelection:(IMSApplicationSelectionOption) option {
    [[Ingenico sharedInstance].PaymentDevice configureApplicationSelection:option andOnDone:^(NSError * _Nullable error){
        [self dismissProgress];
        if(error){
            [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"configureApplicationSelection failed with %ld",(long)error.code]];
        } else {
            [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"configureApplicationSelection success"]];
        }
    }];
}

-(void) doGetFirmwarePackageInfo {
    [self showProgressMessage:@"getFirmwarePackageInfo..." andIsTransactionStoppable:NO];
    [Ingenico.sharedInstance.PaymentDevice getFirmwarePackageInfo:^(NSError * _Nullable error, IMSFirmwarePackageInfo * _Nullable firmwarePackageInfo) {
        [self dismissProgress];
        if (error) {
            [LogHelper.sharedInstance consoleLog:[NSString stringWithFormat:@"getFirmwarePackageInfo failed:%ld", (long)error.code]];
        }
        else {
            [LogHelper.sharedInstance consoleLog:@"getFirmwarePackageInfo success"];
        }
        [LogHelper.sharedInstance consoleLog:firmwarePackageInfo.description];
    }];
}

-(void) customMenuSelection {
    if(![self isDeviceConnected]){
        [self showDeviceNotConnectedErrorMessage];
    }
    else{
        NSMutableArray *menuOptionsArray = [[NSMutableArray alloc] init];
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Custom Menu Selection" message:@"" preferredStyle:UIAlertControllerStyleAlert];
        __block UITextField *menuOptionTF;
        [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
            [textField setPlaceholder:@"Menu Option"];
            [textField setKeyboardType:UIKeyboardTypeDefault];
            menuOptionTF = textField;
        }];
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
            [menuOptionsArray addObject:menuOptionTF.text];
            [Ingenico.sharedInstance.PaymentDevice showMenuOptions:@"Test Menu Title" andMenuOptions:menuOptionsArray andOnDone:^(NSError * _Nullable error, NSInteger menuOptionSelected) {
                if (error) {
                    [LogHelper.sharedInstance consoleLog:[NSString stringWithFormat:@"customMenuSelection failed:%ld", (long)error.code]];
                }else{
                    [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"customMenuSelection success and selected menu index is %ld", (long)menuOptionSelected]];
                }
            }];
        }];
        UIAlertAction *addMenuOptionAction = [UIAlertAction actionWithTitle:@"Add option" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
            [menuOptionsArray addObject:menuOptionTF.text];
            menuOptionTF.text = @"";
            [self presentViewController:alertController animated:YES completion:nil];
        }];
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
        [alertController addAction:okAction];
        [alertController addAction:addMenuOptionAction];
        [alertController addAction:cancelAction];
        [self presentViewController:alertController animated:YES completion:nil];
    }
}

- (void)enableDeviceLogging{
    if(![self isDeviceConnected]){
        [self showDeviceNotConnectedErrorMessage];
    }
    else{
        [[Ingenico sharedInstance].PaymentDevice enableDeviceLogging:true andOnDone:^(NSError * _Nullable error){
            [self dismissProgress];
            if(error){
                [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Enable device logging failed with %ld",(long)error.code]];
            } else {
                [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Enable device logging success"]];
            }
        }];
    }
}

- (void)disableDeviceLogging{
    if(![self isDeviceConnected]){
        [self showDeviceNotConnectedErrorMessage];
    }
    else{
        [[Ingenico sharedInstance].PaymentDevice enableDeviceLogging:false andOnDone:^(NSError * _Nullable error){
            [self dismissProgress];
            if(error){
                [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Disable device logging failed with %ld",(long)error.code]];
            } else {
                [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Disable device logging success"]];
            }
        }];
    }
}

- (void)retrieveLog{
    if(![self isDeviceConnected]){
        [self showDeviceNotConnectedErrorMessage];
    }
    else{
        [[Ingenico sharedInstance].PaymentDevice retrieveDeviceLog:^(IMSProgressMessage progressMessage, NSString * _Nullable extraMessage) {
            NSString *strMessage = [self getProgressStrFromMessage:progressMessage];
            if(strMessage){
                [self showProgressMessage:@"Retrieving logs..." andIsTransactionStoppable:NO];
                [LogHelper.sharedInstance consoleLog:[NSString stringWithFormat:@"Progress message:%@",strMessage]];
            }
        } andOnDone:^(NSError * _Nullable error, NSString * _Nullable log){
            [self dismissProgress];
            if(error){
                [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Retrieve log failed with %ld",(long)error.code]];
            } else {
                [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Retrieve log success: %@", log]];
            }
        }];
    }
}

- (void)selectE2EKey{
    __block UITextField *keyLocIdxTF;
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        [self showProgressMessage:@"Selecting E2E Key" andIsTransactionStoppable:NO];
        [[Ingenico sharedInstance].PaymentDevice selectE2EKey:[keyLocIdxTF.text integerValue] andOnDone:^(NSError * _Nullable error){
            [self dismissProgress];
            if(error){
                [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Select E2E key with %ld",(long)error.code]];
            } else {
                [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Select E2E key success"]];
            }
        }];
    }];
    UIAlertController *alertontroller = [UIAlertController
                                         alertControllerWithTitle:@"Select E2E Key"
                                         message:@"Please enter key location index"
                                         preferredStyle:UIAlertControllerStyleAlert];
    [alertontroller addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.keyboardType = UIKeyboardTypeNumberPad;
        textField.placeholder = @"1 - 20";
        keyLocIdxTF = textField;
    }];
    [alertontroller addAction:okAction];
    [self presentViewController:alertontroller animated:YES completion:nil];
}

-(void)GetCardDetails {
    [self showProgressMessage:@"Getting card details..." withStopBlock:^{
        [[Ingenico sharedInstance].PaymentDevice abortReadMagneticCardData];
        [self dismissProgress];
    }];
    [Ingenico.sharedInstance.PaymentDevice getCardDetails:^(IMSProgressMessage progressMessage, NSString * _Nullable extraMessage) {
        NSString *strMessage = [self getProgressStrFromMessage:progressMessage];
        if(strMessage){
            [self showProgressMessage:strMessage withStopBlock:^{
                [[Ingenico sharedInstance].PaymentDevice abortReadMagneticCardData];
                [self dismissProgress];
            }];
            [LogHelper.sharedInstance consoleLog:[NSString stringWithFormat:@"getCardDetails Progress message:%@",strMessage]];
        }
    } andCardDetails:^(NSError * _Nullable error, IMSCardDetails * _Nullable cardDetails) {
        [self dismissProgress];
        if (error) {
            [LogHelper.sharedInstance consoleLog:[NSString stringWithFormat:@"getCardDetails failed:%ld", (long)error.code]];
        }
        else {
            [LogHelper.sharedInstance consoleLog:@"getCardDetails success"];
        }
        [LogHelper.sharedInstance consoleLog:cardDetails.description];
    }];
}

- (void)setVasMerchant{
    [[Ingenico sharedInstance].PaymentDevice setVasMerchant:@"pass.com.ingenico.loyaltycard2" merchantURL:@"https://www.ingenico-labs.com/ws/vas/url_coffeebar.php" andOnDone:^(NSError * _Nullable error) {
        [self dismissProgress];
        if(error){
            [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"set VAS Merchant failed with %ld",(long)error.code]];
        } else {
            [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"set VAS Merchant success"]];
        }
    }];
}

- (void)updateWorkingKeys{
    [self showProgressMessage:@"Updating working keys..." andIsTransactionStoppable:NO];
    [[Ingenico sharedInstance].PaymentDevice updateWorkingKeys:^(NSError * _Nullable error) {
        [self dismissProgress];
        if(error){
            [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"updateWorkingKey failed with %ld",(long)error.code]];
        } else {
            [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"updateWorkingKeys success"]];
        }
    }];
}

- (void)setBrightnessLevel{
    if(![self isDeviceConnected]){
        [self showDeviceNotConnectedErrorMessage];
    }
    else{
        __block UITextField *brightnessLevelTF;
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
            [self showProgressMessage:@"Setting brightness level" andIsTransactionStoppable:NO];
            [[[Ingenico sharedInstance] PaymentDevice] setBrightnessLevel: [brightnessLevelTF.text integerValue] andOnDone:^(NSError * _Nullable error) {
                [self dismissProgress];
                if(!error){
                    [LogHelper.sharedInstance consoleLog:@"Set brightness level succeeded"];
                }
                else{
                    [LogHelper.sharedInstance consoleLog:[[NSString alloc] initWithFormat:@"Set brightness level failed with %@", [self getResponseCodeString:error.code]]];
                }
            }];
        }];
        UIAlertController *alertontroller = [UIAlertController
                                             alertControllerWithTitle:@"Enter Brightness Level"
                                             message:@"Please provide a brightness level between 5 and 100"
                                             preferredStyle:UIAlertControllerStyleAlert];
        [alertontroller addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            textField.keyboardType = UIKeyboardTypeNumberPad;
            textField.placeholder = @"5 - 100";
            brightnessLevelTF = textField;
        }];
        [alertontroller addAction:okAction];
        [self presentViewController:alertontroller animated:YES completion:nil];
    }
}

#pragma mark TableViewDelegate Implementation

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.bounds.size.width, 35)];
    UILabel *sectionLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 0, tableView.bounds.size.width-20, 35)];
    sectionLabel.text = [sectionTitleArray objectAtIndex:section];
    sectionLabel.font = [UIFont fontWithName:@"Palatino-Italic" size:16];
    [headerView setBackgroundColor:[UIColor lightGrayColor]];
    [headerView addSubview:sectionLabel];
    return headerView;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return paymentDeviceArray.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if(section == 0){
        //firmwareupdate api
        return firmwareAPIArray.count;
    }
    else if(section == 1){
        //setup api
        return setupAPIArray.count;
    }
    else if(section == 2){
        //other api
        return otherAPIArray.count;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *CellIdentifier = @"PaymentAPICell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    cell.textLabel.text = [[paymentDeviceArray objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    cell.textLabel.textColor = [UIColor darkGrayColor];
    cell.textLabel.font = [UIFont fontWithName:@"Palatino" size:14];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    [cell setAccessibilityLabel:[NSString stringWithFormat:@"vc_paymentdeviceapi_section_%d_row_%d", (int)indexPath.section, (int)indexPath.row]];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if(indexPath.section == 0){
        if(indexPath.row == 0){
            [self checkFirmwareUpdate];
        }
        else if(indexPath.row == 1){
            [self doFirmwareUpdate];
        }
        else if(indexPath.row == 2) {
            [self doGetFirmwarePackageInfo];
        }
    }
    else if(indexPath.section == 1){
        if(indexPath.row == 0){
            [self checkDeviceSetup];
        }
        else if(indexPath.row == 1){
            [self setupDevice];
        }
    }
    else if(indexPath.section == 2){
        if(indexPath.row == 0){
            [self getBatteryLevel];
        }
        else if(indexPath.row == 1){
            [self getAllowedPosEntryModes];
        }
        else if(indexPath.row == 2){
            [self getCommunicationType];
        }
        else if(indexPath.row == 3){
            [self configureBeeps];
        }
        else if(indexPath.row == 4){
            [self readMagneticCardData];
        }
        else if(indexPath.row == 5){
            [self configureIdleShutdownTimeout];
        }
        else if(indexPath.row == 6) {
            [self getDeviceSerialNumber];
        }
		else if(indexPath.row == 7) {
			[self displayText];
		}
		else if(indexPath.row == 8) {
			[self showHomeScreen];
		}
        else if(indexPath.row == 9) {
            [self showApplicationSelectionOption];
        }
        else if(indexPath.row == 10) {
            [self retrieveTipAmount];
        }
        else if(indexPath.row == 11) {
            [self resetDevice];
        }
        else if(indexPath.row == 12) {
            [self readMagneticCardDataWithAmountDisplay];
        }
        else if(indexPath.row == 13) {
            [self getBatteryLevelWithChargingStatus];
        }
        else if(indexPath.row == 14) {
            [self customMenuSelection];
        }
        else if(indexPath.row == 15) {
            [self enableDeviceLogging];
        }
        else if(indexPath.row == 16) {
            [self disableDeviceLogging];
        }
        else if(indexPath.row == 17) {
            [self retrieveLog];
        }
        else if(indexPath.row == 18) {
            [self selectE2EKey];
        }
        else if(indexPath.row == 19) {
            [self GetCardDetails];
        }
        else if(indexPath.row == 20) {
            [self setVasMerchant];
        }
        else if(indexPath.row == 21) {
            [self updateWorkingKeys];
        }
        else if(indexPath.row == 22) {
            [self setBrightnessLevel];
        }
    }
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}


#pragma Helper method

- (NSString *)getStringFromFirmwreInfo:(IMSFirmwareInfo *)firmwareInfo{
    if(firmwareInfo){
        return [[NSString alloc] initWithFormat:@"Firmware Info:\nProcessor profile name :%@\nProcessor profile version :%@\nFirmware description:%@\nFirmware version:%@\nFirmware file size:%ld\n",firmwareInfo.processorProfileName,firmwareInfo.processorProfileVersion,firmwareInfo.firmwareDescription,firmwareInfo.firmwareVersion,firmwareInfo.firmwareFileSize];
    }
    else{
        return nil;
    }
}

- (NSString *)getStringFromIMSFirmwareUpdateAction:(IMSFirmwareUpdateAction)action{
    switch (action) {
        case FirmwareUpdateActionRequired:
            return @"Required";
        case FirmwareUpdateActionOptional:
            return @"Optional";
        case FirmwareUpdateActionNo:
            return @"No";
        case FirmwareUpdateActionUnknown:
            return @"Unknown";
        default:
            break;
    }
}

- (void)showDeviceNotConnectedErrorMessage{
    UIAlertController *controller = [UIAlertController alertControllerWithTitle:@"Error" message:@"Please connect device first!" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
    [controller addAction:action];
    [self presentViewController:controller animated:YES completion:nil];
}

- (NSString *)getCommunicationString:(RUACommunicationInterface)type{
    switch (type) {
        case RUACommunicationInterfaceBluetooth:
            return @"Bluetooth";
        case RUACommunicationInterfaceAudioJack:
            return @"AudioJack";
        case RUACommunicationInterfaceUSB:
            return @"USB";
        default:
            return @"Unknown";
    }
}

- (NSString *)getPosEntryModeString:(NSArray *)entryModes{
    if(entryModes){
        NSMutableString *posStrig = [[NSMutableString alloc] init];
        for(NSNumber *pos in entryModes){
            switch ([pos integerValue]) {
                case POSEntryModeKeyed:
                    [posStrig appendString:@"Keyed\n"];
                    break;
                case POSEntryModeContactEMV:
                    [posStrig appendString:@"ContactEMV\n"];
                    break;
                case POSEntryModeContactlessEMV:
                    [posStrig appendString:@"ContactlessEMV\n"];
                    break;
                case POSEntryModeContactlessMSR:
                    [posStrig appendString:@"ContactlessMSR\n"];
                    break;
                case POSEntryModeMagStripe:
                    [posStrig appendString:@"MagStripe\n"];
                    break;
                default:
                    break;
            }
        }
        return posStrig;
    }
    else{
        return @"No allowed pos entry mode";
    }
}
@end
