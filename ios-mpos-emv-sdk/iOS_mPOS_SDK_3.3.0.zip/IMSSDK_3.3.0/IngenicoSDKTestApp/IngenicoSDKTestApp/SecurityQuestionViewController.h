//
//  SecurityQuestionViewController.h
//  IngenicoSDKTestApp
//
//  Created by Abhiram Dinesh on 10/19/21.
//  Copyright © 2021 RoamData. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IMSBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface SecurityQuestionViewController : IMSBaseViewController

@end

NS_ASSUME_NONNULL_END
