//
//  StoreForwardViewController.h
//  IngenicoSDKTestApp
//
//  Copyright © 2016 RoamData. All rights reserved.
//

#import "IMSBaseViewController.h"

@interface StoreForwardViewController : IMSBaseViewController

@property (weak, nonatomic) IBOutlet UITableView *storeForwardTableView;

@end
