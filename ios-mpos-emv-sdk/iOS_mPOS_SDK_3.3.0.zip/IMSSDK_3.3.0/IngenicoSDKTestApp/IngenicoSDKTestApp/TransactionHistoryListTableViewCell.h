//
//  TransactionHistoryListTableViewCell.h
//  IngenicoSDKTestApp
//
//  Created by Bin Lang on 8/9/17.
//  Copyright © 2017 RoamData. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TransactionHistoryListTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *transactionIDLabel;
@property (weak, nonatomic) IBOutlet UILabel *approvedAmountLabel;
@property (weak, nonatomic) IBOutlet UILabel *clientTransactionIDLabel;
@property (weak, nonatomic) IBOutlet UILabel *TransactionTypeLabel;
@property (weak, nonatomic) IBOutlet UILabel *payementServiceTimeStampLabel;
@property (weak, nonatomic) IBOutlet UILabel *statusLabel;
@property (weak, nonatomic) IBOutlet UILabel *posEntryModeLabel;
@property (weak, nonatomic) IBOutlet UILabel *cardTypeLabel;
@end
