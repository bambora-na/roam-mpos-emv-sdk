//
//  TransactionHistoryListViewController.h
//  IngenicoSDKTestApp
//
//  Created by Bin Lang on 8/9/17.
//  Copyright © 2017 RoamData. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IMSBaseViewController.h"

@interface TransactionHistoryListViewController : IMSBaseViewController

@property (weak, nonatomic) IBOutlet UITableView *historyTableView;
@property (strong, nonatomic) NSArray *historyList;
@property BOOL isInvoiceBased;
@end
